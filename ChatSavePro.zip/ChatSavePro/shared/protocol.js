/* ChatSavePro – GOLD-STABLE Protocol Layer (Do Not Minify) */
/* Preserves global exposure even under esbuild tree shaking */

(function () {
    try {
        const globalScope =
            typeof globalThis !== "undefined" ? globalThis :
            typeof self !== "undefined" ? self :
            typeof window !== "undefined" ? window :
            {};

        const ChatSaveProProtocol = {
            VERSION: "1.0.0",
            LAYER_PROTOCOL_VERSION: "1.0.0",
            LAYER: "Versioned Layer Transport v1.0",
            MODE: "RC-GOLD-STABLE",

            MESSAGES: Object.freeze({
                HELLO_FROM_CS: "CSPRO_CS_HELLO",
                HELLO_FROM_SW: "CSPRO_SW_HELLO",
                PROTOCOL_OK: "CSPRO_PROTOCOL_OK",
                PROTOCOL_MISMATCH: "CSPRO_PROTOCOL_MISMATCH"
            }),

            buildMessage(type, payload = {}) {
                return {
                    type,
                    protocolVersion: ChatSaveProProtocol.LAYER_PROTOCOL_VERSION,
                    payload,
                    timestamp: Date.now()
                };
            }
        };

        // Absolute-global freeze
        globalScope.ChatSaveProProtocol = ChatSaveProProtocol;
        Object.freeze(globalScope.ChatSaveProProtocol);

        // Debug (will show in BG AND CS)
        console.log("📡 ChatSaveProProtocol Loaded →", ChatSaveProProtocol);

    } catch (err) {
        console.error("❌ Protocol layer failed:", err);
    }
})();
