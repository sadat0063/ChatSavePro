const fs = require("fs");
const path = require("path");

// مسیر manifest اصلی در ریشه
const manifestPath = path.join(__dirname, "manifest.json");

// خواندن manifest اصلی پروژه
const manifestRaw = fs.readFileSync(manifestPath, "utf8");
const manifest = JSON.parse(manifestRaw);

// گرفتن نسخه فعلی
const currentVersion = manifest.version || "4.0.0";

// تبدیل به آرایه
const parts = currentVersion.split(".");
let major = parseInt(parts[0]);
let minor = parseInt(parts[1]);
let patch = parseInt(parts[2]);

// افزایش patch
patch++;

// ساخت نسخه جدید
const newVersion = `${major}.${minor}.${patch}`;
manifest.version = newVersion;

// نوشتن نسخه جدید
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

console.log("Version updated:", currentVersion, "→", newVersion);
