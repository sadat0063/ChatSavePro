/* ────────────────────────────────────────────────
   ChatSavePro - Guardian Layer (Heavyweight Systems)
   Version: 4.3-GS - Event Listener Only
   ──────────────────────────────────────────────── */

(function() {
    'use strict';

    // ==================== GUARD: PREVENT DUPLICATE BOOTSTRAP ====================
    if (window.__GUARDIAN_BOOTSTRAPPED__) {
        console.warn("Guardian already bootstrapped — skipping duplicate");
        return;
    }
    window.__GUARDIAN_BOOTSTRAPPED__ = true;

    // ==================== ANTI-DUPLICATE GUARD - Guardian Layer Only ====================
    if (window.__CHATSAVEPRO_GUARDIAN_LOADED__) {
        console.warn("🔄 Guardian already loaded → skipping");
        return;
    }
    window.__CHATSAVEPRO_GUARDIAN_LOADED__ = true;

    console.log("🛰️ [Guardian] ChatSavePro Guardian Layer v4.3-GS initializing...");

    // ==================== GUARDIAN SYSTEM VARIABLES ====================
    const platform = (() => {
        const url = (window.location.href || '').toLowerCase();
        if (url.includes('chat.openai.com') || url.includes('chatgpt.com')) return 'chatgpt';
        if (url.includes('deepseek.com')) return 'deepseek';
        if (url.includes('claude.ai')) return 'claude';
        if (url.includes('web.telegram.org')) return 'telegram';
        if (url.includes('web.whatsapp.com')) return 'whatsapp';
        if (url.includes('discord.com')) return 'discord';
        if (url.includes('messenger.com')) return 'messenger';
        return 'generic';
    })();

    const unifiedBridgeToken = crypto.randomUUID?.() || `token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const sessionId = crypto.randomUUID?.() || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // ==================== SCAN MANAGEMENT FUNCTIONS ====================
    const Guardian = {
        // ✅ NEW: Function to start Live Scan
        startLiveScan: function() {
            try {
                console.log('🚀 [Guardian] Starting Live Scan...');
                
                if (!isChromeAPIavailable()) {
                    console.warn('⚠️ [Guardian] Chrome API not available for live scan');
                    return false;
                }
                
                // Send scan request to background
                safeSendMessage({
                    action: "LIVE_SCAN_MESSAGE",
                    timestamp: Date.now(),
                    data: {
                        platform: platform,
                        url: window.location.href,
                        sessionId: sessionId,
                        type: "auto_start",
                        source: "guardian_auto_start"
                    }
                }, (response) => {
                    if (response && response.success) {
                        console.log('✅ [Guardian] Live scan started successfully');
                        telemetry.collectMetric("guardian.scan.live_started", { 
                            auto: true,
                            success: true 
                        });
                    } else {
                        console.warn('⚠️ [Guardian] Live scan response:', response);
                        telemetry.collectMetric("guardian.scan.live_started", { 
                            auto: true,
                            success: false,
                            error: response?.error 
                        });
                    }
                });
                
                return true;
                
            } catch (error) {
                console.error('❌ [Guardian] Live scan error:', error);
                telemetry.collectMetric("guardian.scan.live_started", { 
                    auto: true,
                    success: false,
                    error: error.message 
                });
                return false;
            }
        },
        
        // ✅ NEW: Function to start Deep Scan
        startDeepScan: function(options = {}) {
            try {
                console.log('🚀 [Guardian] Starting Deep Scan...', options);
                
                if (!isChromeAPIavailable()) {
                    console.warn('⚠️ [Guardian] Chrome API not available for deep scan');
                    return false;
                }
                
                // Send deep scan request to background
                safeSendMessage({
                    action: "START_DEEP_SCAN",
                    timestamp: Date.now(),
                    data: {
                        platform: platform,
                        url: window.location.href,
                        sessionId: sessionId,
                        auto: options.auto || false,
                        source: "guardian_auto_start"
                    }
                }, (response) => {
                    if (response && response.success) {
                        console.log('✅ [Guardian] Deep scan started successfully');
                        telemetry.collectMetric("guardian.scan.deep_started", { 
                            auto: options.auto || false,
                            success: true,
                            sessionId: response.sessionId 
                        });
                    } else {
                        console.warn('⚠️ [Guardian] Deep scan response:', response);
                        telemetry.collectMetric("guardian.scan.deep_started", { 
                            auto: options.auto || false,
                            success: false,
                            error: response?.error 
                        });
                    }
                });
                
                return true;
                
            } catch (error) {
                console.error('❌ [Guardian] Deep scan error:', error);
                telemetry.collectMetric("guardian.scan.deep_started", { 
                    auto: options.auto || false,
                    success: false,
                    error: error.message 
                });
                return false;
            }
        },
        
        // ✅ NEW: Properties for SCANLAYER_STATUS
        isLiveScanActive: false,
        isDeepScanActive: false
    };

    // ==================== GUARDIAN MESSAGE VALIDATOR ====================
    class GuardianMessageValidator {
        static validate(message) {
            try {
                if (!message || typeof message !== 'object') {
                    return false;
                }

                // 🔧 **FIX: Accept both type and action for compatibility**
                const action = message.action || message.type;
                if (!action || typeof action !== 'string') {
                    return false;
                }

                // Basic action format validation
                if (action.length > 100 || action.length < 1) {
                    return false;
                }

                // Security: Block dangerous patterns
                const dangerousPatterns = [
                    /eval/i, /function/i, /constructor/i, 
                    /prototype/i, /script/i, /import/i, /require/i,
                    /fetch/i, /xmlhttprequest/i, /websocket/i,
                    /localstorage/i, /indexeddb/i, /database/i
                ];

                for (const pattern of dangerousPatterns) {
                    if (pattern.test(action)) {
                        console.warn('🚫 [Guardian] Blocked potentially dangerous action:', action);
                        return false;
                    }
                }

                // 🔧 **FIX: Special validation for SCANLAYER_STATUS**
                if (action === 'SCANLAYER_STATUS' || message.type === 'SCANLAYER_STATUS') {
                    if (!message.data || typeof message.data !== 'object') {
                        console.warn('🚫 [Guardian] SCANLAYER_STATUS missing data field');
                        return false;
                    }
                }

                // Timestamp validation (if present)
                if (message.timestamp && typeof message.timestamp === 'number') {
                    const now = Date.now();
                    const messageTime = message.timestamp;
                    if (Math.abs(now - messageTime) > 300000) { // 5 minutes
                        console.warn('🚫 [Guardian] Message timestamp out of range:', action);
                        return false;
                    }
                }

                // Data sanitization check
                if (message.data && typeof message.data === 'object') {
                    const dataStr = JSON.stringify(message.data);
                    if (dataStr.length > 50000) { // 50KB max
                        console.warn('🚫 [Guardian] Message data too large:', action);
                        return false;
                    }
                }

                return true;

            } catch (error) {
                console.warn('🚫 [Guardian] Message validation error:', error);
                return false;
            }
        }

        static sanitizeData(data) {
            if (!data || typeof data !== 'object') return {};

            const sanitized = {};
            const MAX_STRING_LENGTH = 1000;
            const MAX_ARRAY_LENGTH = 50;

            for (const [key, value] of Object.entries(data)) {
                if (typeof key !== 'string' || key.length > 100) continue;

                if (typeof value === 'string') {
                    sanitized[key] = value.substring(0, MAX_STRING_LENGTH).replace(/[<>]/g, '');
                } else if (typeof value === 'number' && isFinite(value)) {
                    sanitized[key] = value;
                } else if (typeof value === 'boolean') {
                    sanitized[key] = value;
                } else if (value === null) {
                    sanitized[key] = null;
                } else if (Array.isArray(value)) {
                    sanitized[key] = value.slice(0, MAX_ARRAY_LENGTH);
                } else if (typeof value === 'object') {
                    // Recursive sanitization for nested objects (limited depth)
                    try {
                        sanitized[key] = this.sanitizeData(value);
                    } catch (e) {
                        sanitized[key] = '[Object sanitization failed]';
                    }
                }
            }

            return sanitized;
        }
    }

    // ==================== TELEMETRY ENGINE - FIXED ====================
    class TelemetryEngine {
        constructor() {
            this.queue = [];
            this.lastFlushTime = 0;
            this.autoFlushInterval = null;
            this.isActive = false;
            this.maxQueueSize = 50;
            this.metricsRegistry = new Map();
            this.init();
        }

        init() {
            this.start();
            console.log('✅ [Telemetry] Telemetry Engine initialized');
        }

        start() {
            if (this.isActive) return;
            
            this.isActive = true;
            const flushInterval = 30000 + Math.random() * 15000;
            this.autoFlushInterval = setInterval(() => {
                this.flush();
            }, flushInterval);
            
            console.log('📊 [Telemetry] Telemetry monitoring started');
        }

        stop() {
            if (this.autoFlushInterval) {
                clearInterval(this.autoFlushInterval);
                this.autoFlushInterval = null;
            }
            this.isActive = false;
            this.flush();
            console.log('📊 [Telemetry] Telemetry monitoring stopped');
        }

        collectMetric(type, payload = {}) {
            if (!this.isActive) return;

            const metric = {
                type,
                timestamp: Date.now(),
                payload: {
                    sessionId: sessionId,
                    platform: platform,
                    url: window.location.href,
                    ...payload
                }
            };

            this.queue.push(metric);
            
            this.metricsRegistry.set(type, {
                lastValue: payload,
                lastUpdated: Date.now(),
                count: (this.metricsRegistry.get(type)?.count || 0) + 1
            });

            if (this.queue.length >= this.maxQueueSize) {
                this.flush();
            }

            console.log(`📊 [Telemetry] Metric collected: ${type}`, payload);
        }

        async flush() {
            if (this.queue.length === 0 || !isChromeAPIavailable()) return;

            try {
                const metricsBatch = [...this.queue];
                this.queue = [];
                this.lastFlushTime = Date.now();

                // 🔧 **FIX: Use different action to avoid blocking**
                const telemetryReport = {
                    action: "GUARDIAN_METRICS_REPORT",
                    timestamp: Date.now(),
                    data: {
                        platform: platform,
                        sessionId: sessionId,
                        metrics: metricsBatch,
                        version: "1.0",
                        queueSize: metricsBatch.length,
                        registryStats: Object.fromEntries(this.metricsRegistry),
                        source: "guardian_telemetry"
                    }
                };

                await this.flushMetricsBatch(metricsBatch, telemetryReport);
            } catch (error) {
                console.warn('⚠️ [Telemetry] Flush error:', error);
                this.queue.unshift(...metricsBatch);
                this.queue = this.queue.slice(0, this.maxQueueSize);
            }
        }

        async flushMetricsBatch(metricsBatch, telemetryReport) {
            await new Promise((resolve) => {
                safeSendMessage(telemetryReport, (response) => {
                    try {
                        if (response && response.success) {
                            console.log(`📊 [Telemetry] Flushed ${metricsBatch.length} metrics`);
                        } else {
                            this.queue.unshift(...metricsBatch);
                            this.queue = this.queue.slice(0, this.maxQueueSize);
                        }
                    } catch (e) {
                        // silent
                    }
                    resolve();
                });
            });
        }

        collectDOMLoadTime() {
            const loadTime = performance.timing ? 
                performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart : 
                Date.now() - performance.now();
            
            this.collectMetric("guardian.performance.dom_load_time", { loadTime });
        }

        collectRenderDelay() {
            const renderDelay = performance.timing ?
                performance.timing.loadEventEnd - performance.timing.navigationStart :
                null;

            if (renderDelay) {
                this.collectMetric("guardian.performance.render_delay", { renderDelay });
            }
        }

        collectScanLatency(startTime, endTime, messageCount, selector) {
            const latency = endTime - startTime;
            this.collectMetric("guardian.scan.latency", {
                latency,
                messageCount,
                selector: selector || 'unknown',
                scanner: 'AdaptiveScanner'
            });
        }

        collectSelectorQuality(selector, success, elementsFound) {
            this.collectMetric("guardian.scan.selector_quality", {
                selector,
                success,
                elementsFound,
                score: success ? 1 : 0
            });
        }

        collectMutationCount(count) {
            this.collectMetric("guardian.performance.mutation_count", { count });
        }

        collectFallbackActivated(reason) {
            this.collectMetric("guardian.system.fallback_activated", { reason });
        }

        collectScanLayerLoadTime(loadTime, success) {
            this.collectMetric("guardian.scanlayer.load_time", { loadTime, success });
        }

        collectScanLayerFailure(error) {
            this.collectMetric("guardian.scanlayer.failure", { error: error.message });
        }

        collectPingLatency(latency, success) {
            this.collectMetric("guardian.connection.ping_latency", { latency, success });
        }

        collectResyncAttempts(attempts, success) {
            this.collectMetric("guardian.connection.resync_attempts", { attempts, success });
        }
    }

    const telemetry = new TelemetryEngine();

    // ==================== ENHANCED CHROME API CHECK ====================
    function isChromeAPIavailable() {
        try {
            return !!(chrome?.runtime?.id && 
                     typeof chrome.runtime.sendMessage === 'function' &&
                     typeof chrome.runtime.getURL === 'function');
        } catch (error) {
            console.warn("⚠️ [Guardian] Chrome API check failed");
            return false;
        }
    }

    function safeSendMessage(message, callback) {
        if (!isChromeAPIavailable()) {
            console.warn("🚫 [Guardian] Chrome APIs not available");
            if (callback) setTimeout(() => callback({ 
                success: false, 
                error: "Chrome APIs unavailable", 
                emergency: true 
            }), 10);
            return;
        }
        
        try {
            const sendStartTime = Date.now();
            
            chrome.runtime.sendMessage(message, (response) => {
                const latency = Date.now() - sendStartTime;
                
                if (chrome.runtime.lastError) {
                    console.warn("⚠️ [Guardian] Runtime error:", chrome.runtime.lastError.message);
                    if (callback) callback({ 
                        success: false, 
                        error: chrome.runtime.lastError.message, 
                        emergency: true 
                    });
                } else {
                    if (callback) callback(response);
                }
            });
        } catch (error) {
            console.error("❌ [Guardian] Message send error:", error);
            if (callback) callback({ 
                success: false, 
                error: error.message, 
                emergency: true 
            });
        }
    }

    // ==================== UNIFIED BRIDGE CONTEXT ====================
    class UnifiedBridgeContext {
        constructor() {
            this.isIsolated = true;
            this.securityToken = this.generateSecurityToken();
            this.allowedDomains = [
                'chat.openai.com', 'chatgpt.com', 'deepseek.com', 
                'claude.ai', 'web.telegram.org', 'web.whatsapp.com',
                'discord.com', 'messenger.com'
            ];
            this.mutationCount = 0;
            this.init();
        }
        
        init() {
            this.setupMutationProtection();
            console.log('✅ [Guardian] Unified Bridge Context initialized');
        }

        generateSecurityToken() {
            return `guardian_bridge_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }
        
        setupMutationProtection() {
            if (typeof MutationObserver !== 'undefined') {
                const mutationObserver = new MutationObserver((mutations) => {
                    this.mutationCount += mutations.length;
                    telemetry.collectMutationCount(this.mutationCount);
                });
                
                mutationObserver.observe(document.documentElement, {
                    attributes: true,
                    attributeFilter: ['onload', 'onerror'],
                    childList: true,
                    subtree: true
                });
            }
        }
        
        validateDomain() {
            const currentDomain = window.location.hostname;
            const isValid = this.allowedDomains.some(domain => currentDomain.includes(domain));
            telemetry.collectMetric("guardian.system.domain_validation", { domain: currentDomain, isValid });
            return isValid;
        }
    }

    const unifiedContext = new UnifiedBridgeContext();

    // ==================== QUANTUM RESYNC MANAGER - FIXED ====================
    class QuantumResyncManager {
        constructor() {
            this.resyncAttempts = 0;
            this.MAX_RESYNC_ATTEMPTS = 5;
            this.resyncInterval = null;
            this.isConnected = false;
            this.lastPingTime = 0;
            this._guardianReadySent = false;
            this._readyAnnounced = false;
        }
        
        startConnectionMonitoring() {
            if (!isChromeAPIavailable()) {
                console.log('🔁 [Guardian] Chrome APIs not available - skipping connection monitoring');
                return;
            }
            
            this.checkServiceWorkerConnection();
            
            this.resyncInterval = setInterval(() => {
                this.checkServiceWorkerConnection();
            }, 30000);
            
            console.log('🔄 [Guardian] Quantum Resync monitoring started');
        }
        
        stopConnectionMonitoring() {
            if (this.resyncInterval) {
                clearInterval(this.resyncInterval);
                this.resyncInterval = null;
            }
            this.isConnected = false;
            console.log('🔄 [Guardian] Quantum Resync monitoring stopped');
        }
        
        async checkServiceWorkerConnection() {
            try {
                if (!isChromeAPIavailable()) {
                    console.log('🔁 [Guardian] Chrome APIs not available - stopping checks');
                    this.stopConnectionMonitoring();
                    return;
                }
                
                const pingResult = await this.sendQuantumPing();
                
                if (pingResult.success) {
                    this.isConnected = true;
                    this.resyncAttempts = 0;
                    this.lastPingTime = Date.now();
                } else {
                    this.handleConnectionFailure(pingResult.error);
                }
            } catch (error) {
                console.log('🔁 [Guardian] Connection check error:', error.message);
                this.handleConnectionFailure(error.message);
            }
        }
        
        async sendQuantumPing() {
            return new Promise((resolve) => {
                if (!isChromeAPIavailable()) {
                    resolve({ success: false, error: 'Chrome APIs not available' });
                    return;
                }
                
                const timeoutId = setTimeout(() => {
                    resolve({ success: false, error: 'Ping timeout' });
                }, 5000);
                
                const pingStartTime = Date.now();
                
                safeSendMessage({ 
                    action: "QUANTUM_PING",
                    timestamp: Date.now(),
                    data: {
                        layer: "guardian",
                        url: location.href,
                        attempt: this.resyncAttempts + 1
                    }
                }, (response) => {
                    clearTimeout(timeoutId);
                    resolve({ success: true, response });
                });
            });
        }
        
        handleConnectionFailure(error) {
            this.resyncAttempts++;
            this.isConnected = false;
            
            telemetry.collectResyncAttempts(this.resyncAttempts, false);
            
            console.warn(`🔁 [Guardian] Service Worker connection issue (attempt ${this.resyncAttempts}):`, error);
            
            if (this.resyncAttempts >= this.MAX_RESYNC_ATTEMPTS) {
                console.error('🚨 [Guardian] Max resync attempts reached - stopping monitoring');
                this.stopConnectionMonitoring();
                this.activateFallbackMode();
            } else {
                const backoffDelay = Math.min(1000 * Math.pow(2, this.resyncAttempts - 1), 30000);
                setTimeout(() => this.checkServiceWorkerConnection(), backoffDelay);
            }
        }
        
        activateFallbackMode() {
            console.log('🔄 [Guardian] Activating fallback mode');
            telemetry.collectFallbackActivated("max_resync_attempts");
            initializeEmergencySystem();
        }
        
        // 🔧 **FIX: Single path announcement**
        announceReadyOnce() {
            if (this._readyAnnounced) {
                console.log('🔇 [Guardian] Already announced ready');
                return;
            }
            
            this._readyAnnounced = true;
            
            // 🔧 ارسال به Background فقط (یک مسیر واحد)
            safeSendMessage({
                action: "GUARDIAN_READY",
                timestamp: Date.now(),
                data: {
                    platform: platform,
                    url: window.location.href,
                    sessionId: sessionId,
                    version: "4.3-GS",
                    token: unifiedBridgeToken,
                    layer: "guardian",
                    domReady: document.readyState
                }
            }, (response) => {
                if (response && response.success) {
                    console.log('📢 [Guardian] Ready acknowledged by background');
                    // پس از تأیید background، به content script اطلاع بده
                    window.postMessage({
                        type: "GUARDIAN_READY_ACK",
                        source: "GUARDIAN",
                        timestamp: Date.now(),
                        platform: platform,
                        acknowledged: true
                    }, "*");
                }
            });
            
            console.log('📢 [Guardian] Ready announcement sent');
        }
    }

    const quantumResync = new QuantumResyncManager();

    // ==================== RESOURCE MANAGER - FIXED ====================
    class ResourceManager {
        constructor() {
            this.segments = new Map();
            this.cleanupCallbacks = new Set();
            this.cleanupIntervals = new Set();
            this.setupMemorySegments();
        }
        
        setupMemorySegments() {
            const segmentsConfig = {
                'CACHE': { maxSize: 100, ttl: 5 * 60 * 1000 },
                'SESSION': { maxSize: 50, ttl: 30 * 60 * 1000 },
                'SCAN_RESULTS': { maxSize: 20, ttl: 24 * 60 * 60 * 1000 },
                'TELEMETRY': { maxSize: 200, ttl: 2 * 24 * 60 * 60 * 1000 }
            };

            Object.entries(segmentsConfig).forEach(([name, config]) => {
                this.segments.set(name, {
                    data: new Map(),
                    ...config
                });
            });

            this.startCleanupIntervals();
        }

        startCleanupIntervals() {
            const intervals = [
                { segment: 'CACHE', interval: 60000 },
                { segment: 'SESSION', interval: 120000 },
                { segment: 'SCAN_RESULTS', interval: 300000 },
                { segment: 'TELEMETRY', interval: 300000 }
            ];

            intervals.forEach(({ segment, interval }) => {
                const intervalId = setInterval(() => {
                    this.cleanupSegment(segment);
                }, interval);
                
                this.cleanupIntervals.add(intervalId);
            });
        }
        
        set(segment, key, value) {
            if (!this.segments.has(segment)) {
                throw new Error(`Unknown segment: ${segment}`);
            }

            const segmentConfig = this.segments.get(segment);
            
            if (!segmentConfig.data) {
                segmentConfig.data = new Map();
            }
            
            this.cleanupSegment(segment);
            
            segmentConfig.data.set(key, {
                value,
                timestamp: Date.now()
            });
        }

        get(segment, key) {
            const segmentConfig = this.segments.get(segment);
            if (!segmentConfig || !segmentConfig.data) return null;

            const entry = segmentConfig.data.get(key);
            if (!entry) return null;

            if (Date.now() - entry.timestamp > segmentConfig.ttl) {
                segmentConfig.data.delete(key);
                return null;
            }

            return entry.value;
        }

        cleanupSegment(segmentName) {
            const segmentConfig = this.segments.get(segmentName);
            if (!segmentConfig || !segmentConfig.data) {
                console.warn('⚠️ [Guardian] Segment config or data is undefined');
                return;
            }

            const now = Date.now();
            let deletedCount = 0;

            for (const [key, entry] of segmentConfig.data.entries()) {
                if (now - entry.timestamp > segmentConfig.ttl) {
                    segmentConfig.data.delete(key);
                    deletedCount++;
                }
            }

            if (segmentConfig.data.size >= segmentConfig.maxSize) {
                const entries = Array.from(segmentConfig.data.entries());
                const toDelete = entries.slice(0, Math.floor(segmentConfig.maxSize * 0.2));
                
                toDelete.forEach(([key]) => {
                    segmentConfig.data.delete(key);
                    deletedCount++;
                });
            }

            if (deletedCount > 0) {
                console.log(`🧹 [Guardian] Cleaned ${deletedCount} entries from ${segmentName}`);
            }
        }
        
        registerResource(resource) {
            this.set('SESSION', `resource_${Date.now()}`, resource);
        }
        
        registerCleanupCallback(callback) {
            this.cleanupCallbacks.add(callback);
        }
        
        cleanup() {
            console.log('🧹 [Guardian] Starting comprehensive resource cleanup');
            
            this.cleanupIntervals.forEach(intervalId => clearInterval(intervalId));
            this.cleanupIntervals.clear();
            
            this.cleanupCallbacks.forEach(callback => {
                try {
                    callback();
                } catch (error) {
                    console.warn('⚠️ [Guardian] Cleanup callback error:', error);
                }
            });
            
            quantumResync.stopConnectionMonitoring();
            telemetry.stop();
            
            for (const [segment, config] of this.segments) {
                if (config.data) {
                    config.data.clear();
                }
            }
            
            this.segments.clear();
            this.cleanupCallbacks.clear();
            
            console.log('✅ [Guardian] Resource cleanup completed');
        }
    }

    const resourceManager = new ResourceManager();

    // ==================== EMERGENCY SYSTEM ====================
    function initializeEmergencySystem() {
        if (typeof window.chatSaveProEmergency !== 'undefined') return;
        
        console.log("🆘 [Guardian] Initializing Emergency Backup System...");
        telemetry.collectMetric("guardian.system.emergency_activated", { reason: "chrome_api_unavailable" });
        
        window.chatSaveProEmergency = {
            version: "2.0",
            isActive: true,
            
            saveConversation: function() {
                try {
                    console.log("🔍 [Guardian] Starting emergency scan...");
                    const startTime = Date.now();
                    
                    const messages = document.querySelectorAll('[class*="message"], [class*="chat"], .ds-message, [data-testid*="message"]');
                    console.log(`📝 [Guardian] Found ${messages.length} messages`);
                    
                    const conversation = [];
                    messages.forEach((msg, index) => {
                        const text = msg.innerText || msg.textContent;
                        if (text && text.trim().length > 10) {
                            conversation.push({
                                id: `emergency_${Date.now()}_${index}`,
                                content: text.substring(0, 2000),
                                timestamp: new Date().toISOString(),
                                index: index
                            });
                        }
                    });
                    
                    const saveKey = `emergency_chat_${Date.now()}`;
                    const saveData = {
                        conversation: conversation,
                        count: conversation.length,
                        url: window.location.href,
                        savedAt: new Date().toISOString(),
                        platform: platform
                    };
                    
                    localStorage.setItem(saveKey, JSON.stringify(saveData));
                    
                    telemetry.collectMetric("guardian.emergency.save", {
                        messageCount: conversation.length,
                        success: true,
                        duration: Date.now() - startTime
                    });
                    
                    console.log("💾 [Guardian] Emergency save successful");
                    alert(`✅ ${conversation.length} conversations saved!`);
                    return saveKey;
                    
                } catch (error) {
                    telemetry.collectMetric("guardian.emergency.save", {
                        success: false,
                        error: error.message
                    });
                    console.error("❌ [Guardian] Emergency save error:", error);
                    alert("❌ Save error: " + error.message);
                    return null;
                }
            },
            
            viewSaved: function() {
                const saved = [];
                for (let i = 0; i < localStorage.length; i++) {
                    const key = localStorage.key(i);
                    if (key.startsWith('emergency_chat_')) {
                        try {
                            const data = JSON.parse(localStorage.getItem(key));
                            saved.push({ key: key, ...data });
                        } catch (e) {}
                    }
                }
                return saved;
            },
            
            exportJSON: function() {
                const saved = this.viewSaved();
                const exportData = {
                    exportedAt: new Date().toISOString(),
                    totalConversations: saved.length,
                    conversations: saved
                };
                
                const jsonStr = JSON.stringify(exportData, null, 2);
                const blob = new Blob([jsonStr], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                
                const a = document.createElement('a');
                a.href = url;
                a.download = `chatsavepro_emergency_${Date.now()}.json`;
                a.click();
                
                return exportData;
            }
        };
        
        const emergencyButton = document.createElement('button');
        emergencyButton.innerHTML = '💾 Save Chat (Emergency)';
        emergencyButton.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            z-index: 10000;
            background: #ff4444;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
        `;
        
        emergencyButton.onclick = () => {
            window.chatSaveProEmergency.saveConversation();
        };
        
        document.body.appendChild(emergencyButton);
        console.log("✅ [Guardian] Emergency system activated");
    }

    // ==================== SIMPLE SCANNER (FALLBACK) ====================
    function createSimpleScanner() {
        console.log('🔄 [Guardian] Creating simple internal scanner');
        
        return {
            performAdaptiveScan: async () => {
                const startTime = Date.now();
                try {
                    // اسکن ساده DOM
                    const selectors = {
                        chatgpt: '[class*="message"]',
                        deepseek: '.ds-message',
                        claude: '[class*="message"]',
                        generic: '[class*="message"], [class*="chat"]'
                    };
                    
                    const selector = selectors[platform] || selectors.generic;
                    const elements = document.querySelectorAll(selector);
                    
                    const messages = Array.from(elements).map((el, idx) => ({
                        id: `msg_${Date.now()}_${idx}`,
                        content: el.textContent?.substring(0, 500) || '',
                        element: el.tagName,
                        index: idx
                    }));
                    
                    telemetry.collectScanLatency(startTime, Date.now(), messages.length, selector);
                    
                    return {
                        success: true,
                        messages: { elements: messages },
                        selector: selector,
                        count: messages.length,
                        timestamp: Date.now(),
                        source: "simple_scanner"
                    };
                    
                } catch (error) {
                    telemetry.collectScanLatency(startTime, Date.now(), 0, 'simple_error');
                    return {
                        success: false,
                        error: error.message,
                        timestamp: Date.now()
                    };
                }
            },
            
            destroy: () => {
                console.log('🧹 [Guardian] Simple scanner destroyed');
            },
            
            getCurrentSelectors: () => {
                return platform === 'generic' 
                    ? ['[class*="message"]', '[class*="chat"]']
                    : [platform];
            },
            
            init: async () => {
                console.log('✅ [Guardian] Simple scanner initialized');
                return true;
            }
        };
    }

    // ==================== ADAPTIVE SCANNER WRAPPER - FIXED ====================
    let adaptiveScanner = null;

    function createFallbackScanner() {
        console.log('🔄 [Guardian] Creating fallback scanner');
        telemetry.collectMetric("guardian.system.fallback_scanner_created", { reason: "adaptive_scanner_unavailable" });
        
        return createSimpleScanner();
    }

    async function initializeAdaptiveScanner() {
        const scannerStartTime = Date.now();
        
        try {
            console.log('🔄 [Guardian] Initializing Adaptive Scanner...');
            telemetry.collectMetric("guardian.scan.scanner_initialization_start", { timestamp: scannerStartTime });
            
            // 🔧 اولویت: استفاده از اسکنر موجود در صفحه (اگر تزریق شده)
            if (window.chatSaveProAdaptiveScanner) {
                console.log('🎯 [Guardian] Using existing Adaptive Scanner');
                adaptiveScanner = window.chatSaveProAdaptiveScanner;
                telemetry.collectMetric("guardian.scan.scanner_reused", {});
                return adaptiveScanner;
            }
            
            if (!isChromeAPIavailable()) {
                console.warn('⚠️ [Guardian] Chrome APIs not available - using fallback');
                telemetry.collectMetric("guardian.system.scanner_fallback", { reason: "chrome_api_unavailable" });
                return createFallbackScanner();
            }
            
            try {
                // 🔧 درخواست از background برای بارگذاری اسکنر
                const loadResult = await new Promise((resolve) => {
                    safeSendMessage({
                        action: "LOAD_ADAPTIVE_SCANNER",
                        timestamp: Date.now(),
                        data: { platform: platform }
                    }, resolve);
                });
                
                if (loadResult && loadResult.success) {
                    console.log('✅ [Guardian] Adaptive Scanner loaded via background');
                    adaptiveScanner = window.chatSaveProAdaptiveScanner;
                } else {
                    throw new Error(loadResult?.error || "Failed to load scanner");
                }
                
            } catch (error) {
                console.warn('📥 [Guardian] Scanner loading failed:', error);
                // ایجاد اسکنر ساده داخلی
                adaptiveScanner = createSimpleScanner();
            }
            
            const originalPerformScan = adaptiveScanner.performAdaptiveScan;
            if (typeof originalPerformScan === 'function') {
                adaptiveScanner.performAdaptiveScan = async function(...args) {
                    const scanStartTime = Date.now();
                    try {
                        const result = await originalPerformScan.apply(this, args);
                        const scanEndTime = Date.now();
                        
                        const messageCount = result.messages?.elements?.length || 0;
                        telemetry.collectScanLatency(scanStartTime, scanEndTime, messageCount, 'adaptive');
                        
                        if (result.success) {
                            telemetry.collectSelectorQuality('adaptive', true, messageCount);
                        } else {
                            telemetry.collectSelectorQuality('adaptive', false, 0);
                        }
                        
                        return result;
                    } catch (error) {
                        const scanEndTime = Date.now();
                        telemetry.collectScanLatency(scanStartTime, scanEndTime, 0, 'adaptive_error');
                        telemetry.collectSelectorQuality('adaptive', false, 0);
                        throw error;
                    }
                };
            }
            
            if (typeof adaptiveScanner.init === 'function') {
                await adaptiveScanner.init();
            }
            
            window.chatSaveProAdaptiveScanner = adaptiveScanner;
            
            resourceManager.registerResource(adaptiveScanner);
            resourceManager.registerCleanupCallback(() => {
                if (adaptiveScanner) {
                    telemetry.collectMetric("guardian.system.scanner_destroyed", { type: "adaptive" });
                    if (typeof adaptiveScanner.destroy === 'function') {
                        adaptiveScanner.destroy();
                    }
                    adaptiveScanner = null;
                    delete window.chatSaveProAdaptiveScanner;
                }
            });
            
            const initDuration = Date.now() - scannerStartTime;
            telemetry.collectMetric("guardian.scan.scanner_initialization_complete", { 
                success: true, 
                duration: initDuration,
                type: "adaptive"
            });
            
            console.log('✅ [Guardian] Adaptive Scanner initialized successfully');
            return adaptiveScanner;
            
        } catch (error) {
            const initDuration = Date.now() - scannerStartTime;
            telemetry.collectMetric("guardian.scan.scanner_initialization_complete", { 
                success: false, 
                duration: initDuration,
                error: error.message,
                type: "adaptive"
            });
            
            console.error('❌ [Guardian] Adaptive Scanner initialization failed:', error);
            return createFallbackScanner();
        }
    }

    // ==================== MESSAGE HANDLERS - FIXED ====================
    async function handleAdaptiveMessage(request) {
        if (!GuardianMessageValidator.validate(request)) {
            telemetry.collectMetric("guardian.error.invalid_message", { action: request.action });
            return { success: false, error: "Invalid message structure" };
        }

        const scanner = adaptiveScanner || window.chatSaveProAdaptiveScanner;
        
        if (!scanner) {
            telemetry.collectMetric("guardian.error.scanner_unavailable", { action: request.action });
            return { success: false, error: 'Adaptive scanner not available' };
        }

        switch (request.action) {
            case 'ADAPTIVE_GET_SELECTORS':
                const selectors = scanner.getCurrentSelectors ? scanner.getCurrentSelectors() : [];
                telemetry.collectMetric("guardian.adaptive.get_selectors", { selectorsCount: selectors.length });
                return { success: true, selectors, platform };
                
            case 'ADAPTIVE_PERFORM_SCAN':
                telemetry.collectMetric("guardian.adaptive.perform_scan", {});
                const results = await scanner.performAdaptiveScan();
                return { success: true, results };
                
            case 'ADAPTIVE_HEALTH_CHECK':
                telemetry.collectMetric("guardian.adaptive.health_check", {});
                return { success: true, status: 'Health check completed' };
                
            case 'SELECTOR_CONFIG_CHANGED':
                console.log('🔄 [Guardian] Received selector config update:', request.platform);
                telemetry.collectMetric("guardian.adaptive.selector_config_updated", { platform: request.platform });
                return { success: true, message: 'Update received' };
                
            default:
                telemetry.collectMetric("guardian.error.unknown_adaptive_action", { action: request.action });
                return { success: false, error: `Unknown adaptive action: ${request.action}` };
        }
    }

    function getAdaptiveScanner() {
        return adaptiveScanner || window.chatSaveProAdaptiveScanner || createSimpleScanner();
    }

    async function handleStandardMessage(request) {
        if (!GuardianMessageValidator.validate(request)) {
            telemetry.collectMetric("guardian.error.invalid_message", { action: request.action });
            return { success: false, error: "Invalid message structure" };
        }

        // 🔧 **FIX: Accept both action and type**
        const action = request.action || request.type;

        // 🔧 **FIX: Handle TELEMETRY_ACK with different action**
        if (action === "TELEMETRY_ACK" || action === "GUARDIAN_METRICS_ACK") {
            telemetry.collectMetric("guardian.system.telemetry_acknowledged", { timestamp: request.timestamp });
            return { success: true };
        }

        if (action === "CSPRO_CS_HELLO") {
            console.log('🤝 [Guardian] Received CSPRO_CS_HELLO');
            telemetry.collectMetric("guardian.system.cs_hello", {});
            return { 
                success: true, 
                status: "acknowledged",
                message: "Guardian ready",
                timestamp: Date.now()
            };
        }

        // 🔧 **FIX: Added important message handlers**
        switch (action) {
            case "HELLO_FROM_CS":
                console.log('👋 [Guardian] Hello from Content Script received');
                telemetry.collectMetric("guardian.connection.cs_hello", {});
                return {
                    success: true,
                    acknowledged: true,
                    timestamp: Date.now(),
                    message: "Guardian acknowledges CS"
                };
                
            case "SCAN_RESULT":
                console.log('💾 [Guardian] Scan result received');
                telemetry.collectMetric("guardian.scan.result_received", {
                    messageCount: request.data?.messages?.length || 0
                });
                return {
                    success: true,
                    processed: true,
                    timestamp: Date.now(),
                    message: "Scan result processed"
                };
                
            case "SCAN_NOW":
                console.log('🔍 [Guardian] Manual scan requested');
                telemetry.collectMetric("guardian.scan.manual_request", {});
                
                // اجرای اسکن فوری
                if (typeof Guardian.startLiveScan === 'function') {
                    const scanStarted = Guardian.startLiveScan();
                    return {
                        success: true,
                        scanStarted: scanStarted,
                        timestamp: Date.now(),
                        message: scanStarted ? "Live scan started" : "Failed to start scan"
                    };
                }
                return {
                    success: false,
                    error: "Scan function not available",
                    timestamp: Date.now()
                };
                
            case "GET_SYSTEM_HEALTH":
                const scanner = getAdaptiveScanner();
                telemetry.collectMetric("guardian.system.health_check", {});
                return {
                    success: true,
                    platform: platform,
                    adaptiveScanner: !!scanner,
                    telemetryQueue: telemetry.queue.length,
                    resourceSegments: Array.from(resourceManager.segments.keys()),
                    connectionStatus: quantumResync.isConnected,
                    version: "4.3-GS",
                    timestamp: Date.now(),
                    sessionId: sessionId
                };

            case "PING":
                telemetry.collectMetric("guardian.standard.ping", {});
                return {
                    success: true,
                    message: "pong",
                    from: "guardian",
                    timestamp: Date.now()
                };
                
            case "GET_STATUS":
                const currentScanner = getAdaptiveScanner();
                telemetry.collectMetric("guardian.standard.get_status", {});
                return {
                    success: true,
                    platform,
                    domReady: document.readyState,
                    url: location.href,
                    adaptiveScanner: !!currentScanner,
                    version: "4.3-GS",
                    timestamp: Date.now(),
                    sessionId: sessionId
                };
                
            case "START_DEEP_SCAN":
                telemetry.collectMetric("guardian.standard.start_deep_scan", {});
                return { 
                    success: true, 
                    message: "Deep scan started",
                    timestamp: Date.now()
                };
                
            case "STOP_DEEP_SCAN":
                telemetry.collectMetric("guardian.standard.stop_deep_scan", {});
                return { 
                    success: true, 
                    message: "Deep scan stopped",
                    timestamp: Date.now()
                };
                
            case "QUANTUM_PING":
                telemetry.collectMetric("guardian.standard.quantum_ping", {});
                return {
                    success: true,
                    message: "quantum_pong",
                    layer: "guardian",
                    timestamp: Date.now(),
                    version: "4.3-GS"
                };

            case "TEST_PING":
                telemetry.collectMetric("guardian.standard.test_ping", {});
                return {
                    success: true,
                    message: "test_pong",
                    layer: "guardian",
                    timestamp: Date.now(),
                    version: "4.3-GS"
                };

            default:
                telemetry.collectMetric("guardian.error.unknown_standard_action", { action: action });
                return {
                    success: false,
                    error: `Unknown action '${action}'`,
                    timestamp: Date.now()
                };
        }
    }

    function setupMessageListener() {
        if (!isChromeAPIavailable()) {
            console.warn('⚠️ [Guardian] Chrome APIs not available for message listener');
            return;
        }
        
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            (async () => {
                try {
                    if (!GuardianMessageValidator.validate(request)) {
                        telemetry.collectMetric("guardian.error.message_validation_failed", { 
                            action: request.action,
                            type: request.type 
                        });
                        sendResponse({ 
                            success: false, 
                            error: 'Invalid message structure',
                            timestamp: Date.now()
                        });
                        return;
                    }
                    
                    let response;

                    const action = request.action || request.type;
                    
                    if (action && action.startsWith('ADAPTIVE_')) {
                        response = await handleAdaptiveMessage(request);
                    } else {
                        response = await handleStandardMessage(request);
                    }
                    
                    sendResponse(response);
                    
                } catch (error) {
                    telemetry.collectMetric("guardian.error.message_handler", { 
                        error: error.message, 
                        action: request.action,
                        type: request.type 
                    });
                    console.error("❌ [Guardian] Message handler error:", error);
                    sendResponse({ 
                        success: false, 
                        error: error.message,
                        timestamp: Date.now()
                    });
                }
            })();
            
            return true;
        });
    }

    // ==================== FALLBACK SCANNING ====================
    async function setupFallbackScanning() {
        console.log('🔄 [Guardian] Setting up fallback scanning system');
        telemetry.collectFallbackActivated("scan_layer_failed");
        
        const basicScanner = setInterval(() => {
            const messages = document.querySelectorAll('[class*="message"], [class*="chat"]');
            if (messages.length > 0) {
                console.log(`📝 [Guardian] Found ${messages.length} message elements`);
                telemetry.collectMetric("guardian.scan.fallback_scan", { messageCount: messages.length });
            }
        }, 10000);
        
        resourceManager.registerCleanupCallback(() => {
            clearInterval(basicScanner);
            telemetry.collectMetric("guardian.system.fallback_scanner_stopped", {});
        });
        
        console.log('✅ [Guardian] Fallback scanning system activated');
    }

    // ==================== SCANLAYER STATUS FUNCTIONS - FIXED ====================
    function sendScanLayerStatus() {
        if (!isChromeAPIavailable()) {
            return;
        }
        
        try {
            // 🔧 **CRITICAL FIX: SCANLAYER_STATUS must have data field**
            const statusMessage = {
                type: 'SCANLAYER_STATUS',  // ✅ استفاده از type طبق الگوی درخواست
                data: {                    // ✅ فیلد data اجباری
                    live: Boolean(Guardian?.isLiveScanActive),
                    deep: Boolean(Guardian?.isDeepScanActive),
                    ready: true,
                    source: 'guardian',
                    ts: Date.now(),
                    platform: platform,
                    url: window.location.href,
                    sessionId: sessionId,
                    version: "4.3-GS"
                }
            };
            
            chrome.runtime.sendMessage(statusMessage, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn('⚠️ [Guardian] ScanLayer status error:', chrome.runtime.lastError.message);
                } else if (response && response.success) {
                    console.log('📊 [Guardian] ScanLayer status sent successfully');
                }
            });
            
        } catch (error) {
            console.warn('⚠️ [Guardian] ScanLayer status error:', error);
            telemetry.collectMetric("guardian.error.scanlayer_status", { error: error.message });
        }
    }
    
    function setupPeriodicStatusUpdates() {
        // ارسال اولیه status
        sendScanLayerStatus();
        
        // ارسال دوره‌ای هر 30 ثانیه
        const statusInterval = setInterval(() => {
            sendScanLayerStatus();
        }, 30000);
        
        resourceManager.registerCleanupCallback(() => {
            clearInterval(statusInterval);
        });
    }

    // ==================== SHUTDOWN HANDLERS ====================
    function setupShutdownHandlers() {
        const unloadHandler = () => {
            try {
                telemetry.collectMetric("guardian.system.unload", { reason: "page_unload" });
                
                if (adaptiveScanner) {
                    try {
                        if (typeof adaptiveScanner.destroy === 'function') {
                            adaptiveScanner.destroy();
                            console.log('🧠 [Guardian] Adaptive scanner destroyed');
                        }
                    } catch (scanErr) {
                        console.warn('⚠️ [Guardian] Adaptive scanner cleanup failed:', scanErr);
                    }
                }

                resourceManager.cleanup();

                if (isChromeAPIavailable()) {
                    safeSendMessage({
                        action: 'CONTENT_UNLOAD',
                        url: location.href,
                        platform,
                        timestamp: Date.now(),
                        sessionId: sessionId
                    });
                }
            } catch (e) {
                console.warn('🧹 [Guardian] Exception during unload cleanup:', e);
            }
        };

        window.addEventListener('beforeunload', unloadHandler);
        resourceManager.registerCleanupCallback(() => {
            window.removeEventListener('beforeunload', unloadHandler);
        });

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                telemetry.collectDOMLoadTime();
            });
        } else {
            telemetry.collectDOMLoadTime();
        }

        window.addEventListener('load', () => {
            telemetry.collectRenderDelay();
        });
    }

    // ==================== GUARDIAN INITIALIZATION - FIXED ====================
    async function initializeGuardianLayer() {
        const initStartTime = Date.now();
        
        try {
            console.log("🎯 [Guardian] Starting Guardian Layer initialization...");
            telemetry.collectMetric("guardian.system.initialization_start", { timestamp: initStartTime });

            await initializeAdaptiveScanner();
            
            // 🔧 ارسال GUARDIAN_READY یکبار
            quantumResync.announceReadyOnce();

            const isDomainValid = unifiedContext.validateDomain();
            if (!isDomainValid) {
                console.warn('🚫 [Guardian] Domain not allowed - features disabled');
                telemetry.collectMetric("guardian.system.domain_blocked", { domain: window.location.hostname });
            }

            setupMessageListener();
            setupShutdownHandlers();
            
            // 🔧 SETUP: Periodic status updates
            setupPeriodicStatusUpdates();

            quantumResync.startConnectionMonitoring();
            resourceManager.registerCleanupCallback(() => {
                quantumResync.stopConnectionMonitoring();
            });

            const initDuration = Date.now() - initStartTime;
            telemetry.collectMetric("guardian.system.initialization_complete", { 
                success: true, 
                duration: initDuration,
                domainValid: isDomainValid
            });

            console.log("🎉 [Guardian] Guardian Layer fully operational →", platform);
            
            // 🔧 AUTO-START SCAN AFTER GUARDIAN READY
            try {
                console.log('🚀 [Guardian] Auto-start Live Scan after ready');
                Guardian.startLiveScan?.();

            } catch (e) {
                console.warn('[Guardian] Auto-start scan failed', e);
                telemetry.collectMetric("guardian.error.auto_start_failed", { error: e.message });
            }

        } catch (error) {
            const initDuration = Date.now() - initStartTime;
            telemetry.collectMetric("guardian.system.initialization_complete", { 
                success: false, 
                duration: initDuration,
                error: error.message
            });
            
            console.error("❌ [Guardian] Guardian Layer initialization failed:", error);
            initializeEmergencySystem();
        }
    }

    // Start Guardian Layer initialization
    initializeGuardianLayer().catch(error => {
        console.error("❌ [Guardian] Unhandled initialization error:", error);
    });

})();