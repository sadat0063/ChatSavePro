// ============================================================
// popup.js - ChatSavePro Guardian v3.9 - CLEAN VERSION
// ============================================================

const USER_ACTIONS = {
    START_DEEP_SCAN: 'START_DEEP_SCAN',
    STOP_DEEP_SCAN: 'STOP_DEEP_SCAN',
    REQUEST_LOCAL_SCAN: 'REQUEST_LOCAL_SCAN',
    EXPORT_CONVERSATIONS: 'EXPORT_CONVERSATIONS',
    CLEAR_DATA: 'CLEAR_DATA',
    CLEANUP_CONVERSATIONS: 'CLEANUP_CONVERSATIONS',
    GET_STATS: 'GET_STATS',
    TEST_PING: 'TEST_PING',
    GET_SYSTEM_HEALTH: 'GET_SYSTEM_HEALTH',
    SAVE_CONVERSATION: 'SAVE_CONVERSATION'
};

const FEEDBACK_FLAG_KEY = 'chatSavePro_feedback_submitted';
const FEEDBACK_DATA_KEY = 'chatSavePro_feedback_data';
const FEEDBACK_ENDPOINT = "https://formspree.io/f/mojvabnl";

class ToastManager {
    constructor() {
        this.container = document.getElementById('toastContainer');
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'toastContainer';
            document.body.appendChild(this.container);
        }
    }

    show(message, type = 'success', duration = 3000) {
        const container = document.getElementById('toastContainer');
        if (!container) return;

        container.innerHTML = '';

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.setAttribute('role', 'alert');

        toast.textContent = message;

        container.appendChild(toast);

        clearTimeout(window.__TOAST_TIMER__);
        window.__TOAST_TIMER__ = setTimeout(() => {
            toast.remove();
        }, 2500);
    }

    success(message) {
        return this.show(message, 'success');
    }

    error(message) {
        return this.show(message, 'error');
    }

    info(message) {
        return this.show(message, 'info', 4000);
    }

    warning(message) {
        return this.show(message, 'warning', 4000);
    }
}

class PopupController {
    constructor() {
        this.state = {
            liveScanActive: true,
            deepScanActive: true,
            totalRecords: 0,
            connectionStatus: 'disconnected',
            selectedFormat: 'txt',
            filters: {
                timeRange: 'week',
                platform: 'all',
                startDate: null,
                endDate: null
            }
        };

        this.activeTabId = null;
        this.toast = new ToastManager();
        this.initialized = false;
        this.defaultNotificationSent = false;
        
        console.log('🚀 ChatSavePro Popup Controller Initialized');
    }

    async initialize() {
        if (this.initialized) {
            console.warn('⚠️ Popup already initialized, skipping');
            return;
        }
        
        try {
            console.log('Initializing popup...');
            this.initialized = true;
            
            this.activeTabId = await this.getActiveTabId();
            console.log('📌 Active tab ID:', this.activeTabId);
            
            this.setupEventListeners();
            this.setupProFeatureToastHandler();
            this.setupFeedbackForm();
            
            await this.loadInitialState();
            await this.testConnection();
            
            this.updateUI();
            
            await this.sendDefaultNotifications();
            
            console.log('✅ Popup initialized successfully');
        } catch (error) {
            console.error('❌ Initialization failed:', error);
            this.toast.error('Failed to initialize popup');
        }
    }

    setupFeedbackForm() {
        try {
            const feedbackSubmitted = localStorage.getItem(FEEDBACK_FLAG_KEY);
            
            if (!feedbackSubmitted) {
                const feedbackSection = document.querySelector('.feedback-card');
                if (feedbackSection) {
                    feedbackSection.open = true;
                    console.log('✅ Feedback form shown (first time)');
                }
            }
            
            const form = document.getElementById('feedbackForm');
            if (form) {
                form.addEventListener('submit', (e) => this.handleFeedbackSubmission(e));
                console.log('✅ Feedback submit listener added');
            }
        } catch (error) {
            console.warn('⚠️ Feedback form setup failed:', error);
        }
    }

    async handleFeedbackSubmission(e) {
        e.preventDefault();
        
        try {
            const form = e.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            const consentCheckbox = document.getElementById('feedbackConsent');
            
            if (!consentCheckbox) {
                this.toast.warning('Consent checkbox not found');
                return;
            }
            
            if (!consentCheckbox.checked) {
                this.toast.warning('Please agree to send feedback anonymously');
                return;
            }
            
            const formData = new FormData(form);
            const feedbackData = {
                usefulness: formData.get('feedbackUsefulness'),
                exportType: formData.get('feedbackExportType'),
                proIntent: formData.get('feedbackProIntent'),
                timestamp: new Date().toISOString(),
                source: 'ChatSavePro Popup',
                version: 'v3.9'
            };
            
            if (!feedbackData.usefulness || !feedbackData.exportType || !feedbackData.proIntent) {
                this.toast.warning('Please answer all questions.');
                return;
            }
            
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Sending...';
            }
            
            try {
                console.log('📤 Sending feedback to Formspree:', feedbackData);
                
                const response = await fetch(FEEDBACK_ENDPOINT, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(feedbackData)
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                
                const result = await response.json();
                console.log('✅ Formspree response:', result);
                
                localStorage.setItem(FEEDBACK_DATA_KEY, JSON.stringify(feedbackData));
                localStorage.setItem(FEEDBACK_FLAG_KEY, 'true');
                
                const successMessage = document.getElementById('feedbackSuccess');
                if (successMessage) {
                    successMessage.hidden = false;
                }
                
                form.reset();
                
                this.toast.success('Thank you for your feedback! 🙏');
                console.log('✅ Feedback submitted successfully');
                
                setTimeout(() => {
                    const feedbackCard = document.querySelector('.feedback-card');
                    if (feedbackCard) {
                        feedbackCard.open = false;
                    }
                    if (successMessage) {
                        successMessage.hidden = true;
                    }
                }, 3000);
                
            } catch (fetchError) {
                console.error('❌ Formspree submission failed:', fetchError);
                
                localStorage.setItem(FEEDBACK_DATA_KEY, JSON.stringify(feedbackData));
                this.toast.error('Failed to send feedback. Stored locally.');
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Submit Feedback';
                }
            }
            
        } catch (error) {
            console.error('❌ Feedback submission error:', error);
            this.toast.error('Failed to submit feedback.');
        }
    }

    setupProFeatureToastHandler() {
        if (window.__PRO_TOAST_HANDLER_BOUND__) {
            console.log('✅ Pro toast handler already bound');
            return;
        }
        
        window.__PRO_TOAST_HANDLER_BOUND__ = true;
        console.log('✅ Setting up delegated Pro feature toast handler...');

        document.addEventListener('click', (e) => {
            const btn = e.target.closest('.pro-feature, .format-option[data-format="pdf"], .format-option[data-pro-only="true"]');
            if (!btn) return;

            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();

            let type;
            if (btn.classList.contains('pro-feature')) {
                type = btn.getAttribute('data-pro-type') || 'unknown';
            } else if (btn.getAttribute('data-format') === 'pdf' || btn.getAttribute('data-pro-only') === 'true') {
                type = 'pdf';
            } else {
                return;
            }

            const messages = {
                ai: '🔒 AI Export is available in the Pro version.',
                db: '🔒 Database integration is available in the Pro version.',
                cloud: '🔒 Cloud upload is available in the Pro version.',
                pdf: '🔒 PDF export is available in the Pro version.'
            };

            const message = messages[type];
            if (!message) return;

            console.log(`🔒 Pro toast triggered: ${type} (single handler)`);
            this.toast.info(message);
        });
    }

    async sendDefaultNotifications() {
        if (this.defaultNotificationSent) {
            console.log('🔄 Default notifications already sent');
            return;
        }
        
        if (!this.activeTabId || this.activeTabId < 0) {
            console.warn('⚠️ Cannot send default notifications: invalid tabId');
            return;
        }
        
        try {
            console.log('🔔 Sending default scan notifications...');
            
            if (this.state.liveScanActive) {
                await this.sendDirectMessage({
                    action: USER_ACTIONS.REQUEST_LOCAL_SCAN,
                    enable: true,
                    tabId: this.activeTabId,
                    timestamp: Date.now(),
                    source: 'popup',
                    isDefaultState: true
                });
                console.log('✅ Default Live Scan notification sent');
            }
            
            if (this.state.deepScanActive) {
                await this.sendDirectMessage({
                    action: USER_ACTIONS.START_DEEP_SCAN,
                    tabId: this.activeTabId,
                    timestamp: Date.now(),
                    source: 'popup',
                    isDefaultState: true,
                    data: { tabId: this.activeTabId }
                });
                console.log('✅ Default Deep Scan notification sent');
            }
            
            this.defaultNotificationSent = true;
            
        } catch (error) {
            console.warn('⚠️ Could not send default notifications:', error);
        }
    }

    getActiveTabId() {
        return new Promise((resolve) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs && tabs[0] && tabs[0].id) {
                    const tabId = tabs[0].id;
                    console.log('✅ Active tab found:', tabId);
                    resolve(tabId);
                } else {
                    console.warn('⚠️ No active tab found');
                    resolve(null);
                }
            });
        });
    }

    async testConnection() {
        try {
            const response = await this.sendDirectMessage({ 
                action: USER_ACTIONS.TEST_PING,
                timestamp: Date.now(),
                source: 'popup',
                tabId: this.activeTabId
            });
            
            console.log('🔗 Connection test response:', response);
            
            if (response && response.success !== false) {
                this.state.connectionStatus = 'connected';
                console.log('✅ Connected to background');
            } else {
                this.state.connectionStatus = 'disconnected';
                console.warn('⚠️ Connection test failed:', response?.error);
            }
        } catch (error) {
            console.error('❌ Connection test failed:', error);
            this.state.connectionStatus = 'disconnected';
        }
    }

    async loadInitialState() {
        return new Promise((resolve) => {
            chrome.storage.local.get(
                ['liveScanActive', 'deepScanActive', 'totalRecords'],
                (result) => {
                    if (result.liveScanActive !== undefined) {
                        this.state.liveScanActive = result.liveScanActive;
                        console.log('📊 Live scan loaded from storage:', result.liveScanActive);
                    } else {
                        console.log('📊 Live scan using default: ON');
                        chrome.storage.local.set({ liveScanActive: true });
                    }
                    
                    if (result.deepScanActive !== undefined) {
                        this.state.deepScanActive = result.deepScanActive;
                        console.log('📊 Deep scan loaded from storage:', result.deepScanActive);
                    } else {
                        console.log('📊 Deep scan using default: ON');
                        chrome.storage.local.set({ deepScanActive: true });
                    }
                    
                    if (result.totalRecords !== undefined) {
                        this.state.totalRecords = result.totalRecords;
                    }
                    
                    console.log('📊 Final state:', this.state);
                    resolve();
                }
            );
        });
    }

    async saveScanState() {
        return new Promise((resolve) => {
            chrome.storage.local.set({
                liveScanActive: this.state.liveScanActive,
                deepScanActive: this.state.deepScanActive
            }, () => {
                console.log('💾 Saved scan state:', this.state);
                resolve();
            });
        });
    }

    setupEventListeners() {
        console.log('Setting up event listeners...');
        
        const deepScanBtn = document.getElementById('deepScanBtn');
        if (deepScanBtn) {
            deepScanBtn.addEventListener('click', () => this.toggleDeepScan());
            console.log('✅ Deep Scan listener added');
        }
        
        const liveScanBtn = document.getElementById('liveScanBtn');
        if (liveScanBtn) {
            liveScanBtn.addEventListener('click', () => this.toggleLiveScan());
            console.log('✅ Live Scan listener added');
        }
        
        const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.handleExport());
            console.log('✅ Export listener added');
        }
        
        const clearDataBtn = document.getElementById('clearDataBtn');
        if (clearDataBtn) {
            clearDataBtn.addEventListener('click', () => this.clearData());
            console.log('✅ Clear Data listener added');
        }
        
        const cleanupBtn = document.getElementById('cleanupCacheBtn');
        if (cleanupBtn) {
            cleanupBtn.addEventListener('click', () => this.cleanupCache());
            console.log('✅ Cleanup Cache listener added');
        }
        
        document.querySelectorAll('.format-option').forEach(option => {
            option.addEventListener('click', (e) => {
                const input = option.querySelector('input[type="radio"]');
                if (input && input.value !== 'pdf') {
                    this.selectFormat(input.value);
                }
            });
        });
        
        console.log('✅ All non-Pro event listeners set up');
    }

    selectFormat(format) {
        if (format === 'pdf') {
            return;
        }
        
        this.state.selectedFormat = format;
        
        document.querySelectorAll('.format-option').forEach(option => {
            option.classList.remove('selected');
        });
        
        const selectedInput = document.querySelector(`input[value="${format}"]`);
        if (selectedInput) {
            selectedInput.closest('.format-option').classList.add('selected');
        }
        
        console.log('📁 Format selected:', format);
    }

    updateUI() {
        try {
            console.log('🔄 Updating UI with state:', this.state);
            
            const connDot = document.getElementById('connectionDot');
            const connStatus = document.getElementById('connectionStatus');
            
            if (connDot) {
                connDot.className = `status-dot ${this.state.connectionStatus}`;
                console.log('🔵 Connection dot updated:', this.state.connectionStatus);
            }
            if (connStatus) {
                connStatus.textContent = this.state.connectionStatus === 'connected' ? 'Connected' : 'Disconnected';
            }

            const totalScansEl = document.getElementById('totalScans');
            if (totalScansEl) {
                totalScansEl.textContent = this.state.totalRecords;
            }

            const deepScanIndicator = document.getElementById('deepScanIndicator');
            const deepScanText = document.getElementById('deepScanText');
            
            if (deepScanIndicator) {
                deepScanIndicator.className = `scan-indicator ${this.state.deepScanActive ? 'on' : 'off'}`;
                console.log('🎯 Deep Scan indicator:', this.state.deepScanActive ? 'ON (green)' : 'OFF (red)');
            }
            if (deepScanText) {
                deepScanText.textContent = this.state.deepScanActive ? 'Stop Deep Scan' : 'Start Deep Scan';
            }

            const liveScanIndicator = document.getElementById('liveScanIndicator');
            const liveScanText = document.getElementById('liveScanText');
            
            if (liveScanIndicator) {
                liveScanIndicator.className = `scan-indicator ${this.state.liveScanActive ? 'on' : 'off'}`;
                console.log('🔄 Live Scan indicator:', this.state.liveScanActive ? 'ON (green)' : 'OFF (red)');
            }
            if (liveScanText) {
                liveScanText.textContent = this.state.liveScanActive ? 'Stop Live Scan' : 'Start Live Scan';
            }
            
            console.log('✅ UI updated successfully');
            
        } catch (error) {
            console.error('❌ UI update error:', error);
        }
    }

    async toggleDeepScan() {
        console.log('🎯 Toggling Deep Scan...');
        
        if (!this.activeTabId) {
            this.activeTabId = await this.getActiveTabId();
        }
        
        console.log('📌 Using tabId:', this.activeTabId);
        
        if (!this.activeTabId) {
            this.toast.error('Please open a webpage to start Deep Scan');
            return;
        }
        
        const targetState = !this.state.deepScanActive;
        const btn = document.getElementById('deepScanBtn');
        
        if (btn) btn.disabled = true;
        
        try {
            console.log(`🎯 Deep Scan: ${this.state.deepScanActive ? 'ON → OFF' : 'OFF → ON'}`);
            
            const response = await this.sendDirectMessage({
                action: targetState ? USER_ACTIONS.START_DEEP_SCAN : USER_ACTIONS.STOP_DEEP_SCAN,
                tabId: this.activeTabId,
                timestamp: Date.now(),
                source: 'popup',
                sessionId: `popup_${Date.now()}`,
                data: { tabId: this.activeTabId }
            });

            console.log('🔍 Deep Scan response:', response);

            if (response && response.success !== false) {
                this.state.deepScanActive = targetState;
                await this.saveScanState();
                this.updateUI();
                
                this.toast.success(`Deep Scan ${targetState ? 'started' : 'stopped'}`);
                console.log(`✅ Deep Scan ${targetState ? 'started' : 'stopped'}`);
            } else {
                throw new Error(response?.error || 'Failed to toggle deep scan');
            }
        } catch (error) {
            console.error('❌ Deep Scan toggle failed:', error);
            this.toast.error(`Failed to ${targetState ? 'start' : 'stop'} deep scan`);
        } finally {
            if (btn) btn.disabled = false;
        }
    }

    async toggleLiveScan() {
        console.log('🔄 Toggling Live Scan...');
        
        if (!this.activeTabId) {
            this.activeTabId = await this.getActiveTabId();
        }
        
        console.log('📌 Using tabId:', this.activeTabId);
        
        if (!this.activeTabId) {
            this.toast.error('Please open a webpage to start Live Scan');
            return;
        }
        
        const targetState = !this.state.liveScanActive;
        const btn = document.getElementById('liveScanBtn');
        
        if (btn) btn.disabled = true;
        
        try {
            console.log(`🔄 Live Scan: ${this.state.liveScanActive ? 'ON → OFF' : 'OFF → ON'}`);
            
            const response = await this.sendDirectMessage({
                action: USER_ACTIONS.REQUEST_LOCAL_SCAN,
                enable: targetState,
                tabId: this.activeTabId,
                timestamp: Date.now(),
                source: 'popup',
                sessionId: `popup_${Date.now()}`
            });

            console.log('🔍 Live Scan response:', response);

            if (response && response.success !== false) {
                this.state.liveScanActive = targetState;
                await this.saveScanState();
                this.updateUI();
                
                this.toast.success(`Live Scan ${targetState ? 'started' : 'stopped'}`);
                console.log(`✅ Live Scan ${targetState ? 'started' : 'stopped'}`);
            } else {
                throw new Error(response?.error || 'Failed to toggle live scan');
            }
        } catch (error) {
            console.error('❌ Live Scan toggle failed:', error);
            this.toast.error(`Failed to ${targetState ? 'start' : 'stop'} live scan`);
        } finally {
            if (btn) btn.disabled = false;
        }
    }

    async handleExport() {
        console.log('📤 Starting export...');
        
        if (this.state.selectedFormat === 'pdf') {
            return;
        }
        
        const exportBtn = document.getElementById('exportBtn');
        const exportText = document.getElementById('exportText');
        
        if (!exportBtn || !exportText) return;
        
        exportBtn.disabled = true;
        exportText.textContent = 'Exporting...';
        
        try {
            console.log('[POPUP][EXPORT] Selected format:', this.state.selectedFormat);
            
            const response = await this.sendDirectMessage({
                action: USER_ACTIONS.EXPORT_CONVERSATIONS,
                format: this.state.selectedFormat,
                tabId: this.activeTabId,
                timestamp: Date.now(),
                source: 'popup'
            });

            console.log('📨 Export response:', response);

            if (!response || response.success === false) {
                throw new Error(response?.error || 'Export failed');
            }

            let blobUrl, fileName;
            
            if (response.blobUrl && response.fileName) {
                blobUrl = response.blobUrl;
                fileName = response.fileName;
                console.log('✅ ExportManager response received:', { blobUrl, fileName });
            } else if (response.downloadUrl) {
                blobUrl = response.downloadUrl;
                fileName = response.fileName || `export.${this.state.selectedFormat}`;
                console.log('📦 Legacy export response');
            } else {
                throw new Error('Invalid export response: no blobUrl or downloadUrl found');
            }

            console.log('📥 Starting download:', { blobUrl, fileName });
            
            await this.downloadFile(blobUrl, fileName);
            
            this.toast.success(`Exported as ${this.state.selectedFormat.toUpperCase()}`);

        } catch (error) {
            console.error('❌ Export failed:', error);
            this.toast.error(`Export failed: ${error.message}`);
        } finally {
            exportBtn.disabled = false;
            exportText.textContent = 'Export Now';
        }
    }

    async downloadFile(blobUrl, fileName) {
        return new Promise((resolve, reject) => {
            chrome.downloads.download({
                url: blobUrl,
                filename: fileName,
                saveAs: true
            }, (downloadId) => {
                if (chrome.runtime.lastError) {
                    console.error('Download error:', chrome.runtime.lastError.message);
                    reject(new Error(`Download failed: ${chrome.runtime.lastError.message}`));
                } else {
                    console.log('✅ Download started:', downloadId);
                    
                    if (blobUrl.startsWith('blob:')) {
                        setTimeout(() => {
                            try {
                                URL.revokeObjectURL(blobUrl);
                                console.log('🗑️ Blob URL revoked');
                            } catch (e) {
                                console.warn('Could not revoke blob URL:', e);
                            }
                        }, 1000);
                    }
                    
                    resolve(downloadId);
                }
            });
        });
    }

    async clearData() {
        if (!confirm('⚠️ Clear all data? This cannot be undone.')) return;
        
        const btn = document.getElementById('clearDataBtn');
        if (btn) btn.disabled = true;
        
        try {
            const response = await this.sendDirectMessage({
                action: USER_ACTIONS.CLEAR_DATA,
                tabId: this.activeTabId,
                timestamp: Date.now(),
                source: 'popup'
            });

            if (response && response.success) {
                this.state.totalRecords = 0;
                this.updateUI();
                this.toast.success('Data cleared');
            } else {
                throw new Error(response?.error || 'Clear failed');
            }
        } catch (error) {
            console.error('Clear error:', error);
            this.toast.error('Clear failed');
        } finally {
            if (btn) btn.disabled = false;
        }
    }

    async cleanupCache() {
        const btn = document.getElementById('cleanupCacheBtn');
        if (btn) btn.disabled = true;
        
        try {
            const response = await this.sendDirectMessage({
                action: USER_ACTIONS.CLEANUP_CONVERSATIONS,
                tabId: this.activeTabId,
                timestamp: Date.now(),
                source: 'popup'
            });

            if (response && response.success) {
                this.toast.success('Cache cleaned');
            } else {
                throw new Error(response?.error || 'Cleanup failed');
            }
        } catch (error) {
            console.error('Cleanup error:', error);
            this.toast.error('Cleanup failed');
        } finally {
            if (btn) btn.disabled = false;
        }
    }

    async sendDirectMessage(message) {
        return new Promise((resolve) => {
            const messageWithId = {
                ...message,
                id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
            };
            
            console.log('📤 Sending direct message:', { 
                action: message.action,
                tabId: message.tabId,
                timestamp: message.timestamp 
            });
            
            chrome.runtime.sendMessage(messageWithId, (response) => {
                if (chrome.runtime.lastError) {
                    console.error('❌ Send error:', chrome.runtime.lastError.message);
                    resolve({ 
                        success: false, 
                        error: chrome.runtime.lastError.message 
                    });
                } else {
                    console.log('📨 Received response for:', message.action);
                    resolve(response || { success: true });
                }
            });
        });
    }
}

let popupControllerInstance = null;

document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 DOM Content Loaded - Starting popup initialization');
    
    if (popupControllerInstance) {
        console.warn('⚠️ Popup controller already exists, reusing instance');
        return;
    }
    
    popupControllerInstance = new PopupController();
    popupControllerInstance.initialize();
    
    window.popupController = popupControllerInstance;
});

// Update Privacy Notice Text
const updatePrivacyNotice = () => {
    const privacyNotice = document.getElementById('privacyNotice');
    if (privacyNotice) {
        const strongElement = privacyNotice.querySelector('strong');
        if (strongElement) {
            const textNode = Array.from(privacyNotice.childNodes).find(node => 
                node.nodeType === Node.TEXT_NODE && node.textContent.includes('All processing')
            );
            if (textNode) {
                textNode.textContent = ' All processing is done locally.\nNo data is sent externally unless you choose to submit feedback.';
            } else {
                const newText = document.createTextNode(' All processing is done locally.\nNo data is sent externally unless you choose to submit feedback.');
                privacyNotice.appendChild(newText);
            }
        }
    }
};

document.addEventListener('DOMContentLoaded', updatePrivacyNotice);