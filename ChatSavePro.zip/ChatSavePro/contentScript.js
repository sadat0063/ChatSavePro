/* ────────────────────────────────────────────────
   ChatSavePro - Content Script (Clean Architecture)
   Version: 5.0-Simplified-Fixed
   ──────────────────────────────────────────────── */

// ==================== BLOCK A: ROUTER CORE + BOOTSTRAP ====================
const CSRouter = {
    listeners: {},
    
    on(type, fn) {
        (this.listeners[type] ||= []).push(fn);
    },
    
    emit(type, payload) {
        const arr = this.listeners[type] || [];
        arr.forEach(fn => fn(payload));
    },
    
    off(type, fn) {
        if (!this.listeners[type]) return;
        const index = this.listeners[type].indexOf(fn);
        if (index > -1) this.listeners[type].splice(index, 1);
    }
};

// ==================== NEW: LOAD SCANLAYER VIA IMPORT ====================
async function loadScanLayer() {
    try {
        const loaderURL = chrome.runtime.getURL("modules/scan-layer-loader.js");

        // New loader is an auto-executing IIFE; import only triggers execution.
        await import(loaderURL);

        console.log("[CS] ScanLayer Loader executed (auto-boot)");
        return true;
    } catch (error) {
        console.error("[CS] ScanLayer Loader failed:", error);
        return false;
    }
}

function ensureDomReady() {
    return new Promise(resolve => {
        if (document.readyState === "complete" || document.readyState === "interactive") {
            return resolve();
        }
        document.addEventListener("DOMContentLoaded", resolve, { once: true });
    });
}

async function helloBackground() {
    return new Promise(resolve => {
        chrome.runtime.sendMessage(
            { 
                action: "CSPRO_CS_HELLO",
                timestamp: Date.now(),
                payload: { 
                    url: window.location.href,
                    version: "5.0-Simplified-Fixed"
                } 
            },
            (resp) => {
                if (chrome.runtime.lastError) {
                    resolve({
                        success: false,
                        error: chrome.runtime.lastError.message,
                        runtimeError: true
                    });
                } else if (!resp) {
                    resolve({
                        success: false,
                        error: "No response from background",
                        received: false
                    });
                } else {
                    resolve(resp);
                }
            }
        );
    });
}

function waitGuardianReady() {
    return new Promise(resolve => {
        // ابتدا بررسی کن اگر Guardian قبلاً آماده است
        if (window.__GUARDIAN_LAYER_READY__ || window.guardian) {
            console.log("✅ Guardian already ready via window variable");
            resolve(true);
            return;
        }

        let timeoutId = null;
        
        const handler = (evt) => {
            if (
                evt.data?.type === "GUARDIAN_READY" ||
                evt.data?.type === "GUARDIAN_SYSTEM_READY" ||
                evt.data?.source === "GUARDIAN" ||
                (evt.data?.type && evt.data.type.includes("GUARDIAN"))
            ) {
                // توقف timeout و حذف listener
                if (timeoutId) clearTimeout(timeoutId);
                window.removeEventListener("message", handler);
                
                console.log("✅ Guardian ready detected:", evt.data.type || evt.data.source);
                resolve(true);
            }
        };
        
        window.addEventListener("message", handler);
        
        // تایم‌اوت برای جلوگیری از انتظار نامحدود
        timeoutId = setTimeout(() => {
            window.removeEventListener("message", handler);
            console.warn("⚠️ Guardian ready timeout - proceeding without");
            resolve(false);
        }, 10000);
    });
}

// ==================== DEPRECATED: OLD LOAD SCANLAYER FUNCTION ====================
// این تابع قدیمی است و فقط برای backward compatibility نگه داشته شده
async function legacyLoadScanLayer() {
    try {
        console.log("📦 Loading ScanLayer...");
        
        // بررسی کن اگر قبلاً لود شده
        if (window.__SCAN_LAYER_LOADED__ || window.ScanLayer || window.scanLayer) {
            console.log("✅ ScanLayer already loaded");
            return true;
        }
        
        // Request the background script to inject the ScanLayer loader
        try {
            chrome.runtime.sendMessage({ 
                action: "LOAD_SCAN_LAYER",
                tabId: chrome.devtools?.inspectedWindow?.tabId || null,
                url: window.location.href,
                timestamp: Date.now()
            });
            console.log("📨 Request sent to BG: LOAD_SCAN_LAYER");
        } catch (e) {
            console.error("❌ Failed to request ScanLayer load", e);
            return false;
        }
        
        // منتظر لود ScanLayer بمان
        return new Promise((resolve) => {
            const checkInterval = setInterval(() => {
                if (window.__SCAN_LAYER_LOADED__ || window.ScanLayer || window.scanLayer) {
                    clearInterval(checkInterval);
                    console.log("✅ ScanLayer loaded successfully");
                    resolve(true);
                }
            }, 100);
            
            // تایم‌اوت برای جلوگیری از انتظار نامحدود
            setTimeout(() => {
                clearInterval(checkInterval);
                console.warn("⚠️ ScanLayer load timeout");
                resolve(false);
            }, 5000);
        });
        
    } catch (error) {
        console.error("❌ loadScanLayer failed:", error);
        return false;
    }
}

async function postBootstrapSetup() {
    window.__CSPRO_BOOTSTRAP_COMPLETE__ = true;
    window.__CSPRO_BOOTSTRAP_TIME__ = Date.now();
    
    window.postMessage({
        type: "CS_BOOTSTRAP_COMPLETE",
        source: "ChatSavePro_ContentScript",
        timestamp: Date.now(),
        version: "5.0-Simplified-Fixed",
        stages: {
            domReady: true,
            backgroundHandshake: true,
            guardianReady: true,
            scanLayerLoaded: true
        }
    }, "*");
    
    console.log("📋 System Status:", {
        url: window.location.href,
        guardianReady: window.guardian || window.__GUARDIAN_LAYER_READY__,
        scanLayerReady: window.scanLayer || window.__SCAN_LAYER_LOADED__,
        bootstrapTime: window.__CSPRO_BOOTSTRAP_TIME__,
        routerActive: true
    });
}

async function bootstrap() {
    console.log("🚀 ChatSavePro Bootstrap starting...");
    
    try {
        console.time("DOM Ready");
        await ensureDomReady();
        console.timeEnd("DOM Ready");
        
        console.time("Background Handshake");
        const bgHello = await helloBackground();
        console.timeEnd("Background Handshake");
        
        if (!bgHello || bgHello.success === false) {
            console.warn("⚠️ Background handshake issue:", bgHello?.error || "Unknown");
        } else {
            console.log("✅ Background acknowledged:", bgHello);
        }
        
        console.time("Guardian Ready");
        const guardianReady = await waitGuardianReady();
        console.timeEnd("Guardian Ready");
        
        if (!guardianReady) {
            console.warn("⚠️ Guardian not ready - proceeding");
        }
        
        console.time("ScanLayer Load");
        // استفاده از تابع جدید loadScanLayer
        const scanLayerLoaded = await loadScanLayer();
        console.timeEnd("ScanLayer Load");
        
        if (!scanLayerLoaded) {
            console.warn("⚠️ ScanLayer not loaded - proceeding in limited mode");
        }
        
        console.log("🎉 Bootstrap completed successfully!");
        
        await postBootstrapSetup();
        
        CSRouter.emit("BOOTSTRAP_COMPLETE", {
            success: true,
            timestamp: Date.now(),
            url: window.location.href,
            stages: {
                dom: true,
                background: !!bgHello?.success,
                guardian: guardianReady,
                scanLayer: scanLayerLoaded
            }
        });
        
        return true;
        
    } catch (error) {
        console.error("❌ Bootstrap failed:", error);
        
        CSRouter.emit("BOOTSTRAP_ERROR", {
            error: error.message,
            stack: error.stack,
            timestamp: Date.now(),
            url: window.location.href
        });
        
        console.warn("⚠️ Continuing in degraded mode");
        return false;
    }
}

function setupMessageRelay() {
    window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        
        const message = event.data;
        
        if (message && message.source === "ChatSavePro_Page") {
            console.log("📨 Message from PageWorld:", message.payload?.type);
            
            if (chrome.runtime?.sendMessage) {
                chrome.runtime.sendMessage(message.payload, (response) => {
                    if (message.correlationId) {
                        window.postMessage({
                            source: "ChatSavePro_CS_Response",
                            correlationId: message.correlationId,
                            response: response,
                            timestamp: Date.now()
                        }, "*");
                    }
                });
            }
        }
        
        if (message && message.type) {
            CSRouter.emit(message.type, message);
        }
    });
    
    console.log("✅ Message relay setup complete");
}

// ========== PATCH 3: اضافه کردن relay برای LIVE_SCAN_MESSAGE ==========
// این بلاک relay پیام‌های PAGEWORLD_TO_CS را به background مدیریت می‌کند
window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;

    if (msg && msg.direction === "PAGEWORLD_TO_CS" && msg.payload) {
        console.log("📨 [CS] Relaying PAGEWORLD_TO_CS to BG:", msg.payload.type);
        chrome.runtime.sendMessage(msg.payload, () => {
            // callback خالی برای جلوگیری از warning
        });
    }
});

// ========== PATCH 3: اضافه کردن relay برای SCANLAYER_STATUS ==========
window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;

    if (data?.direction === "PAGEWORLD_BRIDGE" && data.channel === "SCANLAYER_STATUS") {
        console.log("📡 [CS] Relaying SCANLAYER_STATUS to BG:", data.status);
        chrome.runtime.sendMessage({
            type: "SCANLAYER_STATUS",
            status: data.status,
            payload: data.payload || {},
            timestamp: Date.now()
        });
    }
});

async function initializeContentScript() {
    console.log("🔧 Initializing Content Script...");
    
    setupMessageRelay();
    
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        CSRouter.emit(msg.type || "BACKGROUND_MESSAGE", {
            msg,
            sender,
            sendResponse
        });
        
        return true;
    });
    
    CSRouter.on("TEST_PING", (data) => {
        console.log("🏓 Test ping received:", data);
        
        if (data.sendResponse) {
            data.sendResponse({
                success: true,
                response: "CS_PONG",
                timestamp: Date.now()
            });
        }
    });
    
    CSRouter.on("SCAN_NOW", (data) => {
        console.log("🔍 Scan now requested");
        
        window.postMessage({
            type: "LIGHT_TO_GUARDIAN",
            payload: {
                action: "SCAN_NOW",
                data: data.msg?.data || {},
                timestamp: Date.now()
            }
        }, "*");
        
        if (data.sendResponse) {
            data.sendResponse({
                success: true,
                message: "Scan request forwarded to Guardian",
                timestamp: Date.now()
            });
        }
    });
    
    console.log("✅ Content Script initialized");
}

(async () => {
    try {
        await initializeContentScript();
        await bootstrap();
        
        window.postMessage({
            type: "CS_READY",
            source: "ChatSavePro_ContentScript",
            timestamp: Date.now(),
            version: "5.0-Simplified-Fixed"
        }, "*");
        
        console.log("🏁 ChatSavePro Content Script fully operational");
        
    } catch (error) {
        console.error("💥 Critical initialization error:", error);
    }
})();

// ==================== BLOCK B: SCANLAYER RESPONSE HANDLER ====================

function setupScanLayerResponseHandler() {
    window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        
        const message = event.data;
        
        if (message && message.source === "SCANLAYER_LOADER") {
            console.log("📨 ScanLayer loader message:", message.type);
            
            if (message.type === "LOADER_COMPLETE") {
                console.log("✅ ScanLayer loader completed successfully");
            } else if (message.type === "LOADER_ERROR") {
                console.error("❌ ScanLayer loader error:", message.error);
            }
        }
        
        if (message && message.source === "SCAN_LAYER") {
            console.log("📨 ScanLayer response:", message.type);
            
            if (message.type === "SCAN_RESULT") {
                chrome.runtime.sendMessage({
                    type: "SCAN_RESULT",
                    payload: message.payload,
                    url: window.location.href,
                    timestamp: Date.now()
                });
            }
            
            CSRouter.emit("SCANLAYER_RESPONSE", message);
        }
        
        if (message && message.type === "GUARDIAN_SCAN_RESULT") {
            console.log("📊 Guardian scan result received");
            
            chrome.runtime.sendMessage({
                type: "SCAN_RESULT",
                payload: message.payload,
                source: "guardian",
                url: window.location.href,
                timestamp: Date.now()
            });
        }
        
        if (message && message.type === "GUARDIAN_SAVE_RESULT") {
            console.log("💾 Guardian save result received");
            
            chrome.runtime.sendMessage({
                type: "SAVE_RESULT",
                payload: message.payload,
                source: "guardian",
                url: window.location.href,
                timestamp: Date.now()
            });
        }
    });
    
    console.log("✅ ScanLayer response handler setup");
}

setupScanLayerResponseHandler();

window.ChatSaveProRouter = CSRouter;

window.__CSPRO_CS_STATUS__ = {
    version: "5.0-Simplified-Fixed",
    loadedAt: Date.now(),
    url: window.location.href,
    routerActive: true
};

console.log("📄 ChatSavePro Content Script loaded successfully!");