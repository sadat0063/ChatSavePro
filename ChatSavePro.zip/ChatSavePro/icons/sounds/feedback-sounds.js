// ============================================================
// AudioFeedback.js - Guardian Audio Feedback System
// ============================================================
// 🛡️ Secure, Privacy-First Audio Feedback with Guardian Principles
// ============================================================

// 🛡️ PRINCIPLE 1: Context Isolation
const AUDIO_CONTEXTS = Object.freeze({
    UI: 'ui',
    SCAN: 'scan',
    EXPORT: 'export',
    SYSTEM: 'system'
});

// 🛡️ PRINCIPLE 2: Strict Interface Contract
const SOUND_SCHEMAS = Object.freeze({
    SUCCESS: {
        frequency: 800,
        duration: 0.3,
        type: 'sine',
        context: AUDIO_CONTEXTS.SYSTEM,
        volume: 0.3
    },
    ERROR: {
        frequency: 400,
        duration: 0.2,
        type: 'square',
        context: AUDIO_CONTEXTS.SYSTEM,
        volume: 0.2
    },
    SCAN_START: {
        frequency: 600,
        duration: 0.1,
        type: 'sine',
        context: AUDIO_CONTEXTS.SCAN,
        volume: 0.2
    },
    SCAN_COMPLETE: {
        frequency: 1000,
        duration: 0.2,
        type: 'sine',
        context: AUDIO_CONTEXTS.SCAN,
        volume: 0.3
    },
    EXPORT_COMPLETE: {
        frequency: 1200,
        duration: 0.3,
        type: 'triangle',
        context: AUDIO_CONTEXTS.EXPORT,
        volume: 0.4
    },
    CLICK: {
        frequency: 300,
        duration: 0.1,
        type: 'sine',
        context: AUDIO_CONTEXTS.UI,
        volume: 0.1
    }
});

// 🛡️ PRINCIPLE 9: Secure Logging & Sanitization
class AudioLogger {
    constructor() {
        this.logs = [];
        this.maxLogSize = 50;
    }

    log(level, message, data = null) {
        const logEntry = {
            timestamp: Date.now(),
            level,
            message,
            data: this._sanitizeData(data)
        };

        this.logs.push(logEntry);

        if (this.logs.length > this.maxLogSize) {
            this.logs = this.logs.slice(-this.maxLogSize);
        }

        if (process.env.NODE_ENV === 'development') {
            console.log(`[Audio][${level}] ${message}`, data || '');
        }
    }

    _sanitizeData(data) {
        if (!data) return null;
        
        try {
            const sanitized = JSON.parse(JSON.stringify(data, (key, value) => {
                if (key === 'audioBuffer' || key === 'rawData') {
                    return '***';
                }
                return value;
            }));
            return sanitized;
        } catch {
            return { error: 'Unable to sanitize audio data' };
        }
    }

    getLogs() {
        return [...this.logs];
    }
}

// 🛡️ PRINCIPLE 7: Async Pipeline & Resilience
export class AudioFeedbackManager {
    constructor() {
        this.sounds = new Map();
        this.logger = new AudioLogger();
        this.audioContext = null;
        this.isInitialized = false;
        
        // 🛡️ PRINCIPLE 6: Deterministic State Recovery
        this.state = {
            enabled: true,
            masterVolume: 0.3,
            contextVolumes: new Map(),
            lastPlayed: null,
            playCount: 0
        };

        this.initialize();
    }

    async initialize() {
        try {
            await this.loadSettings();
            this.initializeAudioContext();
            this.initializeSounds();
            this.setupEventListeners();
            
            this.isInitialized = true;
            this.logger.log('INFO', 'Audio feedback manager initialized');

        } catch (error) {
            this.logger.log('ERROR', 'Audio initialization failed', {
                error: error.message
            });
        }
    }

    initializeAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            this.logger.log('INFO', 'Audio context created');
        } catch (error) {
            this.logger.log('WARN', 'Web Audio API not supported', {
                error: error.message
            });
            this.state.enabled = false;
        }
    }

    initializeSounds() {
        Object.entries(SOUND_SCHEMAS).forEach(([name, schema]) => {
            this.sounds.set(name, schema);
        });
        this.logger.log('INFO', 'Sound schemas initialized', {
            count: this.sounds.size
        });
    }

    // 🛡️ PRINCIPLE 8: Secure Audio Generation
    async play(soundName, options = {}) {
        if (!this.state.enabled || !this.audioContext) {
            return false;
        }

        try {
            const schema = this.sounds.get(soundName);
            if (!schema) {
                this.logger.log('WARN', 'Unknown sound requested', { soundName });
                return false;
            }

            // 🛡️ Validate input parameters
            if (!this.validatePlayParameters(soundName, options)) {
                return false;
            }

            const soundConfig = { ...schema, ...options };
            await this.generateSound(soundConfig);

            // 🛡️ PRINCIPLE 10: Audit & Traceability
            this.state.lastPlayed = {
                sound: soundName,
                timestamp: Date.now(),
                context: soundConfig.context
            };
            this.state.playCount++;

            this.logger.log('INFO', 'Sound played successfully', {
                sound: soundName,
                context: soundConfig.context,
                volume: soundConfig.volume
            });

            return true;

        } catch (error) {
            this.logger.log('ERROR', 'Sound playback failed', {
                sound: soundName,
                error: error.message
            });
            return false;
        }
    }

    validatePlayParameters(soundName, options) {
        // Validate sound name
        if (!this.sounds.has(soundName)) {
            return false;
        }

        // Validate volume
        if (options.volume !== undefined && 
            (typeof options.volume !== 'number' || options.volume < 0 || options.volume > 1)) {
            return false;
        }

        // Validate duration
        if (options.duration !== undefined && 
            (typeof options.duration !== 'number' || options.duration <= 0 || options.duration > 5)) {
            return false;
        }

        return true;
    }

    async generateSound(config) {
        return new Promise((resolve, reject) => {
            try {
                if (this.audioContext.state === 'suspended') {
                    this.audioContext.resume();
                }

                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();

                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);

                // Apply sound configuration
                oscillator.frequency.value = config.frequency;
                oscillator.type = config.type;

                const finalVolume = config.volume * this.state.masterVolume;
                
                // Smooth volume envelope
                gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
                gainNode.gain.linearRampToValueAtTime(finalVolume, this.audioContext.currentTime + 0.01);
                gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + config.duration);

                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + config.duration);

                oscillator.onended = () => {
                    resolve();
                };

            } catch (error) {
                reject(error);
            }
        });
    }

    // 🛡️ PRINCIPLE 3: Configuration Management
    async loadSettings() {
        try {
            const settings = await chrome.storage.local.get([
                'audioFeedbackEnabled',
                'audioMasterVolume',
                'audioContextVolumes'
            ]);

            this.state.enabled = settings.audioFeedbackEnabled !== false;
            this.state.masterVolume = settings.audioMasterVolume || 0.3;
            
            if (settings.audioContextVolumes) {
                this.state.contextVolumes = new Map(Object.entries(settings.audioContextVolumes));
            }

            this.logger.log('INFO', 'Audio settings loaded');

        } catch (error) {
            this.logger.log('WARN', 'Failed to load audio settings', {
                error: error.message
            });
        }
    }

    async saveSettings() {
        try {
            await chrome.storage.local.set({
                audioFeedbackEnabled: this.state.enabled,
                audioMasterVolume: this.state.masterVolume,
                audioContextVolumes: Object.fromEntries(this.state.contextVolumes)
            });

            this.logger.log('INFO', 'Audio settings saved');

        } catch (error) {
            this.logger.log('ERROR', 'Failed to save audio settings', {
                error: error.message
            });
        }
    }

    // 🛡️ PRINCIPLE 4: Enhanced Control Methods
    enable() {
        this.state.enabled = true;
        this.saveSettings();
        this.logger.log('INFO', 'Audio feedback enabled');
    }

    disable() {
        this.state.enabled = false;
        this.saveSettings();
        this.logger.log('INFO', 'Audio feedback disabled');
    }

    setMasterVolume(volume) {
        const safeVolume = Math.max(0, Math.min(1, volume));
        this.state.masterVolume = safeVolume;
        this.saveSettings();
        
        this.logger.log('INFO', 'Master volume updated', {
            volume: safeVolume
        });
    }

    setContextVolume(context, volume) {
        if (!Object.values(AUDIO_CONTEXTS).includes(context)) {
            this.logger.log('WARN', 'Invalid context for volume setting', { context });
            return;
        }

        const safeVolume = Math.max(0, Math.min(1, volume));
        this.state.contextVolumes.set(context, safeVolume);
        this.saveSettings();

        this.logger.log('INFO', 'Context volume updated', {
            context,
            volume: safeVolume
        });
    }

    // 🛡️ PRINCIPLE 11: Event Integration
    setupEventListeners() {
        // Scan events
        document.addEventListener('scanStarted', () => {
            this.play('SCAN_START', { context: AUDIO_CONTEXTS.SCAN });
        });

        document.addEventListener('scanCompleted', () => {
            this.play('SCAN_COMPLETE', { context: AUDIO_CONTEXTS.SCAN });
        });

        // Export events
        document.addEventListener('exportStarted', () => {
            this.play('CLICK', { context: AUDIO_CONTEXTS.EXPORT });
        });

        document.addEventListener('exportCompleted', () => {
            this.play('EXPORT_COMPLETE', { context: AUDIO_CONTEXTS.EXPORT });
        });

        // UI events
        document.addEventListener('guardianSuccess', () => {
            this.play('SUCCESS', { context: AUDIO_CONTEXTS.SYSTEM });
        });

        document.addEventListener('guardianError', () => {
            this.play('ERROR', { context: AUDIO_CONTEXTS.SYSTEM });
        });

        this.logger.log('INFO', 'Audio event listeners setup complete');
    }

    // 🛡️ PRINCIPLE 10: Metrics & Monitoring
    getAudioMetrics() {
        return {
            enabled: this.state.enabled,
            masterVolume: this.state.masterVolume,
            totalPlays: this.state.playCount,
            lastPlayed: this.state.lastPlayed,
            contextVolumes: Object.fromEntries(this.state.contextVolumes),
            logs: this.logger.getLogs()
        };
    }

    // 🛡️ PRINCIPLE 8: Cleanup
    destroy() {
        if (this.audioContext) {
            this.audioContext.close();
        }
        this.logger.log('INFO', 'Audio feedback manager destroyed', {
            totalPlays: this.state.playCount
        });
    }
}

// 🛡️ PRINCIPLE 5: Safe Global Registration
if (typeof window !== 'undefined') {
    window.guardianAudio = new AudioFeedbackManager();
}

export default AudioFeedbackManager;