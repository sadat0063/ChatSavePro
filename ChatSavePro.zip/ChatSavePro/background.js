// ==================== 🔧 SECUREFILTERMANAGER IMPORT ====================
// Import SecureFilterManager قبل از هر استفاده‌ای از آن
importScripts("modules/filter-manager.js");

// ==================== ✅ OFFSCREEN MESSAGE BYPASS (CRITICAL FIX - SINGLE SOURCE) ====================
// این تنها listener باید باشد - تمام پیام‌های Offscreen مستقیماً عبور می‌کنند
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return false;
    
    // ✅ لیست پیام‌هایی که باید مستقیماً به offscreen بروند (NO PROCESSING)
    const offscreenMessages = [
        "PING",
        "GENERATE_PDF", 
        "OFFSCREEN_READY",
        "OFFSCREEN_ERROR",
        "GENERATE_PDF_RESPONSE",
        "OFFSCREEN_PING",
        "GENERATE_PDF_V1" // ✅ اضافه کردن PDF v1 به لیست bypass
    ];
    
    if (offscreenMessages.includes(msg.type)) {
        console.log('[BG][OFFSCREEN_BYPASS] ⚡ Direct pass-through to offscreen:', msg.type, {
            timestamp: msg.timestamp || Date.now(),
            source: msg.source || 'unknown'
        });
        
        // ❌❌❌ ABSOLUTELY NO PROCESSING - LET IT PASS THROUGH TO OFFSCREEN
        return false;
    }
    
    // ✅ برای سایر پیام‌ها ادامه دهید
    return false;
});

// ============================================================
// PDF v1 Offscreen (Free version) – Lifecycle Manager
// ============================================================

let pdfV1OffscreenReady = false;
let pdfV1OffscreenCreating = false;
let pdfV1OffscreenDocumentId = null;

async function ensurePdfV1Offscreen(maxRetries = 3) {
  if (pdfV1OffscreenReady) return true;

  if (pdfV1OffscreenCreating) {
    // صبر کن تا ساخت کامل شود
    await new Promise(resolve => {
      const check = setInterval(() => {
        if (pdfV1OffscreenReady) {
          clearInterval(check);
          resolve();
        }
      }, 50);
    });
    return true;
  }

  pdfV1OffscreenCreating = true;
  console.log('[BG][PDFv1] 🚀 Ensuring PDF v1 Offscreen document...');

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
        // بررسی وجود document
        const hasDocument = await chrome.offscreen.hasDocument?.();
        
        if (hasDocument) {
            console.log('[BG][PDFv1] ✅ PDF v1 Offscreen document already exists');
            pdfV1OffscreenReady = true;
            pdfV1OffscreenCreating = false;
            return true;
        }

        // ایجاد document جدید
        const documentId = await chrome.offscreen.createDocument({
            url: chrome.runtime.getURL('offscreen/pdf-v1-offscreen.html'),
            reasons: [chrome.offscreen.Reason.DOM_PARSER],
            justification: "Generate simple PDF (v1 free) using pure MV3 Offscreen"
        });

        pdfV1OffscreenDocumentId = documentId;
        pdfV1OffscreenReady = true;
        pdfV1OffscreenCreating = false;
        
        console.log('[BG][PDFv1] ✅ PDF v1 Offscreen document created successfully', {
            documentId,
            timestamp: Date.now()
        });

        // اضافه کردن listener برای پیام‌های از offscreen
        chrome.runtime.onMessage.addListener(function pdfV1OffscreenListener(message) {
            if (message.type === 'PDF_V1_READY') {
                console.log('[BG][PDFv1] ✅ PDF v1 Offscreen confirmed ready');
                chrome.runtime.onMessage.removeListener(pdfV1OffscreenListener);
            }
            return false;
        });

        return true;

    } catch (error) {
        console.error(`[BG][PDFv1] ❌ Attempt ${attempt}/${maxRetries} failed:`, error);
        if (attempt === maxRetries) {
            pdfV1OffscreenReady = false;
            pdfV1OffscreenCreating = false;
            throw error;
        }
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
  return false;
}

// ==================== 🆕 FreePDFExporter Class (ISOLATED) ====================
class FreePDFExporter {
  constructor() {
    console.log('[BG][FreePDFExporter] ✅ Initialized - Pure MV3 Offscreen only');
    this.isInitialized = false;
    this.initializationPromise = null;
  }

  async initialize() {
    if (this.isInitialized) return true;
    
    if (this.initializationPromise) {
      return await this.initializationPromise;
    }

    this.initializationPromise = (async () => {
      try {
        // اطمینان از وجود offscreen document
        await ensurePdfV1Offscreen();
        this.isInitialized = true;
        console.log('[BG][FreePDFExporter] ✅ Ready for PDF v1 exports');
        return true;
      } catch (error) {
        console.error('[BG][FreePDFExporter] ❌ Initialization failed:', error);
        throw error;
      }
    })();

    return await this.initializationPromise;
  }

  async exportToPDF(options) {
    console.log('[BG][FreePDFExporter] 🚀 Starting PDF v1 export via Offscreen', {
        title: options?.title?.substring(0, 50) || 'Untitled',
        contentLength: options?.htmlContent?.length || 0,
        timestamp: Date.now()
    });

    try {
        // 1. Initialize exporter
        await this.initialize();

        // 2. Validate and extract HTML content
        const htmlString = this.extractAndValidateHTML(options?.htmlContent);
        
        console.log('[FreePDFExporter] Payload preview:', {
            type: typeof htmlString,
            length: htmlString.length,
            first500: htmlString.substring(0, 500)
        });

        // 3. Send to Offscreen for rendering
        console.log('[BG][FreePDFExporter] 📤 Sending GENERATE_PDF_V1 to Offscreen...');
        
        const response = await chrome.runtime.sendMessage({
            type: "GENERATE_PDF_V1",
            payload: {
                content: htmlString,
                fileName: options.fileName || `chatsavepro_${Date.now()}.pdf`,
                title: options.title || 'ChatSavePro Export',
                metadata: options.metadata || {},
                timestamp: Date.now()
            }
        });

        // 4. Validate response
        if (!response) {
            throw new Error('No response from PDF v1 Offscreen');
        }

        if (!response.success) {
            throw new Error(response.error || 'PDF generation failed in Offscreen');
        }

        if (!response.buffer || !ArrayBuffer.isView(response.buffer)) {
            throw new Error('Invalid PDF buffer received from Offscreen');
        }

        // 5. Convert ArrayBuffer to Blob and download
        console.log('[BG][FreePDFExporter] 📥 Received PDF buffer, starting download...', {
            bufferSize: response.buffer.byteLength,
            fileName: response.fileName || options.fileName
        });

        const blob = new Blob([response.buffer], { type: 'application/pdf' });
        const blobUrl = URL.createObjectURL(blob);
        
        const downloadId = await new Promise((resolve, reject) => {
            chrome.downloads.download({
                url: blobUrl,
                filename: response.fileName || options.fileName || `chatsavepro_${Date.now()}.pdf`,
                saveAs: true,
                conflictAction: 'uniquify'
            }, (downloadId) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(downloadId);
                }
            });
        });

        // Cleanup blob URL
        setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

        console.log('[BG][FreePDFExporter] ✅ PDF v1 download started successfully', {
            downloadId,
            fileName: response.fileName,
            bufferSize: response.buffer.byteLength,
            timestamp: Date.now()
        });

        // 6. Return contract-compliant response
        return {
            success: true,
            downloadStarted: true,
            downloadId: downloadId,
            fileName: response.fileName,
            message: 'PDF v1 exported successfully via MV3 Offscreen',
            fallback: false,
            direct: true,
            timestamp: Date.now()
        };

    } catch (error) {
        console.error('[BG][FreePDFExporter] ❌ PDF v1 export failed:', error);
        
        // فقط در صورت خطای Offscreen به fallback برو
        if (error.message.includes('Offscreen') || error.message.includes('receiving end')) {
            console.log('[BG][FreePDFExporter] 🛠️ Offscreen failed, using HTML fallback');
            
            const htmlContent = options.htmlContent || '<h1>PDF Export Failed</h1><p>Using HTML fallback</p>';
            const fileName = (options.fileName || 'chatsavepro_export').replace('.pdf', '.html');
            
            return {
                success: true,
                downloadStarted: false,
                fallback: true,
                htmlContent: htmlContent,
                fileName: fileName,
                message: `PDF v1 failed, HTML fallback available: ${error.message}`,
                error: error.message,
                timestamp: Date.now()
            };
        }
        
        throw error;
    }
  }

  extractAndValidateHTML(htmlContent) {
    // اگر HTML خالی است، خطا بده
    if (!htmlContent) {
        throw new Error('PDF_HTML_EMPTY: No HTML content provided');
    }

    // ✅ 1️⃣ اگر HTML رشته‌ای است، مستقیماً برگردان
    if (typeof htmlContent === 'string') {
        if (htmlContent.trim().length === 0) {
            throw new Error('PDF_HTML_EMPTY: Empty string provided');
        }
        return htmlContent;
    }

    // ✅ 2️⃣ اگر HTML داخل آبجکت است، صریح extract شود
    const htmlString = 
        htmlContent?.html ||
        htmlContent?.content ||
        htmlContent?.data ||
        (typeof htmlContent === 'object' ? JSON.stringify(htmlContent) : String(htmlContent));

    if (!htmlString || htmlString.trim().length === 0) {
        throw new Error('PDF_HTML_EMPTY: Could not extract HTML from object');
    }

    return htmlString;
  }

  healthCheck() {
    return {
      available: true,
      healthy: pdfV1OffscreenReady,
      ready: this.isInitialized,
      mode: 'MV3_OFFSCREEN',
      offscreenReady: pdfV1OffscreenReady,
      error: pdfV1OffscreenReady ? null : 'Offscreen not ready',
      fallback: false
    };
  }
}

// ==================== CSPRO_CS_HELLO HANDLER ====================
function handleCSPRO_CS_HELLO(message, sender, sendResponse) {
    console.log('[BG][CSPRO] Processing CSPRO_CS_HELLO', {
        source: message.source || 'unknown',
        tabId: sender?.tab?.id,
        timestamp: message.timestamp || Date.now()
    });
    
    sendResponse({
        success: true,
        handled: true,
        message: 'CSPRO_CS_HELLO processed successfully',
        timestamp: Date.now(),
        version: '3.9.8-final',
        ready: true
    });
    
    return true;
}

// ==================== ULTIMATE HARD STOP LEGACY HANDLER ====================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if ((msg && msg.type === 'CSPRO_CS_HELLO') || (msg && msg.action === 'CSPRO_CS_HELLO')) {
    console.log('[BG][LEGACY] CSPRO_CS_HELLO routed to handler');
    return handleCSPRO_CS_HELLO(msg, sender, sendResponse);
  }
  return;
});

// ==================== POST MESSAGE HANDLER ====================
if (typeof window !== 'undefined') {
    window.addEventListener('message', (event) => {
        if (event.data && 
            (event.data.source === 'chatsavepro_cs' || 
             event.data.source === 'guardian_layer' ||
             event.data.source === 'content_script')) {
            
            console.log('[BG][POST] Received message:', event.data.type || event.data.action);
            
            const message = event.data.payload || event.data;
            const tabId = event.data.tabId || event.source?.tabId;
            
            if (message && message.action) {
                const sender = {
                    tab: { id: tabId },
                    url: event.origin,
                    frameId: 0
                };
                
                const sendResponse = (response) => {
                    if (event.source && event.source.postMessage) {
                        event.source.postMessage({
                            type: 'BACKGROUND_RESPONSE',
                            payload: response,
                            source: 'background',
                            correlationId: message.correlationId || message.id || Date.now(),
                            timestamp: Date.now()
                        }, '*');
                    }
                };
                
                setTimeout(() => {
                    if (actionHandlerManager && typeof actionHandlerManager.handle === 'function') {
                        actionHandlerManager.handle(message.action, message, sender)
                            .then(response => {
                                sendResponse(response);
                            })
                            .catch(error => {
                                sendResponse({
                                    success: false,
                                    error: error.message,
                                    timestamp: Date.now()
                                });
                            });
                    } else {
                        sendResponse({
                            success: false,
                            error: 'ActionHandlerManager not ready',
                            timestamp: Date.now()
                        });
                    }
                }, 0);
            }
        }
    });
    
    console.log('✅ postMessage listener added in background');
}

// ==================== HIGH PRIORITY HANDLER ====================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;

    // ==================== 🆕 SCANLAYER_DATA_READY HANDLER ====================
    if (msg.type === "SCANLAYER_DATA_READY" || msg.action === "SCANLAYER_DATA_READY") {
        console.log("[BG][HPL] 🔥 SCANLAYER_DATA_READY received:", {
            count: msg.payload?.messages?.length || 0,
            tabId: sender.tab?.id,
            url: sender.tab?.url,
            source: msg.source || 'unknown',
            timestamp: msg.timestamp || 'missing'
        });
        
        // اعتبارسنجی داده‌ها
        if (!msg.payload?.messages || !Array.isArray(msg.payload.messages)) {
            console.error("[BG][HPL] ❌ Invalid SCANLAYER_DATA_READY payload");
            sendResponse({ success: false, error: "Invalid payload" });
            return true;
        }
        
        if (msg.payload.messages.length === 0) {
            console.warn("[BG][HPL] ⚠️ SCANLAYER_DATA_READY with empty messages");
            sendResponse({ success: false, error: "No messages to save" });
            return true;
        }
        
        // FIX: تابع استخراج site
        const getSiteFromUrl = (url) => {
            try {
                const urlObj = new URL(url);
                return urlObj.hostname;
            } catch {
                return "unknown-site";
            }
        };
        
        // ایجاد رکورد مکالمه
        const conversation = {
            id: `scanlayer_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            url: sender.tab?.url || "unknown",
            title: "DeepSeek Conversation (Live)",
            timestamp: Date.now(),
            platform: "deepseek.com",
            site: getSiteFromUrl(sender.tab?.url || ""),
            messages: msg.payload.messages.map((msg, index) => ({
                id: `msg_${Date.now()}_${index}`,
                role: msg.role || "unknown",
                content: msg.content || "",
                timestamp: msg.timestamp || Date.now(),
                source: msg.source || "scanlayer_extraction"
            })),
            messageCount: msg.payload.messages.length,
            extractedAt: Date.now(),
            source: "scanlayer_live",
            version: "1.0"
        };
        
        console.log(`[BG][HPL] 💾 Saving ${conversation.messageCount} messages from ScanLayer`);
        
        // ذخیره در storage با اولویت بالا
        chrome.storage.local.get(['scanlayer_conversations', 'conversations'], (result) => {
            // ذخیره در scanlayer_conversations
            const scanlayerConvs = result.scanlayer_conversations || [];
            scanlayerConvs.unshift(conversation);
            const trimmedScanlayer = scanlayerConvs.slice(0, 50);
            
            // ذخیره در conversations عمومی
            const allConvs = result.conversations || [];
            allConvs.unshift(conversation);
            const trimmedAll = allConvs.slice(0, 100);
            
            // ذخیره نهایی
            chrome.storage.local.set({
                scanlayer_conversations: trimmedScanlayer,
                conversations: trimmedAll,
                last_scanlayer_data: {
                    timestamp: Date.now(),
                    count: conversation.messageCount,
                    conversationId: conversation.id
                }
            }, () => {
                console.log(`[BG][HPL] ✅ ScanLayer data saved successfully!`, {
                    conversationId: conversation.id,
                    messageCount: conversation.messageCount,
                    scanlayerTotal: trimmedScanlayer.length,
                    allTotal: trimmedAll.length,
                    site: conversation.site
                });
            });
        });
        
        // ذخیره در memory manager برای دسترسی سریع
        if (memoryManager) {
            memoryManager.set("scanlayer", `latest_${sender.tab?.id || 'global'}`, conversation, 3600000);
        }
        
        sendResponse({ 
            success: true, 
            saved: true,
            count: msg.payload.messages.length,
            conversationId: conversation.id,
            site: conversation.site,
            message: "ScanLayer data saved successfully"
        });
        return true;
    }

    // MESSAGES_EXTRACTED HANDLER
    if (msg.type === "MESSAGES_EXTRACTED") {
        console.log("[BG][HPL] MESSAGES_EXTRACTED received:", {
            count: msg.messages?.length || 0,
            tabId: sender.tab?.id,
            url: sender.tab?.url
        });
        
        if (msg.messages && msg.messages.length > 0) {
            const conversation = {
                id: `conv_${Date.now()}`,
                url: sender.tab?.url || "unknown",
                title: "DeepSeek Conversation",
                timestamp: Date.now(),
                site: sender.tab?.url ? new URL(sender.tab.url).hostname : "unknown",
                platform: "deepseek.com",
                messages: msg.messages.map(msg => ({
                    role: msg.role,
                    content: msg.content,
                    timestamp: msg.timestamp,
                    source: msg.source || "extraction"
                })),
                messageCount: msg.messages.length,
                extractedAt: Date.now()
            };
            
            chrome.storage.local.get(['scanlayer_conversations'], (result) => {
                const conversations = result.scanlayer_conversations || [];
                conversations.unshift(conversation);
                const trimmedConversations = conversations.slice(0, 50);
                
                chrome.storage.local.set({
                    scanlayer_conversations: trimmedConversations
                }, () => {
                    console.log(`[BG][HPL] Saved ${msg.messages.length} messages to scanlayer_conversations`);
                });
            });
            
            sendResponse({ success: true, saved: msg.messages.length });
            return true;
        }
    }

    // LIVE SCAN
    if (msg.type === "LIVE_SCAN_MESSAGE") {
        console.log("[BG][HPL] LIVE_SCAN_MESSAGE received:", msg);
        const key = `live_${msg.sessionId}`;
        chrome.storage.local.set({ [key]: msg }, () => {
            console.log("[BG][HPL] Live scan saved OK:", key);
        });
        sendResponse({ success: true });
        return true;
    }

    // DEEP SCAN
    if (msg.type === "DEEP_SCAN_RESULTS") {
        console.log("[BG][HPL] DEEP_SCAN_RESULTS received:", msg);
        const key = `deep_${msg.sessionId}`;
        chrome.storage.local.set({ [key]: msg.items }, () => {
            console.log("[BG][HPL] Deep scan saved OK:", key);
        });
        sendResponse({ success: true });
        return true;
    }
});

// ==================== GLOBAL REGISTRIES ====================
if (!globalThis.__GUARDIAN_REGISTRY__) globalThis.__GUARDIAN_REGISTRY__ = {};
if (!globalThis.__CONTENT_SCRIPT_REGISTRY__) globalThis.__CONTENT_SCRIPT_REGISTRY__ = {};
if (!globalThis.__LAST_PING_TS__) globalThis.__LAST_PING_TS__ = 0;
if (!globalThis.__INJECTION_LOCK__) globalThis.__INJECTION_LOCK__ = new Set();
if (!globalThis.__CONVERSATIONS_STORE__) globalThis.__CONVERSATIONS_STORE__ = {
    conversations: [],
    lastSync: 0,
    maxConversations: 1000
};

console.log("✅ Global registries initialized");

// ==================== INITIALIZATION ====================
console.log("[Injector] MAIN world tab injection ENABLED");

if (typeof self !== "undefined" && self._QUANTUMSTAGE_BG_V39_LOADED) {
  throw new Error("QuantumStage Background Context already loaded - terminating duplicate");
}
var SECURE_GLOBALS = Object.freeze({
  _QUANTUMSTAGE_BG_V39_LOADED: true,
  _QUANTUMSTAGE_BG_LOAD_TIMESTAMP: Date.now(),
  _QUANTUMSTAGE_BG_SECURITY_TOKEN: crypto.randomUUID()
});
Object.assign(self, SECURE_GLOBALS);
console.log("⚡ QuantumStage Background v3.9.8 - JSON v1.1 Architecture");

// ==================== CLASS DEFINITIONS ====================
var SelectorDatabase = class {
  constructor() {
    this.userReports = [];
    this.selectorHistory = new Map();
    this.performanceMetrics = new Map();
    this.isInitialized = false;
  }

  async initialize() {
    if (this.isInitialized) return;
    try {
      const result = await chrome.storage.local.get([
        "selectorUserReports",
        "selectorPerformanceData",
        "adaptiveSelectorHistory"
      ]);
      this.userReports = result.selectorUserReports || [];
      this.performanceMetrics = new Map(Object.entries(result.selectorPerformanceData || {}));
      this.selectorHistory = new Map(Object.entries(result.adaptiveSelectorHistory || {}));
      this.isInitialized = true;
      console.log("✅ SelectorDatabase initialized successfully");
    } catch (error) {
      console.error("❌ SelectorDatabase initialization failed:", error);
      this.userReports = [];
      this.performanceMetrics = new Map();
      this.selectorHistory = new Map();
      this.isInitialized = true;
    }
  }

  async reportSelectorUpdate(platform, oldSelector, newSelector) {
    try {
      const report = {
        platform,
        oldSelector,
        newSelector,
        timestamp: Date.now(),
        type: "selector_update"
      };
      this.userReports.push(report);
      if (!this.selectorHistory.has(platform)) {
        this.selectorHistory.set(platform, []);
      }
      this.selectorHistory.get(platform).push({
        selector: newSelector,
        timestamp: Date.now(),
        type: "update"
      });
      const history = this.selectorHistory.get(platform);
      if (history.length > 50) {
        this.selectorHistory.set(platform, history.slice(-50));
      }
      await this.persistData();
      console.log("📝 Selector update recorded:", report);
      return true;
    } catch (error) {
      console.error("Error reporting selector update:", error);
      return false;
    }
  }

  async reportBrokenSelector(platform, brokenSelector, alternativeSelector) {
    try {
      const report = {
        platform,
        brokenSelector,
        alternativeSelector,
        timestamp: Date.now(),
        type: "broken_selector"
      };
      this.userReports.push(report);
      const metricKey = `${platform}_${brokenSelector}`;
      this.performanceMetrics.set(metricKey, {
        lastUsed: Date.now(),
        status: "broken",
        failureCount: (this.performanceMetrics.get(metricKey)?.failureCount || 0) + 1,
        reportedAt: Date.now()
      });
      await this.persistData();
      console.log("🚨 Broken selector reported:", report);
      return true;
    } catch (error) {
      console.error("Error reporting broken selector:", error);
      return false;
    }
  }

  async getSelectorPerformance(platform, selector) {
    const metricKey = `${platform}_${selector}`;
    return this.performanceMetrics.get(metricKey) || {
      status: "unknown",
      failureCount: 0,
      successCount: 0
    };
  }

  async updateSelectorPerformance(platform, selector, success = true) {
    try {
      const metricKey = `${platform}_${selector}`;
      const current = this.performanceMetrics.get(metricKey) || {
        successCount: 0,
        failureCount: 0,
        firstUsed: Date.now()
      };
      if (success) {
        current.successCount++;
        current.status = "working";
      } else {
        current.failureCount++;
        current.status = "unreliable";
      }
      current.lastUsed = Date.now();
      current.lastStatus = success ? "success" : "failure";
      this.performanceMetrics.set(metricKey, current);
      if (Math.random() < 0.1) {
        await this.persistData();
      }
      return true;
    } catch (error) {
      console.error("Error updating selector performance:", error);
      return false;
    }
  }

  async persistData() {
    try {
      await chrome.storage.local.set({
        selectorUserReports: this.userReports.slice(-200),
        selectorPerformanceData: Object.fromEntries(this.performanceMetrics),
        adaptiveSelectorHistory: Object.fromEntries(this.selectorHistory)
      });
    } catch (error) {
      console.error("Error persisting selector data:", error);
    }
  }

  async cleanupOldData() {
    try {
      const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1e3;
      this.userReports = this.userReports.filter(
        (report) => report.timestamp > thirtyDaysAgo
      );
      const sixtyDaysAgo = Date.now() - 60 * 24 * 60 * 60 * 1e3;
      for (const [key, metric] of this.performanceMetrics) {
        if (metric.lastUsed < sixtyDaysAgo) {
          this.performanceMetrics.delete(key);
        }
      }
      await this.persistData();
      console.log("🧹 Selector database cleanup completed");
    } catch (error) {
      console.error("Error cleaning up selector data:", error);
    }
  }

  getStats() {
    return {
      totalReports: this.userReports.length,
      performanceMetrics: this.performanceMetrics.size,
      platformHistory: Array.from(this.selectorHistory.keys()).map((platform) => ({
        platform,
        historyCount: this.selectorHistory.get(platform).length
      })),
      recentReports: this.userReports.slice(-5)
    };
  }
};

var AdaptiveSystemManager = class {
  constructor() {
    this.adaptiveScanners = new Map();
    this.selectorDatabase = new SelectorDatabase();
    this.isInitialized = false;
  }

  async initialize() {
    if (this.isInitialized) return;
    try {
      await this.selectorDatabase.initialize();
      this.setupMessageHandlers();
      this.startPeriodicSync();
      this.isInitialized = true;
      console.log("🔄 AdaptiveSystemManager initialized successfully");
    } catch (error) {
      console.error("❌ AdaptiveSystemManager initialization failed:", error);
    }
  }

  setupMessageHandlers() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        // ✅ FIX: Ignore Offscreen messages completely (مطابق با دستور هوش دیگه)
        if (
          message.type === "PING" ||
          message.type === "GENERATE_PDF" ||
          message.type === "OFFSCREEN_READY" ||
          message.type === "GENERATE_PDF_V1" // ✅ اضافه کردن PDF v1
        ) {
          console.log('[Adaptive] 🔧 Offscreen message bypassed:', message.type);
          return;
        }

        if (message && (message.action === 'CSPRO_CS_HELLO' || message.type === 'CSPRO_CS_HELLO')) {
            console.log('[BG][Adaptive] CSPRO_CS_HELLO passed through');
            return;
        }

        // FIX: حذف چک TELEMETRY_STUB_NAMESPACE
        if (!message || typeof message !== "object") {
            console.warn("[BG] Ignored malformed message:", message);
            return;
        }

        if (message.type && !message.action) {
            console.log("[BG] Converting type to action:", message.type);
            message.action = message.type;
        }

        if (!message.action) {
            console.warn("[BG] Ignored message with no action:", message);
            return;
        }

        if (message.action === 'ROUTE_TO_MAIN_WORLD') {
            console.warn('[BG] Guardian routing not implemented:', message);
            sendResponse({ success: false, error: 'Routing not implemented' });
            return false;
        }

        if (message.action === 'MAIN_WORLD_RESPONSE') {
            console.warn('[BG] Main world response not implemented:', message);
            sendResponse({ success: false, error: 'Response handler not implemented' });
            return false;
        }

        if (message.action === 'PAGEWORLD_TO_ISOLATED') {
            chrome.tabs.sendMessage(sender.tab.id, {
                source: 'PAGEWORLD_TO_ISOLATED',
                correlationId: message.correlationId,
                payload: message.payload,
                timestamp: Date.now()
            }, (response) => {
                if (chrome.runtime.lastError) {
                    sendResponse({ success: false, error: chrome.runtime.lastError.message });
                } else {
                    sendResponse(response || { success: false, error: 'No response' });
                }
            });
            return true;
        }

        if (message.action === 'LOAD_SCAN_LAYER') {
            console.log("[BG] LOAD_SCAN_LAYER request received:", {
                tabId: sender?.tab?.id,
                url: sender?.tab?.url,
                world: message.world || "ISOLATED"
            });
            
            (async () => {
                try {
                    await chrome.scripting.executeScript({
                        target: { tabId: sender.tab.id },
                        files: ["modules/scan-layer-loader.js"],
                        world: "ISOLATED"
                    });
                    
                    sendResponse({ 
                        success: true, 
                        message: "ScanLayer loader injected successfully",
                        timestamp: Date.now() 
                    });
                } catch (error) {
                    console.error("[BG] ScanLayer injection failed:", error);
                    sendResponse({ 
                        success: false, 
                        error: error.message,
                        timestamp: Date.now() 
                    });
                }
            })();
            return true;
        }

        this.handleIncomingMessage(message, sender, sendResponse);
        return true;
    });
  }

  async handleIncomingMessage(message, sender, sendResponse) {
    try {
      switch (message.action) {
        case "SELECTOR_CONFIG_UPDATED":
          await this.handleSelectorUpdate(message, sender.tab?.id);
          sendResponse({ success: true });
          break;
        case "REPORT_BROKEN_SELECTOR":
          await this.handleBrokenSelectorReport(message);
          sendResponse({ success: true });
          break;
        case "GET_ADAPTIVE_CONFIG":
          const config = await this.getAdaptiveConfig(message.platform);
          sendResponse({ success: true, config });
          break;
        default:
          const response = await actionHandlerManager.handle(message.action, message, sender);
          sendResponse(response);
      }
    } catch (error) {
      console.error("Error handling message:", error);
      sendResponse({ success: false, error: error.message });
    }
  }

  async handleSelectorUpdate(message, tabId) {
    console.log("🔄 Selector config updated:", {
      platform: message.platform,
      tabId,
      timestamp: message.timestamp
    });
    await this.selectorDatabase.reportSelectorUpdate(
      message.platform,
      message.oldSelector,
      message.newSelector
    );
    await this.updateGlobalConfigIfNeeded(message.platform, message.newSelector);
  }

  async handleBrokenSelectorReport(message) {
    console.log("🚨 Broken selector reported:", message);
    await this.selectorDatabase.reportBrokenSelector(
      message.platform,
      message.brokenSelector,
      message.alternativeSelector
    );
    await this.notifyOtherTabs(message.platform);
  }

  async notifyOtherTabs(platform) {
    try {
      if (!platform) return;

      const tabs = await chrome.tabs.query({});
      tabs.forEach((tab) => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            action: "SELECTOR_CONFIG_CHANGED",
            platform,
            timestamp: Date.now()
          }).catch(() => {
            // Tab may not have content script
          });
        }
      });
    } catch (error) {
      console.warn("Could not notify all tabs:", error);
    }
  }

  async updateGlobalConfigIfNeeded(platform, newSelector) {
    const shouldUpdate = await this.evaluateSelectorQuality(platform, newSelector);
    if (shouldUpdate) {
      console.log("🎯 Updating global config with improved selector:", newSelector);
    }
  }

  async evaluateSelectorQuality(platform, selector) {
    return selector && selector.length > 0 && selector.length < 100;
  }

  async getAdaptiveConfig(platform) {
    try {
      const result = await chrome.storage.local.get(["adaptiveSelectors"]);
      const config = result.adaptiveSelectors || {};
      return config[platform] || null;
    } catch (error) {
      console.error("Error getting adaptive config:", error);
      return null;
    }
  }

  startPeriodicSync() {
    setInterval(async () => {
      await this.performMaintenance();
    }, 6 * 60 * 60 * 1e3);
  }

  async performMaintenance() {
    try {
      console.log("🔧 Performing adaptive system maintenance...");
      await this.cleanupOldReports();
      await this.optimizeStorage();
    } catch (error) {
      console.error("Maintenance error:", error);
    }
  }

  async cleanupOldReports() {
    try {
      const result = await chrome.storage.local.get(["selectorUserReports"]);
      const reports = result.selectorUserReports || [];
      const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1e3;
      const recentReports = reports.filter((report) => report.timestamp > cutoff);
      await chrome.storage.local.set({ selectorUserReports: recentReports });
    } catch (error) {
      console.error("Cleanup error:", error);
    }
  }

  async optimizeStorage() {
    try {
      const result = await chrome.storage.local.get(["adaptiveSelectors"]);
      const config = result.adaptiveSelectors || {};
      const activePlatforms = ["chatgpt", "deepseek", "claude", "telegram", "whatsapp"];
      const optimizedConfig = {};
      for (const platform of activePlatforms) {
        if (config[platform]) {
          optimizedConfig[platform] = config[platform];
        }
      }
      await chrome.storage.local.set({ adaptiveSelectors: optimizedConfig });
    } catch (error) {
      console.error("Storage optimization error:", error);
    }
  }

  getSystemStatus() {
    return {
      isInitialized: this.isInitialized,
      activeScanners: this.adaptiveScanners.size,
      databaseReports: this.selectorDatabase.userReports.length
    };
  }
};

var SimplifiedMemoryManager = class {
    constructor() {
        this.store = new Map();
        this.categories = ['scan', 'session', 'config', 'conversations', 'offscreen'];
        this.setupCleanup();
        console.log("✅ SimplifiedMemoryManager initialized");
    }
    
    set(category, key, value, ttl = null) {
        const fullKey = `${category}_${key}`;
        this.store.set(fullKey, {
            value,
            timestamp: Date.now(),
            ttl,
            category
        });
        return true;
    }
    
    get(category, key) {
        const fullKey = `${category}_${key}`;
        const item = this.store.get(fullKey);
        if (!item) return null;
        
        if (item.ttl && Date.now() - item.timestamp > item.ttl) {
            this.store.delete(fullKey);
            return null;
        }
        
        return item.value;
    }
    
    setupCleanup() {
        setInterval(() => {
            this.cleanupExpired();
        }, 300000);
    }
    
    cleanupExpired() {
        const now = Date.now();
        let cleaned = 0;
        
        for (const [key, item] of this.store) {
            if (item.ttl && now - item.timestamp > item.ttl) {
                this.store.delete(key);
                cleaned++;
            }
        }
        
        if (cleaned > 0) {
            console.log(`🧹 Memory cleanup: ${cleaned} expired items removed`);
        }
        
        if (this.store.size > 5000) {
            const entries = Array.from(this.store.entries());
            entries.sort((a, b) => a[1].timestamp - b[1].timestamp);
            
            const toRemove = entries.slice(0, 1000);
            toRemove.forEach(([key]) => this.store.delete(key));
            
            console.log(`📉 Memory trimmed: 1000 old items removed`);
        }
        
        return cleaned;
    }
    
    getStats() {
        const stats = {
            total: this.store.size,
            byCategory: {}
        };
        
        for (const [key, item] of this.store) {
            const cat = item.category;
            stats.byCategory[cat] = (stats.byCategory[cat] || 0) + 1;
        }
        
        return stats;
    }
    
    clearCategory(category) {
        let removed = 0;
        for (const [key, item] of this.store) {
            if (item.category === category) {
                this.store.delete(key);
                removed++;
            }
        }
        return removed;
    }
};

var SecureMessageValidator = class {
  static validateRuntimeMessage(message, sender) {
    if (message.type && !message.action) {
        console.log("[Validator] Accepting message with type:", message.type);
        return true;
    }
    
    if (!message || typeof message !== "object") {
      throw new Error("Message must be an object");
    }
    
    const required = ["action", "timestamp"];
    const missing = required.filter((field) => !(field in message));
    if (missing.length > 0) {
      throw new Error(`Missing required fields: ${missing.join(", ")}`);
    }
    
    if (typeof message.action !== "string" || message.action.length > 100) {
      throw new Error("Invalid action format");
    }
    
    const dangerousPatterns = [/eval/i, /function/i, /constructor/i, /prototype/i, /script/i, /import/i];
    for (const pattern of dangerousPatterns) {
      if (pattern.test(message.action)) {
        throw new Error(`Potentially dangerous action: ${message.action}`);
      }
    }
    
    const now = Date.now();
    const messageTime = message.timestamp;
    if (Math.abs(now - messageTime) > 3e5) {
      throw new Error(`Message timestamp out of range: ${message.action}`);
    }
    
    if (sender && !this.isValidSender(sender)) {
      throw new Error("Invalid message sender");
    }
    
    if (message.data && typeof message.data === "object") {
      message.data = this.sanitizePayload(message.data);
    }
    
    return true;
  }

  static isValidSender(sender) {
    if (sender.tab) {
      return this.isValidTab(sender.tab);
    }
    if (sender.url) {
      return this.isValidUrl(sender.url);
    }
    return false;
  }

  static isValidTab(tab) {
    return tab.id && typeof tab.id === "number" && tab.id > 0;
  }

  static isValidUrl(url) {
    try {
      const parsed = new URL(url);
      const allowedDomains = [
        "chrome-extension://",
        "https://chat.deepseek.com",
        "https://chat.openai.com",
        "https://claude.ai"
      ];
      return allowedDomains.some((domain) => url.startsWith(domain));
    } catch {
      return false;
    }
  }

  static sanitizePayload(data) {
    const sanitized = {};
    const MAX_STRING_LENGTH = 1e4;
    const MAX_OBJECT_DEPTH = 5;
    const sanitizeValue = (value, depth = 0) => {
      if (depth > MAX_OBJECT_DEPTH)
        return "[MAX_DEPTH_EXCEEDED]";
      if (typeof value === "string") {
        return value.substring(0, MAX_STRING_LENGTH).replace(/[<>]/g, "").replace(/javascript:/gi, "").replace(/vbscript:/gi, "");
      } else if (typeof value === "number" && isFinite(value)) {
        return value;
      } else if (typeof value === "boolean") {
        return value;
      } else if (value === null) {
        return null;
      } else if (Array.isArray(value)) {
        return value.map((item) => sanitizeValue(item, depth + 1));
      } else if (typeof value === "object") {
        const cleanObj = {};
        for (const [key, val] of Object.entries(value)) {
          if (typeof key === "string" && key.length <= 100) {
            cleanObj[key] = sanitizeValue(val, depth + 1);
          }
        }
        return cleanObj;
      }
      return "[UNSUPPORTED_TYPE]";
    };
    for (const [key, value] of Object.entries(data)) {
      if (typeof key === "string" && key.length <= 100) {
        sanitized[key] = sanitizeValue(value);
      }
    }
    return sanitized;
  }
};

var ResilientAsyncExecutor = class {
  constructor() {
    this.operations = new Map();
    this.maxRetries = 3;
    this.retryDelay = 1e3;
    this.operationTimeout = 3e4;
  }

  async executeWithRetry(operationName, asyncFn, context = {}) {
    let lastError;
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const result = await this.executeWithTimeout(operationName, asyncFn, context);
        console.log(`✅ ${operationName} succeeded on attempt ${attempt}`);
        return result;
      } catch (error) {
        lastError = error;
        console.warn(`⚠️ ${operationName} failed on attempt ${attempt}:`, error.message);
        if (attempt < this.maxRetries) {
          await this.delay(this.retryDelay * attempt);
        }
      }
    }
    throw new Error(`${operationName} failed after ${this.maxRetries} attempts: ${lastError.message}`);
  }

  async executeWithTimeout(operationName, asyncFn, context = {}) {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new Error(`${operationName} timeout after ${this.operationTimeout}ms`));
      }, this.operationTimeout);
      asyncFn().then(
        (result) => {
          clearTimeout(timeoutId);
          resolve(result);
        },
        (error) => {
          clearTimeout(timeoutId);
          reject(error);
        }
      );
    });
  }

  async delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  trackOperation(operationId, operation) {
    this.operations.set(operationId, {
      operation,
      startTime: Date.now(),
      status: "running"
    });
  }

  completeOperation(operationId) {
    const op = this.operations.get(operationId);
    if (op) {
      op.status = "completed";
      op.endTime = op.startTime;
      op.duration = op.endTime - op.startTime;
    }
  }
};

var QuantumResyncManager = class {
  constructor() {
    this.contentScripts = new Map();
    this.resyncIntervals = new Map();
    this.maxResyncAttempts = 5;
    this.healthCheckInterval = 3e4;
    this.connectionTimeout = 45e3;
  }

  registerContentScript(tabId, securityToken) {
    const scriptInfo = {
      tabId,
      securityToken,
      lastPing: Date.now(),
      isConnected: true,
      resyncAttempts: 0,
      connectionEstablished: Date.now(),
      messageCount: 0
    };
    this.contentScripts.set(tabId, scriptInfo);
    this.startHealthMonitoring(tabId);
    console.log(`🔗 QuantumResync: Content script registered for tab ${tabId}`);
  }

  unregisterContentScript(tabId) {
    this.stopHealthMonitoring(tabId);
    this.contentScripts.delete(tabId);
    console.log(`🔗 QuantumResync: Content script unregistered for tab ${tabId}`);
  }

  startHealthMonitoring(tabId) {
    this.stopHealthMonitoring(tabId);
    const intervalId = setInterval(() => {
      this.checkContentScriptHealth(tabId);
    }, this.healthCheckInterval);
    this.resyncIntervals.set(tabId, intervalId);
  }

  stopHealthMonitoring(tabId) {
    const intervalId = this.resyncIntervals.get(tabId);
    if (intervalId) {
      clearInterval(intervalId);
      this.resyncIntervals.delete(tabId);
    }
  }

  async checkContentScriptHealth(tabId) {
    const scriptInfo = this.contentScripts.get(tabId);
    if (!scriptInfo) return;

    const timeSinceLastPing = Date.now() - scriptInfo.lastPing;
    
    if (timeSinceLastPing > this.connectionTimeout && scriptInfo.resyncAttempts <= this.maxResyncAttempts) {
        scriptInfo.resyncAttempts++;
        console.log(`🔍 QuantumResync: Checking tab ${tabId} health, attempt ${scriptInfo.resyncAttempts}`);
        
        try {
            const tab = await chrome.tabs.get(tabId);
            
            if (tab.status === 'complete' && tab.url && this.isAllowedUrl(tab.url)) {
                await this.attemptResync(tabId);
            } else {
                console.log(`📭 Tab ${tabId} not ready or invalid URL: ${tab.url}`);
                scriptInfo.resyncAttempts = Math.max(0, scriptInfo.resyncAttempts - 1);
            }
        } catch (error) {
            console.log(`📭 Tab ${tabId} inaccessible, removing from monitoring:`, error.message);
            this.unregisterContentScript(tabId);
        }
    }
  }

    isAllowedUrl(url) {
    try {
      const allowedDomains = [
        'chat.deepseek.com',
        'chat.openai.com', 
        'claude.ai',
        'web.telegram.org'
      ];
      const urlObj = new URL(url);
      return allowedDomains.some(domain => urlObj.hostname.includes(domain));
    } catch {
      return false;
    }
  }

  async attemptResync(tabId) {
    try {
      const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Resync timeout')), 5000)
      );
      
      const resyncPromise = chrome.tabs.sendMessage(tabId, {
        action: "QUANTUM_RESYNC",
        data: {
          timestamp: Date.now(),
          attempt: this.contentScripts.get(tabId)?.resyncAttempts || 1,
          type: "health_check"
        }
      });
      
      await Promise.race([resyncPromise, timeoutPromise]);
      console.log(`✅ QuantumResync: Resync successful for tab ${tabId}`);
      
    } catch (error) {
      console.warn(`🔁 QuantumResync: Resync failed for tab ${tabId}:`, error.message);
      
      const scriptInfo = this.contentScripts.get(tabId);
      if (scriptInfo) {
        const backoffDelay = Math.min(1000 * Math.pow(2, scriptInfo.resyncAttempts - 1), 30000);
        console.log(`⏳ Next resync for tab ${tabId} in ${backoffDelay}ms`);
      }
    }
  }

  async setupTabCleanup() {
    chrome.tabs.onRemoved.addListener((tabId) => {
      if (this.contentScripts.has(tabId)) {
        console.log(`🗑️ Tab ${tabId} closed, cleaning up QuantumResync`);
        this.unregisterContentScript(tabId);
      }
    });
  }

  updateContentScriptPing(tabId) {
    const scriptInfo = this.contentScripts.get(tabId);
    if (scriptInfo) {
      scriptInfo.lastPing = Date.now();
      scriptInfo.resyncAttempts = 0;
      scriptInfo.isConnected = true;
      scriptInfo.messageCount++;
    }
  }

  notifyConnectionLost(tabId) {
    if (globalThis.backgroundManager) {
      globalThis.backgroundManager.handleConnectionLost(tabId);
    }
  }

  getConnectionStatus() {
    const status = {};
    for (const [tabId, info] of this.contentScripts) {
      status[tabId] = {
        isConnected: info.isConnected,
        lastPing: info.lastPing,
        resyncAttempts: info.resyncAttempts,
        connectionAge: Date.now() - info.connectionEstablished,
        messageCount: info.messageCount
      };
    }
    return status;
  }

  getOverallHealth() {
    const connections = Array.from(this.contentScripts.values());
    const connected = connections.filter((c) => c.isConnected).length;
    const total = connections.length;
    return {
      connected,
      total,
      healthPercentage: total > 0 ? Math.round(connected / total * 100) : 100,
      needsAttention: connections.some((c) => c.resyncAttempts > 0)
    };
  }
};

var ConversationManager = class {
  constructor() {
    this.conversations = [];
    this.maxConversations = 1000;
    this.isInitialized = false;
  }
  
  async initialize() {
    if (this.isInitialized) return;
    
    try {
      const result = await chrome.storage.local.get([
        "savedConversations", 
        "scanResults", 
        "scanlayer_conversations",
        "last_scanlayer_data"
      ]);
      
      console.log("[ConversationManager] Storage check:", {
        scanlayer: result.scanlayer_conversations?.length || 0,
        saved: result.savedConversations?.length || 0,
        scanResults: result.scanResults?.length || 0,
        lastScanlayer: result.last_scanlayer_data ? 'yes' : 'no'
      });
      
      // اولویت با scanlayer_conversations است
      if (result.scanlayer_conversations && result.scanlayer_conversations.length > 0) {
        this.conversations = result.scanlayer_conversations;
        console.log(`✅ ConversationManager initialized with ${this.conversations.length} scanlayer conversations`);
      } 
      // سپس savedConversations
      else if (result.savedConversations && result.savedConversations.length > 0) {
        this.conversations = result.savedConversations;
        console.log(`✅ ConversationManager initialized with ${this.conversations.length} saved conversations`);
      }
      // در نهایت scanResults
      else if (result.scanResults && result.scanResults.length > 0) {
        console.log("🔄 Converting scanResults to conversations...");
        this.conversations = result.scanResults.map((scan, index) => ({
          id: `conv_${Date.now()}_${index}`,
          site: scan.platform || "deepseek.com",
          url: scan.url || window.location.href,
          title: `Chat ${index + 1}`,
          messages: scan.messages || [],
          messageCount: scan.messages?.length || 0,
          savedAt: scan.timestamp || Date.now(),
          scannedAt: scan.timestamp || Date.now()
        }));
        console.log(`✅ Converted ${this.conversations.length} scan results to conversations`);
      }
      
      this.isInitialized = true;
      console.log("✅ ConversationManager initialized with", this.conversations.length, "conversations");
    } catch (error) {
      console.error("❌ ConversationManager initialization failed:", error);
      this.conversations = [];
      this.isInitialized = true;
    }
  }
  
  async saveConversation(conversation) {
    try {
      if (!conversation || !conversation.id || !conversation.messages || conversation.messages.length === 0) {
        throw new Error("Invalid conversation data");
      }
      
      if (!conversation.savedAt) {
        conversation.savedAt = Date.now();
      }
      
      const existingIndex = this.conversations.findIndex(c => c.id === conversation.id);
      if (existingIndex !== -1) {
        this.conversations[existingIndex] = conversation;
      } else {
        this.conversations.push(conversation);
      }
      
      if (this.conversations.length > this.maxConversations) {
        this.conversations = this.conversations.slice(-this.maxConversations);
      }
      
      // ذخیره در دو مکان برای سازگاری
      await chrome.storage.local.set({
        savedConversations: this.conversations,
        scanlayer_conversations: this.conversations
      });
      
      if (memoryManager) {
        memoryManager.set("conversations", conversation.id, conversation, 86400000);
      }
      
      console.log("💾 Conversation saved:", {
        id: conversation.id,
        messages: conversation.messages.length,
        site: conversation.site
      });
      
      return {
        success: true,
        conversationId: conversation.id,
        savedAt: conversation.savedAt,
        totalConversations: this.conversations.length
      };
      
    } catch (error) {
      console.error("❌ Error saving conversation:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  async getConversations(filter = {}) {
    await this.initialize();
    
    let filtered = [...this.conversations];
    
    if (filter.site) {
      filtered = filtered.filter(c => c.site === filter.site);
    }
    
    if (filter.since) {
      filtered = filtered.filter(c => c.savedAt >= filter.since);
    }
    
    filtered.sort((a, b) => b.savedAt - a.savedAt);
    
    if (filter.limit && filtered.length > filter.limit) {
      filtered = filtered.slice(0, filter.limit);
    }
    
    return {
      success: true,
      conversations: filtered,
      totalCount: filtered.length,
      totalAll: this.conversations.length
    };
  }
  
  async getConversation(id) {
    await this.initialize();
    
    const conversation = this.conversations.find(c => c.id === id);
    
    if (conversation) {
      return {
        success: true,
        conversation: conversation
      };
    } else {
      const memConversation = memoryManager?.get("conversations", id);
      if (memConversation) {
        return {
          success: true,
          conversation: memConversation,
          fromMemory: true
        };
      }
      
      return {
        success: false,
        error: "Conversation not found"
      };
    }
  }
  
  async deleteConversation(id) {
    try {
      const initialLength = this.conversations.length;
      this.conversations = this.conversations.filter(c => c.id !== id);
      
      if (this.conversations.length < initialLength) {
        await chrome.storage.local.set({
          savedConversations: this.conversations,
          scanlayer_conversations: this.conversations
        });
        
        if (memoryManager) {
          memoryManager.clearCategory("conversations");
        }
        
        return {
          success: true,
          deleted: true,
          totalConversations: this.conversations.length
        };
      } else {
        return {
          success: false,
          error: "Conversation not found"
        };
      }
      
    } catch (error) {
      console.error("❌ Error deleting conversation:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  async exportConversations(format = "json") {
    await this.initialize();
    
    try {
      const exportData = {
        version: "1.0",
        exportDate: new Date().toISOString(),
        totalConversations: this.conversations.length,
        conversations: this.conversations
      };
      
      return {
        success: true,
        data: exportData,
        format: format
      };
      
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  getStats() {
    const sites = {};
    this.conversations.forEach(conv => {
      sites[conv.site] = (sites[conv.site] || 0) + 1;
    });
    
    return {
      totalConversations: this.conversations.length,
      sites: sites,
      lastSaved: this.conversations.length > 0 
        ? new Date(Math.max(...this.conversations.map(c => c.savedAt))).toISOString()
        : null
    };
  }
  
  async cleanupOldConversations(days = 30) {
    try {
      const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
      const initialCount = this.conversations.length;
      
      this.conversations = this.conversations.filter(c => c.savedAt >= cutoff);
      
      if (this.conversations.length < initialCount) {
        await chrome.storage.local.set({
          savedConversations: this.conversations,
          scanlayer_conversations: this.conversations
        });
        
        console.log(`🧹 Cleaned up ${initialCount - this.conversations.length} old conversations`);
        
        return {
          success: true,
          cleaned: initialCount - this.conversations.length,
          remaining: this.conversations.length
        };
      }
      
      return {
        success: true,
        cleaned: 0,
        message: "No old conversations to clean"
      };
    } catch (error) {
      console.error("❌ Error cleaning up conversations:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// ==================== 🆕 تابع کمکی: Force File Download (MV3-SAFE VERSION) ====================
async function forceFileDownload({ content, fileName, mimeType }) {
    try {
        if (!content || typeof content !== "string" || content.length === 0) {
            throw new Error("Download aborted: empty content");
        }

        const base64 = btoa(unescape(encodeURIComponent(content)));
        const dataUrl = `data:${mimeType};base64,${base64}`;

        console.log("[BG][DOWNLOAD] 📦 DataURL prepared", {
            fileName,
            mimeType,
            size: content.length
        });

        await new Promise((resolve, reject) => {
            chrome.downloads.download({
                url: dataUrl,
                filename: fileName,
                saveAs: true
            }, (downloadId) => {
                if (chrome.runtime.lastError) {
                    console.error("[BG][DOWNLOAD] ❌ Download failed:", chrome.runtime.lastError);
                    reject(chrome.runtime.lastError);
                } else {
                    console.log("[BG][DOWNLOAD] ✅ Download started, id:", downloadId);
                    resolve(downloadId);
                }
            });
        });

        return true;

    } catch (error) {
        console.error("[BG][DOWNLOAD] ❌ Download failed:", error);
        throw error;
    }
}

// ==================== 🆕 تابع کمکی: Guardian Routing (اضافه شده برای رفع خطا) ====================
function handleGuardianRouting(message, sender, sendResponse) {
    console.warn('[BG] Guardian routing not implemented:', message);
    sendResponse({ success: false, error: 'Routing not implemented' });
    return false;
}

// ==================== 🆕 تابع کمکی: Main World Response (اضافه شده برای رفع خطا) ====================
function handleMainWorldResponse(message, sender, sendResponse) {
    console.warn('[BG] Main world response not implemented:', message);
    sendResponse({ success: false, error: 'Response handler not implemented' });
    return false;
}

// ==================== 🆕 ExportFormatHelpers - Single Source of Truth ====================
class ExportFormatHelpers {
  constructor() {
    console.log('[ExportFormatHelpers] ✅ Initialized - JSON v1.1 as single source of truth');
  }

  // ==================== CORE: Normalize Message to Blocks ====================
  normalizeMessageToBlocks(message) {
    console.log('[ExportFormatHelpers][JSON] 🔄 Normalizing message to blocks v1.1', {
        messageId: message.id,
        contentLength: message.content?.length || 0
    });
    
    const blocks = [];
    let content = message.content || '';
    
    // Backward compatibility: اگر قبلاً blocks داشته باشد، استفاده کن
    if (Array.isArray(message.blocks) && message.blocks.length > 0) {
      console.log('[ExportFormatHelpers][JSON] ✅ Message already has blocks, cleaning metadata...');
      
      // 🔴 STEP 2: Remove forbidden fields from blocks
      return message.blocks.map(block => {
        const cleanBlock = { ...block };
        // ❌ REMOVE forbidden fields from blocks
        delete cleanBlock.timestamp;
        delete cleanBlock.role;
        delete cleanBlock.index;
        delete cleanBlock.total;
        
        // 🔴 STEP 3: Ensure proper block types
        if (cleanBlock.type === 'code') {
          // 🔴 STEP 4: Code block detection during generation ONLY
          if (cleanBlock.content && cleanBlock.content.includes('```')) {
            const lines = cleanBlock.content.split('\n');
            let language = 'text';
            let codeContent = cleanBlock.content;
            
            if (lines[0].startsWith('```')) {
              const langMatch = lines[0].match(/^```(\w+)/);
              if (langMatch) {
                language = langMatch[1];
              }
              codeContent = lines.slice(1, -1).join('\n');
            }
            
            return {
              type: 'code',
              language: language,
              content: codeContent.trim()
            };
          }
        }
        
        // Ensure minimal block structure
        return {
          type: cleanBlock.type || 'text',
          text: cleanBlock.text || cleanBlock.content || '',
          ...(cleanBlock.type === 'code' ? { 
            language: cleanBlock.language || 'text',
            content: cleanBlock.content || cleanBlock.text || '' 
          } : {})
        };
      });
    }
    
    // 🔴 STEP 3: Code Block Detection (MANDATORY) - ONLY during generation
    if (content.includes('```')) {
      console.log('[ExportFormatHelpers][JSON] 🔍 Detecting code blocks...');
      
      const codeBlockRegex = /```(\w*)\n([\s\S]*?)```/g;
      let lastIndex = 0;
      let match;
      
      while ((match = codeBlockRegex.exec(content)) !== null) {
        const beforeCode = content.substring(lastIndex, match.index);
        
        // Add text block before code
        if (beforeCode.trim()) {
          blocks.push({
            type: 'text',
            text: beforeCode.trim()
          });
        }
        
        // Add code block
        blocks.push({
          type: 'code',
          language: match[1] || 'text',
          content: match[2].trim()
        });
        
        lastIndex = match.index + match[0].length;
      }
      
      // Add remaining text after last code block
      const afterCode = content.substring(lastIndex);
      if (afterCode.trim()) {
        blocks.push({
          type: 'text',
          text: afterCode.trim()
        });
      }
    } else {
      // No code blocks found
      blocks.push({
        type: 'text',
        text: content
      });
    }
    
    return blocks;
  }

  // ==================== CORE: Normalize Conversation ====================
  normalizeConversation(conversation, index) {
    console.log('[ExportFormatHelpers][JSON] 🔄 Normalizing conversation v1.1', {
        conversationId: conversation.id,
        index: index,
        messageCount: conversation.messages?.length || 0
    });
    
    // 🔴 STEP 2: LOCK JSON v1.1 CONTRACT
    const normalized = {
        id: conversation.id || `conv_${Date.now()}_${index}`,
        index: index + 1, // 🔴 REQUIRED
        title: conversation.title || `Conversation ${index + 1}`,
        site: conversation.site || conversation.platform || 'unknown',
        url: conversation.url || 'unknown',
        timestamp: conversation.timestamp || conversation.savedAt || Date.now(),
        savedAt: conversation.savedAt || conversation.timestamp || Date.now(),
        messageCount: conversation.messages?.length || 0, // 🔴 REQUIRED
        language: this.detectLanguage(conversation.messages || []),
        direction: this.detectDirection(conversation.messages || []),
        messages: []
    };
    
    // نرمال‌سازی پیام‌ها با ساختار blocks
    if (conversation.messages && conversation.messages.length > 0) {
      normalized.messages = conversation.messages.map((msg, msgIndex) => {
        // 🔴 STEP 1: Enforce canonical blocks[] (NO content field)
        const blocks = this.normalizeMessageToBlocks(msg);
        
        return {
          id: msg.id || `msg_${Date.now()}_${msgIndex}`,
          index: msgIndex + 1, // 🔴 REQUIRED
          total: conversation.messages.length, // 🔴 REQUIRED
          role: msg.role || 'unknown',
          timestamp: msg.timestamp || Date.now(),
          blocks: blocks
          // ❌ حذف کامل فیلد content - blocks[] تنها منبع حقیقت است
        };
      });
    }
    
    return normalized;
  }

  // ==================== HELPER: Detect Language ====================
  detectLanguage(messages) {
    if (!messages || messages.length === 0) return 'en-US';
    
    const sampleText = messages.slice(0, 3).map(m => m.content || '').join(' ');
    const persianArabicRegex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
    const hasPersianArabic = persianArabicRegex.test(sampleText);
    
    return hasPersianArabic ? 'fa-IR' : 'en-US';
  }

  // ==================== HELPER: Detect Direction ====================
  detectDirection(messages) {
    const language = this.detectLanguage(messages);
    return language === 'fa-IR' ? 'rtl' : 'ltr';
  }

  // ==================== CORE: Generate JSON v1.1 ====================
  generateJSON(conversations = [], scanData = []) {
    console.log('[ExportFormatHelpers][JSON] 🔥 JSON v1.1 SINGLE SOURCE GENERATOR EXECUTED');
    
    // نرمال‌سازی مکالمات
    const normalizedConversations = conversations.map((conv, index) => 
      this.normalizeConversation(conv, index)
    );
    
    // محاسبه آمار
    const totalMessages = normalizedConversations.reduce((sum, conv) => sum + conv.messageCount, 0);
    const language = this.detectLanguage(normalizedConversations.flatMap(c => c.messages));
    const direction = this.detectDirection(normalizedConversations.flatMap(c => c.messages));
    
    const siteStats = {};
    normalizedConversations.forEach(conv => {
      siteStats[conv.site] = (siteStats[conv.site] || 0) + 1;
    });
    
    // 🔴 STEP 2: LOCK JSON v1.1 CONTRACT - root level
    const jsonData = {
      version: "1.1",
      format: "json.v1.1",
      generatedAt: new Date().toISOString(),
      system: "ChatSavePro QuantumStage v3.9.8",
      language: language,
      direction: direction,
      
      statistics: {
        totalConversations: normalizedConversations.length,
        totalMessages: totalMessages,
        sites: siteStats,
        timeRange: {
          oldest: normalizedConversations.reduce((oldest, conv) => 
            Math.min(oldest, conv.timestamp), Date.now()),
          newest: normalizedConversations.reduce((newest, conv) => 
            Math.max(newest, conv.timestamp), 0),
          durationDays: 0
        }
      },
      
      conversations: normalizedConversations,
      
      // 🔴 اصلاح: scanData فقط زمانی اضافه شود که دارای داده باشد
      ...(scanData && scanData.length > 0 ? {
        scanData: scanData.map(scan => ({
          type: scan.type || "scan_result",
          timestamp: scan.timestamp || Date.now(),
          site: scan.site || scan.platform || "unknown",
          messageCount: scan.messageCount || scan.messages?.length || 0,
          data: scan.data || { messages: scan.messages?.length || 0 }
        }))
      } : {}),
      
      exportMetadata: {
        exportId: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        exportedBy: "ChatSavePro Export System",
        schemaVersion: "1.1",
        blockTypes: ["text", "code"],
        note: "JSON v1.1 is the Single Source of Truth"
      }
    };
    
    if (jsonData.statistics.timeRange.oldest && jsonData.statistics.timeRange.newest) {
      const durationMs = jsonData.statistics.timeRange.newest - jsonData.statistics.timeRange.oldest;
      jsonData.statistics.timeRange.durationDays = Math.ceil(durationMs / (1000 * 60 * 60 * 24));
    }
    
    console.log('[ExportFormatHelpers][JSON] ✅ v1.1 block structure generated', {
      conversations: normalizedConversations.length,
      totalMessages: totalMessages,
      blockBased: true,
      scanDataIncluded: scanData && scanData.length > 0
    });
    
    return JSON.stringify(jsonData, null, 2);
  }

  // ==================== RENDERER: Generate HTML (Chat-Like Design) ====================
  renderHTMLFromJSON(jsonData) {
    console.log('[ExportFormatHelpers][HTML] 🔥 HTML BLOCK-BASED RENDERER EXECUTED (from JSON v1.1)');
    
    const data = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
    const { conversations, statistics, language, direction } = data;
    
    const isRTL = direction === 'rtl';
    const fontFamily = isRTL ? "'Vazirmatn', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" : 
                               "'Segoe UI', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Arial, sans-serif'";
    
    const headerText = isRTL ? 'گفتگوی ذخیره شده' : 'Saved Conversation';
    const exportDateText = isRTL ? 'تاریخ صادرات' : 'Export Date';
    const conversationsText = isRTL ? 'مکالمات' : 'Conversations';
    const messagesText = isRTL ? 'پیام‌ها' : 'Messages';
    const roleLabels = {
      'user': isRTL ? 'کاربر' : 'User',
      'assistant': isRTL ? 'دستیار' : 'Assistant',
      'system': isRTL ? 'سیستم' : 'System'
    };
    
    return `<!DOCTYPE html>
<html lang="${language}" dir="${direction}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${isRTL ? 'گفتگوی ذخیره شده - ChatSavePro' : 'Saved Conversation - ChatSavePro'}</title>
    <style>
        /* Reset & Base */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: ${fontFamily};
            background: ${isRTL ? '#f5f5f5' : '#f7f7f8'};
            color: ${isRTL ? '#1f2937' : '#374151'};
            line-height: 1.6;
            direction: ${direction};
            text-align: ${isRTL ? 'right' : 'left'};
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        /* Container */
        .chat-container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            min-height: 100vh;
            box-shadow: ${isRTL ? 
                '-10px 0 30px rgba(0,0,0,0.05), 10px 0 30px rgba(0,0,0,0.05)' : 
                '10px 0 30px rgba(0,0,0,0.05), -10px 0 30px rgba(0,0,0,0.05)'};
            position: relative;
        }
        
        /* Header - Similar to Chat Websites */
        .chat-header {
            background: ${isRTL ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 
                                   'linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)'};
            color: white;
            padding: ${isRTL ? '20px 30px 20px 20px' : '20px 20px 20px 30px'};
            border-bottom: 1px solid rgba(255,255,255,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(10px);
        }
        
        .chat-header h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .chat-header .icon {
            width: 24px;
            height: 24px;
            background: rgba(255,255,255,0.2);
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        
        .chat-header .stats {
            display: flex;
            gap: 20px;
            margin-top: 10px;
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .stat-badge {
            background: rgba(255,255,255,0.2);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
        }
        
        /* Conversation List */
        .conversations-list {
            padding: 30px;
        }
        
        .conversation-section {
            margin-bottom: 40px;
            background: white;
            border-radius: 12px;
            border: 1px solid ${isRTL ? '#e5e7eb' : '#e5e7eb'};
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        
        .conversation-meta {
            padding: 20px;
            background: ${isRTL ? '#f9fafb' : '#f9fafb'};
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .conversation-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: ${isRTL ? '#1f2937' : '#1f2937'};
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .conversation-badge {
            background: ${isRTL ? '#10b981' : '#10b981'};
            color: white;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .conversation-info {
            font-size: 0.9rem;
            color: #6b7280;
            display: flex;
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        /* Messages - Chat Interface Style */
        .messages-container {
            padding: 0;
        }
        
        .message {
            padding: 24px;
            border-bottom: 1px solid #f3f4f6;
            transition: background 0.2s;
        }
        
        .message:hover {
            background: ${isRTL ? '#fafafa' : '#fafafa'};
        }
        
        .message:last-child {
            border-bottom: none;
        }
        
        /* User Message */
        .message-user {
            background: ${isRTL ? '#f8fafc' : '#f8fafc'};
            border-${isRTL ? 'right' : 'left'}: 4px solid #3b82f6;
        }
        
        /* Assistant Message */
        .message-assistant {
            background: ${isRTL ? '#f0f9ff' : '#f0f9ff'};
            border-${isRTL ? 'right' : 'left'}: 4px solid #10b981;
        }
        
        /* System Message */
        .message-system {
            background: ${isRTL ? '#fef3c7' : '#fef3c7'};
            border-${isRTL ? 'right' : 'left'}: 4px solid #f59e0b;
        }
        
        /* Message Header */
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .message-role {
            font-weight: 600;
            color: ${isRTL ? '#1f2937' : '#1f2937'};
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .role-avatar {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }
        
        .avatar-user {
            background: #3b82f6;
        }
        
        .avatar-assistant {
            background: #10b981;
        }
        
        .avatar-system {
            background: #f59e0b;
        }
        
        .message-info {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.85rem;
            color: #6b7280;
        }
        
        .message-index {
            background: #e5e7eb;
            padding: 2px 8px;
            border-radius: 10px;
            font-family: 'Courier New', monospace;
        }
        
        .message-time {
            font-family: 'Courier New', monospace;
            direction: ltr;
        }
        
        /* Message Content */
        .message-content {
            line-height: 1.7;
        }
        
        /* Text Blocks - 🔴 STEP 4: BLOCK-BASED ONLY */
        .text-block {
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 1rem;
            margin-bottom: 16px;
        }
        
        .text-block:last-child {
            margin-bottom: 0;
        }
        
        /* Code Blocks - 🔴 STEP 4: BLOCK-BASED ONLY - Always LTR */
        .code-block-container {
            margin: 16px 0;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            direction: ltr; /* 🔴 STEP 4: Always LTR for code */
        }
        
        .code-header {
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 0.9rem;
            border-bottom: 1px solid #333;
        }
        
        .code-language {
            color: #569cd6;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .code-copy {
            background: #2d2d2d;
            border: 1px solid #444;
            color: #d4d4d4;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .code-copy:hover {
            background: #3d3d3d;
        }
        
        .code-content {
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 20px;
            overflow-x: auto;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 0.95rem;
            line-height: 1.5;
            direction: ltr;
            text-align: left;
        }
        
        pre {
            margin: 0;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        
        code {
            font-family: inherit;
        }
        
        /* Footer */
        .chat-footer {
            background: ${isRTL ? '#f9fafb' : '#f9fafb'};
            padding: 30px;
            border-top: 1px solid #e5e7eb;
            text-align: center;
            color: #6b7280;
            font-size: 0.9rem;
        }
        
        .footer-info {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .footer-label {
            font-size: 0.8rem;
            color: #9ca3af;
        }
        
        .footer-value {
            font-weight: 500,
            color: #4b5563;
        }
        
        .copyright {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        /* Print Optimization */
        @media print {
            body {
                background: white !important;
                font-size: 11pt !important;
            }
            
            .chat-container {
                max-width: 100% !important;
                margin: 0 !important;
                box-shadow: none !important;
            }
            
            .chat-header {
                position: static !important;
                background: #4f46e5 !important;
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
            }
            
            .message {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            
            .code-block-container {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            
            .chat-footer {
                page-break-before: always !important;
            }
            
            .no-print {
                display: none !important;
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .chat-container {
                border-radius: 0;
            }
            
            .conversations-list {
                padding: 20px 15px;
            }
            
            .message {
                padding: 20px 15px;
            }
            
            .message-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }
            
            .message-info {
                width: 100%;
                justify-content: space-between;
            }
            
            .conversation-meta {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .conversation-info {
                flex-direction: column;
                gap: 8px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
    
    ${isRTL ? '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/vazirmatn@33.003/font.css">' : ''}
</head>
<body>
    <div class="chat-container">
        <!-- Header -->
        <div class="chat-header">
            <h1>
                <span class="icon">💬</span>
                ${headerText}
            </h1>
            <div class="stats">
                <div class="stat-item">
                    <span>${conversationsText}:</span>
                    <span class="stat-badge">${statistics.totalConversations}</span>
                </div>
                <div class="stat-item">
                    <span>${messagesText}:</span>
                    <span class="stat-badge">${statistics.totalMessages}</span>
                </div>
                <div class="stat-item">
                    <span>${exportDateText}:</span>
                    <span class="stat-badge">${new Date().toLocaleDateString(language)}</span>
                </div>
            </div>
        </div>
        
        <!-- Conversations -->
        <div class="conversations-list">
            ${conversations.map(conv => {
                const date = new Date(conv.timestamp).toLocaleDateString(language, {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                });
                const time = new Date(conv.timestamp).toLocaleTimeString(language, {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                
                return `
            <div class="conversation-section">
                <div class="conversation-meta">
                    <div class="conversation-title">
                        ${conv.title}
                        <span class="conversation-badge">#${conv.index}</span>
                    </div>
                    <div class="conversation-info">
                        <div class="info-item">
                            <span>🌐</span>
                            <span>${conv.site}</span>
                        </div>
                        <div class="info-item">
                            <span>📅</span>
                            <span>${date}</span>
                        </div>
                        <div class="info-item">
                            <span>⏰</span>
                            <span>${time}</span>
                        </div>
                        <div class="info-item">
                            <span>💬</span>
                            <span>${conv.messageCount} ${isRTL ? 'پیام' : 'messages'}</span>
                        </div>
                    </div>
                </div>
                
                <div class="messages-container">
                    ${conv.messages && conv.messages.length > 0 ? 
                        conv.messages.map(msg => {
                            const msgTime = new Date(msg.timestamp).toLocaleTimeString(language, {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit'
                            });
                            const msgDate = new Date(msg.timestamp).toLocaleDateString(language);
                            const roleLabel = roleLabels[msg.role] || msg.role;
                            const avatarClass = `avatar-${msg.role}`;
                            const messageClass = `message-${msg.role}`;
                            
                            return `
                    <div class="message ${messageClass}">
                        <div class="message-header">
                            <div class="message-role">
                                <span class="role-avatar ${avatarClass}">
                                    ${msg.role === 'user' ? (isRTL ? 'ک' : 'U') : 
                                      msg.role === 'assistant' ? (isRTL ? 'د' : 'A') : 
                                      (isRTL ? 'س' : 'S')}
                                </span>
                                ${roleLabel}
                            </div>
                            <div class="message-info">
                                <span class="message-index">${msg.index}/${msg.total}</span>
                                <span class="message-time">${msgDate} ${msgTime}</span>
                            </div>
                        </div>
                        <div class="message-content">
                            ${msg.blocks.map(block => {
                                // 🔴 STEP 4: HTML MUST ONLY render message.blocks
                                if (block.type === 'code') {
                                    // 🔴 STEP 4: Code Block - Block-based
                                    return `
                            <div class="code-block-container">
                                <div class="code-header">
                                    <span class="code-language">${block.language || 'code'}</span>
                                    <button class="code-copy no-print" onclick="copyCode(this)">
                                        ${isRTL ? 'کپی' : 'Copy'}
                                    </button>
                                </div>
                                <div class="code-content">
                                    <pre><code>${this.escapeHtml(block.content)}</code></pre>
                                </div>
                            </div>`;
                                } else {
                                    // 🔴 STEP 4: Text Block - Block-based
                                    return `
                            <div class="text-block">${this.escapeHtml(block.text || '')}</div>`;
                                }
                            }).join('')}
                        </div>
                    </div>`;
                        }).join('') 
                    : `
                    <div class="message message-system">
                        <div class="message-content">
                            <div class="text-block">
                                ${isRTL ? 'هیچ پیامی در این مکالمه وجود ندارد.' : 'No messages in this conversation.'}
                            </div>
                        </div>
                    </div>`}
                </div>
            </div>`;
            }).join('')}
        </div>
        
        <!-- Footer -->
        <div class="chat-footer">
            <div class="footer-info">
                <div class="footer-item">
                    <div class="footer-label">${isRTL ? 'تعداد کل مکالمات' : 'Total Conversations'}</div>
                    <div class="footer-value">${statistics.totalConversations}</div>
                </div>
                <div class="footer-item">
                    <div class="footer-label">${isRTL ? 'تعداد کل پیام‌ها' : 'Total Messages'}</div>
                    <div class="footer-value">${statistics.totalMessages}</div>
                </div>
                <div class="footer-item">
                    <div class="footer-label">${isRTL ? 'فرمت' : 'Format'}</div>
                    <div class="footer-value">JSON v1.1</div>
                </div>
                <div class="footer-item">
                    <div class="footer-label">${isRTL ? 'تاریخ صادرات' : 'Export Date'}</div>
                    <div class="footer-value">${new Date().toLocaleDateString(language)}</div>
                </div>
            </div>
            
            <div class="copyright">
                ${isRTL ? 'تولید شده توسط ChatSavePro - سیستم ذخیره‌سازی حرفه‌ای گفتگو' : 
                         'Generated by ChatSavePro - Professional Chat Export System'} |
                ${isRTL ? 'شناسه صادرات' : 'Export ID'}: ${data.exportMetadata?.exportId || 'unknown'} |
                ${new Date().toISOString()}
            </div>
        </div>
    </div>
    
    <script>
        // Copy code function
        function copyCode(button) {
            const codeContent = button.closest('.code-block-container').querySelector('code').innerText;
            navigator.clipboard.writeText(codeContent).then(() => {
                const originalText = button.innerText;
                button.innerText = '${isRTL ? 'کپی شد!' : 'Copied!'}';
                button.style.background = '#10b981';
                setTimeout(() => {
                    button.innerText = originalText;
                    button.style.background = '';
                }, 2000);
            });
        }
        
        // Print optimization
        window.addEventListener('beforeprint', () => {
            document.querySelectorAll('.no-print').forEach(el => {
                el.style.display = 'none';
            });
        });
        
        window.addEventListener('afterprint', () => {
            document.querySelectorAll('.no-print').forEach(el => {
                el.style.display = '';
            });
        });
    </script>
</body>
</html>`;
  }

  // ==================== RENDERER: Generate TXT from JSON v1.1 ====================
  renderTXTFromJSON(jsonData) {
    console.log('[ExportFormatHelpers][TXT] 🔥 TXT BLOCK-ONLY RENDERER EXECUTED (from JSON v1.1)');
    
    const data = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
    const { conversations, statistics, language, direction } = data;
    
    const lines = [];
    const leftMargin = '      ';
    const contentWidth = 64;
    
    // Helper: Safe word wrap
    function wordWrap(text, width) {
      if (!text || text.length === 0) return '';
      
      const words = text.split(' ');
      const lines = [];
      let currentLine = '';
      
      words.forEach(word => {
        if ((currentLine + word).length <= width) {
          currentLine += (currentLine.length > 0 ? ' ' : '') + word;
        } else {
          if (currentLine.length > 0) {
            lines.push(currentLine);
          }
          currentLine = word.substring(0, width);
          if (word.length > width) {
            const remaining = word.substring(width);
            for (let i = 0; i < remaining.length; i += width) {
              lines.push(remaining.substring(i, i + width));
            }
          }
        }
      });
      
      if (currentLine.length > 0) {
        lines.push(currentLine);
      }
      
      return lines.map(line => leftMargin + line).join('\n');
    }
    
    // ===== HEADER =====
    lines.push('='.repeat(60));
    lines.push('     ChatSavePro Export - JSON v1.1 Format');
    lines.push('='.repeat(60));
    lines.push('');
    lines.push(`Generated at: ${new Date().toISOString().split('T')[0]}`);
    lines.push(`Format: JSON v1.1 (Block-based structure)`);
    lines.push(`Conversations: ${statistics.totalConversations} | Messages: ${statistics.totalMessages}`);
    lines.push(`Language: ${language} | Direction: ${direction}`);
    lines.push(`System: ChatSavePro QuantumStage v3.9.8`);
    lines.push('');
    
    // ===== CONVERSATIONS =====
    conversations.forEach(conv => {
      const convTitle = conv.title;
      const messageCount = conv.messageCount;
      const site = conv.site;
      const date = new Date(conv.timestamp).toLocaleDateString(language);
      
      // Conversation header
      lines.push('─'.repeat(60));
      lines.push(`  ${convTitle} (#${conv.index})`);
      lines.push('─'.repeat(60));
      lines.push(`${leftMargin}Site: ${site}`);
      lines.push(`${leftMargin}Date: ${date}`);
      lines.push(`${leftMargin}Messages: ${messageCount}`);
      lines.push(`${leftMargin}Language: ${conv.language}`);
      lines.push('');
      
      // Messages - 🟠 STEP 3: TXT MUST iterate over message.blocks
      if (conv.messages && conv.messages.length > 0) {
        conv.messages.forEach(msg => {
          const role = (msg.role || 'unknown').toUpperCase();
          const time = new Date(msg.timestamp).toLocaleTimeString(language);
          
          lines.push(`${leftMargin}${role} — ${time} [${msg.index}/${msg.total}]`);
          lines.push(`${leftMargin}${'-'.repeat(30)}`);
          
          // 🟠 STEP 3: TXT MUST iterate over message.blocks
          if (msg.blocks && msg.blocks.length > 0) {
            msg.blocks.forEach(block => {
              // 🟠 STEP 3: Code blocks MUST render ONLY if block.type === "code"
              if (block.type === 'code') {
                lines.push(`${leftMargin}[ CODE BLOCK - ${block.language || 'text'} ]`);
                lines.push(`${leftMargin}${'='.repeat(20)}`);
                lines.push(wordWrap(block.content || '', contentWidth));
                lines.push(`${leftMargin}${'='.repeat(20)}`);
              } else {
                // Text block
                lines.push(wordWrap(block.text || '', contentWidth));
              }
            });
          }
          
          lines.push(''); // Empty line between messages
        });
      } else {
        lines.push(`${leftMargin}[No messages in this conversation]`);
        lines.push('');
      }
      
      lines.push(''); // Extra empty line between conversations
    });
    
    // ===== STATISTICS =====
    lines.push('='.repeat(60));
    lines.push('     EXPORT STATISTICS');
    lines.push('='.repeat(60));
    lines.push('');
    
    Object.entries(statistics.sites || {}).forEach(([site, count]) => {
      lines.push(`${leftMargin}${site}: ${count} conversations`);
    });
    
    if (statistics.timeRange) {
      lines.push('');
      lines.push(`${leftMargin}Time Range: ${new Date(statistics.timeRange.oldest).toLocaleDateString()} to ${new Date(statistics.timeRange.newest).toLocaleDateString()}`);
      if (statistics.timeRange.durationDays) {
        lines.push(`${leftMargin}Duration: ${statistics.timeRange.durationDays} days`);
      }
    }
    
    // ===== FOOTER =====
    lines.push('');
    lines.push('='.repeat(60));
    lines.push('     Export Information');
    lines.push('='.repeat(60));
    lines.push('');
    lines.push(`${leftMargin}TXT Format: v1.7 Book / Report Style (Block-based)`); // 🟠 STEP 3: Required footer
    lines.push(`${leftMargin}Format: JSON v1.1 -> TXT Render`);
    lines.push(`${leftMargin}Generated: ${new Date().toISOString()}`);
    lines.push(`${leftMargin}Export ID: ${data.exportMetadata?.exportId || 'unknown'}`);
    lines.push(`${leftMargin}Schema: Block-based message structure`);
    lines.push('');
    lines.push(`${leftMargin}© ChatSavePro - Professional Chat Export Tool v1.1`);
    
    return lines.join('\n');
  }

  // ==================== HELPER: Escape HTML ====================
  escapeHtml(text) {
    if (!text) return '';
    return text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;")
      .replace(/\n/g, "<br>")
      .replace(/ /g, "&nbsp;");
  }
}

var ActionHandlerManager = class {
  constructor() {
    this.handlers = new Map();
    this.validator = new SecureMessageValidator();
    this.asyncExecutor = new ResilientAsyncExecutor();
    this.conversationManager = new ConversationManager();
    this._namespaces = new Map();
    
    // ==================== 🆕 استفاده از FreePDFExporter جدید ====================
    this.freePdfExporter = null;
    this._loadFreePDFExporter();
    
    // ==================== 🆕 استفاده از ExportFormatHelpers جدید ====================
    this.exportHelpers = new ExportFormatHelpers();
    
    // ==================== 🆕 اضافه کردن flag برای PDF Pro-only ====================
    this.isPDFProOnly = true; // PDF فقط برای کاربران Pro
    
    console.log('[BG][AHM] ✅ ActionHandlerManager initialized with JSON v1.1 ExportFormatHelpers');
    
    this.setupActionHandlers();
  }

  // تابع برای بارگیری FreePDFExporter جدید
  async _loadFreePDFExporter() {
    try {
      this.freePdfExporter = new FreePDFExporter();
      console.log('[BG][FreePDFExporter] ✅ FreePDFExporter (Pure MV3 Offscreen) loaded successfully');
    } catch (error) {
      console.error('[BG][FreePDFExporter] ❌ Failed to load FreePDFExporter:', error);
      this.freePdfExporter = null;
    }
  }

  setupActionHandlers() {
    // ==================== 🆕 اضافه کردن handlerهای Offscreen ====================
    this.register("OFFSCREEN_READY", async (message, sender) => {
        console.log("[BG][AHM] OFFSCREEN_READY received (should be handled by raw listener):", {
            timestamp: message.timestamp,
            source: message.payload?.source
        });
        
        return {
            success: true,
            acknowledged: true,
            timestamp: Date.now(),
            message: "Offscreen ready acknowledged by AHM",
            alreadyHandled: true
        };
    }, {
        input: ["timestamp"],
        output: ["success", "acknowledged", "timestamp"],
        timeout: 2000,
        retries: 1
    });

    this.register("OFFSCREEN_ERROR", async (message, sender) => {
        console.error("[BG][AHM] OFFSCREEN_ERROR received:", {
            error: message.payload?.error,
            timestamp: message.timestamp
        });
        
        return {
            success: true,
            logged: true,
            timestamp: Date.now(),
            message: "Offscreen error logged by AHM"
        };
    }, {
        input: ["timestamp", "payload"],
        output: ["success", "logged", "timestamp"],
        timeout: 2000,
        retries: 1
    });

    this.register("GENERATE_PDF_RESPONSE", async (message, sender) => {
        console.log("[BG][AHM] GENERATE_PDF_RESPONSE received:", {
            success: message.payload?.success,
            htmlReady: message.payload?.htmlReady,
            fileName: message.payload?.fileName,
            timestamp: message.timestamp
        });
        
        return {
            success: true,
            forwarded: true,
            timestamp: Date.now(),
            message: "PDF response forwarded"
        };
    }, {
        input: ["timestamp", "payload"],
        output: ["success", "forwarded", "timestamp"],
        timeout: 5000,
        retries: 1
    });

    // ==================== 🆕 اضافه کردن handler برای PDF v1 ====================
    this.register("GENERATE_PDF_V1_REQUEST", async (message, sender) => {
        console.log("[BG][AHM] GENERATE_PDF_V1_REQUEST received:", {
            title: message.payload?.title,
            contentLength: message.payload?.content?.length || 0,
            timestamp: message.timestamp
        });
        
        try {
            // ✅ اطمینان از ایجاد offscreen document
            await ensurePdfV1Offscreen();
            
            // ✅ ارسال پیام به offscreen برای تولید PDF
            const response = await chrome.runtime.sendMessage({
                type: "GENERATE_PDF_V1",
                payload: {
                    title: message.payload?.title,
                    content: message.payload?.content
                }
            });
            
            return {
                success: response.success,
                buffer: response.buffer,
                error: response.error,
                timestamp: Date.now()
            };
            
        } catch (error) {
            console.error("[BG][AHM] GENERATE_PDF_V1_REQUEST failed:", error);
            return {
                success: false,
                error: error.message,
                timestamp: Date.now()
            };
        }
    }, {
        input: ["timestamp", "payload"],
        output: ["success", "buffer", "error", "timestamp"],
        timeout: 15000,
        retries: 2
    });

    // ==================== بقیه handlerها ====================
    this.register("SCANLAYER_DATA_READY", async (message, sender) => {
        console.log("[BG][AHM-SCANLAYER] SCANLAYER_DATA_READY received:", {
            payload: message.payload ? `with ${message.payload.messages?.length || 0} messages` : 'empty',
            tabId: sender?.tab?.id,
            timestamp: message.timestamp || Date.now(),
            source: message.source || 'unknown'
        });
        
        if (!message.payload?.messages || !Array.isArray(message.payload.messages)) {
            console.error("[BG][AHM-SCANLAYER] ❌ Invalid SCANLAYER_DATA_READY payload");
            return {
                success: false,
                error: "Invalid SCANLAYER_DATA_READY payload",
                timestamp: Date.now()
            };
        }
        
        if (message.payload.messages.length === 0) {
            console.warn("[BG][AHM-SCANLAYER] ⚠️ SCANLAYER_DATA_READY with empty messages");
            return {
                success: false,
                error: "No messages in SCANLAYER_DATA_READY payload",
                timestamp: Date.now()
            };
        }
        
        console.log(`[BG][AHM-SCANLAYER] 📥 Processing ${message.payload.messages.length} messages`);
        
        const getSiteFromUrl = (url) => {
            try {
                const urlObj = new URL(url);
                return urlObj.hostname;
            } catch {
                return "unknown-site";
            }
        };
        
        const conversation = {
            id: `scanlayer_ahm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            url: sender?.tab?.url || "unknown",
            title: "ScanLayer Conversation",
            timestamp: Date.now(),
            site: getSiteFromUrl(sender?.tab?.url || ""),
            platform: "deepseek.com",
            messages: message.payload.messages.map((msg, index) => ({
                id: `msg_${Date.now()}_${index}`,
                role: msg.role || "unknown",
                content: msg.content || "",
                timestamp: msg.timestamp || Date.now(),
                source: msg.source || "scanlayer"
            })),
            messageCount: message.payload.messages.length,
            extractedAt: Date.now(),
            source: "scanlayer_ahm"
        };
        
        try {
            const saveResult = await this.conversationManager.saveConversation(conversation);
            
            if (saveResult.success) {
                console.log(`[BG][AHM-SCANLAYER] ✅ Saved ${message.payload.messages.length} messages`);
                return {
                    success: true,
                    saved: true,
                    count: message.payload.messages.length,
                    conversationId: conversation.id,
                    site: conversation.site,
                    message: "ScanLayer data saved successfully",
                    timestamp: Date.now()
                };
            } else {
                console.error(`[BG][AHM-SCANLAYER] ❌ Failed to save conversation: ${saveResult.error}`);
                return {
                    success: false,
                    error: saveResult.error || "Failed to save conversation",
                    timestamp: Date.now()
                };
            }
        } catch (error) {
            console.error("[BG][AHM-SCANLAYER] ❌ Error saving ScanLayer data:", error);
            return {
                success: false,
                error: error.message,
                timestamp: Date.now()
            };
        }
    }, {
        input: ["payload", "timestamp"],
        output: ["success", "saved", "count", "conversationId", "message", "timestamp"],
               timeout: 10000,
        retries: 2
    });
    
    this.register("CSPRO_CS_HELLO", async (message, sender) => {
        console.log("[BG][AHM-CSPRO] Processing CSPRO_CS_HELLO", {
            source: message.source || 'unknown',
            tabId: sender?.tab?.id,
            timestamp: message.timestamp || Date.now()
        });
        
        return {
            success: true,
            message: "CSPRO_CS_HELLO processed",
            timestamp: Date.now(),
            system: "QuantumStage v3.9.8",
            ready: true,
            canProceed: true
        };
    }, {
        input: ["timestamp"],
        output: ["success", "message", "timestamp"],
        timeout: 2000,
        retries: 1
    });
    
    this.register("CONTENT_SCRIPT_READY", this.handleContentScriptReady.bind(this), {
      input: ["timestamp", "data"],
      output: ["success", "message", "timestamp", "tabId"],
      timeout: 5e3,
      retries: 2
    });
    this.register("GET_CURRENT_TAB_INFO", this.handleGetCurrentTabInfo.bind(this), {
      input: ["timestamp"],
      output: ["success", "tabId", "url", "title"],
      timeout: 3e3,
      retries: 1
    });
    this.register("GET_SYSTEM_HEALTH", this.handleGetSystemHealth.bind(this), {
      input: ["timestamp"],
      output: ["status", "version", "timestamp", "layers"],
      timeout: 5e3,
      retries: 2
    });
    this.register("START_DEEP_SCAN", this.handleStartDeepScan.bind(this), {
      input: ["timestamp", "tabId"],
      output: ["success", "sessionId", "startedAt", "scanType", "tabId"],
      timeout: 1e4,
      retries: 3
    });
    this.register("STOP_DEEP_SCAN", this.handleStopDeepScan.bind(this), {
      input: ["timestamp", "tabId"],
      output: ["success", "stopped", "tabId", "stoppedAt"],
      timeout: 5e3,
      retries: 2
    });
    this.register("EXPORT_DATA", this.handleExportData.bind(this), {
      input: ["data", "timestamp"],
      output: ["success", "blobUrl", "mimeType", "fileName"],
      timeout: 15e3,
      retries: 2
    });
    this.register("QUANTUM_PING", this.handleQuantumPing.bind(this), {
      input: ["timestamp"],
      output: ["success", "message", "layer", "timestamp"],
      timeout: 3e3,
      retries: 1
    });
    this.register("PROCESS_DEEP_SCAN", this.handleProcessDeepScan.bind(this), {
      input: ["session", "messages", "timestamp"],
      output: ["success", "saved", "messageCount", "sessionId"],
      timeout: 1e4,
      retries: 3
    });
    this.register("REPORT_BROKEN_SELECTOR", this.handleReportBrokenSelector.bind(this), {
      input: ["platform", "brokenSelector", "timestamp"],
      output: ["success", "message", "platform"],
      timeout: 5e3,
      retries: 2
    });
    this.register("GET_ADAPTIVE_CONFIG", this.handleGetAdaptiveConfig.bind(this), {
      input: ["platform", "timestamp"],
      output: ["success", "config", "platform"],
      timeout: 5e3,
      retries: 2
    });
    this.register("SELECTOR_CONFIG_UPDATED", this.handleSelectorConfigUpdated.bind(this), {
      input: ["platform", "oldSelector", "newSelector", "timestamp"],
      output: ["success", "message", "platform"],
      timeout: 5e3,
      retries: 2
    });
    
    this.register("REQUEST_LOCAL_SCAN", this.handleRequestLocalScan.bind(this), {
      input: ["tabId", "timestamp"],
      output: ["success", "message", "tabId"],
      timeout: 8e3,
      retries: 2
    });
    
    this.register("TEST_PING", this.handleTestPing.bind(this), {
      input: ["timestamp"],
      output: ["success", "response", "system", "timestamp"],
      timeout: 3e3,
      retries: 1
    });
    this.register("SCANLAYER_STATUS", this.handleScanLayerStatus.bind(this), {
      input: ["timestamp"],
      output: ["success", "scanLayerLoaded", "scanLayerVersion", "timestamp"],
      timeout: 5000,
      retries: 2
    });
    this.register("GUARDIAN_READY", async (message, sender) => {
        if (globalThis.__GUARDIAN_REGISTRY__ && globalThis.__GUARDIAN_REGISTRY__[message.tabId]) {
            return {
                success: true,
                acknowledged: true,
                tabId: message.tabId,
                timestamp: Date.now(),
                message: "duplicate_guardian_ignored"
            };
        }
        if (!globalThis.__GUARDIAN_REGISTRY__) globalThis.__GUARDIAN_REGISTRY__ = {};
        globalThis.__GUARDIAN_REGISTRY__[message.tabId] = true;
        
        console.log("🛡️ [BG] Guardian layer registered:", {
            tabId: message.tabId,
            version: message.data?.version || "unknown",
            startedAt: message.data?.guardianStartedAt,
            token: message.data?.token
        });

        if (message.data?.token && quantumResyncManager) {
            quantumResyncManager.updateContentScriptPing(message.tabId);
        }

        return {
            success: true,
            acknowledged: true,
            tabId: message.tabId,
            timestamp: Date.now()
        };
    }, {
        input: ["timestamp", "data", "tabId"],
        output: ["success", "acknowledged", "tabId", "timestamp"],
        timeout: 4000,
        retries: 1
    });
    
    this.register("LIVE_SCAN_MESSAGE", async (message, sender) => {
        console.log("📊 [BG] LIVE_SCAN_MESSAGE handler:", {
            sessionId: message.sessionId,
            data: message.data,
            timestamp: message.timestamp
        });
        
        if (memoryManager) {
            memoryManager.set("scan", `live_${message.sessionId}`, {
                data: message.data,
                timestamp: message.timestamp || Date.now(),
                tabId: message.tabId
            }, 3600000);
        }
        
        return {
            success: true,
            received: true,
            sessionId: message.sessionId,
            timestamp: Date.now(),
            message: "Live scan processed"
        };
    }, {
        input: ["sessionId", "tabId"],
        output: ["success", "received", "sessionId", "timestamp"],
        timeout: 3000,
        retries: 1
    });
    
    this.register("DEEP_SCAN_RESULTS", async (message, sender) => {
        console.log("📊 [BG] DEEP_SCAN_RESULTS handler:", {
            sessionId: message.sessionId,
            itemsCount: message.items?.length || 0,
            timestamp: message.timestamp
        });
        
        if (memoryManager) {
            memoryManager.set("scan", `deep_${message.sessionId}`, {
                items: message.items || [],
                count: message.items?.length || 0,
                timestamp: message.timestamp || Date.now(),
                tabId: message.tabId
            }, 86400000);
        }
        
        return {
            success: true,
            received: true,
            sessionId: message.sessionId,
            itemsCount: message.items?.length || 0,
            timestamp: Date.now(),
            message: "Deep scan results processed"
        };
    }, {
        input: ["sessionId", "tabId"],
        output: ["success", "received", "sessionId", "itemsCount", "timestamp"],
        timeout: 5000,
        retries: 1
    });
    
    this.register("HELLO_FROM_CS", async (message, sender) => {
        console.log("👋 [BG] HELLO_FROM_CS received:", {
            protocolVersion: message.protocolVersion,
            tabId: message.tabId,
            timestamp: message.timestamp
        });
        
        if (quantumResyncManager && message.tabId) {
            quantumResyncManager.updateContentScriptPing(message.tabId);
        }
        
        return {
            success: true,
            acknowledged: true,
            protocolVersion: message.protocolVersion,
            timestamp: Date.now(),
            tabId: message.tabId,
            message: "CS hello received"
        };
    }, {
        input: ["protocolVersion", "tabId"],
        output: ["success", "acknowledged", "timestamp"],
        timeout: 3000,
        retries: 1
    });
    
    this.register("SCAN_RESULT", this.handleScanResult.bind(this), {
      input: ["timestamp", "data", "tabId"],
      output: ["success", "saved", "conversationId", "messageCount"],
      timeout: 8000,
      retries: 2
    });
    
    this.register("SAVE_CONVERSATION", this.handleSaveConversation.bind(this), {
      input: ["timestamp", "conversation"],
      output: ["success", "conversationId", "savedAt"],
      timeout: 8000,
      retries: 2
    });
    
    this.register("GET_CONVERSATIONS", this.handleGetConversations.bind(this), {
      input: ["timestamp"],
      output: ["success", "conversations", "totalCount"],
      timeout: 5000,
      retries: 1
    });
    
    this.register("SCAN_NOW", this.handleScanNow.bind(this), {
      input: ["timestamp", "tabId"],
      output: ["success", "forwarded", "tabId"],
      timeout: 5000,
      retries: 1
    });
    
    this.register("AUTO_SCAN_RESULT", this.handleAutoScanResult.bind(this), {
      input: ["timestamp", "conversation"],
      output: ["success", "autoSaved", "conversationId"],
      timeout: 5000,
      retries: 1
    });
    
    this.register("GET_CONVERSATION", this.handleGetConversation.bind(this), {
      input: ["timestamp", "id"],
      output: ["success", "conversation"],
      timeout: 5000,
      retries: 1
    });
    
    this.register("DELETE_CONVERSATION", this.handleDeleteConversation.bind(this), {
      input: ["timestamp", "id"],
      output: ["success", "deleted"],
      timeout: 5000,
      retries: 1
    });
    
    // ==================== 🆕 EXPORT_CONVERSATIONS - نسخه کاملاً اصلاح شده با JSON v1.1 ====================
    this.register("EXPORT_CONVERSATIONS", this.handleExportConversations.bind(this), {
      input: ["timestamp", "format"],
      output: ["success", "format", "fileName", "itemCount", "message"],
      timeout: 60000, // افزایش به 60 ثانیه برای PDF
      retries: 2
    });
    
    this.register("CLEANUP_CONVERSATIONS", this.handleCleanupConversations.bind(this), {
      input: ["timestamp", "days"],
      output: ["success", "cleaned", "remaining"],
      timeout: 10000,
      retries: 2
    });

    this.register("CLEAR_DATA", async (message, sender) => {
        console.log("[BG] 🔥 CLEAR_DATA handler called");
        
        try {
            await chrome.storage.local.clear();
            
            if (memoryManager) {
                memoryManager.store.clear();
            }
            
            if (globalThis.__CONVERSATIONS_STORE__) {
                globalThis.__CONVERSATIONS_STORE__.conversations = [];
            }
            
            console.log("[BG] ✅ All data cleared successfully");
            
            return {
                success: true,
                message: "All data cleared successfully",
                timestamp: Date.now(),
                cleared: true
            };
            
        } catch (error) {
            console.error("[BG] ❌ Error clearing data:", error);
            return {
                success: false,
                error: error.message,
                timestamp: Date.now()
            };
        }
    }, {
        input: ["timestamp"],
        output: ["success", "message", "timestamp"],
        timeout: 5000,
        retries: 1
    });

    console.log(`✅ ActionHandlerManager: ${this.handlers.size} handlers registered`);
    
    // ==================== 🆕 CRITICAL FIX: Register PopupBridge Namespace with Live/Deep Scan Handlers ====================
    this.registerNamespace("PopupBridge", {
        // ✅ START_LIVE_SCAN handler
        START_LIVE_SCAN: async function startLiveScan(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            if (!effectiveTabId) {
                throw new Error("Unable to resolve effectiveTabId for Live Scan");
            }

            console.log("[PopupBridge] START_LIVE_SCAN → content", { effectiveTabId });

            try {
                const response = await chrome.tabs.sendMessage(effectiveTabId, {
                    type: "LIVE_SCAN_START",
                    timestamp: Date.now()
                });
                
                // ذخیره وضعیت live scan در memory
                if (globalThis.quantumBackground?.memory) {
                    globalThis.quantumBackground.memory.set("scan", `live_scan_${effectiveTabId}`, {
                        status: "active",
                        startedAt: Date.now(),
                        tabId: effectiveTabId
                    }, 3600000);
                }
                
                return {
                    success: true,
                    started: true,
                    tabId: effectiveTabId,
                    timestamp: Date.now(),
                    message: "Live scan started successfully"
                };
            } catch (error) {
                console.error("[PopupBridge] START_LIVE_SCAN failed:", error);
                return {
                    success: false,
                    error: error.message,
                    tabId: effectiveTabId,
                    timestamp: Date.now()
                };
            }
        },

        // ✅ STOP_LIVE_SCAN handler
        STOP_LIVE_SCAN: async function stopLiveScan(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            if (!effectiveTabId) {
                throw new Error("Unable to resolve effectiveTabId for Live Scan");
            }

            console.log("[PopupBridge] STOP_LIVE_SCAN → content", { effectiveTabId });

            try {
                const response = await chrome.tabs.sendMessage(effectiveTabId, {
                    type: "LIVE_SCAN_STOP",
                    timestamp: Date.now()
                });
                
                // به‌روزرسانی وضعیت live scan در memory
                if (globalThis.quantumBackground?.memory) {
                    globalThis.quantumBackground.memory.set("scan", `live_scan_${effectiveTabId}`, {
                        status: "stopped",
                        stoppedAt: Date.now(),
                        tabId: effectiveTabId
                    }, 3600000);
                }
                
                return {
                    success: true,
                    stopped: true,
                    tabId: effectiveTabId,
                    timestamp: Date.now(),
                    message: "Live scan stopped successfully"
                };
            } catch (error) {
                console.error("[PopupBridge] STOP_LIVE_SCAN failed:", error);
                return {
                    success: false,
                    error: error.message,
                    tabId: effectiveTabId,
                    timestamp: Date.now()
                };
            }
        },

        // ✅ START_DEEP_SCAN handler (برای popup)
        START_DEEP_SCAN: async function startDeepScan(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            if (!effectiveTabId) {
                throw new Error("Unable to resolve effectiveTabId for Deep Scan");
            }

            console.log("[PopupBridge] START_DEEP_SCAN → content", { effectiveTabId });

            try {
                const response = await chrome.tabs.sendMessage(effectiveTabId, {
                    type: "DEEP_SCAN_START",
                    timestamp: Date.now()
                });
                
                // ذخیره وضعیت deep scan در memory
                if (globalThis.quantumBackground?.memory) {
                    globalThis.quantumBackground.memory.set("scan", `deep_scan_${effectiveTabId}`, {
                        status: "active",
                        startedAt: Date.now(),
                        tabId: effectiveTabId,
                        scanType: "deep"
                    }, 7200000);
                }
                
                return {
                    success: true,
                    started: true,
                    tabId: effectiveTabId,
                    timestamp: Date.now(),
                    message: "Deep scan started successfully"
                };
            } catch (error) {
                console.error("[PopupBridge] START_DEEP_SCAN failed:", error);
                return {
                    success: false,
                    error: error.message,
                    tabId: effectiveTabId,
                    timestamp: Date.now()
                };
            }
        },

        // ✅ STOP_DEEP_SCAN handler (برای popup)
        STOP_DEEP_SCAN: async function stopDeepScan(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            if (!effectiveTabId) {
                throw new Error("Unable to resolve effectiveTabId for Deep Scan");
            }

            console.log("[PopupBridge] STOP_DEEP_SCAN → content", { effectiveTabId });

            try {
                const response = await chrome.tabs.sendMessage(effectiveTabId, {
                    type: "DEEP_SCAN_STOP",
                    timestamp: Date.now()
                });
                
                // به‌روزرسانی وضعیت deep scan در memory
                if (globalThis.quantumBackground?.memory) {
                    globalThis.quantumBackground.memory.set("scan", `deep_scan_${effectiveTabId}`, {
                        status: "stopped",
                        stoppedAt: Date.now(),
                        tabId: effectiveTabId,
                        scanType: "deep"
                    }, 3600000);
                }
                
                return {
                    success: true,
                    stopped: true,
                    tabId: effectiveTabId,
                    timestamp: Date.now(),
                    message: "Deep scan stopped successfully"
                };
            } catch (error) {
                console.error("[PopupBridge] STOP_DEEP_SCAN failed:", error);
                return {
                    success: false,
                    error: error.message,
                    tabId: effectiveTabId,
                    timestamp: Date.now()
                };
            }
        },

        // ✅ GET_SCAN_STATUS handler
        GET_SCAN_STATUS: async function getScanStatus(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            console.log("[PopupBridge] GET_SCAN_STATUS", { effectiveTabId });

            let liveStatus = null;
            let deepStatus = null;

            if (effectiveTabId && globalThis.quantumBackground?.memory) {
                liveStatus = globalThis.quantumBackground.memory.get("scan", `live_scan_${effectiveTabId}`);
                deepStatus = globalThis.quantumBackground.memory.get("scan", `deep_scan_${effectiveTabId}`);
            }

            return {
                success: true,
                liveScan: liveStatus,
                deepScan: deepStatus,
                tabId: effectiveTabId,
                timestamp: Date.now()
            };
        },

        // ✅ TOGGLE_LIVE_SCAN handler
        TOGGLE_LIVE_SCAN: async function toggleLiveScan(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            if (!effectiveTabId) {
                throw new Error("Unable to resolve effectiveTabId for Live Scan");
            }

            // بررسی وضعیت فعلی live scan
            const currentStatus = globalThis.quantumBackground?.memory?.get("scan", `live_scan_${effectiveTabId}`);
            const isActive = currentStatus?.status === "active";

            if (isActive) {
                // اگر فعال است، stop کن
                console.log("[PopupBridge] TOGGLE_LIVE_SCAN → stopping", { effectiveTabId });
                return await this.STOP_LIVE_SCAN(payload, sender);
            } else {
                // اگر غیرفعال است، start کن
                console.log("[PopupBridge] TOGGLE_LIVE_SCAN → starting", { effectiveTabId });
                return await this.START_LIVE_SCAN(payload, sender);
            }
        },

        // ✅ TOGGLE_DEEP_SCAN handler
        TOGGLE_DEEP_SCAN: async function toggleDeepScan(payload, sender) {
            const realTab = sender?.tab?.id;
            const requestedTab = payload?.tabId || null;
            const effectiveTabId =
                realTab && realTab > 0
                    ? realTab
                    : requestedTab && requestedTab > 0
                    ? requestedTab
                    : null;

            if (!effectiveTabId) {
                throw new Error("Unable to resolve effectiveTabId for Deep Scan");
            }

            // بررسی وضعیت فعلی deep scan
            const currentStatus = globalThis.quantumBackground?.memory?.get("scan", `deep_scan_${effectiveTabId}`);
            const isActive = currentStatus?.status === "active";

            if (isActive) {
                // اگر فعال است، stop کن
                console.log("[PopupBridge] TOGGLE_DEEP_SCAN → stopping", { effectiveTabId });
                return await this.STOP_DEEP_SCAN(payload, sender);
            } else {
                // اگر غیرفعال است، start کن
                console.log("[PopupBridge] TOGGLE_DEEP_SCAN → starting", { effectiveTabId });
                return await this.START_DEEP_SCAN(payload, sender);
            }
        },

        // ✅ GENERATE_PDF_V1 handler برای PopupBridge
        GENERATE_PDF_V1: async function generatePdfV1(payload, sender) {
            console.log("[PopupBridge] GENERATE_PDF_V1 requested from popup", {
                title: payload?.title,
                contentLength: payload?.content?.length || 0
            });
            
            try {
                // اطمینان از ایجاد offscreen document
                await ensurePdfV1Offscreen();
                
                // ارسال درخواست به offscreen
                const response = await chrome.runtime.sendMessage({
                    type: "GENERATE_PDF_V1",
                    payload: {
                        title: payload?.title,
                        content: payload?.content
                    }
                });
                
                return {
                    success: response.success,
                    buffer: response.buffer,
                    error: response.error,
                    timestamp: Date.now(),
                    source: "popup_bridge"
                };
                
            } catch (error) {
                console.error("[PopupBridge] GENERATE_PDF_V1 failed:", error);
                return {
                    success: false,
                    error: error.message,
                    timestamp: Date.now()
                };
            }
        }
    });

    console.log("✅ PopupBridge namespace registered with Live/Deep Scan handlers and PDF v1 support");
  }
  
  register(action, handler, contract = {}) {
    this.handlers.set(action, {
      handler,
      contract: {
        input: contract.input || [],
        output: contract.output || [],
        timeout: contract.timeout || 1e4,
        retries: contract.retries || 1
      }
    });
  }

  async handle(action, message, sender) {
    // ✅ FIX: اگر action ناشناخته بود، خطا نده - فقط warning بده
    const handlerInfo = this.handlers.get(action);
    if (!handlerInfo) {
        console.warn(`[BG][AHM] Unknown action ignored: ${action}`);
        return { 
            ok: false, 
            ignored: true,
            message: `Action ${action} is not handled by AHM`,
            timestamp: Date.now()
        };
    }
    
    try {
      this.validateContract(handlerInfo.contract, message, "input");
    } catch (error) {
      console.error(`Contract validation error for ${action}:`, error.message);
      throw error;
    }
    
    const result = await this.asyncExecutor.executeWithRetry(
      `Action: ${action}`,
      () => handlerInfo.handler(message, sender),
      { contract: handlerInfo.contract }
    );
    
    try {
      this.validateContract(handlerInfo.contract, result, "output");
    } catch (error) {
      console.error(`Contract output error for ${action}:`, error.message);
      throw error;
    }
    
    return result;
  }

  validateContract(contract, data, type) {
    const requiredFields = contract[type] || [];
    const missing = requiredFields.filter((field) => !(field in data));
    if (missing.length > 0) {
      throw new Error(`Contract violation: Missing ${type} fields: ${missing.join(", ")}`);
    }
  }

  // ==================== 🆕 تابع generateProfessionalTxt (قدیمی - نگهداری برای سازگاری) ====================
  async generateProfessionalTxt(conversations = []) {
    console.log('[BG][EXPORT] 📝 Using professional TXT generation (legacy v1.1)');
    const jsonData = this.exportHelpers.generateJSON(conversations, []);
    return this.exportHelpers.renderTXTFromJSON(jsonData);
  }

  async handleContentScriptReady(message, sender) {
    try {
        const tabId = message.tabId || sender?.tab?.id;
        
        if (globalThis.__CONTENT_SCRIPT_REGISTRY__ && globalThis.__CONTENT_SCRIPT_REGISTRY__[tabId]) {
            console.log(`🔄 Content script re-registered for tab ${tabId}, updating timestamp`);
        } else {
            if (!globalThis.__CONTENT_SCRIPT_REGISTRY__) globalThis.__CONTENT_SCRIPT_REGISTRY__ = {};
            globalThis.__CONTENT_SCRIPT_REGISTRY__[tabId] = Date.now();
        }
        
        if (quantumResyncManager && quantumResyncManager.contentScripts.has(tabId)) {
            console.log("🛡️ Guardian already registered for tab → updating");
            quantumResyncManager.updateContentScriptPing(tabId);
            return {
                success: true,
                message: "Already registered, ping updated",
                timestamp: Date.now(),
                tabId
            };
        }

        console.log("🔄 [BG] Content script ready received:", {
            platform: message.data?.platform,
            url: message.data?.url,
            tabId: tabId,
            securityToken: message.data?.securityToken ? '***' : 'missing'
        });

        if (message.data?.securityToken && quantumResyncManager) {
                   quantumResyncManager.registerContentScript(
                tabId,
                message.data.securityToken
            );
        } else {
            console.warn("⚠️ [BG] CONTENT_SCRIPT_READY with missing securityToken, registering anyway");
            if (quantumResyncManager && tabId) {
                quantumResyncManager.registerContentScript(
                    tabId,
                    'fallback_token_' + Date.now()
                );
            }
        }

        return {
            success: true,
            message: "Content script registration acknowledged",
            timestamp: Date.now(),
            tabId: tabId,
            registered: true
        };

    } catch (error) {
        console.error("❌ [BG] CONTENT_SCRIPT_READY handler error:", error);
        return {
            success: false,
            message: "Content script registration failed",
            timestamp: Date.now(),
            tabId: message.tabId,
            error: error.message
        };
    }
  }

  async handleGetCurrentTabInfo(message, sender) {
    const tabId = message.tabId || sender?.tab?.id;
    console.log(`🔍 [BG] GET_CURRENT_TAB_INFO - tabId: ${tabId}`);
    return {
      success: true,
      tabId: tabId || -1,
      url: sender?.tab?.url || "unknown",
      title: sender?.tab?.title || "unknown",
      timestamp: Date.now(),
      source: "background"
    };
  }

  async handleTestPing(message, sender) {
    console.log("🧪 [BG] Test ping received:", message);
    return {
      success: true,
      response: "TEST_PONG",
      system: "QuantumStage v3.9.8",
      timestamp: Date.now()
    };
  }

  async handleScanLayerStatus(message, sender) {
    console.log("📡 [BG] ScanLayer status handler invoked:", {
        hasData: !!message.data,
        dataKeys: message.data ? Object.keys(message.data) : [],
        tabId: sender?.tab?.id,
        timestamp: message.timestamp
    });
    
    try {
        if (!message.timestamp) {
            console.log("[BG] Adding timestamp to SCANLAYER_STATUS");
            message.timestamp = Date.now();
        }
        
        let statusData = message.data || {};
        
        const status = {
            scanLayerLoaded: Boolean(statusData.loaded || statusData.ready || false),
            scanLayerVersion: statusData.version || statusData.VERSION || "unknown",
            dependencies: Array.isArray(statusData.dependencies) 
                ? statusData.dependencies 
                : [],
            timestamp: Date.now(),
            tabId: sender?.tab?.id,
            source: statusData.source || "background_handler"
        };
        
        if (memoryManager && sender?.tab?.id) {
            memoryManager.set("config", `scanlayer_status_${sender.tab.id}`, status, 300000);
        }
        
        console.log("[BG] SCANLAYER_STATUS processed successfully:", {
            loaded: status.scanLayerLoaded,
            version: status.scanLayerVersion,
            dependenciesCount: status.dependencies.length
        });
        
        return {
            success: true,
            scanLayerLoaded: status.scanLayerLoaded,
                       scanLayerVersion: status.scanLayerVersion,
            timestamp: status.timestamp,
            dependencies: status.dependencies
        };
        
    } catch (error) {
        console.error("[BG] SCANLAYER_STATUS handler error:", error);
        
        return {
            success: false,
            scanLayerLoaded: false,
            scanLayerVersion: "error",
            timestamp: Date.now(),
            error: error.message,
            dependencies: []
        };
    }
  }

  async handleGetSystemHealth(message, sender) {
    const conversationStats = this.conversationManager.getStats();
    
    // ✅ FreePDFExporter health check بهبود یافته
    let freePdfExporterHealth = { available: false, healthy: false, error: "Not checked" };
    try {
        if (this.freePdfExporter && typeof this.freePdfExporter.healthCheck === 'function') {
            freePdfExporterHealth = await this.freePdfExporter.healthCheck();
        } else {
            freePdfExporterHealth.error = "FreePDFExporter healthCheck method not available";
        }
    } catch (error) {
        console.log("[BG] FreePDFExporter health check failed:", error.message);
        freePdfExporterHealth = { 
            available: false, 
            healthy: false, 
            error: error.message 
        };
    }
    
    // ✅ همچنین وضعیت ExportRegistry را چک کن
    const exportRegistryStatus = {
        available: typeof globalThis.ExportRegistry !== 'undefined',
        hasRender: typeof globalThis.ExportRegistry?.render === 'function',
        hasRegister: typeof globalThis.ExportRegistry?.register === 'function',
        source: "globalThis"
    };
    
    // ✅ اضافه کردن وضعیت live/deep scan
    const liveScanStatus = memoryManager.get("scan", `live_scan_${sender?.tab?.id}`);
    const deepScanStatus = memoryManager.get("scan", `deep_scan_${sender?.tab?.id}`);
    
    return {
      success: true,
      status: "operational",
      version: "3.9.8",
      timestamp: Date.now(),
      layers: {
        background: "healthy",
        content: "healthy",
        scan: "healthy",
        storage: "healthy",
        pdfExport: freePdfExporterHealth.healthy ? "healthy" : "degraded",
        exportRegistry: exportRegistryStatus.available ? "healthy" : "critical"
      },
      scanState: {
        liveScanActive: liveScanStatus?.status === "active",
        deepScanActive: deepScanStatus?.status === "active",
        autoStarted: true
      },
      memory: memoryManager.getStats(),
      quantumHealth: quantumResyncManager.getOverallHealth(),
      adaptiveStatus: adaptiveSystemManager.getSystemStatus(),
      selectorStats: selectorDatabase.getStats(),
      conversations: conversationStats,
      freePdfExporter: freePdfExporterHealth,
      exportRegistry: exportRegistryStatus,
      popupBridge: {
        registered: true,
        handlers: Object.keys(this._namespaces.get("PopupBridge") || {})
      },
      jsonVersion: "1.1",
      architecture: "block_based"
    };
  }

  async handleStartDeepScan(message, sender) {
    const requestedTabId = message.tabId;
    console.log(`🔍 [BG] START_DEEP_SCAN - tabId: ${requestedTabId}`);
    
    if (!requestedTabId || requestedTabId < 0) {
      return {
        success: false,
        error: "Invalid tab ID",
        details: {
          requestedTabId
        }
      };
    }
    
    memoryManager.set("scan", `deep_scan_${requestedTabId}`, {
      startTime: Date.now(),
      tabId: requestedTabId,
      platform: message.data?.platform,
      status: "started"
    }, 36e5);
    
    return {
      success: true,
      sessionId: "deep_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9),
      startedAt: Date.now(),
      scanType: "deep",
      message: "Deep scan started successfully",
      tabId: requestedTabId
    };
  }

  async handleStopDeepScan(message, sender) {
    const tabId = message.tabId;
    if (tabId) {
      memoryManager.set("scan", `deep_scan_${tabId}`, {
        stopTime: Date.now(),
        status: "stopped"
      }, 9e5);
    }
    return {
      success: true,
      stopped: true,
      tabId,
      stoppedAt: Date.now(),
      scanType: "deep",
      message: "Deep scan stopped successfully"
    };
  }

  async handleExportData(message, sender) {
    console.log("[BG] EXPORT_DATA handler called");
    
    try {
      const conversations = await this.conversationManager.getConversations();
      
      if (!conversations.success || conversations.conversations.length === 0) {
        return {
          success: false,
          error: "No conversations to export"
        };
      }
      
      const format = message.data?.exportType || message.data?.format || "txt"; // ✅ تغییر به txt
      
      return await this.handleExportConversations({
        timestamp: message.timestamp,
        format: format
      }, sender);
      
    } catch (error) {
      console.error("❌ Export error:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async handleRequestLocalScan(message, sender) {
    const tabId = message.tabId;
    console.log("🔍 [BG] Local scan request for tab:", tabId);
    
    return {
      success: true,
      message: "Live scan request acknowledged. Ensure ScanLayer is loaded.",
      tabId,
      timestamp: Date.now()
    };
  }

  // ==================== 🆕 EXPORT_CONVERSATIONS - نسخه ارتقا یافته با JSON v1.1 ====================
  async handleExportConversations(message, sender) {
    try {
        console.log("[BG][EXPORT] 🚀 Starting export process with JSON v1.1...");
        const format = message?.format || "txt"; // ✅ تغییر فرمت پیش‌فرض به TXT
        
        // ✅ بررسی PDF برای کاربران Free
        if (format === "pdf" && this.isPDFProOnly) {
            console.log("[BG][EXPORT] ❌ PDF export blocked - Pro feature");
            return {
                success: false,
                format: "pdf",
                fileName: "",
                itemCount: 0,
                message: "PDF export is only available in the Pro version. Please upgrade to access PDF export features.",
                error: "PRO_ONLY_FEATURE",
                timestamp: Date.now()
            };
        }

        console.log("[BG][EXPORT] 📦 Selected format:", format);
        
        // 1. دریافت داده از storage
        const storageResult = await new Promise((resolve) => {
            chrome.storage.local.get([
                'conversations', 
                'scanlayer_conversations',
                'scanResults'
            ], resolve);
        });
        
        console.log("[BG][EXPORT] 📊 Storage check:", {
            conversations: storageResult.conversations?.length || 0,
            scanlayer: storageResult.scanlayer_conversations?.length || 0,
            scanResults: storageResult.scanResults?.length || 0
        });
        
        let exportData = null;
        let scanData = [];
        let dataSource = "unknown";
        
        // اولویت‌بندی: scanlayer_conversations > conversations > scanResults
        if (storageResult.scanlayer_conversations && storageResult.scanlayer_conversations.length > 0) {
            exportData = storageResult.scanlayer_conversations;
            dataSource = "scanlayer";
            console.log(`[BG][EXPORT] ✅ Using scanlayer conversations (${exportData.length} items)`);
        }
        else if (storageResult.conversations && storageResult.conversations.length > 0) {
            exportData = storageResult.conversations;
            dataSource = "legacy";
            console.log(`[BG][EXPORT] 📦 Using legacy conversations (${exportData.length} items)`);
        }
        else if (storageResult.scanResults && storageResult.scanResults.length > 0) {
            // تبدیل scanResults به conversations
            exportData = storageResult.scanResults.map((scan, index) => ({
                id: `conv_${Date.now()}_${index}`,
                site: scan.platform || "deepseek.com",
                url: scan.url || window.location.href,
                title: `Chat ${index + 1}`,
                messages: scan.messages || [],
                messageCount: scan.messages?.length || 0,
                savedAt: scan.timestamp || Date.now(),
                scannedAt: scan.timestamp || Date.now()
            }));
            dataSource = "scanResults";
            console.log(`[BG][EXPORT] 🔄 Converted scanResults to conversations (${exportData.length} items)`);
        }
        
        // استفاده از scanResults به عنوان scanData
        if (storageResult.scanResults) {
            scanData = storageResult.scanResults.map(scan => ({
                type: "scan_result",
                timestamp: scan.timestamp || Date.now(),
                site: scan.platform || "unknown",
                messageCount: scan.messages?.length || 0,
                data: { messages: scan.messages?.length || 0 }
            }));
        }
        
        // 2. اگر داده‌ای نبود
        if (!exportData || exportData.length === 0) {
            console.warn("[BG][EXPORT] ⚠️ No data available for export");
            
            return {
                success: true,
                format: "txt",
                fileName: "no_conversations.txt",
                itemCount: 0,
                message: "No conversations found yet. Please scan some conversations first.",
                dataSource: dataSource,
                timestamp: Date.now()
            };
        }
        
        // ================================
        // Export Filter Injection (v1.1)
        // ================================
        if (!this._secureFilterManager) {
            this._secureFilterManager = new SecureFilterManager();
        }

        const _beforeCount = Array.isArray(exportData) ? exportData.length : 'object';

        const filteredExportData = await this._secureFilterManager.applyFilters(exportData);

        const _afterCount = Array.isArray(filteredExportData)
            ? filteredExportData.length
            : 'object';

        console.log('[ExportScope] ✅ Filters applied at export boundary', {
            before: _beforeCount,
            after: _afterCount
        });

        exportData = filteredExportData;
        
        // 3. export بر اساس format
        const timestamp = Date.now();
        const baseFileName = `chatsavepro_export_${timestamp}`;
        let result = null;
        
        // 🔴 ALL EXPORTS USE JSON v1.1 AS SINGLE SOURCE OF TRUTH
        console.log('[BG][EXPORT] 🔥 Using JSON v1.1 as Single Source of Truth');
        const jsonData = this.exportHelpers.generateJSON(exportData, scanData);
        
        if (format === "txt") {
            // ✅ TXT export - استفاده از JSON v1.1 و سپس رندر TXT
            console.log('[BG][EXPORT] 📝 Using professional TXT generation');
            
            const txtContent = this.exportHelpers.renderTXTFromJSON(jsonData);
            const txtFileName = `${baseFileName}.txt`;
            
            await forceFileDownload({
                content: txtContent,
                fileName: txtFileName,
                mimeType: 'text/plain;charset=utf-8'
            });
            
            result = {
                success: true,
                format: "txt",
                fileName: txtFileName,
                itemCount: exportData.length,
                message: "TXT export (via JSON v1.1) completed and downloaded successfully",
                dataSource: dataSource,
                timestamp: timestamp,
                version: "1.1",
                architecture: "json_v1.1_based"
            };
            
        } else if (format === "json") {
            // ✅ JSON export v1.1 - Single Source of Truth
            console.log('[BG][EXPORT] 📝 Using JSON v1.1 export');
            const jsonFileName = `${baseFileName}.json`;
            
            await forceFileDownload({
                content: jsonData,
                fileName: jsonFileName,
                mimeType: "application/json;charset=utf-8"
            });
            
            result = {
                success: true,
                format: "json",
                fileName: jsonFileName,
                itemCount: exportData.length,
                message: "JSON v1.1 export (Single Source of Truth) completed and downloaded successfully",
                dataSource: dataSource,
                timestamp: timestamp,
                version: "1.1",
                architecture: "single_source_of_truth"
            };
            
        } else if (format === "html") {
            // ✅ HTML export - Chat-Like Design from JSON v1.1
            console.log('[BG][EXPORT] 📝 Using HTML Chat-Like export via JSON v1.1');
            
            const htmlContent = this.exportHelpers.renderHTMLFromJSON(jsonData);
            const htmlFileName = `${baseFileName}.html`;
            
            await forceFileDownload({
                content: htmlContent,
                fileName: htmlFileName,
                mimeType: "text/html"
            });
            
            result = {
                success: true,
                format: "html",
                fileName: htmlFileName,
                itemCount: exportData.length,
                message: "HTML export (Chat-Like Design via JSON v1.1) completed and downloaded successfully",
                dataSource: dataSource,
                timestamp: timestamp,
                version: "1.1",
                architecture: "json_v1.1_based",
                design: "chat_like_70_80_similarity"
            };
            
        } else if (format === "pdf") {
            // ✅✅✅ PDF export - استفاده از HTML رندر شده از JSON v1.1
            console.log("[BG][EXPORT] 📄 Starting PDF export via JSON v1.1 → HTML → PDF...");
            
            try {
                // ✅ STEP 2: Render HTML from JSON v1.1 (Optimized for PDF)
                console.log("[BG][EXPORT] 🎨 Rendering HTML from JSON v1.1 for PDF...");
                const htmlContent = this.exportHelpers.renderHTMLFromJSON(jsonData);
                
                // ✅ STEP 3: Validate and extract HTML string
                const htmlString = this.freePdfExporter?.extractAndValidateHTML(htmlContent) || htmlContent;
                
                console.log('[BG][EXPORT] PDF HTML payload preview:', {
                    type: typeof htmlString,
                    length: htmlString.length,
                    first500: htmlString.substring(0, 500)
                });
                
                if (!htmlString || typeof htmlString !== "string" || htmlString.trim().length === 0) {
                    throw new Error("HTML generation failed for PDF export - Empty or invalid HTML");
                }
                
                console.log(`[BG][EXPORT] 🧪 HTML payload length for PDF: ${htmlString.length} characters`);
                
                // ✅ STEP 4: Call FreePDFExporter جدید
                console.log("[BG][EXPORT] 📦 Calling FreePDFExporter.exportToPDF...");
                
                if (!this.freePdfExporter) {
                    console.log("[BG][EXPORT] ⏳ FreePDFExporter not loaded yet, loading...");
                    await this._loadFreePDFExporter();
                }
                
                if (!this.freePdfExporter) {
                    throw new Error("FreePDFExporter not available");
                }
                
                const pdfResult = await this.freePdfExporter.exportToPDF({
                    htmlContent: htmlString,
                    fileName: `${baseFileName}.pdf`,
                    title: 'ChatSavePro Export - JSON v1.1 Based',
                    metadata: {
                        title: 'ChatSavePro Export',
                        author: 'ChatSavePro',
                        subject: 'Chat Conversations Export (JSON v1.1 Architecture)',
                        conversationCount: exportData.length,
                        keywords: ['chat', 'export', 'conversation', 'pdf', 'json_v1.1'],
                        architecture: 'json_v1.1_single_source_of_truth'
                    }
                });
                
                console.log("[BG][EXPORT] 🔄 FreePDFExporter result:", {
                    success: pdfResult?.success,
                    downloadStarted: pdfResult?.downloadStarted,
                    fileName: pdfResult?.fileName,
                    fallback: pdfResult?.fallback
                });
                
                if (pdfResult && pdfResult.success && pdfResult.downloadStarted) {
                    // ✅ FreePDFExporter جدید مستقیماً دانلود را شروع می‌کند
                    result = {
                        success: true,
                        format: "pdf",
                        fileName: pdfResult.fileName || `${baseFileName}.pdf`,
                        itemCount: exportData.length,
                        message: "PDF export completed successfully (JSON v1.1 Architecture)",
                        dataSource: dataSource,
                        timestamp: timestamp,
                        downloadStarted: pdfResult.downloadStarted,
                        fallback: pdfResult.fallback || false,
                        htmlGenerated: true,
                        htmlLength: htmlString.length,
                        architecture: "json_v1.1_based",
                        design: "chat_like_for_pdf"
                    };
                    
                } else if (pdfResult?.fallback && pdfResult?.htmlContent) {
                    // ✅ Fallback به HTML با کیفیت بالا
                    console.log("[BG][EXPORT] 🔄 Falling back to HTML export...");
                    
                    const fileName = `${baseFileName}_fallback.html`;
                    
                    await forceFileDownload({
                        content: pdfResult.htmlContent,
                        fileName: fileName,
                        mimeType: "text/html"
                    });
                    
                    result = {
                        success: true,
                        format: "html_fallback",
                        fileName: fileName,
                        itemCount: exportData.length,
                        message: `PDF export failed, HTML fallback downloaded: ${pdfResult.error || 'Unknown error'}`,
                        dataSource: dataSource,
                        timestamp: timestamp,
                        error: pdfResult.error,
                        fallback: true,
                        enhanced: true,
                        htmlLength: pdfResult.htmlContent.length
                    };
                } else {
                    throw new Error(pdfResult?.error || "PDF export failed - invalid response from FreePDFExporter");
                }
                
            } catch (pdfError) {
                console.error("[BG][EXPORT] ❌ PDF export failed:", pdfError);
                
                // Fallback به HTML از JSON v1.1
                console.log("[BG][EXPORT] 🔄 Falling back to HTML export due to PDF failure...");
                
                const fallbackHtml = this.exportHelpers.renderHTMLFromJSON(jsonData);
                const fileName = `${baseFileName}_fallback.html`;
                
                await forceFileDownload({
                    content: fallbackHtml,
                    fileName: fileName,
                    mimeType: "text/html"
                });
                
                result = {
                    success: true,
                    format: "html_fallback",
                    fileName: fileName,
                    itemCount: exportData.length,
                    message: `PDF export failed, HTML fallback downloaded: ${pdfError.message}`,
                    dataSource: dataSource,
                    timestamp: timestamp,
                    error: pdfError.message,
                    fallback: true,
                    enhanced: true,
                    htmlLength: fallbackHtml.length,
                    architecture: "json_v1.1_based_fallback"
                };
            }
            
        } else {
            throw new Error(`Unsupported format: ${format}`);
        }

        console.log("[BG][EXPORT] ✅ Export completed successfully with JSON v1.1");
        return result;

    } catch (error) {
        console.error("[BG][EXPORT] ❌ Export failed:", error);
        
        return {
            success: false,
            format: message?.format || "unknown",
            fileName: "",
            itemCount: 0,
            message: error?.message || "Export failed",
            error: error.message,
            timestamp: Date.now()
        };
    }
  }

  async handleQuantumPing(message, sender) {
    if (message.timestamp && message.timestamp === globalThis.__LAST_PING_TS__) {
        return { 
            success: true, 
            message: "duplicate_ping_ignored",
            layer: "background",
            timestamp: Date.now()
        };
    }
    globalThis.__LAST_PING_TS__ = message.timestamp;
    
    const tabId = message.tabId;
    if (tabId && quantumResyncManager) {
      quantumResyncManager.updateContentScriptPing(tabId);
    }
    return {
      success: true,
      message: "quantum_pong",
      layer: "background",
      timestamp: Date.now(),
      version: "3.9.8",
      tabId
    };
  }

  async handleProcessDeepScan(message, sender) {
    if (!message.session || !message.session.sessionId) {
      throw new Error("Invalid session data");
    }
    if (!Array.isArray(message.messages)) {
      throw new Error("Messages must be an array");
    }
    const scanRecord = {
      sessionId: message.session.sessionId,
      messages: message.messages,
      timestamp: Date.now(),
      messageCount: message.messages.length,
      platform: message.session.platform || "unknown",
      url: message.session.url || "unknown",
      type: "deep_scan",
      tabId: message.tabId
    };
    memoryManager.set("scan", message.session.sessionId, {
      lastUpdate: Date.now(),
      messageCount: message.messages.length,
      status: "completed"
    }, 9e5);
    return {
      success: true,
      saved: true,
      messageCount: message.messages.length,
      sessionId: message.session.sessionId,
      tabId: message.tabId
    };
  }

  async handleReportBrokenSelector(message, sender) {
    console.log("🚨 [BG] Handling broken selector report:", message);
    try {
      await adaptiveSystemManager.handleBrokenSelectorReport(message);
      return {
        success: true,
        message: "Broken selector reported successfully",
        timestamp: Date.now(),
        platform: message.platform
      };
    } catch (error) {
      console.error("❌ Error reporting broken selector:", error);
      return {
        success: false,
        error: error.message,
        timestamp: Date.now()
      };
    }
  }

  async handleGetAdaptiveConfig(message, sender) {
    console.log("🔄 [BG] Getting adaptive config for platform:", message.platform);
    try {
      const config = await adaptiveSystemManager.getAdaptiveConfig(message.platform);
      return {
        success: true,
        config,
        platform: message.platform,
        timestamp: Date.now()
      };
    } catch (error) {
      console.error("❌ Error getting adaptive config:", error);
      return {
        success: false,
        error: error.message,
        timestamp: Date.now()
      };
    }
  }

  async handleSelectorConfigUpdated(message, sender) {
    console.log("🔄 [BG] Handling selector config update:", message);
    try {
      await adaptiveSystemManager.handleSelectorUpdate(message, message.tabId);
      return {
        success: true,
        message: "Selector config updated successfully",
        timestamp: Date.now(),
        platform: message.platform
      };
    } catch (error) {
      console.error("❌ Error updating selector config:", error);
      return {
        success: false,
        error: error.message,
        timestamp: Date.now()
      };
    }
  }
  
  async handleScanResult(message, sender) {
    try {
        const scanData = message.data;
        const tabId = message.tabId;
        
        console.log("💾 [BG] Processing scan result:", {
            site: scanData.site,
            messages: scanData.messages?.length || 0,
            tabId: tabId
        });
        
        if (!scanData || !scanData.messages || scanData.messages.length === 0) {
            return {
                success: false,
                error: "No messages to save",
                timestamp: Date.now()
            };
        }
        
        const conversation = {
            id: `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            site: scanData.site || "unknown",
            hostname: scanData.hostname || "unknown",
            url: scanData.url || "unknown",
            title: scanData.title || `Chat ${new Date().toLocaleString()}`,
            messages: scanData.messages || [],
            messageCount: scanData.messages?.length || 0,
            scannedAt: scanData.timestamp || Date.now(),
            savedAt: Date.now(),
            tabId: tabId,
            version: "1.0"
        };
        
        const saveResult = await this.conversationManager.saveConversation(conversation);
        
        if (saveResult.success) {
            memoryManager.set("session", `last_scan_${tabId}`, {
                conversationId: conversation.id,
                timestamp: Date.now(),
                messageCount: conversation.messageCount
            }, 3600000);
            
            console.log("✅ [BG] Scan result saved:", {
                conversationId: conversation.id,
                messageCount: conversation.messageCount,
                site: conversation.site
            });
            
            return {
                success: true,
                saved: true,
                conversationId: conversation.id,
                messageCount: conversation.messageCount,
                timestamp: Date.now()
            };
        } else {
            return {
                success: false,
                error: saveResult.error || "Failed to save conversation",
                timestamp: Date.now()
            };
        }
        
    } catch (error) {
        console.error("❌ [BG] Error handling scan result:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleSaveConversation(message, sender) {
    try {
        const conversation = message.conversation;
        
        if (!conversation || !conversation.messages || conversation.messages.length === 0) {
            return {
                success: false,
                error: "Invalid conversation data",
                timestamp: Date.now()
            };
        }
        
        if (!conversation.id) {
            conversation.id = `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }
        if (!conversation.savedAt) {
            conversation.savedAt = Date.now();
        }
        
        const saveResult = await this.conversationManager.saveConversation(conversation);
        
        return {
            success: saveResult.success,
            conversationId: conversation.id,
            savedAt: conversation.savedAt,
            timestamp: Date.now(),
            totalConversations: saveResult.totalConversations
        };
        
    } catch (error) {
        console.error("❌ [BG] Error saving conversation:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleGetConversations(message, sender) {
    try {
        const filter = message.data || {};
        const result = await this.conversationManager.getConversations(filter);
        return result;
    } catch (error) {
        console.error("❌ [BG] Error getting conversations:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleScanNow(message, sender) {
    try {
        const tabId = message.tabId;
        
        if (!tabId) {
            return {
                success: false,
                error: "No tab ID available",
                timestamp: Date.now()
            };
        }
        
        console.log("🔍 [BG] Manual scan requested for tab:", tabId);
        
        try {
            await chrome.tabs.sendMessage(tabId, {
                action: "SCAN_NOW",
                data: { manual: true, timestamp: Date.now() }
            });
            
            return {
                success: true,
                forwarded: true,
                tabId: tabId,
                timestamp: Date.now(),
                message: "Scan request forwarded to content script"
            };
        } catch (error) {
            console.warn("⚠️ [BG] Could not send scan request to tab:", tabId, error.message);
            return {
                success: false,
                error: "Content script not ready",
                tabId: tabId,
                timestamp: Date.now()
            };
        }
        
    } catch (error) {
        console.error("❌ [BG] Error handling scan now:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleAutoScanResult(message, sender) {
    try {
        const conversation = message.conversation;
        
        if (!conversation || !conversation.messages || conversation.messages.length === 0) {
            return {
                success: false,
                error: "Invalid conversation data",
                timestamp: Date.now()
            };
        }
        
        conversation.id = `auto_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        conversation.savedAt = Date.now();
        conversation.autoSaved = true;
        
        const saveResult = await this.conversationManager.saveConversation(conversation);
        
        return {
            success: saveResult.success,
            autoSaved: saveResult.success,
            conversationId: conversation.id,
            timestamp: Date.now(),
            messageCount: conversation.messages.length
        };
        
    } catch (error) {
        console.error("❌ [BG] Error handling auto scan result:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleGetConversation(message, sender) {
    try {
        const id = message.id;
        if (!id) {
            return {
                success: false,
                error: "Conversation ID required",
                timestamp: Date.now()
            };
        }
        
        const result = await this.conversationManager.getConversation(id);
        return result;
    } catch (error) {
        console.error("❌ [BG] Error getting conversation:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleDeleteConversation(message, sender) {
    try {
        const id = message.id;
        if (!id) {
            return {
                success: false,
                error: "Conversation ID required",
                timestamp: Date.now()
            };
        }
        
        const result = await this.conversationManager.deleteConversation(id);
        return result;
    } catch (error) {
        console.error("❌ [BG] Error deleting conversation:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }
  
  async handleCleanupConversations(message, sender) {
    try {
        const days = message.days || 30;
        const result = await this.conversationManager.cleanupOldConversations(days);
        return result;
    } catch (error) {
        console.error("❌ [BG] Error cleaning up conversations:", error);
        return {
            success: false,
            error: error.message,
            timestamp: Date.now()
        };
    }
  }

  // ✅ اضافه کردن handlerهای Offscreen
  registerNamespace(namespace, handlers) {
    if (!this._namespaces) {
      this._namespaces = new Map();
    }
    this._namespaces.set(namespace, handlers);
    console.log(`✅ Registered namespace: ${namespace} with ${Object.keys(handlers).length} handlers`);
  }

  getNamespaceHandler(namespace, action) {
    const ns = this._namespaces?.get(namespace);
    return ns?.[action];
  }
  
  getRegisteredNamespaces() {
    if (!this._namespaces) return {};
    return Object.fromEntries(this._namespaces);
  }
};

// ==================== CREATE INSTANCES ====================
var memoryManager = new SimplifiedMemoryManager();
var quantumResyncManager = new QuantumResyncManager();
var actionHandlerManager = new ActionHandlerManager();
var selectorDatabase = new SelectorDatabase();
var adaptiveSystemManager = new AdaptiveSystemManager();

// 🔴 FIX: تعریف backgroundManager
globalThis.backgroundManager = {
  handleConnectionLost: function(tabId) {
    console.log(`🔌 Connection lost for tab ${tabId}, handled by backgroundManager`);
    // می‌توانید منطق real handler را اینجا اضافه کنید
  }
};

globalThis.actionHandlerManager = actionHandlerManager;

console.log("✅ Core instances created");

// ==================== INITIALIZATION ====================
let initAttempts = 0;
const MAX_INIT_ATTEMPTS = 3;

async function initializeBackgroundSystem() {
    try {
        if (initAttempts >= MAX_INIT_ATTEMPTS) {
            console.warn("🚨 Max initialization attempts reached");
            return;
        }
        
        initAttempts++;
        console.log(`🚀 Initializing background system (attempt ${initAttempts})`);
        
        await adaptiveSystemManager.initialize();
        await selectorDatabase.initialize();
        await actionHandlerManager.conversationManager.initialize();
        
        // ✅ Initialize FreePDFExporter
        if (actionHandlerManager.freePdfExporter) {
            await actionHandlerManager.freePdfExporter.initialize();
        }
        
        await quantumResyncManager.setupTabCleanup();
        
        // 🔴 FIX: Initialize ExportRegistry fallback
        if (typeof globalThis.ExportRegistry === 'undefined') {
            console.log("[BG] 📦 Initializing ExportRegistry fallback");
            globalThis.ExportRegistry = {
                render: (format, data) => {
                    console.log(`[ExportRegistry] Rendering ${format} via JSON v1.1 fallback`);
                    const helpers = new ExportFormatHelpers();
                    if (format === 'html') {
                        return helpers.renderHTMLFromJSON(data);
                    } else if (format === 'txt') {
                        return helpers.renderTXTFromJSON(data);
                    }
                    return JSON.stringify(data, null, 2);
                },
                register: (name, renderer) => {
                    console.log(`[ExportRegistry] Registered renderer: ${name}`);
                }
            };
        }
        
        console.log("🎉 Background system initialized successfully with JSON v1.1");
        
    } catch (error) {
        console.error("❌ Background initialization failed:", error);
        
        if (initAttempts < MAX_INIT_ATTEMPTS) {
            setTimeout(initializeBackgroundSystem, 2000);
        }
    }
}

initializeBackgroundSystem();

globalThis.quantumBackground = {
    memory: memoryManager,
    resync: quantumResyncManager,
    adaptive: adaptiveSystemManager,
    selectors: selectorDatabase,
    conversations: actionHandlerManager.conversationManager,
    freePdfExporter: actionHandlerManager.freePdfExporter,
    ensurePdfV1Offscreen: ensurePdfV1Offscreen,
    exportHelpers: new ExportFormatHelpers(),
    exportRegistry: globalThis.ExportRegistry
};

console.log("🎯 QuantumStage v3.9.8 - JSON v1.1 Block-Based Architecture");

// ==================== SERVICE WORKER KEEPALIVE ====================
let keepAliveInterval = null;

function setupKeepAlive() {
    if (keepAliveInterval) clearInterval(keepAliveInterval);
    
    keepAliveInterval = setInterval(() => {
        const stats = memoryManager.getStats();
        console.log("💓 Service worker keepalive - Memory stats:", stats.total);
        
        // Keep PDF v1 Offscreen alive
        if (!pdfV1OffscreenReady) {
            ensurePdfV1Offscreen().catch(() => {});
        }
    }, 30000);
}

setupKeepAlive();

chrome.runtime.onSuspend.addListener(() => {
    if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
        keepAliveInterval = null;
    }
    console.log("🛑 Service worker suspending...");
});

console.log("🎉 Background.js initialization COMPLETE with JSON v1.1 Single Source of Truth!");