// modules/FreePDFExporter.js
export class FreePDFExporter {
  async export({ html, filename }) {
    console.log("[FreePDFExporter] 🚀 Sending GENERATE_PDF_V1 to Offscreen");

    const response = await chrome.runtime.sendMessage({
      type: "GENERATE_PDF_V1",
      payload: {
        html,
        filename,
      },
    });

    if (!response?.success) {
      throw new Error(response?.error || "PDF v1 export failed");
    }

    console.log("[FreePDFExporter] ✅ PDF download started");
    return response;
  }
}
