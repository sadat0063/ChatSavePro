// ============================================================
// modules/GuardianIntegrity.js — QuantumStage v3.9 / SIMPLIFIED
// Simplified GuardianIntegrity for ChatSavePro Extension
// ============================================================

// ✅ SIMPLE SIGNATURE MANAGER
class SimpleSignatureManager {
    #signatures = new Map();
    
    constructor() {
        this.#initializeDefaultSignatures();
    }
    
    #initializeDefaultSignatures() {
        // Default system signatures
        this.#signatures.set('ScanLayer', ['scan:v1', 'scan:v2']);
        this.#signatures.set('ContentScript', ['cs:v1', 'cs:v2']);
        this.#signatures.set('Background', ['bg:v1', 'bg:v2']);
        this.#signatures.set('Guardian', ['guardian:v1', 'guardian:v2']);
        this.#signatures.set('System', ['system:v1']);
    }
    
    register(moduleId, signature) {
        if (!moduleId || typeof moduleId !== 'string') {
            throw new Error('Module ID must be a string');
        }
        
        if (!this.#signatures.has(moduleId)) {
            this.#signatures.set(moduleId, []);
        }
        
        const signatures = this.#signatures.get(moduleId);
        if (!signatures.includes(signature)) {
            signatures.push(signature);
        }
        
        return true;
    }
    
    verify(moduleId, signature) {
        const moduleSignatures = this.#signatures.get(moduleId);
        return moduleSignatures ? moduleSignatures.includes(signature) : false;
    }
    
    getStats() {
        return {
            totalModules: this.#signatures.size,
            totalSignatures: Array.from(this.#signatures.values())
                .reduce((sum, sigs) => sum + sigs.length, 0)
        };
    }
}

// ✅ SIMPLE AUDIT LOGGER
class SimpleAuditLogger {
    #logs = [];
    #maxLogs = 200;
    #sensitivePatterns = [
        /password=['"]?([^'"]+)['"]?/gi,
        /token=['"]?([^'"]+)['"]?/gi,
        /api[_-]?key=['"]?([^'"]+)['"]?/gi,
        /secret=['"]?([^'"]+)['"]?/gi
    ];
    
    log(event, data = {}, level = 'info') {
        try {
            const logEntry = {
                id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
                timestamp: Date.now(),
                event,
                level,
                data: this.#sanitizeData(data)
            };
            
            this.#logs.push(logEntry);
            
            // Maintain size limit
            if (this.#logs.length > this.#maxLogs) {
                this.#logs.shift();
            }
            
            // Console output for important events
            if (level === 'error' || level === 'warn') {
                console[level](`[Guardian] ${event}:`, data);
            }
            
            return logEntry.id;
            
        } catch (error) {
            console.warn('⚠️ Audit logging failed:', error.message);
            return null;
        }
    }
    
    #sanitizeData(data) {
        if (typeof data !== 'object' || data === null) {
            return typeof data === 'string' ? this.#sanitizeString(data) : data;
        }
        
        const sanitized = {};
        for (const [key, value] of Object.entries(data)) {
            if (typeof value === 'string') {
                sanitized[key] = this.#sanitizeString(value);
            } else if (typeof value === 'object' && value !== null) {
                sanitized[key] = this.#sanitizeData(value);
            } else {
                sanitized[key] = value;
            }
        }
        
        return sanitized;
    }
    
    #sanitizeString(str) {
        let sanitized = String(str);
        
        // Redact sensitive info
        this.#sensitivePatterns.forEach(pattern => {
            sanitized = sanitized.replace(pattern, (match) => {
                return match.replace(/(['"]?)([^'"]+)(['"]?)/, '$1***$3');
            });
        });
        
        // Limit length
        if (sanitized.length > 1000) {
            sanitized = sanitized.substring(0, 1000) + '...';
        }
        
        return sanitized;
    }
    
    getEvents(limit = 50, level = null) {
        let events = this.#logs;
        if (level) {
            events = events.filter(entry => entry.level === level);
        }
        return events.slice(-limit);
    }
    
    getStats() {
        return {
            totalLogs: this.#logs.length,
            errorLogs: this.#logs.filter(log => log.level === 'error').length,
            warningLogs: this.#logs.filter(log => log.level === 'warn').length,
            infoLogs: this.#logs.filter(log => log.level === 'info').length
        };
    }
    
    clear() {
        this.#logs = [];
    }
}

// ✅ GUARDIAN INTEGRITY - SIMPLIFIED VERSION
export class GuardianIntegrity {
    static #instance = null;

    constructor(config = {}) {
        if (GuardianIntegrity.#instance) return GuardianIntegrity.#instance;
        GuardianIntegrity.#instance = this;

        this.mode = config.mode || 'active';
        this.version = '1.0-simple';
        this.initialized = false;
        
        // Core components
        this.signatureManager = new SimpleSignatureManager();
        this.logger = new SimpleAuditLogger();
        
        // Message handlers
        this.messageHandlers = new Map();
        
        // ScanLayer status
        this.scanLayerStatus = {
            loaded: false,
            ready: false,
            lastCheck: 0
        };
        
        console.log('🛡️ Simplified GuardianIntegrity initialized');
    }

    static getInstance(config = {}) {
        return GuardianIntegrity.#instance || new GuardianIntegrity(config);
    }

    static create(config = {}) {
        return GuardianIntegrity.getInstance(config);
    }

    // ✅ INITIALIZATION
    async init(config = {}) {
        if (this.initialized) {
            return this;
        }
        
        const initId = this.logger.log('INIT_STARTED', { config: Object.keys(config) });
        
        try {
            // Setup message listeners
            this.setupMessageListeners();
            
            // Setup bridge to Content Script
            this.setupBridge();
            
            // Setup ScanLayer integration
            this.setupScanLayerIntegration();
            
            // Register default signatures
            this.signatureManager.register('GuardianIntegrity', 'gi:v1:self');
            
            this.initialized = true;
            
            this.logger.log('INIT_COMPLETED', { 
                mode: this.mode,
                version: this.version
            });
            
            console.log('✅ Simplified GuardianIntegrity initialization completed');
            
            // ارسال handshake به CS
            this.sendHandshake();
            
            // درخواست وضعیت از ScanLayer
            window.postMessage({
                source: 'GUARDIAN',
                type: 'SL_STATUS_REQUEST',
                reqId: 'GUARDIAN_CHECK'
            }, '*');
            
            return this;
            
        } catch (error) {
            this.logger.log('INIT_FAILED', { error: error.message }, 'error');
            console.error('❌ GuardianIntegrity initialization failed:', error);
            throw error;
        }
    }

    // ✅ MESSAGE LISTENERS
    setupMessageListeners() {
        // Listen for window messages
        window.addEventListener('message', (event) => {
            if (!event.data || !event.data.type) return;
            
            const data = event.data;
            
            // Handle ScanLayer responses
            if (data.type === 'SL_STATUS_RESPONSE') {
                this.handleScanLayerStatus(data);
            }
            
            // Handle messages from Content Script
            if (data.source === 'CS_BRIDGE') {
                this.handleBridgeMessage(data);
            }
            
            // Handle scan results
            if (data.type === 'SCAN_RESULT') {
                this.handleScanResult(data);
            }
            
            // Handle Guardian messages
            if (data.type === 'GUARDIAN_TO_LIGHT') {
                this.handleGuardianMessage(data);
            }
        });
        
        // Listen for extension messages (if in extension context)
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                return this.handleExtensionMessage(message, sender, sendResponse);
            });
        }
        
        this.logger.log('MESSAGE_LISTENERS_SETUP', {});
    }

    // ✅ BRIDGE SETUP
    setupBridge() {
        this.bridgeActive = true;
        this.bridgeSessionId = `bridge_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        
        this.logger.log('BRIDGE_SETUP', {
            sessionId: this.bridgeSessionId,
            active: this.bridgeActive
        });
    }

    // ✅ SCANLAYER INTEGRATION
    setupScanLayerIntegration() {
        // Register scan handlers
        this.registerMessageHandler('SCAN_NOW', this.handleScanRequest.bind(this));
        this.registerMessageHandler('SAVE_CURRENT', this.handleSaveRequest.bind(this));
        this.registerMessageHandler('GET_SCAN_STATUS', this.handleGetScanStatus.bind(this));
        
        // Periodically check ScanLayer status
        this.startScanLayerMonitor();
        
        this.logger.log('SCANLAYER_INTEGRATION_SETUP', {});
    }

    // ✅ SEND HANDSHAKE TO CONTENT SCRIPT
    sendHandshake() {
        try {
            window.postMessage({
                source: 'GUARDIAN',
                type: 'GUARDIAN_READY',
                payload: {
                    version: this.version,
                    mode: this.mode,
                    timestamp: Date.now(),
                    bridgeActive: this.bridgeActive,
                    sessionId: this.bridgeSessionId
                }
            }, '*');
            
            this.logger.log('HANDSHAKE_SENT', {});
            console.log('🤝 Guardian handshake sent to Content Script');
            
        } catch (error) {
            this.logger.log('HANDSHAKE_FAILED', { error: error.message }, 'error');
        }
    }

    // ✅ SCANLAYER STATUS MONITOR
    startScanLayerMonitor() {
        const checkInterval = setInterval(() => {
            if (!this.scanLayerStatus.loaded || Date.now() - this.scanLayerStatus.lastCheck > 60000) {
                window.postMessage({
                    source: 'GUARDIAN',
                    type: 'SL_STATUS_REQUEST',
                    reqId: `monitor_${Date.now()}`
                }, '*');
            }
        }, 30000);
        
        // Store interval for cleanup
        this.scanLayerMonitorInterval = checkInterval;
        
        this.logger.log('SCANLAYER_MONITOR_STARTED', { interval: 30000 });
    }

    // ✅ MESSAGE HANDLER REGISTRATION
    registerMessageHandler(action, handler) {
        this.messageHandlers.set(action, handler);
    }

    // ✅ HANDLE SCANLAYER STATUS
    handleScanLayerStatus(data) {
        const { payload } = data;
        
        this.scanLayerStatus = {
            loaded: payload.loaded || false,
            ready: payload.ready || false,
            lastCheck: Date.now(),
            version: payload.version || 'unknown',
            scannerReady: payload.scannerReady || false,
            timestamp: Date.now()
        };
        
        this.logger.log('SCANLAYER_STATUS', {
            loaded: this.scanLayerStatus.loaded,
            ready: this.scanLayerStatus.ready,
            version: this.scanLayerStatus.version
        });
        
        // If ScanLayer is loaded and ready, trigger initial scan
        if (this.scanLayerStatus.ready && this.scanLayerStatus.scannerReady) {
            setTimeout(() => {
                this.triggerInitialScan();
            }, 2000);
        }
    }

    // ✅ HANDLE BRIDGE MESSAGES
    handleBridgeMessage(data) {
        const { type, payload } = data;
        
        this.logger.log('BRIDGE_MESSAGE_RECEIVED', { type });
        
        switch (type) {
            case 'SL_STATUS_REQUEST':
                // Forward to ScanLayer
                window.postMessage({
                    source: 'GUARDIAN',
                    type: 'SL_STATUS_REQUEST',
                    reqId: data.reqId || 'forwarded'
                }, '*');
                break;
                
            case 'SCAN_NOW':
                this.handleScanRequest(payload);
                break;
                
            case 'SAVE_CURRENT':
                this.handleSaveRequest(payload);
                break;
                
            default:
                console.warn('⚠️ Unknown bridge message type:', type);
        }
    }

    // ✅ HANDLE EXTENSION MESSAGES
    handleExtensionMessage(message, sender, sendResponse) {
        const { action } = message || {};
        
        this.logger.log('EXTENSION_MESSAGE_RECEIVED', { 
            action,
            senderId: sender.tab?.id 
        });
        
        // Check for signature
        if (message.signature) {
            try {
                const isValid = this.signatureManager.verify(message.module || 'unknown', message.signature);
                if (!isValid) {
                    sendResponse({ success: false, error: 'Invalid signature' });
                    return true;
                }
            } catch (error) {
                sendResponse({ success: false, error: 'Signature verification failed' });
                return true;
            }
        }
        
        // Handle specific actions
        const handler = this.messageHandlers.get(action);
        if (handler) {
            try {
                const result = handler(message.data || {});
                if (result && result.then) {
                    // Async handler
                    result.then(response => sendResponse(response))
                        .catch(error => sendResponse({ success: false, error: error.message }));
                    return true;
                } else {
                    // Sync handler
                    sendResponse(result);
                    return false;
                }
            } catch (error) {
                this.logger.log('MESSAGE_HANDLER_ERROR', { action, error: error.message }, 'error');
                sendResponse({ success: false, error: error.message });
                return false;
            }
        }
        
        // Default response for unknown actions
        sendResponse({ 
            success: false, 
            error: 'Unknown action',
            receivedAction: action 
        });
        return false;
    }

    // ✅ HANDLE SCAN REQUEST
    async handleScanRequest(data = {}) {
        this.logger.log('SCAN_REQUEST_RECEIVED', data);
        
        if (!this.scanLayerStatus.ready) {
            this.logger.log('SCANLAYER_NOT_READY', {}, 'warn');
            return { success: false, error: 'ScanLayer not ready' };
        }
        
        try {
            // Forward scan request to ScanLayer
            window.postMessage({
                source: 'GUARDIAN',
                type: 'SCAN_NOW',
                payload: data,
                timestamp: Date.now()
            }, '*');
            
            this.logger.log('SCAN_REQUEST_FORWARDED', data);
            
            return { 
                success: true, 
                message: 'Scan request forwarded to ScanLayer',
                timestamp: Date.now()
            };
            
        } catch (error) {
            this.logger.log('SCAN_REQUEST_FAILED', { error: error.message }, 'error');
            return { success: false, error: error.message };
        }
    }

    // ✅ HANDLE SAVE REQUEST
    async handleSaveRequest(data = {}) {
        this.logger.log('SAVE_REQUEST_RECEIVED', data);
        
        try {
            // Send save request through bridge
            window.postMessage({
                source: 'GUARDIAN',
                type: 'SAVE_CURRENT',
                payload: data,
                timestamp: Date.now()
            }, '*');
            
            return { 
                success: true, 
                message: 'Save request processed',
                timestamp: Date.now() 
            };
            
        } catch (error) {
            this.logger.log('SAVE_REQUEST_FAILED', { error: error.message }, 'error');
            return { success: false, error: error.message };
        }
    }

    // ✅ HANDLE SCAN RESULT
    handleScanResult(data) {
        const { payload } = data;
        
        this.logger.log('SCAN_RESULT', {
            site: payload.site,
            messagesCount: payload.messages?.length || 0,
            success: payload.success || false
        });
        
        // Forward to background for storage
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({
                action: 'SCAN_RESULT',
                data: payload,
                signature: 'guardian:v1',
                timestamp: Date.now()
            });
        }
    }

    // ✅ HANDLE GUARDIAN MESSAGE
    handleGuardianMessage(data) {
        this.logger.log('GUARDIAN_MESSAGE_RECEIVED', { type: data.payload?.action });
        
        // Forward to appropriate handler
        if (data.payload?.action === 'SCAN_NOW') {
            this.handleScanRequest(data.payload.data || {});
        }
    }

    // ✅ TRIGGER INITIAL SCAN
    triggerInitialScan() {
        if (this.initialScanTriggered) return;
        
        this.initialScanTriggered = true;
        
        this.logger.log('INITIAL_SCAN_TRIGGERED', {});
        
        // Trigger initial scan after 3 seconds
        setTimeout(() => {
            this.handleScanRequest({ auto: true });
        }, 3000);
    }

    // ✅ HANDLE GET SCAN STATUS
    handleGetScanStatus(data = {}) {
        return {
            success: true,
            scanLayer: this.scanLayerStatus,
            guardian: {
                initialized: this.initialized,
                mode: this.mode,
                version: this.version,
                bridgeActive: this.bridgeActive
            },
            timestamp: Date.now()
        };
    }

    // ✅ VALIDATE MESSAGE
    validateMessage(message, expectedModule = null) {
        try {
            // Basic validation
            if (!message || typeof message !== 'object') {
                throw new Error('Invalid message format');
            }
            
            if (!message.action) {
                throw new Error('Message missing action');
            }
            
            // Signature validation (if required)
            if (expectedModule && message.signature) {
                const isValid = this.signatureManager.verify(expectedModule, message.signature);
                if (!isValid) {
                    throw new Error(`Invalid signature for module: ${expectedModule}`);
                }
            }
            
            return true;
            
        } catch (error) {
            this.logger.log('MESSAGE_VALIDATION_FAILED', { 
                error: error.message,
                expectedModule 
            }, 'error');
            throw error;
        }
    }

    // ✅ GET HEALTH REPORT
    getHealthReport() {
        const signatureStats = this.signatureManager.getStats();
        const auditStats = this.logger.getStats();
        
        return {
            status: 'healthy',
            initialized: this.initialized,
            mode: this.mode,
            version: this.version,
            scanLayerStatus: this.scanLayerStatus,
            signatureStats,
            auditStats,
            bridgeActive: this.bridgeActive,
            timestamp: Date.now()
        };
    }

    // ✅ HEALTH CHECK
    healthCheck() {
        const signatureStats = this.signatureManager.getStats();
        
        return {
            status: this.initialized ? 'healthy' : 'initializing',
            signaturesHealthy: signatureStats.totalModules > 0,
            scanLayerLoaded: this.scanLayerStatus.loaded,
            scanLayerReady: this.scanLayerStatus.ready,
            timestamp: Date.now()
        };
    }

    // ✅ CLEANUP
    destroy() {
        try {
            // Clear monitor interval
            if (this.scanLayerMonitorInterval) {
                clearInterval(this.scanLayerMonitorInterval);
            }
            
            // Clear logs
            this.logger.clear();
            
            // Clear message handlers
            this.messageHandlers.clear();
            
            this.logger.log('DESTROYED', {});
            console.log('🧹 GuardianIntegrity destroyed');
            
        } catch (error) {
            console.error('❌ GuardianIntegrity destruction error:', error);
        }
    }

    // ✅ GET AUDIT TRAIL
    getAuditTrail(limit = 50, level = null) {
        return this.logger.getEvents(limit, level);
    }

    // ✅ VERSION INFO
    static get version() {
        return '1.0-simple';
    }
}

export default GuardianIntegrity;