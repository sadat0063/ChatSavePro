// ============================================================
// TooltipManager.js - ES6 Module with Guardian Principles
// ============================================================

// 🛡️ PRINCIPLE 1: Context Isolation
const TOOLTIP_POSITIONS = Object.freeze({
    TOP: 'top',
    BOTTOM: 'bottom',
    LEFT: 'left',
    RIGHT: 'right'
});

const TOOLTIP_TYPES = Object.freeze({
    DEFAULT: '',
    SUCCESS: 'success',
    WARNING: 'warning',
    ERROR: 'error',
    INFO: 'info'
});

// 🛡️ PRINCIPLE 2: Strict Interface Contract
const TOOLTIP_CONFIG = Object.freeze({
    DEFAULT_DELAY: 200,
    DEFAULT_DURATION: 4000,
    MAX_TOOLTIPS: 50,
    CLEANUP_THRESHOLD: 0.8,
    QUEUE_MAX_SIZE: 20,
    QUEUE_THROTTLE_DELAY: 10
});

// 🛡️ PRINCIPLE 7: Async Pipeline & Resilience
class TooltipPipeline {
    constructor() {
        this.tasks = [];
        this.isProcessing = false;
        this.maxQueueSize = TOOLTIP_CONFIG.QUEUE_MAX_SIZE;
        this.throttleDelay = TOOLTIP_CONFIG.QUEUE_THROTTLE_DELAY;
        this.metrics = {
            processed: 0,
            errors: 0,
            averageTime: 0
        };
    }

    async queueOperation(operation, ...args) {
        return new Promise((resolve, reject) => {
            const task = {
                operation,
                args,
                resolve,
                reject,
                timestamp: Date.now(),
                id: `tooltip_op_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
            };

            this.tasks.push(task);

            // 🛡️ PRINCIPLE 5: Memory Segmentation - مدیریت صف
            if (this.tasks.length > this.maxQueueSize) {
                const removed = this.tasks.shift();
                console.warn('[TooltipManager] Queue overflow, removed task:', removed.id);
            }

            if (!this.isProcessing) {
                this._processQueue();
            }
        });
    }

    async _processQueue() {
        if (this.isProcessing || this.tasks.length === 0) return;
        
        this.isProcessing = true;
        const startTime = Date.now();

        try {
            while (this.tasks.length > 0) {
                const task = this.tasks.shift();
                const taskStart = Date.now();

                try {
                    const result = await task.operation(...task.args);
                    task.resolve(result);
                    this.metrics.processed++;
                } catch (error) {
                    task.reject(error);
                    this.metrics.errors++;
                }

                // Throttle برای عملکرد بهتر
                if (this.tasks.length > 0) {
                    await new Promise(resolve => 
                        setTimeout(resolve, this.throttleDelay)
                    );
                }
            }
        } finally {
            this.isProcessing = false;
            const totalTime = Date.now() - startTime;
            this.metrics.averageTime = this.metrics.processed > 0 ? 
                totalTime / this.metrics.processed : 0;
        }
    }

    getMetrics() {
        return {
            ...this.metrics,
            queueSize: this.tasks.length,
            isProcessing: this.isProcessing
        };
    }
}

// 🛡️ PRINCIPLE 9: Secure Logging & Sanitization
class TooltipLogger {
    constructor() {
        this.enabled = true;
        this.maxLogSize = 100;
        this.logs = [];
    }

    log(level, message, data = null) {
        if (!this.enabled) return;

        const logEntry = {
            timestamp: Date.now(),
            level,
            message,
            data: this._sanitizeData(data)
        };

        this.logs.push(logEntry);

        // مدیریت اندازه لاگ‌ها
        if (this.logs.length > this.maxLogSize) {
            this.logs = this.logs.slice(-this.maxLogSize);
        }

        // کنسول فقط در حالت توسعه
        if (process.env.NODE_ENV === 'development') {
            const consoleMethod = console[level] || console.log;
            consoleMethod(`[TooltipManager][${level}] ${message}`, data || '');
        }
    }

    _sanitizeData(data) {
        if (!data) return null;
        
        try {
            // حذف داده‌های حساس از DOM elements
            const sanitized = JSON.parse(JSON.stringify(data, (key, value) => {
                if (value instanceof HTMLElement) {
                    return `HTMLElement:${value.tagName}`;
                }
                if (key === 'element' || key === 'tooltip') {
                    return `HTMLElement:${value?.tagName || 'unknown'}`;
                }
                return value;
            }));
            return sanitized;
        } catch {
            return { error: 'Unable to sanitize data' };
        }
    }

    getLogs() {
        return [...this.logs];
    }

    clearLogs() {
        this.logs = [];
    }
}

// 🛡️ PRINCIPLE 4: Enhanced Engine Abstraction
export class TooltipManager {
    constructor() {
        this.tooltips = new Map();
        this.pipeline = new TooltipPipeline();
        this.logger = new TooltipLogger();
        
        // 🛡️ PRINCIPLE 6: Deterministic State Recovery
        this.monitoring = {
            totalTooltips: 0,
            activeTooltips: 0,
            shownTooltips: 0,
            hiddenTooltips: 0,
            errorCount: 0,
            averageShowTime: 0,
            lastOperationTime: null
        };
        
        this.performance = {
            stylesInjected: false,
            mutationObserver: null,
            animationSupported: this._checkAnimationSupport(),
            transitionSupported: this._checkTransitionSupport()
        };

        this.cleanupInterval = null;
        this.systemPreferenceHandler = null;

        this.logger.log('info', 'TooltipManager instance created', {
            config: TOOLTIP_CONFIG,
            features: this.performance
        });
    }

    // 🛡️ PRINCIPLE 7: Async Pipeline & Resilience
    async initialize() {
        try {
            await this._waitForDOM();
            this._initStyles();
            this._setupCleanupInterval();
            this._setupMutationObserver();
            
            this.logger.log('info', 'TooltipManager initialized successfully', {
                performance: this.performance
            });
            
            return true;
        } catch (error) {
            this.logger.log('error', 'Initialization failed', { error: error.message });
            this.monitoring.errorCount++;
            throw error;
        }
    }

    async _waitForDOM() {
        return new Promise((resolve) => {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', resolve);
            } else {
                resolve();
            }
        });
    }

    _checkAnimationSupport() {
        return !!(window.CSS && CSS.supports && CSS.supports('animation', 'fadeIn 0.2s'));
    }

    _checkTransitionSupport() {
        return !!(window.CSS && CSS.supports && CSS.supports('transition', 'all 0.2s'));
    }

    _initStyles() {
        if (this.performance.stylesInjected) return;

        const styles = `
            .chat-tooltip {
                position: absolute;
                background: rgba(0, 0, 0, 0.9);
                color: white;
                padding: 8px 12px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 500;
                white-space: nowrap;
                z-index: 10000;
                pointer-events: none;
                opacity: 0;
                transform: translateY(-10px);
                transition: all 0.2s ease;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                max-width: 200px;
                text-align: center;
                backdrop-filter: blur(4px);
                border: 1px solid rgba(255,255,255,0.1);
            }

            .chat-tooltip.visible {
                opacity: 1;
                transform: translateY(0);
            }

            .chat-tooltip::after {
                content: '';
                position: absolute;
                top: 100%;
                left: 50%;
                transform: translateX(-50%);
                border: 5px solid transparent;
                border-top-color: rgba(0, 0, 0, 0.9);
            }

            .chat-tooltip.top::after {
                top: auto;
                bottom: 100%;
                border-top-color: transparent;
                border-bottom-color: rgba(0, 0, 0, 0.9);
            }

            .chat-tooltip.left::after {
                left: 10px;
                transform: translateX(0);
            }

            .chat-tooltip.right::after {
                left: auto;
                right: 10px;
                transform: translateX(0);
            }

            .chat-tooltip.bottom::after {
                top: 100%;
                bottom: auto;
            }

            .chat-tooltip.success {
                background: rgba(46, 204, 113, 0.95);
            }

            .chat-tooltip.warning {
                background: rgba(243, 156, 18, 0.95);
            }

            .chat-tooltip.error {
                background: rgba(231, 76, 60, 0.95);
            }

            .chat-tooltip.info {
                background: rgba(52, 152, 219, 0.95);
            }

            .chat-tooltip.multiline {
                white-space: normal;
                word-wrap: break-word;
                max-width: 300px;
            }
        `;

        const styleSheet = document.createElement('style');
        styleSheet.id = 'tooltip-styles';
        styleSheet.textContent = styles;
        document.head.appendChild(styleSheet);
        
        this.performance.stylesInjected = true;
    }

    _setupMutationObserver() {
        this.performance.mutationObserver = new MutationObserver((mutations) => {
            this._handleMutations(mutations);
        });

        this.performance.mutationObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    _handleMutations(mutations) {
        for (const mutation of mutations) {
            if (mutation.type === 'childList') {
                for (const node of mutation.removedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        this._cleanupForRemovedElement(node);
                    }
                }
            }
        }
    }

    _cleanupForRemovedElement(element) {
        // بررسی اگر المنت خودش tooltip دارد
        if (this.tooltips.has(element)) {
            this.removeTooltip(element);
        }

        // بررسی تمام المنت‌های فرزند
        const childElements = element.querySelectorAll('*');
        childElements.forEach(child => {
            if (this.tooltips.has(child)) {
                this.removeTooltip(child);
            }
        });
    }

    _setupCleanupInterval() {
        this.cleanupInterval = setInterval(() => {
            this._performAutoCleanup();
        }, 30000); // تمیزکاری هر 30 ثانیه
    }

    _performAutoCleanup() {
        try {
            const startTime = Date.now();
            let cleanedCount = 0;

            // تمیزکاری اگر تعداد tooltip‌ها زیاد است
            if (this.tooltips.size > TOOLTIP_CONFIG.MAX_TOOLTIPS * TOOLTIP_CONFIG.CLEANUP_THRESHOLD) {
                const tooltipsToRemove = this.tooltips.size - Math.floor(TOOLTIP_CONFIG.MAX_TOOLTIPS * 0.6);
                const iterator = this.tooltips.keys();
                
                for (let i = 0; i < tooltipsToRemove; i++) {
                    const element = iterator.next().value;
                    if (element) {
                        this.removeTooltip(element);
                        cleanedCount++;
                    }
                }
            }

            // تمیزکاری tooltip‌های مربوط به المنت‌های حذف شده از DOM
            this.tooltips.forEach((_, element) => {
                if (!document.body.contains(element)) {
                    this.removeTooltip(element);
                    cleanedCount++;
                }
            });

            const cleanupTime = Date.now() - startTime;
            if (cleanedCount > 0) {
                this.logger.log('info', 'Auto-cleanup performed', {
                    cleanedCount,
                    duration: cleanupTime,
                    remainingTooltips: this.tooltips.size
                });
            }

        } catch (error) {
            this.logger.log('error', 'Auto-cleanup failed', { error: error.message });
            this.monitoring.errorCount++;
        }
    }

    // 🛡️ PRINCIPLE 2: Strict Interface Contract
    async createTooltip(element, text, options = {}) {
        return this.pipeline.queueOperation(async () => {
            const startTime = Date.now();
            this.monitoring.totalTooltips++;
            
            try {
                // اعتبارسنجی
                if (!element || !(element instanceof HTMLElement)) {
                    throw new Error('Invalid element provided');
                }

                if (!text || typeof text !== 'string') {
                    throw new Error('Invalid tooltip text');
                }

                const {
                    position = TOOLTIP_POSITIONS.TOP,
                    delay = TOOLTIP_CONFIG.DEFAULT_DELAY,
                    offset = 10,
                    customClass = '',
                    type = TOOLTIP_TYPES.DEFAULT,
                    multiline = false,
                    autoHide = false,
                    duration = TOOLTIP_CONFIG.DEFAULT_DURATION
                } = options;

                // حذف tooltip موجود اگر وجود دارد
                this.removeTooltip(element);

                // بررسی تمیزکاری خودکار
                this._autoCleanupCheck();

                let timeoutId;
                let autoHideTimeoutId;
                const tooltip = document.createElement('div');
                
                tooltip.className = `chat-tooltip ${position} ${type} ${customClass} ${multiline ? 'multiline' : ''}`;
                tooltip.textContent = text;

                const showTooltip = () => {
                    try {
                        document.body.appendChild(tooltip);
                        this._positionTooltip(element, tooltip, position, offset);
                        
                        requestAnimationFrame(() => {
                            tooltip.classList.add('visible');
                        });

                        this.monitoring.shownTooltips++;
                        this.monitoring.activeTooltips++;
                        this.monitoring.lastOperationTime = Date.now();

                        // پنهان‌سازی خودکار اگر فعال باشد
                        if (autoHide) {
                            autoHideTimeoutId = setTimeout(() => {
                                hideTooltip();
                            }, duration);
                        }

                    } catch (error) {
                        this.logger.log('error', 'Show tooltip failed', { error: error.message });
                        this.monitoring.errorCount++;
                    }
                };

                const hideTooltip = () => {
                    if (timeoutId) clearTimeout(timeoutId);
                    if (autoHideTimeoutId) clearTimeout(autoHideTimeoutId);
                    
                    tooltip.classList.remove('visible');
                    
                    setTimeout(() => {
                        if (tooltip.parentNode) {
                            tooltip.parentNode.removeChild(tooltip);
                            this.monitoring.hiddenTooltips++;
                            this.monitoring.activeTooltips--;
                        }
                    }, 200);
                };

                // event handlers
                const mouseEnterHandler = () => {
                    timeoutId = setTimeout(showTooltip, delay);
                };

                const mouseLeaveHandler = hideTooltip;
                const focusHandler = () => {
                    timeoutId = setTimeout(showTooltip, delay);
                };
                const blurHandler = hideTooltip;

                element.addEventListener('mouseenter', mouseEnterHandler);
                element.addEventListener('mouseleave', mouseLeaveHandler);
                element.addEventListener('focus', focusHandler);
                element.addEventListener('blur', blurHandler);

                // ذخیره reference tooltip
                this.tooltips.set(element, {
                    tooltip,
                    hideTooltip,
                    timeoutId,
                    autoHideTimeoutId,
                    eventHandlers: {
                        mouseEnter: mouseEnterHandler,
                        mouseLeave: mouseLeaveHandler,
                        focus: focusHandler,
                        blur: blurHandler
                    }
                });

                const operationTime = Date.now() - startTime;
                this.monitoring.averageShowTime = 
                    (this.monitoring.averageShowTime * (this.monitoring.totalTooltips - 1) + operationTime) / 
                    this.monitoring.totalTooltips;

                return {
                    show: () => {
                        if (timeoutId) clearTimeout(timeoutId);
                        showTooltip();
                    },
                    hide: hideTooltip,
                    update: (newText, newOptions = {}) => {
                        tooltip.textContent = newText;
                        if (newOptions.position) {
                            tooltip.className = tooltip.className.replace(
                                /(top|bottom|left|right)/, 
                                newOptions.position
                            );
                            this._positionTooltip(element, tooltip, newOptions.position, newOptions.offset || offset);
                        }
                    },
                    destroy: () => this.removeTooltip(element),
                    element: tooltip
                };

            } catch (error) {
                this.monitoring.errorCount++;
                this.logger.log('error', 'Create tooltip failed', { error: error.message });
                throw error;
            }
        });
    }

    _autoCleanupCheck() {
        if (this.tooltips.size >= TOOLTIP_CONFIG.MAX_TOOLTIPS) {
            // حذف قدیمی‌ترین tooltip
            const firstElement = this.tooltips.keys().next().value;
            if (firstElement) {
                this.removeTooltip(firstElement);
            }
        }
    }

    _positionTooltip(element, tooltip, position, offset) {
        try {
            const elementRect = element.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            const scrollX = window.pageXOffset;
            const scrollY = window.pageYOffset;

            let top, left;

            switch (position) {
                case TOOLTIP_POSITIONS.TOP:
                    top = elementRect.top + scrollY - tooltipRect.height - offset;
                    left = elementRect.left + scrollX + (elementRect.width - tooltipRect.width) / 2;
                    break;
                case TOOLTIP_POSITIONS.BOTTOM:
                    top = elementRect.bottom + scrollY + offset;
                    left = elementRect.left + scrollX + (elementRect.width - tooltipRect.width) / 2;
                    break;
                case TOOLTIP_POSITIONS.LEFT:
                    top = elementRect.top + scrollY + (elementRect.height - tooltipRect.height) / 2;
                    left = elementRect.left + scrollX - tooltipRect.width - offset;
                    break;
                case TOOLTIP_POSITIONS.RIGHT:
                    top = elementRect.top + scrollY + (elementRect.height - tooltipRect.height) / 2;
                    left = elementRect.right + scrollX + offset;
                    break;
            }

            // نگه داشتن tooltip در viewport
            const viewport = {
                width: window.innerWidth,
                height: window.innerHeight
            };

            // بررسی مرزها
            if (left < 5) left = 5;
            if (left + tooltipRect.width > viewport.width - 5) {
                left = viewport.width - tooltipRect.width - 5;
            }
            if (top < 5) top = 5;
            if (top + tooltipRect.height > viewport.height - 5) {
                top = viewport.height - tooltipRect.height - 5;
            }

            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';

        } catch (error) {
            this.logger.log('error', 'Position tooltip failed', { error: error.message });
            this.monitoring.errorCount++;
        }
    }

    async removeTooltip(element) {
        return this.pipeline.queueOperation(async () => {
            const existing = this.tooltips.get(element);
            if (existing) {
                try {
                    // پاک کردن timeouts
                    if (existing.timeoutId) clearTimeout(existing.timeoutId);
                    if (existing.autoHideTimeoutId) clearTimeout(existing.autoHideTimeoutId);
                    
                    // حذف event listeners
                    if (existing.eventHandlers) {
                        element.removeEventListener('mouseenter', existing.eventHandlers.mouseEnter);
                        element.removeEventListener('mouseleave', existing.eventHandlers.mouseLeave);
                        element.removeEventListener('focus', existing.eventHandlers.focus);
                        element.removeEventListener('blur', existing.eventHandlers.blur);
                    }
                    
                    // پنهان کردن و حذف tooltip
                    existing.hideTooltip();
                    
                    this.tooltips.delete(element);
                    
                } catch (error) {
                    this.logger.log('error', 'Remove tooltip failed', { error: error.message });
                    this.monitoring.errorCount++;
                }
            }
        });
    }

    // 🛡️ PRINCIPLE 3: Lazy Loading & Performance
    async quickTooltip(selector, text, options = {}) {
        return this.pipeline.queueOperation(async () => {
            try {
                const elements = document.querySelectorAll(selector);
                const results = [];
                
                for (const element of elements) {
                    const result = await this.createTooltip(element, text, options);
                    results.push(result);
                }
                
                return results;
                
            } catch (error) {
                this.logger.log('error', 'Quick tooltip failed', { error: error.message });
                this.monitoring.errorCount++;
                throw error;
            }
        });
    }

    async initDataTooltips() {
        return this.pipeline.queueOperation(async () => {
            try {
                const elements = document.querySelectorAll('[data-tooltip]');
                const results = [];
                
                for (const element of elements) {
                    const text = element.getAttribute('data-tooltip');
                    const position = element.getAttribute('data-tooltip-position') || TOOLTIP_POSITIONS.TOP;
                    const delay = parseInt(element.getAttribute('data-tooltip-delay')) || TOOLTIP_CONFIG.DEFAULT_DELAY;
                    const type = element.getAttribute('data-tooltip-type') || TOOLTIP_TYPES.DEFAULT;
                    const multiline = element.hasAttribute('data-tooltip-multiline');
                    
                    const result = await this.createTooltip(element, text, { 
                        position, 
                        delay, 
                        type,
                        multiline 
                    });
                    results.push(result);
                }
                
                return results;
                
            } catch (error) {
                this.logger.log('error', 'Init data tooltips failed', { error: error.message });
                this.monitoring.errorCount++;
                throw error;
            }
        });
    }

    async showTemporary(element, text, duration = 3000, options = {}) {
        return this.pipeline.queueOperation(async () => {
            const tooltip = await this.createTooltip(element, text, {
                ...options,
                autoHide: true,
                duration: duration
            });
            
            tooltip.show();
            return tooltip;
        });
    }

    // 🛡️ PRINCIPLE 10: Audit & Traceability
    getTooltipMetrics() {
        const successRate = this.monitoring.totalTooltips > 0 ? 
            (this.monitoring.totalTooltips - this.monitoring.errorCount) / this.monitoring.totalTooltips : 1;
            
        return {
            ...this.monitoring,
            successRate: Math.round(successRate * 100) / 100,
            performance: this.performance,
            pipeline: this.pipeline.getMetrics(),
            currentState: {
                activeTooltips: this.monitoring.activeTooltips,
                totalRegistered: this.tooltips.size,
                maxTooltips: TOOLTIP_CONFIG.MAX_TOOLTIPS
            },
            logs: this.logger.getLogs()
        };
    }

    // 🛡️ PRINCIPLE 8: Minimal Permissions & Cleanup
    async destroyAll() {
        return this.pipeline.queueOperation(async () => {
            try {
                this.tooltips.forEach((_, element) => {
                    this.removeTooltip(element);
                });
                
                this.logger.log('info', 'All tooltips destroyed', {
                    destroyedCount: this.tooltips.size
                });
                
            } catch (error) {
                this.logger.log('error', 'Destroy all failed', { error: error.message });
                this.monitoring.errorCount++;
                throw error;
            }
        });
    }

    destroy() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }
        
        if (this.performance.mutationObserver) {
            this.performance.mutationObserver.disconnect();
        }
        
        this.destroyAll();
        
        this.logger.log('info', 'TooltipManager destroyed', {
            totalTooltips: this.monitoring.totalTooltips,
            finalMetrics: this.getTooltipMetrics()
        });
    }
}

// 🛡️ PRINCIPLE 1: Context Isolation - Export استاندارد ES6
export default TooltipManager;
export { TOOLTIP_POSITIONS, TOOLTIP_TYPES, TOOLTIP_CONFIG };