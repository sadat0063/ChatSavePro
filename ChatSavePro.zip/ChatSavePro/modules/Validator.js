// ============================================================
// Validator.js - ES6 Module with Guardian Principles (MV3 Optimized)
// ============================================================

// 🛡️ PRINCIPLE 1: Context Isolation
export const VALIDATION_CONTEXTS = Object.freeze({
    BACKGROUND: 'background',
    POPUP: 'popup', 
    CONTENT_SCRIPT: 'content_script',
    EXPORT: 'export'
});

// 🛡️ PRINCIPLE 2: Strict Interface Contract
export const VALID_ACTIONS = Object.freeze({
    // Core Actions
    HANDSHAKE: 'HANDSHAKE',
    PING: 'PING',
    
    // Scan Actions
    DEEP_SCAN: 'DEEP_SCAN',
    START_LIVE_SCAN: 'START_LIVE_SCAN', 
    STOP_LIVE_SCAN: 'STOP_LIVE_SCAN',
    LIVE_SCAN_DATA_CHUNK: 'LIVE_SCAN_DATA_CHUNK',
    DEEP_SCAN_RESULT: 'DEEP_SCAN_RESULT',
    LIVE_SCAN_STATUS: 'LIVE_SCAN_STATUS',
    
    // Data Management
    EXPORT: 'EXPORT',
    CLEAR_DATA: 'CLEAR_DATA',
    EXPORT_RESULT: 'EXPORT_RESULT',
    EXPORT_ERROR: 'EXPORT_ERROR',
    DATA_CLEARED: 'DATA_CLEARED',
    CLEAR_DATA_RESULT: 'CLEAR_DATA_RESULT',
    
    // System
    HANDSHAKE_RESPONSE: 'HANDSHAKE_RESPONSE',
    GET_LIVE_STATUS: 'GET_LIVE_STATUS',
    PERFORMANCE_REPORT: 'PERFORMANCE_REPORT'
});

export const VALID_FORMATS = Object.freeze(['json', 'txt', 'csv', 'pdf', 'html', 'jsonl']);
export const VALID_PLATFORMS = Object.freeze(['ChatGPT', 'DeepSeek', 'Telegram', 'WhatsApp', 'Messenger', 'Discord', 'Web']);

// 🛡️ PRINCIPLE 4: Enhanced Validation Schemas
const MESSAGE_SCHEMAS = Object.freeze({
    INCOMING: {
        required: ['action'],
        optional: ['data', 'format', 'handshake'],
        actions: Object.values(VALID_ACTIONS)
    },
    OUTGOING: {
        required: ['action'],
        optional: ['data', 'handshake', 'content', 'mimeType', 'filename'],
        actions: Object.values(VALID_ACTIONS)
    }
});

const PORT_PATTERNS = Object.freeze({
    POPUP: /^ChatSavePopup_\d+$/,
    TEST: /^TestChecklist/,
    CONTENT_SCRIPT: /^ContentScript_/
});

// 🛡️ PRINCIPLE 5: Memory Segmentation (Optimized for MV3)
class ValidationCache {
    constructor(maxSize = 50) {
        this.cache = new Map();
        this.maxSize = maxSize;
        this.metrics = {
            hits: 0,
            misses: 0,
            evictions: 0
        };
        
        // 🛡️ حافظه‌بندی خودکار برای MV3
        this.cleanupInterval = setInterval(() => {
            if (this.cache.size > this.maxSize * 0.8) {
                this._autoCleanup();
            }
        }, 30000);
    }

    get(key) {
        if (this.cache.has(key)) {
            this.metrics.hits++;
            return this.cache.get(key);
        }
        this.metrics.misses++;
        return null;
    }

    set(key, value) {
        if (this.cache.size >= this.maxSize) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
            this.metrics.evictions++;
        }
        this.cache.set(key, value);
    }

    _autoCleanup() {
        const targetSize = Math.floor(this.maxSize * 0.6);
        while (this.cache.size > targetSize) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
            this.metrics.evictions++;
        }
    }

    clear() {
        this.cache.clear();
        this.metrics.hits = 0;
        this.metrics.misses = 0;
        this.metrics.evictions = 0;
    }

    getMetrics() {
        const hitRate = this.metrics.hits + this.metrics.misses > 0 
            ? (this.metrics.hits / (this.metrics.hits + this.metrics.misses) * 100).toFixed(2)
            : 0;

        return {
            ...this.metrics,
            hitRate: `${hitRate}%`,
            size: this.cache.size,
            maxSize: this.maxSize
        };
    }

    destroy() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }
    }
}

// 🛡️ PRINCIPLE 9: Secure Logging & Sanitization (MV3 Compatible)
class ValidationLogger {
    constructor() {
        this.enabled = true;
        this.maxLogSize = 100;
        this.logs = [];
    }

    log(level, message, data = null) {
        if (!this.enabled) return;

        const logEntry = {
            timestamp: Date.now(),
            level,
            message,
            data: this._sanitizeData(data)
        };

        this.logs.push(logEntry);

        if (this.logs.length > this.maxLogSize) {
            this.logs = this.logs.slice(-this.maxLogSize);
        }

        // ✅ سازگار با MV3 - حذف وابستگی به process.env
        if (typeof process === 'undefined' || !process.env || process.env.NODE_ENV === 'development') {
            const consoleMethod = console[level] || console.log;
            consoleMethod(`[Validator][${level}] ${message}`, data || '');
        }
    }

    _sanitizeData(data) {
        if (!data) return null;
        
        try {
            const sanitized = JSON.parse(JSON.stringify(data, (key, value) => {
                if (key === 'content' || key === 'data' || key === 'message') {
                    if (typeof value === 'string' && value.length > 100) {
                        return value.substring(0, 100) + '...';
                    }
                }
                // 🛡️ حذف داده‌های حساس
                if (key.toLowerCase().includes('token') || key.toLowerCase().includes('password')) {
                    return '***REDACTED***';
                }
                return value;
            }));
            return sanitized;
        } catch {
            return { error: 'Unable to sanitize data' };
        }
    }

    getLogs() {
        return [...this.logs];
    }

    clearLogs() {
        this.logs = [];
    }
}

// 🛡️ PRINCIPLE 4: Enhanced Engine Abstraction
export class Validator {
    constructor() {
        this.cache = new ValidationCache();
        this.logger = new ValidationLogger();
        
        this.metrics = {
            totalValidations: 0,
            failedValidations: 0,
            securityViolations: 0
        };

        this.logger.log('info', 'Validator instance created', {
            actions: Object.keys(VALID_ACTIONS).length,
            formats: VALID_FORMATS.length,
            platforms: VALID_PLATFORMS.length
        });
    }

    // 🆕 متد initialization برای سازگاری با Loader
    static async init() {
        const validator = new Validator();
        await validator._initialize();
        return validator;
    }

    async _initialize() {
        this.logger.log('info', 'Validator initialized successfully', {
            version: '2.0.0-guardian-mv3',
            timestamp: Date.now(),
            architecture: 'Phase-9-Modular'
        });
        return this;
    }

    // 🛡️ PRINCIPLE 2: Strict Interface Contract
    validateMessage(message, context = 'INCOMING') {
        this.metrics.totalValidations++;
        
        const cacheKey = this._generateCacheKey(message, context);
        const cachedResult = this.cache.get(cacheKey);
        if (cachedResult !== null) {
            return cachedResult;
        }

        const schema = MESSAGE_SCHEMAS[context];
        if (!schema) {
            this._recordFailure('INVALID_CONTEXT', { context });
            return false;
        }

        if (!this._validateBasicStructure(message)) {
            this._recordFailure('INVALID_STRUCTURE', { message });
            return false;
        }

        if (!this._validateRequiredFields(message, schema)) {
            this._recordFailure('MISSING_REQUIRED_FIELDS', { message, schema });
            return false;
        }

        if (!this._validateAction(message.action, schema)) {
            this._recordFailure('INVALID_ACTION', { action: message.action });
            return false;
        }

        if (message.action === VALID_ACTIONS.EXPORT && message.format) {
            if (!this._validateFormat(message.format)) {
                this._recordFailure('INVALID_FORMAT', { format: message.format });
                return false;
            }
        }

        if (message.data && !this._validateDataStructure(message.data, message.action)) {
            this._recordFailure('INVALID_DATA_STRUCTURE', { data: message.data });
            return false;
        }

        if (!this._validateSecurity(message)) {
            this.metrics.securityViolations++;
            this._recordFailure('SECURITY_VIOLATION', { message });
            return false;
        }

        this.cache.set(cacheKey, true);
        return true;
    }

    validatePort(portName, portType = 'POPUP') {
        if (!portName || typeof portName !== 'string') {
            return false;
        }

        const pattern = PORT_PATTERNS[portType];
        if (!pattern) {
            this.logger.log('warn', 'Unknown port type', { portType });
            return false;
        }

        return pattern.test(portName);
    }

    validatePlatform(platform) {
        return VALID_PLATFORMS.includes(platform);
    }

    validateScanConfig(config) {
        if (!config || typeof config !== 'object') return false;

        const required = ['maxScanTime', 'scanInterval', 'messageSelectors'];
        return required.every(field => 
            field in config && 
            (field !== 'messageSelectors' || Array.isArray(config[field]))
        );
    }

    // 🛡️ PRINCIPLE 7: Private Validation Methods
    _validateBasicStructure(message) {
        return message && 
               typeof message === 'object' && 
               !Array.isArray(message);
    }

    _validateRequiredFields(message, schema) {
        return schema.required.every(field => field in message);
    }

    _validateAction(action, schema) {
        return action && schema.actions.includes(action);
    }

    _validateFormat(format) {
        return VALID_FORMATS.includes(format);
    }

    _validateDataStructure(data, action) {
        if (typeof data !== 'object' || Array.isArray(data)) {
            return false;
        }

        switch (action) {
            case VALID_ACTIONS.EXPORT_RESULT:
                return this._validateExportResultData(data);
            case VALID_ACTIONS.LIVE_SCAN_DATA_CHUNK:
                return this._validateScanData(data);
            case VALID_ACTIONS.DEEP_SCAN_RESULT:
                return this._validateScanData(data);
            default:
                return true;
        }
    }

    _validateExportResultData(data) {
        return data && 
               typeof data.content === 'string' &&
               typeof data.mimeType === 'string' &&
               typeof data.filename === 'string';
    }

    _validateScanData(data) {
        return data && 
               Array.isArray(data.messages) &&
               data.messages.every(msg => 
                   msg && 
                   typeof msg.id === 'string' &&
                   typeof msg.content === 'string'
               );
    }

    _validateSecurity(message) {
        if (message.action && typeof message.action === 'string') {
            if (message.action.includes('<script>') || message.action.includes('</script>')) {
                return false;
            }
        }

        if (message.data) {
            try {
                const jsonString = JSON.stringify(message.data);
                if (jsonString.includes('__proto__') || jsonString.includes('constructor')) {
                    return false;
                }
            } catch {
                return false;
            }
        }

        return true;
    }

    _generateCacheKey(message, context) {
        try {
            return `${context}_${message.action}_${JSON.stringify(message.data)}`;
        } catch {
            return `${context}_${message.action}_fallback`;
        }
    }

    _recordFailure(reason, details) {
        this.metrics.failedValidations++;
        this.logger.log('warn', `Validation failed: ${reason}`, details);
    }

    // 🛡️ PRINCIPLE 10: Audit & Traceability
    getValidationMetrics() {
        const successRate = this.metrics.totalValidations > 0 
            ? ((this.metrics.totalValidations - this.metrics.failedValidations) / this.metrics.totalValidations * 100).toFixed(2)
            : 100;

        return {
            ...this.metrics,
            successRate: `${successRate}%`,
            cache: this.cache.getMetrics(),
            security: {
                violations: this.metrics.securityViolations,
                violationRate: this.metrics.totalValidations > 0 
                    ? ((this.metrics.securityViolations / this.metrics.totalValidations) * 100).toFixed(2) + '%'
                    : '0%'
            },
            logs: this.logger.getLogs()
        };
    }

    clearCache() {
        this.cache.clear();
        this.logger.log('info', 'Validation cache cleared');
    }

    // 🛡️ PRINCIPLE 9: Security Methods
    sanitizeInput(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return input;
    }

    validateUrl(url) {
        try {
            const parsed = new URL(url);
            return parsed.protocol === 'https:';
        } catch {
            return false;
        }
    }

    // 🛡️ PRINCIPLE 6: Batch Validation
    validateBatch(messages, context) {
        const results = {
            valid: [],
            invalid: [],
            errors: []
        };

        messages.forEach((message, index) => {
            try {
                if (this.validateMessage(message, context)) {
                    results.valid.push(message);
                } else {
                    results.invalid.push({ index, message });
                }
            } catch (error) {
                results.errors.push({ index, error: error.message });
            }
        });

        this.logger.log('info', 'Batch validation completed', {
            total: messages.length,
            valid: results.valid.length,
            invalid: results.invalid.length,
            errors: results.errors.length
        });

        return results;
    }

    // 🛡️ PRINCIPLE 11: Inter-Module Integrity
    getConstants() {
        return {
            VALID_ACTIONS: Object.freeze({...VALID_ACTIONS}),
            VALID_FORMATS: Object.freeze([...VALID_FORMATS]),
            VALID_PLATFORMS: Object.freeze([...VALID_PLATFORMS]),
            VALIDATION_CONTEXTS: Object.freeze({...VALIDATION_CONTEXTS})
        };
    }

    destroy() {
        this.cache.destroy();
        this.clearCache();
        this.logger.clearLogs();
        this.logger.log('info', 'Validator destroyed', {
            finalMetrics: this.getValidationMetrics()
        });
    }
}

// 🛡️ PRINCIPLE 3: Lazy Loading & Performance - Default Export
export default Validator;