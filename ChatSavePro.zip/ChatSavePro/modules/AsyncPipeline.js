// ============================================================
// modules/AsyncPipeline.js - PRINCIPLE 5: RESILIENT ASYNC OPERATIONS
// ============================================================

// 🆕 PRINCIPLE 14: STATIC ES6 IMPORTS
import { ModuleLoadTracker } from './ModuleLoadTracker.js';

// 🆕 PRINCIPLE 2: STRICT INTERFACE CONTRACTS
const PIPELINE_SCHEMAS = Object.freeze({
    OPERATION_REGISTRATION: Object.freeze({
        required: ['name', 'operationFn'],
        name: { type: 'string', maxLength: 50, pattern: /^[a-zA-Z0-9_-]+$/ },
        operationFn: { type: 'function' }
    }),
    RETRY_CONFIG: Object.freeze({
        maxRetries: { type: 'number', min: 1, max: 10 },
        baseDelay: { type: 'number', min: 0, max: 30000 },
        timeout: { type: 'number', min: 1000, max: 120000 }
    })
});

export class AsyncPipeline {
    constructor() {
        // 🆕 PRINCIPLE 7: MEMORY SEGMENTATION
        this.operations = new Map();
        this.retryConfigs = new Map();
        this.circuitBreakers = new Map();
        this.metrics = new Map();
        this.operationQueue = new Set();
        
        // 🆕 PRINCIPLE 9: FROZEN GLOBALS
        this.DEFAULT_CONFIG = Object.freeze({
            MAX_RETRIES: 3,
            BASE_DELAY: 100,
            MAX_DELAY: 5000,
            TIMEOUT: 30000,
            CIRCUIT_THRESHOLD: 5,
            CIRCUIT_TIMEOUT: 60000
        });
        
        // 🆕 PRINCIPLE 12: SECURE LOGGING
        this.auditLog = [];
        this.maxAuditEntries = 100;
        
        this.init();
    }

    init() {
        try {
            // 🆕 PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Default configs
            this.setRetryConfig('system', {
                maxRetries: 5,
                baseDelay: 200,
                maxDelay: 10000,
                timeout: 60000,
                backoff: 'exponential'
            });

            this.setRetryConfig('network', {
                maxRetries: 3,
                baseDelay: 1000,
                maxDelay: 15000,
                timeout: 45000,
                backoff: 'exponential'
            });

            this.setRetryConfig('storage', {
                maxRetries: 2,
                baseDelay: 500,
                maxDelay: 5000,
                timeout: 30000,
                backoff: 'linear'
            });

            // 🆕 PRINCIPLE 14: MODULE TRACKING
            ModuleLoadTracker.registerModule('AsyncPipeline', 'background', 'AsyncPipeline.js');
            
            console.log('✅ AsyncPipeline initialized');
        } catch (error) {
            console.error('❌ AsyncPipeline initialization failed:', error);
            throw error;
        }
    }

    // 🆕 PRINCIPLE 12: SECURE LOGGING - Audit trail
    #logAudit(eventType, data) {
        try {
            const auditEntry = {
                timestamp: Date.now(),
                event: eventType,
                data: this.#sanitizeAuditData(data),
                pipelineVersion: '1.0'
            };

            this.auditLog.push(auditEntry);
            
            if (this.auditLog.length > this.maxAuditEntries) {
                this.auditLog.shift();
            }
        } catch (error) {
            console.warn('⚠️ AsyncPipeline audit logging failed:', error);
        }
    }

    // 🆕 PRINCIPLE 9: FROZEN GLOBALS - Data sanitization
    #sanitizeAuditData(data) {
        if (typeof data !== 'object' || data === null) return data;

        const sanitized = {};
        for (const [key, value] of Object.entries(data)) {
            if (['__proto__', 'constructor', 'prototype'].includes(key)) {
                continue;
            }

            if (typeof value === 'string') {
                sanitized[key] = value.substring(0, 1000).replace(/[<>]/g, '');
            } else if (typeof value === 'object' && value !== null) {
                sanitized[key] = this.#sanitizeAuditData(value);
            } else {
                sanitized[key] = value;
            }
        }

        return sanitized;
    }

    // 🆕 PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Operation validation
    #validateOperationRegistration(name, operationFn) {
        const schema = PIPELINE_SCHEMAS.OPERATION_REGISTRATION;

        if (typeof name !== 'string' || name.length > schema.name.maxLength) {
            throw new Error(`Invalid operation name: ${name}`);
        }

        if (!schema.name.pattern.test(name)) {
            throw new Error('Operation name contains invalid characters');
        }

        if (typeof operationFn !== 'function') {
            throw new Error('Operation must be a function');
        }

        return true;
    }

    // ثبت عملیات جدید
    registerOperation(name, operationFn, config = {}) {
        try {
            // 🆕 PRINCIPLE 2: STRICT INTERFACE CONTRACTS
            this.#validateOperationRegistration(name, operationFn);

            this.operations.set(name, {
                fn: operationFn,
                config: { ...this.DEFAULT_CONFIG, ...config },
                callCount: 0,
                successCount: 0,
                failureCount: 0,
                lastCall: null
            });

            this.#logAudit('OPERATION_REGISTERED', { operation: name, config });
            console.log(`⚡ Operation registered: ${name}`);

        } catch (error) {
            this.#logAudit('OPERATION_REGISTRATION_FAILED', { 
                operation: name, 
                error: error.message 
            }, 'error');
            throw error;
        }
    }

    // تنظیم کانفیگ retry
    setRetryConfig(operationType, config) {
        try {
            // 🆕 PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Config validation
            if (config.maxRetries && (config.maxRetries < 1 || config.maxRetries > 10)) {
                throw new Error('maxRetries must be between 1 and 10');
            }

            this.retryConfigs.set(operationType, {
                ...this.DEFAULT_CONFIG,
                ...config
            });

            this.#logAudit('RETRY_CONFIG_SET', { type: operationType, config });
            
        } catch (error) {
            this.#logAudit('RETRY_CONFIG_FAILED', { 
                type: operationType, 
                error: error.message 
            }, 'error');
            throw error;
        }
    }

    // اجرای عملیات با قابلیت retry
    async executeWithRetry(operationName, ...args) {
        const operation = this.operations.get(operationName);
        if (!operation) {
            throw new Error(`Operation not found: ${operationName}`);
        }

        // 🆕 PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Circuit breaker check
        if (this.isCircuitOpen(operationName)) {
            throw new Error(`Circuit breaker open for operation: ${operationName}`);
        }

        const operationId = `${operationName}_${Date.now()}`;
        this.operationQueue.add(operationId);

        try {
            operation.callCount++;
            operation.lastCall = Date.now();

            const startTime = Date.now();
            const result = await this.executeWithRetryInternal(
                operationName,
                operation.fn,
                args,
                operation.config
            );

            const duration = Date.now() - startTime;
            
            operation.successCount++;
            this.recordSuccess(operationName);
            this.recordMetrics(operationName, true, duration);
            
            this.#logAudit('OPERATION_SUCCESS', { 
                operation: operationName, 
                duration,
                argsCount: args.length 
            });
            
            return result;

        } catch (error) {
            operation.failureCount++;
            this.recordFailure(operationName, error);
            this.recordMetrics(operationName, false, 0);
            
            this.#logAudit('OPERATION_FAILED', { 
                operation: operationName, 
                error: error.message,
                argsCount: args.length 
            }, 'error');
            
            throw error;

        } finally {
            this.operationQueue.delete(operationId);
        }
    }

    // اجرای داخلی با قابلیت retry
    async executeWithRetryInternal(operationName, operationFn, args, config) {
        let lastError;
        let attempt = 1;

        while (attempt <= config.maxRetries) {
            try {
                const result = await Promise.race([
                    operationFn(...args),
                    this.createTimeout(config.timeout, operationName)
                ]);

                return result;

            } catch (error) {
                lastError = error;

                if (attempt < config.maxRetries) {
                    const delay = this.calculateBackoff(attempt, config);
                    console.log(`🔄 Retry ${attempt}/${config.maxRetries} for ${operationName} in ${delay}ms`);
                    
                    await new Promise(resolve => setTimeout(resolve, delay));
                    attempt++;
                } else {
                    break;
                }
            }
        }

        throw new Error(
            `Operation '${operationName}' failed after ${config.maxRetries} attempts: ${lastError.message}`
        );
    }

    // ایجاد timeout
    createTimeout(ms, operationName) {
        return new Promise((_, reject) => {
            setTimeout(() => {
                reject(new Error(`Operation '${operationName}' timed out after ${ms}ms`));
            }, ms);
        });
    }

    // محاسبه backoff
    calculateBackoff(attempt, config) {
        const baseDelay = config.baseDelay || this.DEFAULT_CONFIG.BASE_DELAY;
        const maxDelay = config.maxDelay || this.DEFAULT_CONFIG.MAX_DELAY;

        switch (config.backoff) {
            case 'exponential':
                return Math.min(baseDelay * Math.pow(2, attempt - 1), maxDelay);
            case 'linear':
                return Math.min(baseDelay * attempt, maxDelay);
            case 'fixed':
                return baseDelay;
            default:
                return Math.min(baseDelay * Math.pow(2, attempt - 1), maxDelay);
        }
    }

    // مدیریت circuit breaker
    isCircuitOpen(operationName) {
        const circuit = this.circuitBreakers.get(operationName);
        if (!circuit) return false;

        if (circuit.isOpen) {
            if (Date.now() >= circuit.nextAttempt) {
                // حالت half-open
                circuit.isOpen = false;
                circuit.failures = 0;
                console.log(`🔓 Circuit half-open for: ${operationName}`);
                return false;
            }
            return true;
        }

        return false;
    }

    recordSuccess(operationName) {
        const circuit = this.circuitBreakers.get(operationName);
        if (circuit) {
            // ریست کردن circuit در صورت موفقیت
            circuit.failures = 0;
        }
    }

    recordFailure(operationName, error) {
        let circuit = this.circuitBreakers.get(operationName);
        if (!circuit) {
            circuit = {
                failures: 0,
                lastFailure: 0,
                isOpen: false,
                nextAttempt: 0
            };
            this.circuitBreakers.set(operationName, circuit);
        }

        circuit.failures++;
        circuit.lastFailure = Date.now();

        if (circuit.failures >= this.DEFAULT_CONFIG.CIRCUIT_THRESHOLD) {
            circuit.isOpen = true;
            circuit.nextAttempt = Date.now() + this.DEFAULT_CONFIG.CIRCUIT_TIMEOUT;
            console.log(`🔒 Circuit breaker opened for: ${operationName}`);
        }
    }

    // اجرای pipeline از چندین عملیات
    async executePipeline(operations, options = {}) {
        const {
            stopOnError = true,
            continueOnError = false,
            timeout = 60000
        } = options;

        const results = [];
        const errors = [];

        for (let i = 0; i < operations.length; i++) {
            const op = operations[i];
            const operationName = op.name || `pipeline_op_${i}`;

            try {
                console.log(`🚀 Executing pipeline step ${i + 1}/${operations.length}: ${operationName}`);
                
                const result = await this.executeWithRetry(
                    operationName,
                    ...(op.args || [])
                );

                results.push({
                    step: i + 1,
                    name: operationName,
                    success: true,
                    result: result,
                    timestamp: Date.now()
                });

            } catch (error) {
                console.error(`❌ Pipeline step ${i + 1} failed: ${operationName}`, error);

                errors.push({
                    step: i + 1,
                    name: operationName,
                    success: false,
                    error: error.message,
                    timestamp: Date.now()
                });

                if (stopOnError && !continueOnError) {
                    throw new Error(
                        `Pipeline failed at step ${i + 1} (${operationName}): ${error.message}`
                    );
                }
            }
        }

        return {
            success: errors.length === 0,
            results: results,
            errors: errors,
            totalSteps: operations.length,
            successfulSteps: results.length,
            failedSteps: errors.length
        };
    }

    // اجرای موازی عملیات
    async executeParallel(operations, options = {}) {
        const {
            maxConcurrent = 5,
            timeout = 30000
        } = options;

        const results = [];
        const executing = new Set();

        for (let i = 0; i < operations.length; i++) {
            const op = operations[i];
            const operationName = op.name || `parallel_op_${i}`;

            // کنترل concurrent executions
            if (executing.size >= maxConcurrent) {
                await Promise.race(executing);
            }

            const operationPromise = this.executeWithRetry(
                operationName,
                ...(op.args || [])
            ).then(result => {
                results.push({
                    name: operationName,
                    success: true,
                    result: result,
                    timestamp: Date.now()
                });
            }).catch(error => {
                results.push({
                    name: operationName,
                    success: false,
                    error: error.message,
                    timestamp: Date.now()
                });
            }).finally(() => {
                executing.delete(operationPromise);
            });

            executing.add(operationPromise);
        }

        // منتظر ماندن برای اتمام تمام عملیات
        await Promise.allSettled(executing);

        return {
            success: results.every(r => r.success),
            results: results,
            total: operations.length,
            successful: results.filter(r => r.success).length,
            failed: results.filter(r => !r.success).length
        };
    }

    // متریک‌ها و مانیتورینگ
    recordMetrics(operationName, success, duration) {
        if (!this.metrics.has(operationName)) {
            this.metrics.set(operationName, {
                totalCalls: 0,
                successfulCalls: 0,
                failedCalls: 0,
                totalDuration: 0,
                averageDuration: 0,
                lastCall: null
            });
        }

        const metric = this.metrics.get(operationName);
        metric.totalCalls++;
        metric.lastCall = Date.now();

        if (success) {
            metric.successfulCalls++;
            metric.totalDuration += duration;
            metric.averageDuration = metric.totalDuration / metric.successfulCalls;
        } else {
            metric.failedCalls++;
        }
    }

    getMetrics(operationName = null) {
        if (operationName) {
            return this.metrics.get(operationName) || null;
        }

        const allMetrics = {};
        for (const [name, metric] of this.metrics) {
            allMetrics[name] = { ...metric };
        }
        return allMetrics;
    }

    getOperationStats(operationName = null) {
        if (operationName) {
            const operation = this.operations.get(operationName);
            const metrics = this.metrics.get(operationName);
            const circuit = this.circuitBreakers.get(operationName);

            return {
                name: operationName,
                registered: !!operation,
                callCount: operation?.callCount || 0,
                successCount: operation?.successCount || 0,
                failureCount: operation?.failureCount || 0,
                successRate: operation ? 
                    (operation.successCount / operation.callCount * 100).toFixed(2) : 0,
                circuitStatus: circuit ? 
                    (circuit.isOpen ? 'OPEN' : 'CLOSED') : 'N/A',
                lastCall: operation?.lastCall || null,
                metrics: metrics || null
            };
        }

        const stats = {};
        for (const [name] of this.operations) {
            stats[name] = this.getOperationStats(name);
        }
        return stats;
    }

    // سلامت سیستم
    healthCheck() {
        const report = {
            status: 'healthy',
            timestamp: Date.now(),
            operations: {
                total: this.operations.size,
                active: this.operationQueue.size
            },
            circuits: {
                total: this.circuitBreakers.size,
                open: Array.from(this.circuitBreakers.values())
                    .filter(c => c.isOpen).length
            },
            metrics: {
                tracked: this.metrics.size
            },
            audit: {
                entries: this.auditLog.length
            }
        };

        // بررسی circuit breakerهای باز
        if (report.circuits.open > 0) {
            report.status = 'degraded';
            report.message = `${report.circuits.open} circuit breakers are open`;
        }

        // بررسی عملیات blocked
        if (this.operationQueue.size > 10) {
            report.status = 'warning';
            report.message = 'High number of active operations';
        }

        return report;
    }

    // 🆕 PRINCIPLE 8: MODULAR CLEANUP - Enhanced cleanup
    cleanup() {
        try {
            // پاک‌سازی عملیات قدیمی
            const oneHourAgo = Date.now() - (60 * 60 * 1000);
            let cleanedCount = 0;
            
            for (const [name, operation] of this.operations) {
                if (operation.lastCall && operation.lastCall < oneHourAgo) {
                    if (operation.callCount === 0) {
                        this.operations.delete(name);
                        this.metrics.delete(name);
                        this.circuitBreakers.delete(name);
                        cleanedCount++;
                    }
                }
            }

            // پاک‌سازی audit log قدیمی
            const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
            this.auditLog = this.auditLog.filter(entry => 
                entry.timestamp > oneDayAgo
            );

            this.#logAudit('CLEANUP_COMPLETED', { 
                operationsCleaned: cleanedCount,
                auditEntries: this.auditLog.length 
            });
            
            console.log('🧹 AsyncPipeline cleanup completed');

        } catch (error) {
            console.error('❌ AsyncPipeline cleanup failed:', error);
        }
    }

    // 🆕 PRINCIPLE 12: SECURE LOGGING - Get audit trail
    getAuditTrail(limit = 50) {
        return this.auditLog
            .slice(-limit)
            .map(entry => Object.freeze({ ...entry }));
    }

    // 🆕 PRINCIPLE 7: MEMORY SEGMENTATION - Get memory stats
    getMemoryStats() {
        return {
            operations: this.operations.size,
            retryConfigs: this.retryConfigs.size,
            circuitBreakers: this.circuitBreakers.size,
            metrics: this.metrics.size,
            operationQueue: this.operationQueue.size,
            auditLog: this.auditLog.length
        };
    }

    destroy() {
        try {
            this.operations.clear();
            this.retryConfigs.clear();
            this.circuitBreakers.clear();
            this.metrics.clear();
            this.operationQueue.clear();
            this.auditLog = [];
            
            this.#logAudit('DESTROYED', {});
            console.log('🧹 AsyncPipeline destroyed');
        } catch (error) {
            console.error('❌ AsyncPipeline destroy failed:', error);
        }
    }
}

// Singleton instance
let asyncPipelineInstance = null;

export function getAsyncPipeline() {
    if (!asyncPipelineInstance) {
        asyncPipelineInstance = new AsyncPipeline();
    }
    return asyncPipelineInstance;
}

export default AsyncPipeline;