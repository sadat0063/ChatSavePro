// ============================================================
// ModuleLoadTracker.js - QuantumStage Module Monitoring System
// Based on 13 Security Principles - R9.9.0‑Final
// ============================================================

// 🛡️ Principle 1: Context Isolation - Separate logging per layer
// 🛡️ Principle 8: Frozen Globals - Immutable tracking object
// 🛡️ Principle 11: Secure Logging - Sanitized and safe logging

class ModuleLoadTracker {
    static #modules = new Map();
    static #startTime = performance.now();
    static #isInitialized = false;

    // 🛡️ Principle 9: Integrity Bridge - Secure initialization
    static init() {
        if (this.#isInitialized) return;
        
        // Freeze configuration for security
        Object.freeze(this.#modules);
        this.#isInitialized = true;
        
        console.log('🛡️ [ModuleLoadTracker] QuantumStage Monitoring System Initialized');
    }

    // 🛡️ Principle 2: Strict Interface Contracts - Defined input/output
    static registerModule(name, layer, sourceFile, additionalInfo = {}) {
        if (!this.#isInitialized) this.init();

        const loadInfo = Object.freeze({
            name,
            layer, // 'background', 'content', 'scan-layer', 'popup', 'dashboard'
            sourceFile,
            loadTime: performance.now() - this.#startTime,
            timestamp: Date.now(),
            status: 'loaded',
            ...additionalInfo
        });
        
        this.#modules.set(name, loadInfo);
        
        // 🛡️ Principle 3: Resilient Async Operations - Safe logging
        this.#logToConsole(layer, name, loadInfo);
        
        // 🛡️ Principle 10: Quantum Resync - Report to background
        this.#reportToBackground(layer, loadInfo);
        
        return loadInfo;
    }

    // 🛡️ Principle 4: Enhanced Scan Engine - Multi-layer logging
    static #logToConsole(layer, name, info) {
        const styles = {
            background: 'background: #1a365d; color: #63b3ed; padding: 2px 4px; border-radius: 3px;',
            'scan-layer': 'background: #22543d; color: #68d391; padding: 2px 4px; border-radius: 3px;',
            content: 'background: #744210; color: #faf089; padding: 2px 4px; border-radius: 3px;',
            popup: 'background: #553c9a; color: #d6bcfa; padding: 2px 4px; border-radius: 3px;',
            dashboard: 'background: #97266d; color: #fbb6ce; padding: 2px 4px; border-radius: 3px;'
        };

        const logMessage = `✅ [${layer.toUpperCase()}] ${name} loaded in ${info.loadTime.toFixed(2)}ms`;
        console.log(`%c${logMessage}`, styles[layer] || '', info);
    }

    // 🛡️ Principle 5: Memory Segmentation - Isolated reporting
    static #reportToBackground(layer, info) {
        if (layer === 'background') return;
        
        try {
            chrome.runtime?.sendMessage({
                action: 'MODULE_LOADED',
                data: info
            });
        } catch (error) {
            // Silent fail - background might not be ready
        }
    }

    // 🛡️ Principle 6: Secure Event Bus - Validated data access
    static getLoadReport() {
        const modules = Array.from(this.#modules.values());
        const byLayer = {};
        
        modules.forEach(module => {
            if (!byLayer[module.layer]) byLayer[module.layer] = [];
            byLayer[module.layer].push(module);
        });

        return Object.freeze({
            total: modules.length,
            byLayer: Object.freeze(byLayer),
            summary: Object.freeze(Object.keys(byLayer).reduce((acc, layer) => {
                acc[layer] = byLayer[layer].length;
                return acc;
            }, {}))
        });
    }

    // 🛡️ Principle 7: Async Pipeline & Resilience - Safe summary logging
    static logSummary() {
        const report = this.getLoadReport();
        
        console.group('📊 QUANTUMSTAGE MODULE LOAD SUMMARY');
        console.log('%c=== SYSTEM OVERVIEW ===', 'font-weight: bold; color: #2d3748;');
        
        Object.keys(report.summary).forEach(layer => {
            const count = report.summary[layer];
            console.log(`%c${layer.toUpperCase()}: ${count} modules`, 
                'font-weight: bold; color: #4a5568;');
        });
        
        console.log(`%cTOTAL: ${report.total} modules loaded`, 
            'font-weight: bold; color: #2d3748; font-size: 14px;');
        
        console.log('%c=== DETAILED BREAKDOWN ===', 'font-weight: bold; color: #2d3748;');
        Object.keys(report.byLayer).forEach(layer => {
            console.groupCollapsed(`${layer.toUpperCase()} Layer (${report.byLayer[layer].length} modules)`);
            report.byLayer[layer].forEach(module => {
                console.log(`  ✅ ${module.name} - ${module.loadTime.toFixed(2)}ms`);
            });
            console.groupEnd();
        });
        
        console.groupEnd();
    }

    // 🛡️ Principle 12: Secure Logging & Audit Trail - Debug commands
    static debug() {
        const report = this.getLoadReport();
        const expectedModules = [
            // Background modules
            'ModuleBridge', 'GuardianIntegrity', 'EventBus', 'SecureStatsManager',
            'InsightAnalyticsManager', 'AdvancedStorageManager', 'Logger', 'EnhancedLogger',
            'StorageManager', 'DBHandler', 'ExportManager', 'EnhancedExportManager',
            'ExportScopeManager', 'MultiFormatExporter', 'PDFExporter', 'DeepScanCoordinator',
            'ScanSystem', 'BackStackManager',
            
            // Scan Layer modules  
            'LiveScanManager', 'DeepScan', 'SecureFilterManager', 'Validator',
            'animation-manager', 'audio-feedback', 'tooltip-manager', 'theme-manager',
            'progress-indicator', 'modal-stack',
            
            // Content modules
            'ScanLayerLoader'
        ];

        const loaded = Array.from(this.#modules.keys());
        const missing = expectedModules.filter(m => !loaded.includes(m));
        
        console.group('🔍 MODULE LOAD DEBUG INFO');
        console.log('Loaded modules:', loaded);
        console.log('Missing modules:', missing);
        console.log('Load report:', report);
        console.groupEnd();

        return { loaded, missing, report };
    }
}

// 🛡️ Principle 13: Modular Cleanup & Lifecycle Control - Auto initialization
ModuleLoadTracker.init();

export { ModuleLoadTracker };
export default ModuleLoadTracker;