// ============================================================
// modules/SecureLogger.js - PRINCIPLE 12: SECURE LOGGING & AUDIT TRAIL
// ============================================================

export class SecureLogger {
    constructor(context = 'system') {
        this.context = context;
        this.logLevels = Object.freeze({
            ERROR: 0,
            WARN: 1,
            INFO: 2,
            DEBUG: 3,
            TRACE: 4
        });

        this.currentLogLevel = this.logLevels.INFO;
        this.logStore = new Map();
        this.auditTrail = [];
        this.sensitivePatterns = [
            /password[=:]['"]?([^'"\s]+)/gi,
            /token[=:]['"]?([^'"\s]+)/gi,
            /api[_-]?key[=:]['"]?([^'"\s]+)/gi,
            /secret[=:]['"]?([^'"\s]+)/gi,
            /credit[_-]?card[=:]['"]?([^'"\s]+)/gi,
            /authorization:\s*bearer\s+(\S+)/gi
        ];

        this.CONFIG = Object.freeze({
            MAX_LOG_ENTRIES: 1000,
            MAX_AUDIT_ENTRIES: 500,
            LOG_RETENTION_MS: 24 * 60 * 60 * 1000, // 24 hours
            AUDIT_RETENTION_MS: 7 * 24 * 60 * 60 * 1000, // 7 days
            BATCH_FLUSH_INTERVAL: 30000 // 30 seconds
        });

        this.init();
    }

    init() {
        // ایجاد سگمنت‌های مختلف برای لاگ‌ها
        this.createLogSegment('system');
        this.createLogSegment('security');
        this.createLogSegment('performance');
        this.createLogSegment('user');
        this.createLogSegment('debug');

        // شروع نظافت دوره‌ای
        this.startCleanupInterval();
        
        console.log(`✅ SecureLogger initialized for context: ${this.context}`);
    }

    createLogSegment(segmentName) {
        this.logStore.set(segmentName, {
            entries: [],
            maxSize: this.CONFIG.MAX_LOG_ENTRIES,
            segment: segmentName,
            createdAt: Date.now()
        });
    }

    // ثبت لاگ با سطوح مختلف
    error(message, data = null, segment = 'system') {
        this.log(this.logLevels.ERROR, 'ERROR', message, data, segment);
    }

    warn(message, data = null, segment = 'system') {
        this.log(this.logLevels.WARN, 'WARN', message, data, segment);
    }

    info(message, data = null, segment = 'system') {
        this.log(this.logLevels.INFO, 'INFO', message, data, segment);
    }

    debug(message, data = null, segment = 'debug') {
        this.log(this.logLevels.DEBUG, 'DEBUG', message, data, segment);
    }

    trace(message, data = null, segment = 'debug') {
        this.log(this.logLevels.TRACE, 'TRACE', message, data, segment);
    }

    // ثبت لاگ امنیتی
    security(message, data = null) {
        this.log(this.logLevels.INFO, 'SECURITY', message, data, 'security');
    }

    // ثبت لاگ عملکرد
    performance(message, data = null) {
        this.log(this.logLevels.INFO, 'PERFORMANCE', message, data, 'performance');
    }

    // متد اصلی ثبت لاگ
    log(level, levelName, message, data = null, segment = 'system') {
        if (level > this.currentLogLevel) {
            return; // لاگ کردن فقط برای سطوح مجاز
        }

        try {
            const sanitizedData = this.sanitizeData(data);
            const sanitizedMessage = this.sanitizeMessage(message);

            const logEntry = {
                timestamp: Date.now(),
                level: levelName,
                message: sanitizedMessage,
                data: sanitizedData,
                segment: segment,
                context: this.context,
                source: this.getCallerInfo()
            };

            this.storeLogEntry(segment, logEntry);
            this.emitToConsole(levelName, logEntry);

        } catch (error) {
            // در صورت خطا در لاگ کردن، از console استفاده کن اما اطلاعات حساس را فیلتر کن
            console.error(`❌ [SecureLogger] Logging failed: ${error.message}`);
        }
    }

    // ذخیره امن لاگ
    storeLogEntry(segment, entry) {
        if (!this.logStore.has(segment)) {
            this.createLogSegment(segment);
        }

        const segmentData = this.logStore.get(segment);
        
        // مدیریت سایز لاگ
        if (segmentData.entries.length >= segmentData.maxSize) {
            segmentData.entries.shift();
        }

        segmentData.entries.push(Object.freeze(entry));
    }

    // سانیتایز داده‌ها
    sanitizeData(data) {
        if (data === null || data === undefined) {
            return null;
        }

        if (typeof data === 'string') {
            return this.sanitizeString(data);
        }

        if (typeof data === 'object') {
            return this.sanitizeObject(data);
        }

        return data;
    }

    // سانیتایز رشته‌ها
    sanitizeString(str) {
        if (typeof str !== 'string') return str;

        // حذف اطلاعات حساس
        let sanitized = str;
        this.sensitivePatterns.forEach(pattern => {
            sanitized = sanitized.replace(pattern, (match, group) => {
                return match.replace(group, '***REDACTED***');
            });
        });

        // محدود کردن طول
        if (sanitized.length > 10000) {
            sanitized = sanitized.substring(0, 10000) + '... [TRUNCATED]';
        }

        // حذف کاراکترهای خطرناک
        sanitized = sanitized.replace(/[<>]/g, '');

        return sanitized;
    }

    // سانیتایز آبجکت‌ها
    sanitizeObject(obj) {
        if (obj === null || typeof obj !== 'object') {
            return obj;
        }

        const sanitized = Array.isArray(obj) ? [] : {};

        for (const [key, value] of Object.entries(obj)) {
            // حذف keyهای خطرناک
            if (['__proto__', 'constructor', 'prototype'].includes(key)) {
                continue;
            }

            // سانیتایز value
            if (typeof value === 'string') {
                sanitized[key] = this.sanitizeString(value);
            } else if (typeof value === 'object' && value !== null) {
                sanitized[key] = this.sanitizeObject(value);
            } else {
                sanitized[key] = value;
            }

            // حذف فیلدهای حساس
            const sensitiveKeys = [
                'password', 'token', 'secret', 'apiKey', 'authorization',
                'creditCard', 'ssn', 'privateKey', 'credentials'
            ];

            if (sensitiveKeys.some(sensitive => 
                key.toLowerCase().includes(sensitive.toLowerCase()))) {
                sanitized[key] = '***REDACTED***';
            }
        }

        return sanitized;
    }

    // سانیتایز پیام
    sanitizeMessage(message) {
        if (typeof message !== 'string') {
            return String(message);
        }

        return this.sanitizeString(message);
    }

    // ثبت audit trail
    audit(action, resource, user = 'system', details = null) {
        const auditEntry = {
            timestamp: Date.now(),
            action: action,
            resource: resource,
            user: user,
            details: this.sanitizeData(details),
            context: this.context,
            ip: this.getClientIP(),
            userAgent: this.getUserAgent()
        };

        this.auditTrail.push(Object.freeze(auditEntry));

        // مدیریت سایز audit trail
        if (this.auditTrail.length > this.CONFIG.MAX_AUDIT_ENTRIES) {
            this.auditTrail.shift();
        }

        // همچنین در سگمنت security لاگ کن
        this.security(`AUDIT: ${action} on ${resource} by ${user}`, details);
    }

    // نمایش در کنسول با فرمت امن
    emitToConsole(level, entry) {
        const colors = {
            ERROR: '🔴',
            WARN: '🟡', 
            INFO: '🔵',
            DEBUG: '🟢',
            TRACE: '⚪',
            SECURITY: '🛡️',
            PERFORMANCE: '⚡'
        };

        const emoji = colors[level] || '⚪';
        const timestamp = new Date(entry.timestamp).toISOString();
        
        const consoleMessage = `${emoji} [${timestamp}] [${level}] [${entry.context}] ${entry.message}`;

        switch (level) {
            case 'ERROR':
                if (entry.data) {
                    console.error(consoleMessage, entry.data);
                } else {
                    console.error(consoleMessage);
                }
                break;
            case 'WARN':
                if (entry.data) {
                    console.warn(consoleMessage, entry.data);
                } else {
                    console.warn(consoleMessage);
                }
                break;
            case 'SECURITY':
                if (entry.data) {
                    console.log(`%c${consoleMessage}`, 'color: orange; font-weight: bold', entry.data);
                } else {
                    console.log(`%c${consoleMessage}`, 'color: orange; font-weight: bold');
                }
                break;
            default:
                if (entry.data) {
                    console.log(consoleMessage, entry.data);
                } else {
                    console.log(consoleMessage);
                }
        }
    }

    // دریافت اطلاعات caller
    getCallerInfo() {
        try {
            const error = new Error();
            const stack = error.stack?.split('\n') || [];
            
            // خط سوم stack معمولاً caller است
            if (stack.length >= 4) {
                const callerLine = stack[3].trim();
                return callerLine.substring(0, 200); // محدود کردن طول
            }
        } catch {
            // در صورت خطا، نادیده بگیر
        }
        
        return 'unknown';
    }

    // دریافت IP کلاینت (در محیط extension)
    getClientIP() {
        // در محیط extension معمولاً در دسترس نیست
        return 'extension_context';
    }

    // دریافت User Agent
    getUserAgent() {
        return navigator.userAgent?.substring(0, 200) || 'unknown';
    }

    // جستجو در لاگ‌ها
    searchLogs(query, options = {}) {
        const {
            segment = null,
            level = null,
            startTime = null,
            endTime = null,
            limit = 100
        } = options;

        let results = [];

        const segmentsToSearch = segment ? [segment] : Array.from(this.logStore.keys());

        for (const segName of segmentsToSearch) {
            const segmentData = this.logStore.get(segName);
            if (!segmentData) continue;

            for (const entry of segmentData.entries) {
                // فیلتر بر اساس زمان
                if (startTime && entry.timestamp < startTime) continue;
                if (endTime && entry.timestamp > endTime) continue;

                // فیلتر بر اساس سطح
                if (level && entry.level !== level) continue;

                // جستجو در متن
                const searchText = `${entry.message} ${JSON.stringify(entry.data || {})}`.toLowerCase();
                if (searchText.includes(query.toLowerCase())) {
                    results.push(entry);
                }

                if (results.length >= limit) {
                    break;
                }
            }

            if (results.length >= limit) {
                break;
            }
        }

        return results.sort((a, b) => b.timestamp - a.timestamp);
    }

    // دریافت آمار لاگ‌ها
    getLogStats() {
        const stats = {
            totalEntries: 0,
            segments: {},
            levels: {},
            retention: this.CONFIG.LOG_RETENTION_MS
        };

        for (const [segmentName, segmentData] of this.logStore) {
            const segmentStats = {
                entries: segmentData.entries.length,
                oldest: segmentData.entries[0]?.timestamp || null,
                newest: segmentData.entries[segmentData.entries.length - 1]?.timestamp || null
            };

            stats.segments[segmentName] = segmentStats;
            stats.totalEntries += segmentData.entries.length;

            // آمار بر اساس سطح
            for (const entry of segmentData.entries) {
                stats.levels[entry.level] = (stats.levels[entry.level] || 0) + 1;
            }
        }

        stats.auditEntries = this.auditTrail.length;
        return stats;
    }

    // دریافت لاگ‌ها
    getLogs(segment = null, limit = 100) {
        if (segment) {
            const segmentData = this.logStore.get(segment);
            return segmentData ? segmentData.entries.slice(-limit) : [];
        }

        const allLogs = [];
        for (const [, segmentData] of this.logStore) {
            allLogs.push(...segmentData.entries);
        }

        return allLogs
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, limit);
    }

    // دریافت audit trail
    getAuditTrail(limit = 100) {
        return this.auditTrail
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, limit);
    }

    // تنظیم سطح لاگ
    setLogLevel(level) {
        if (typeof level === 'string') {
            const upperLevel = level.toUpperCase();
            if (this.logLevels[upperLevel] !== undefined) {
                this.currentLogLevel = this.logLevels[upperLevel];
                this.info(`Log level changed to: ${level}`);
            }
        } else if (typeof level === 'number') {
            this.currentLogLevel = level;
            this.info(`Log level changed to numeric: ${level}`);
        }
    }

    // نظافت دوره‌ای
    startCleanupInterval() {
        setInterval(() => {
            this.cleanupOldEntries();
        }, this.CONFIG.BATCH_FLUSH_INTERVAL);
    }

    cleanupOldEntries() {
        const now = Date.now();
        let cleanedCount = 0;

        // نظافت لاگ‌های قدیمی
        for (const [, segmentData] of this.logStore) {
            const initialLength = segmentData.entries.length;
            segmentData.entries = segmentData.entries.filter(entry => 
                now - entry.timestamp < this.CONFIG.LOG_RETENTION_MS
            );
            cleanedCount += (initialLength - segmentData.entries.length);
        }

        // نظافت audit trail قدیمی
        const initialAuditLength = this.auditTrail.length;
        this.auditTrail = this.auditTrail.filter(entry =>
            now - entry.timestamp < this.CONFIG.AUDIT_RETENTION_MS
        );
        cleanedCount += (initialAuditLength - this.auditTrail.length);

        if (cleanedCount > 0) {
            this.debug(`Cleaned ${cleanedCount} old log entries`);
        }
    }

    // export لاگ‌ها (برای دیباگ)
    exportLogs(format = 'json') {
        const exportData = {
            metadata: {
                exportedAt: Date.now(),
                context: this.context,
                logLevel: this.currentLogLevel,
                totalEntries: this.getLogStats().totalEntries
            },
            logs: this.getLogs(null, 1000),
            audit: this.getAuditTrail(500)
        };

        if (format === 'json') {
            return JSON.stringify(exportData, null, 2);
        }

        return exportData;
    }

    // پاک‌سازی کامل
    clear() {
        for (const [, segmentData] of this.logStore) {
            segmentData.entries = [];
        }
        this.auditTrail = [];
        this.info('All logs cleared');
    }

    destroy() {
        this.clear();
        this.logStore.clear();
        console.log('🧹 SecureLogger destroyed');
    }
}

// Singleton instance
let secureLoggerInstance = null;

export function getSecureLogger(context = 'system') {
    if (!secureLoggerInstance) {
        secureLoggerInstance = new SecureLogger(context);
    }
    return secureLoggerInstance;
}

export default SecureLogger;