// modules/fallback-exporter.js - فایل جدید ایجاد کن
// ============================================================
// fallback-exporter.js - Fallback Export System for CSP Environments  
// ============================================================

class FallbackExporter {
    static exportData(data, format = 'json', fileName = null) {
        console.log('📤 [FallbackExporter] Exporting data in format:', format);
        
        let content, finalFileName, mimeType;
        
        switch (format) {
            case 'json':
                content = JSON.stringify(data, null, 2);
                finalFileName = fileName || `chatsavepro_${Date.now()}.json`;
                mimeType = 'application/json';
                break;
                
            case 'csv':
                content = this.convertToCSV(data);
                finalFileName = fileName || `chatsavepro_${Date.now()}.csv`;
                mimeType = 'text/csv';
                break;
                
            case 'txt':
                content = this.convertToTXT(data);
                finalFileName = fileName || `chatsavepro_${Date.now()}.txt`;
                mimeType = 'text/plain';
                break;
                
            case 'pdf':
                content = this.convertToTXT(data); // PDF ساده
                finalFileName = fileName || `chatsavepro_${Date.now()}.pdf`;
                mimeType = 'application/pdf';
                break;
                
            default:
                throw new Error(`Unsupported format: ${format}`);
        }
        
        return this.downloadFile(content, finalFileName, mimeType);
    }
    
    static convertToCSV(data) {
        const headers = ['ID', 'Content', 'Timestamp', 'Type', 'Platform'];
        const rows = [];
        
        if (data.conversations && Array.isArray(data.conversations)) {
            data.conversations.forEach(conv => {
                rows.push([
                    conv.id || 'N/A',
                    `"${(conv.content || '').replace(/"/g, '""')}"`,
                    conv.timestamp || 'N/A',
                    conv.type || 'unknown',
                    data.scanInfo?.platform || 'unknown'
                ]);
            });
        }
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }
    
    static convertToTXT(data) {
        let content = `ChatSavePro Export\n`;
        content += `Generated: ${new Date().toLocaleString('fa-IR')}\n`;
        content += `Version: ${data.version || '3.9'}\n`;
        content += `Platform: ${data.scanInfo?.platform || 'unknown'}\n`;
        content += `Total Messages: ${data.conversations?.length || 0}\n`;
        content += '='.repeat(60) + '\n\n';
        
        if (data.conversations && Array.isArray(data.conversations)) {
            data.conversations.forEach((conv, index) => {
                content += `MESSAGE ${index + 1}\n`;
                content += `Type: ${conv.type || 'unknown'}\n`;
                content += `Time: ${conv.timestamp || 'N/A'}\n`;
                content += `ID: ${conv.id || 'N/A'}\n`;
                content += '-'.repeat(40) + '\n';
                content += `${conv.content || 'No content'}\n`;
                content += '='.repeat(60) + '\n\n';
            });
        } else {
            content += 'No conversation data available.\n';
        }
        
        return content;
    }
    
    static downloadFile(content, fileName, mimeType) {
        try {
            // ایجاد Blob
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            
            // ایجاد لینک دانلود
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            a.style.display = 'none';
            
            // اضافه کردن به صفحه و کلیک
            document.body.appendChild(a);
            a.click();
            
            // تمیزکاری
            setTimeout(() => {
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 100);
            
            console.log('✅ [FallbackExporter] File downloaded:', fileName);
            return { 
                success: true, 
                fileName: fileName,
                fileSize: `${Math.round(content.length / 1024 * 100) / 100} KB`,
                method: 'fallback'
            };
            
        } catch (error) {
            console.error('❌ [FallbackExporter] Download failed:', error);
            return { 
                success: false, 
                error: error.message,
                method: 'fallback'
            };
        }
    }
    
    static exportScanResults(scanResults, format = 'json') {
        console.log('🔍 [FallbackExporter] Exporting scan results');
        
        if (!scanResults || scanResults.length === 0) {
            return { success: false, error: 'No scan results to export' };
        }
        
        const latestScan = scanResults[scanResults.length - 1];
        const exportData = {
            message: "ChatSavePro Export - Fallback Mode",
            timestamp: new Date().toISOString(),
            version: "3.9",
            source: "Fallback Export System",
            scanInfo: {
                sessionId: latestScan.sessionId,
                messageCount: latestScan.messageCount,
                platform: latestScan.platform,
                scannedAt: new Date(latestScan.timestamp).toLocaleString('fa-IR'),
                source: latestScan.source
            },
            conversations: latestScan.messages || []
        };
        
        return this.exportData(exportData, format);
    }
    
    // متد برای export مستقیم از localStorage
    static exportFromLocalStorage(format = 'json') {
        try {
            const storedData = localStorage.getItem('chatsavepro_transfer');
            if (storedData) {
                const data = JSON.parse(storedData);
                return this.exportData(data, format);
            } else {
                return { success: false, error: 'No data found in localStorage' };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
}

// قرار دادن در global scope برای دسترسی آسان
if (typeof globalThis !== 'undefined') {
    globalThis.FallbackExporter = FallbackExporter;
}

export { FallbackExporter };
export default FallbackExporter;