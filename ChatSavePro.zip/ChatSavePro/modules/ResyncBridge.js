// =========================================================
// 🛰️ ChatSavePro Guardian QuantumStage v3.9
// ResyncBridge.js - Automatic Reinject & Resync Controller
// =========================================================

// 🛡️ PRINCIPLE 1: CONTEXT ISOLATION - Anti-duplicate injection guard
if (globalThis.__RESYNC_BRIDGE_LOADED__) {
    console.log("⚠️ [ResyncBridge] Already loaded - skipping reinit");
    throw new Error("ResyncBridge already loaded");
}
globalThis.__RESYNC_BRIDGE_LOADED__ = true;

console.log("🛰️ [ResyncBridge] QuantumStage v3.9 initializing...");

// 🛡️ PRINCIPLE 2: STRICT INTERFACE CONTRACTS
class ResyncBridge {
    constructor() {
        // 🛡️ PRINCIPLE 5: MEMORY SEGMENTATION
        // 🔧 اصلاح: استفاده از private property برای state
        this._state = { 
            activeTab: null, 
            lastResync: 0,
            injectionQueue: new Map(),
            sessionTokens: new Map()
        };
        
        this.sessionKey = 'guardian_session_active';
        this.maxRetries = 3;
        this.retryCount = 0;
        this.cleanupCallbacks = new Set();
        this.isInitialized = false;
        
        // 🛡️ PRINCIPLE 9: FROZEN GLOBALS - اصلاح شده
        this.setupStateManagement();
    }

    // 🛡️ PRINCIPLE 9: FROZEN GLOBALS - Secure state management (اصلاح شده)
    setupStateManagement() {
        try {
            // 🔧 اصلاح: ایجاد state مدیریت شده بدون فریز کردن مستقیم
            Object.defineProperty(this, 'state', {
                get: () => ({ ...this._state }), // بازگرداندن کپی از state
                set: (value) => {
                    console.warn('⚠️ [ResyncBridge] Direct state assignment not allowed - use updateState()');
                },
                enumerable: true,
                configurable: false
            });
        } catch (error) {
            console.warn('⚠️ [ResyncBridge] State setup partial:', error.message);
        }
    }

    // 🔧 NEW: متدهای امن برای به‌روزرسانی state
    updateState(updates) {
        try {
            Object.assign(this._state, updates);
            return true;
        } catch (error) {
            console.error('❌ [ResyncBridge] State update failed:', error);
            return false;
        }
    }

    setActiveTab(tabId) {
        this._state.activeTab = tabId;
    }

    setLastResync(timestamp) {
        this._state.lastResync = timestamp;
    }

    // 🛡️ PRINCIPLE 3: RESILIENT ASYNC OPERATIONS - Enhanced initialization
    async initialize() {
        if (this.isInitialized) {
            console.warn("⚠️ [ResyncBridge] Already initialized");
            return;
        }

        try {
            console.log("🚀 [ResyncBridge] Initializing with 14 principles compliance...");

            // 🛡️ PRINCIPLE 10: INTEGRITY BRIDGE - Session validation
            await this.initializeSession();
            
            // 🛡️ PRINCIPLE 6: SECURE EVENT BUS - Event listeners with validation
            this.setupEventListeners();
            
            // 🛡️ PRINCIPLE 11: QUANTUM RESYNC - Connection monitoring
            this.startHealthMonitoring();

            this.isInitialized = true;
            console.log("✅ [ResyncBridge] Initialized successfully with all security measures");

        } catch (error) {
            console.error("❌ [ResyncBridge] Initialization failed:", error);
            await this.handleInitializationError(error);
        }
    }

    // 🛡️ PRINCIPLE 10: INTEGRITY BRIDGE - Secure session management
    async initializeSession() {
        try {
            const sessionToken = this.generateSessionToken();
            await chrome.storage.session.set({ 
                [this.sessionKey]: true,
                sessionToken: sessionToken,
                initializedAt: Date.now()
            });
            
            this._state.sessionTokens.set('main', sessionToken);
            console.log("🔐 [ResyncBridge] Session initialized with token");
            
        } catch (error) {
            console.error("❌ [ResyncBridge] Session initialization failed:", error);
            throw error;
        }
    }

    // 🛡️ PRINCIPLE 10: INTEGRITY BRIDGE - Token generation
    generateSessionToken() {
        const timestamp = Date.now();
        const randomPart = crypto.getRandomValues(new Uint32Array(2))[0];
        return `rs_token_${timestamp}_${randomPart}`;
    }

    // 🛡️ PRINCIPLE 6: SECURE EVENT BUS - Secure event listener setup
    setupEventListeners() {
        // 🔁 Tab update listener with validation
        chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
            this.handleTabUpdate(tabId, changeInfo, tab);
        });

        // 📡 Message listener with validation
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            return this.handleRuntimeMessage(message, sender, sendResponse);
        });

        // 🛡️ PRINCIPLE 13: MODULAR CLEANUP - Cleanup on unload
        chrome.runtime.onSuspend.addListener(() => {
            this.cleanup();
        });

        console.log("📡 [ResyncBridge] Secure event listeners established");
    }

    // 🛡️ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Tab update validation (اصلاح شده)
    async handleTabUpdate(tabId, changeInfo, tab) {
        try {
            // Validate input parameters
            if (!tabId || typeof tabId !== 'number') {
                console.warn('⚠️ [ResyncBridge] Invalid tabId in update handler');
                return;
            }

            if (changeInfo.status === 'complete' && tab?.active) {
                console.log(`♻️ [ResyncBridge] Tab ${tabId} refreshed, validating and reinjecting...`);
                
                // 🛡️ PRINCIPLE 4: ENHANCED SCAN ENGINE - Domain validation
                if (this.isAllowedDomain(tab.url)) {
                    // 🔧 اصلاح: استفاده از متد امن برای به‌روزرسانی state
                    this.setActiveTab(tabId);
                    await this.injectContentScript(tabId);
                } else {
                    console.log(`🚫 [ResyncBridge] Domain not allowed: ${tab.url}`);
                }
            }
        } catch (error) {
            console.error("❌ [ResyncBridge] Tab update handler error:", error);
        }
    }

    // 🛡️ PRINCIPLE 4: ENHANCED SCAN ENGINE - Domain validation
    isAllowedDomain(url) {
        try {
            const allowedDomains = [
                'chat.openai.com', 'chatgpt.com', 'deepseek.com', 
                'claude.ai', 'web.telegram.org', 'web.whatsapp.com',
                'discord.com', 'messenger.com'
            ];
            
            const domain = new URL(url).hostname;
            return allowedDomains.some(allowed => domain.includes(allowed));
        } catch {
            return false;
        }
    }

    // 🛡️ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Message validation
    async handleRuntimeMessage(message, sender, sendResponse) {
        try {
            // Validate message structure
            if (!this.validateIncomingMessage(message)) {
                console.warn('🚫 [ResyncBridge] Invalid message structure:', message);
                sendResponse({ success: false, error: 'Invalid message' });
                return false;
            }

            if (message.action === 'CONTENT_SCRIPT_READY') {
                console.log("🔄 [ResyncBridge] Valid ContentScript ready message received");
                await this.handleContentScriptReady(sender.tab?.id, message);
                sendResponse({ success: true });
            } else if (message.action === 'QUANTUM_PING') {
                sendResponse({ 
                    success: true, 
                    message: 'quantum_pong',
                    timestamp: Date.now() 
                });
            }

            return true;
        } catch (error) {
            console.error("❌ [ResyncBridge] Message handler error:", error);
            sendResponse({ success: false, error: error.message });
            return false;
        }
    }

    // 🛡️ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Message validation
    validateIncomingMessage(message) {
        if (!message || typeof message !== 'object') return false;
        if (!message.action || typeof message.action !== 'string') return false;
        if (message.timestamp && typeof message.timestamp !== 'number') return false;
        
        // Security token validation for sensitive actions
        if (this.requiresSecurityToken(message.action)) {
            if (!message.securityToken) return false;
        }
        
        return true;
    }

    requiresSecurityToken(action) {
        const securedActions = ['BACKGROUND_RESYNC', 'MODIFY_SETTINGS', 'CLEAR_DATA'];
        return securedActions.includes(action);
    }

    // 🛡️ PRINCIPLE 7: ASYNC PIPELINE & RESILIENCE - Enhanced injection with retry
    async injectContentScript(tabId) {
        try {
            console.log(`📦 [ResyncBridge] Starting secure injection for tab ${tabId}`);
            
            // 🛡️ PRINCIPLE 10: INTEGRITY BRIDGE - Session validation
            const session = await chrome.storage.session.get([this.sessionKey, 'sessionToken']);
            if (!session[this.sessionKey]) {
                console.warn("⚠️ [ResyncBridge] Session inactive, skipping injection");
                return;
            }

            // 🛡️ PRINCIPLE 5: MEMORY SEGMENTATION - Queue management
            if (this._state.injectionQueue.has(tabId)) {
                console.log(`⏳ [ResyncBridge] Injection already queued for tab ${tabId}`);
                return;
            }

            this._state.injectionQueue.set(tabId, Date.now());

            // 🛡️ PRINCIPLE 3: RESILIENT ASYNC OPERATIONS - Execute with timeout
            await this.executeWithTimeout(
                () => chrome.scripting.executeScript({
                    target: { tabId },
                    files: ['contentScript.js']
                }),
                10000,
                `Injection timeout for tab ${tabId}`
            );

            this._state.injectionQueue.delete(tabId);
            console.log(`✅ [ResyncBridge] Successfully injected into tab ${tabId}`);

        } catch (error) {
            this._state.injectionQueue.delete(tabId);
            console.error(`❌ [ResyncBridge] Injection failed for tab ${tabId}:`, error.message);
            await this.retryReinject(tabId);
        }
    }

    // 🛡️ PRINCIPLE 3: RESILIENT ASYNC OPERATIONS - Timeout wrapper
    async executeWithTimeout(operation, timeoutMs, errorMessage) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(errorMessage));
            }, timeoutMs);

            operation()
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }

    // 🛡️ PRINCIPLE 11: QUANTUM RESYNC - Enhanced ready handler (اصلاح شده)
    async handleContentScriptReady(tabId, message) {
        // 🔧 اصلاح: استفاده از متد امن برای به‌روزرسانی state
        this.setLastResync(Date.now());

        try {
            console.log("🔄 [ResyncBridge] Starting comprehensive resync procedure...");

            // 🛡️ PRINCIPLE 8: DYNAMIC DEPENDENCY GRAPH - Check dependencies
            const dependenciesReady = await this.checkDependencies();
            if (!dependenciesReady) {
                console.warn("⚠️ [ResyncBridge] Dependencies not ready, using fallback");
                this.startFallbackPing();
                return;
            }

            // 🛡️ PRINCIPLE 4: ENHANCED SCAN ENGINE - Restart monitoring
            await this.restartMonitoringSystems();

            // 🛡️ PRINCIPLE 6: SECURE EVENT BUS - Notify background
            await this.notifyBackgroundResync(tabId, message);

            console.log("✅ [ResyncBridge] Resync procedure completed successfully");

        } catch (error) {
            console.error("❌ [ResyncBridge] Resync handling error:", error);
            await this.retryReinject(tabId);
        }
    }

    // 🛡️ PRINCIPLE 8: DYNAMIC DEPENDENCY GRAPH - Dependency checking
    async checkDependencies() {
        const dependencies = [
            { name: 'scanLayer', check: () => !!globalThis.scanLayer },
            { name: 'resyncManager', check: () => !!globalThis.scanLayer?.resyncManager },
            { name: 'startConnectionMonitoring', check: () => 
                typeof globalThis.scanLayer?.resyncManager?.startConnectionMonitoring === 'function' 
            }
        ];

        for (const dep of dependencies) {
            if (!dep.check()) {
                console.warn(`⚠️ [ResyncBridge] Dependency missing: ${dep.name}`);
                return false;
            }
        }

        return true;
    }

    // 🛡️ PRINCIPLE 4: ENHANCED SCAN ENGINE - Restart monitoring
    async restartMonitoringSystems() {
        try {
            const resyncManager = globalThis.scanLayer.resyncManager;
            await resyncManager.startConnectionMonitoring();
            console.log("✅ [ResyncBridge] Resync monitoring restarted");
        } catch (error) {
            console.error("❌ [ResyncBridge] Failed to restart monitoring:", error);
            throw error;
        }
    }

    // 🛡️ PRINCIPLE 6: SECURE EVENT BUS - Background notification
    async notifyBackgroundResync(tabId, originalMessage) {
        try {
            const resyncMessage = {
                action: "BACKGROUND_RESYNC",
                tabId: tabId,
                timestamp: Date.now(),
                bridge: "ResyncBridge",
                securityToken: originalMessage.securityToken,
                data: {
                    originalUrl: originalMessage.url,
                    resyncType: 'tab_refresh'
                }
            };

            await chrome.runtime.sendMessage(resyncMessage);
            console.log("📤 [ResyncBridge] Background resync notification sent");
        } catch (error) {
            console.error("❌ [ResyncBridge] Background notification failed:", error);
        }
    }

    // 🛡️ PRINCIPLE 7: ASYNC PIPELINE & RESILIENCE - Fallback system
    startFallbackPing() {
        console.log("🔁 [ResyncBridge] Starting secure fallback ping system");
        
        const pingInterval = setInterval(() => {
            chrome.runtime.sendMessage({
                action: "QUANTUM_PING",
                data: { 
                    timestamp: Date.now(), 
                    fallback: true,
                    bridge: "ResyncBridge"
                }
            }).catch(error => {
                console.warn("⚠️ [ResyncBridge] Fallback ping failed:", error.message);
            });
        }, 30000);

        // 🛡️ PRINCIPLE 13: MODULAR CLEANUP - Register for cleanup
        this.cleanupCallbacks.add(() => {
            clearInterval(pingInterval);
            console.log("🧹 [ResyncBridge] Fallback ping stopped");
        });
    }

    // 🛡️ PRINCIPLE 3: RESILIENT ASYNC OPERATIONS - Enhanced retry with backoff
    async retryReinject(tabId) {
        if (this.retryCount >= this.maxRetries) {
            console.error("🚨 [ResyncBridge] Max retries reached, giving up");
            return;
        }

        this.retryCount++;
        const backoffDelay = Math.min(1000 * Math.pow(2, this.retryCount - 1), 30000);
        
        console.log(`🔁 [ResyncBridge] Retry ${this.retryCount} in ${backoffDelay}ms`);
        
        await new Promise(resolve => setTimeout(resolve, backoffDelay));
        await this.injectContentScript(tabId);
    }

    // 🛡️ PRINCIPLE 11: QUANTUM RESYNC - Health monitoring
    startHealthMonitoring() {
        console.log("❤️ [ResyncBridge] Starting health monitoring");
        
        const healthCheck = setInterval(() => {
            this.performHealthCheck();
        }, 60000);

        this.cleanupCallbacks.add(() => {
            clearInterval(healthCheck);
            console.log("🧹 [ResyncBridge] Health monitoring stopped");
        });
    }

    async performHealthCheck() {
        try {
            const session = await chrome.storage.session.get(this.sessionKey);
            if (!session[this.sessionKey]) {
                console.warn("⚠️ [ResyncBridge] Health check: Session inactive");
            }
            
            console.log("✅ [ResyncBridge] Health check passed");
        } catch (error) {
            console.error("❌ [ResyncBridge] Health check failed:", error);
        }
    }

    // 🛡️ PRINCIPLE 13: MODULAR CLEANUP & LIFECYCLE CONTROL
    async cleanup() {
        console.log("🧹 [ResyncBridge] Starting cleanup procedure...");
        
        // Execute all cleanup callbacks
        this.cleanupCallbacks.forEach(callback => {
            try {
                callback();
            } catch (error) {
                console.warn("⚠️ [ResyncBridge] Cleanup callback error:", error);
            }
        });
        
        this.cleanupCallbacks.clear();
        this._state.injectionQueue.clear();
        this._state.sessionTokens.clear();
        this.isInitialized = false;
        
        console.log("✅ [ResyncBridge] Cleanup completed");
    }

    // 🛡️ PRINCIPLE 12: SECURE LOGGING & AUDIT TRAIL
    logSecurityEvent(event, details) {
        const auditLog = {
            event,
            timestamp: Date.now(),
            bridge: "ResyncBridge",
            tabId: this._state.activeTab,
            details: this.sanitizeLogDetails(details)
        };
        
        console.log(`🔐 [Audit] ${event}`, auditLog);
    }

    sanitizeLogDetails(details) {
        if (typeof details === 'object') {
            const sanitized = {};
            for (const [key, value] of Object.entries(details)) {
                if (typeof value === 'string') {
                    sanitized[key] = value.substring(0, 500);
                } else {
                    sanitized[key] = value;
                }
            }
            return sanitized;
        }
        return details;
    }

    async handleInitializationError(error) {
        this.logSecurityEvent('INITIALIZATION_FAILED', { error: error.message });
        
        // Attempt recovery
        try {
            await chrome.storage.session.remove(this.sessionKey);
            console.log("🔄 [ResyncBridge] Attempting recovery...");
        } catch {
            // Silent fail
        }
    }
}

// 🛡️ PRINCIPLE 14: STATIC ES6 IMPORTS - Main execution wrapper
(async () => {
    try {
        console.log("🎯 [ResyncBridge] Starting QuantumStage v3.9...");
        
        const bridge = new ResyncBridge();
        await bridge.initialize();
        
        // 🛡️ PRINCIPLE 1: CONTEXT ISOLATION - Global registration
        globalThis.__RESYNC_BRIDGE__ = bridge;
        
        console.log("✅ [ResyncBridge] QuantumStage v3.9 fully operational");
        
    } catch (error) {
        console.error("🚨 [ResyncBridge] Critical initialization error:", error);
    }
})();