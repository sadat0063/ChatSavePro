// File: modules/progress-indicator.js
// ============================================================
// Guardian Principles + Manifest V3 Compatible Progress Indicator
// ============================================================

class SecureProgressIndicator {
    #indicators = new Map();
    #animationFrames = new Map();
    #cleanupIntervals = new Set();
    #operationQueue = new Map();
    #metrics = new Map();
    #config = new Map();

    static #instance = null;

    constructor() {
        if (SecureProgressIndicator.#instance) {
            return SecureProgressIndicator.#instance;
        }

        this.#initializeSecureState();
        this.#applySecurityHardening();
        this.#setupMonitoring();
        
        SecureProgressIndicator.#instance = this;
        Object.freeze(this);
    }

    static getInstance() {
        if (!this.#instance) {
            this.#instance = new SecureProgressIndicator();
        }
        return this.#instance;
    }

    #initializeSecureState() {
        // Configuration
        this.#config.set('maxIndicators', 20);
        this.#config.set('autoHideDelay', 3000);
        this.#config.set('cleanupInterval', 30000);
        this.#config.set('maxQueueSize', 10);
        this.#config.set('throttleDelay', 16);
        this.#config.set('maxAnimationDuration', 10000);

        // Security settings
        this.#config.set('allowedContainerTypes', Object.freeze(['div', 'section', 'article', 'main']));
        this.#config.set('maxTextLength', 100);
        this.#config.set('sanitizeText', true);

        // Performance metrics
        this.#metrics.set('operations', {
            totalIndicators: 0,
            activeIndicators: 0,
            completedAnimations: 0,
            cancelledAnimations: 0,
            errorCount: 0,
            averageAnimationTime: 0,
            lastOperationTime: null
        });

        this.#metrics.set('performance', {
            rafSupported: !!window.requestAnimationFrame,
            cssAnimationsSupported: this.#checkCSSAnimationsSupport(),
            prefersReducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
            startTime: Date.now()
        });
    }

    #applySecurityHardening() {
        Object.freeze(this.constructor.prototype);
        Object.freeze(SecureProgressIndicator);
        
        // Prevent prototype pollution
        Object.setPrototypeOf(this, null);
    }

    #setupMonitoring() {
        const cleanupInterval = setInterval(() => {
            this.#cleanupStaleIndicators();
        }, this.#config.get('cleanupInterval'));

        this.#cleanupIntervals.add(cleanupInterval);
    }

    async init() {
        try {
            await this.#injectStyles();
            this.#log('info', 'SecureProgressIndicator initialized', {
                maxIndicators: this.#config.get('maxIndicators'),
                performance: this.#metrics.get('performance')
            });
            return true;
        } catch (error) {
            this.#log('error', 'Initialization failed', { error: error.message });
            throw error;
        }
    }

    #checkCSSAnimationsSupport() {
        return !!(window.CSS && CSS.supports && CSS.supports('animation', 'name 1s'));
    }

    async #injectStyles() {
        if (document.getElementById('secure-progress-styles')) return;

        const styles = `
            .secure-progress-container {
                position: relative;
                width: 100%;
                height: 4px;
                background: #e9ecef;
                border-radius: 2px;
                overflow: hidden;
                margin: 8px 0;
                transition: opacity 0.3s ease;
            }

            .secure-progress-bar {
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                background: linear-gradient(90deg, #4a90e2, #357abd);
                border-radius: 2px;
                transition: width 0.3s ease;
                width: 0%;
            }

            .secure-progress-bar.indeterminate {
                background: linear-gradient(90deg, #4a90e2, #357abd, #4a90e2);
                background-size: 200% 100%;
                animation: secureProgressShimmer 1.5s infinite linear;
            }

            .secure-progress-text {
                font-size: 11px;
                color: #6c757d;
                text-align: center;
                margin-top: 4px;
                font-weight: 500;
                transition: color 0.3s ease;
            }

            .secure-progress-success {
                background: linear-gradient(90deg, #28a745, #20c997) !important;
            }

            .secure-progress-error {
                background: linear-gradient(90deg, #dc3545, #e83e8c) !important;
            }

            .secure-progress-warning {
                background: linear-gradient(90deg, #ffc107, #fd7e14) !important;
            }

            .secure-progress-info {
                background: linear-gradient(90deg, #17a2b8, #6f42c1) !important;
            }

            @keyframes secureProgressShimmer {
                0% { background-position: 200% 0; }
                100% { background-position: -200% 0; }
            }

            .secure-progress-pulse {
                animation: secureProgressPulse 2s infinite;
            }

            @keyframes secureProgressPulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.7; }
            }

            .secure-progress-hidden {
                opacity: 0 !important;
                pointer-events: none;
            }

            .secure-progress-compact {
                height: 2px !important;
                margin: 4px 0 !important;
            }

            .secure-progress-large {
                height: 6px !important;
                margin: 12px 0 !important;
            }
        `;

        const styleSheet = document.createElement('style');
        styleSheet.id = 'secure-progress-styles';
        styleSheet.textContent = styles;
        document.head.appendChild(styleSheet);
    }

    // ==================== CORE OPERATIONS ====================

    async create(container, options = {}) {
        const operationId = this.#generateId('create');
        
        try {
            await this.#validateContainer(container);
            await this.#validateOptions(options);
            
            // Remove existing progress if any
            await this.#destroy(container);

            const indicator = await this.#createIndicator(container, options, operationId);
            this.#indicators.set(container, indicator);

            this.#recordMetric('totalIndicators');
            this.#recordMetric('activeIndicators');

            return Object.freeze({ ...indicator });

        } catch (error) {
            this.#recordMetric('errorCount');
            throw this.#enhanceError(error, 'create', operationId);
        }
    }

    async update(container, percentage, text = null) {
        const operationId = this.#generateId('update');
        
        try {
            const indicator = this.#indicators.get(container);
            if (!indicator) {
                throw new Error('Progress indicator not found');
            }

            percentage = Math.max(0, Math.min(100, percentage));
            indicator.value = percentage;
            indicator.lastUpdate = Date.now();

            await this.#updateIndicatorVisuals(indicator, percentage, text);

            return Object.freeze({ ...indicator });

        } catch (error) {
            throw this.#enhanceError(error, 'update', operationId);
        }
    }

    async setIndeterminate(container) {
        const operationId = this.#generateId('indeterminate');
        
        try {
            const indicator = this.#indicators.get(container);
            if (!indicator) return;

            indicator.bar.classList.add('indeterminate');
            indicator.bar.style.width = '100%';
            indicator.lastUpdate = Date.now();

            if (indicator.text) {
                indicator.text.textContent = 'Processing...';
            }

            return Object.freeze({ ...indicator });

        } catch (error) {
            throw this.#enhanceError(error, 'setIndeterminate', operationId);
        }
    }

    async setSuccess(container, message = 'Completed!') {
        const operationId = this.#generateId('success');
        
        try {
            const indicator = this.#indicators.get(container);
            if (!indicator) return;

            indicator.bar.classList.remove('indeterminate');
            indicator.bar.classList.add('secure-progress-success');
            indicator.bar.style.width = '100%';
            indicator.lastUpdate = Date.now();

            if (indicator.text) {
                indicator.text.textContent = this.#sanitizeText(message);
                indicator.text.style.color = '#28a745';
            }

            // Auto-hide after success
            setTimeout(() => {
                this.hide(container).catch(() => {});
            }, this.#config.get('autoHideDelay'));

            return Object.freeze({ ...indicator });

        } catch (error) {
            throw this.#enhanceError(error, 'setSuccess', operationId);
        }
    }

    async setError(container, message = 'Failed!') {
        const operationId = this.#generateId('error');
        
        try {
            const indicator = this.#indicators.get(container);
            if (!indicator) return;

            indicator.bar.classList.remove('indeterminate');
            indicator.bar.classList.add('secure-progress-error');
            indicator.bar.style.width = '100%';
            indicator.lastUpdate = Date.now();

            if (indicator.text) {
                indicator.text.textContent = this.#sanitizeText(message);
                indicator.text.style.color = '#dc3545';
            }

            return Object.freeze({ ...indicator });

        } catch (error) {
            throw this.#enhanceError(error, 'setError', operationId);
        }
    }

    async hide(container) {
        const operationId = this.#generateId('hide');
        
        try {
            const indicator = this.#indicators.get(container);
            if (!indicator) return;

            indicator.container.classList.add('secure-progress-hidden');
            
            setTimeout(() => {
                if (indicator.container.parentNode) {
                    indicator.container.parentNode.removeChild(indicator.container);
                }
                this.#indicators.delete(container);
                this.#metrics.get('operations').activeIndicators--;
            }, 300);

            return true;

        } catch (error) {
            throw this.#enhanceError(error, 'hide', operationId);
        }
    }

    async destroy(container) {
        const operationId = this.#generateId('destroy');
        
        try {
            await this.#destroy(container);
            return true;

        } catch (error) {
            throw this.#enhanceError(error, 'destroy', operationId);
        }
    }

    // ==================== ANIMATION METHODS ====================

    async animateProgress(container, from, to, duration = 1000) {
        const operationId = this.#generateId('animate');
        
        try {
            if (this.#metrics.get('performance').prefersReducedMotion) {
                // Skip animation for users who prefer reduced motion
                return this.update(container, to);
            }

            const indicator = this.#indicators.get(container);
            if (!indicator) {
                throw new Error('Progress indicator not found');
            }

            // Cancel previous animation
            if (this.#animationFrames.has(container)) {
                this.#cancelAnimation(container);
            }

            return await this.#executeAnimation(container, from, to, duration, operationId);

        } catch (error) {
            throw this.#enhanceError(error, 'animateProgress', operationId);
        }
    }

    async #executeAnimation(container, from, to, duration, operationId) {
        return new Promise((resolve, reject) => {
            const startTime = performance.now();
            const timeoutId = setTimeout(() => {
                this.#cancelAnimation(container);
                reject(new Error('Animation timeout'));
            }, this.#config.get('maxAnimationDuration'));

            const animate = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                const easeProgress = this.#easeInOutCubic(progress);
                const currentValue = from + (to - from) * easeProgress;
                
                this.update(container, currentValue).catch(() => {
                    // Ignore update errors during animation
                });
                
                if (progress < 1) {
                    const animationId = requestAnimationFrame(animate);
                    this.#animationFrames.set(container, { id: animationId, timeoutId });
                } else {
                    this.#animationFrames.delete(container);
                    clearTimeout(timeoutId);
                    this.#recordMetric('completedAnimations');
                    resolve();
                }
            };
            
            const initialAnimationId = requestAnimationFrame(animate);
            this.#animationFrames.set(container, { 
                id: initialAnimationId, 
                timeoutId 
            });
        });
    }

    #cancelAnimation(container) {
        const animation = this.#animationFrames.get(container);
        if (animation) {
            cancelAnimationFrame(animation.id);
            clearTimeout(animation.timeoutId);
            this.#animationFrames.delete(container);
            this.#recordMetric('cancelledAnimations');
        }
    }

    // ==================== SECURITY & VALIDATION ====================

    async #validateContainer(container) {
        if (!container || !(container instanceof HTMLElement)) {
            throw new Error('Invalid container element');
        }

        if (!this.#config.get('allowedContainerTypes').includes(container.tagName.toLowerCase())) {
            throw new Error(`Container type not allowed: ${container.tagName}`);
        }

        if (!document.body.contains(container)) {
            throw new Error('Container not in document');
        }

        return true;
    }

    async #validateOptions(options) {
        const validOptions = ['showText', 'height', 'borderRadius', 'customClass', 'compact', 'large'];
        const invalidKeys = Object.keys(options).filter(key => !validOptions.includes(key));
        
        if (invalidKeys.length > 0) {
            throw new Error(`Invalid options: ${invalidKeys.join(', ')}`);
        }

        if (options.height && !/^\d+(px|%)$/.test(options.height)) {
            throw new Error('Height must be in px or %');
        }

        return true;
    }

    #sanitizeText(text) {
        if (!this.#config.get('sanitizeText')) {
            return String(text).slice(0, this.#config.get('maxTextLength'));
        }

        return String(text)
            .replace(/[<>]/g, '') // Remove < and >
            .slice(0, this.#config.get('maxTextLength'));
    }

    // ==================== PRIVATE METHODS ====================

    async #createIndicator(container, options, operationId) {
        const {
            showText = true,
            height = '4px',
            borderRadius = '2px',
            customClass = '',
            compact = false,
            large = false
        } = options;

        const progressContainer = document.createElement('div');
        progressContainer.className = `secure-progress-container ${customClass}`;
        
        if (compact) {
            progressContainer.classList.add('secure-progress-compact');
        } else if (large) {
            progressContainer.classList.add('secure-progress-large');
        } else {
            progressContainer.style.height = height;
        }
        
        progressContainer.style.borderRadius = borderRadius;

        const progressBar = document.createElement('div');
        progressBar.className = 'secure-progress-bar';
        progressContainer.appendChild(progressBar);

        let progressText = null;
        if (showText) {
            progressText = document.createElement('div');
            progressText.className = 'secure-progress-text';
            progressText.textContent = '0%';
            progressContainer.appendChild(progressText);
        }

        container.appendChild(progressContainer);

        return Object.freeze({
            container: progressContainer,
            bar: progressBar,
            text: progressText,
            value: 0,
            created: Date.now(),
            lastUpdate: Date.now(),
            operationId
        });
    }

    async #updateIndicatorVisuals(indicator, percentage, text) {
        indicator.bar.style.width = percentage + '%';
        indicator.bar.setAttribute('data-progress', percentage);

        if (indicator.text) {
            indicator.text.textContent = text ? 
                this.#sanitizeText(text) : `${Math.round(percentage)}%`;
        }

        this.#updateProgressColor(indicator.bar, percentage);
    }

    #updateProgressColor(progressBar, percentage) {
        progressBar.classList.remove(
            'secure-progress-success', 
            'secure-progress-error', 
            'secure-progress-warning',
            'secure-progress-info'
        );

        if (percentage >= 100) {
            progressBar.classList.add('secure-progress-success');
        } else if (percentage >= 75) {
            progressBar.classList.add('secure-progress-warning');
        } else if (percentage >= 50) {
            progressBar.classList.add('secure-progress-info');
        }
    }

    async #destroy(container) {
        const indicator = this.#indicators.get(container);
        if (!indicator) return;

        // Cancel any ongoing animation
        this.#cancelAnimation(container);

        if (indicator.container.parentNode) {
            indicator.container.parentNode.removeChild(indicator.container);
        }
        
        this.#indicators.delete(container);
        this.#metrics.get('operations').activeIndicators--;
    }

    #cleanupStaleIndicators() {
        const now = Date.now();
        const cutoffTime = now - 60000; // 1 minute ago
        
        this.#indicators.forEach((indicator, container) => {
            if (!document.body.contains(container) || 
                (indicator.lastUpdate && indicator.lastUpdate < cutoffTime)) {
                this.#destroy(container).catch(() => {});
            }
        });
    }

    #easeInOutCubic(t) {
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }

    #generateId(prefix) {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
    }

    #recordMetric(metric) {
        const operations = this.#metrics.get('operations');
        if (operations[metric] !== undefined) {
            operations[metric]++;
        }
        operations.lastOperationTime = Date.now();
    }

    #enhanceError(error, context, id) {
        const enhanced = new Error(`[${context}] ${error.message} (ID: ${id})`);
        enhanced.originalError = error;
        enhanced.context = context;
        enhanced.id = id;
        enhanced.timestamp = new Date().toISOString();
        return enhanced;
    }

    #log(level, message, meta = {}) {
        const entry = Object.freeze({
            timestamp: new Date().toISOString(),
            level,
            message,
            module: 'SecureProgressIndicator',
            ...meta
        });
        
        console[level](`[SecureProgressIndicator] ${message}`, entry);
    }

    // ==================== PUBLIC API ====================

    getPerformanceReport() {
        const operations = this.#metrics.get('operations');
        const performance = this.#metrics.get('performance');
        
        const successRate = operations.completedAnimations > 0 ? 
            (operations.completedAnimations / 
             (operations.completedAnimations + operations.cancelledAnimations)) * 100 : 100;

        return Object.freeze({
            timestamp: new Date().toISOString(),
            operations: Object.freeze({
                ...operations,
                successRate: Math.round(successRate * 100) / 100
            }),
            performance: Object.freeze(performance),
            indicators: Object.freeze({
                total: operations.totalIndicators,
                active: operations.activeIndicators,
                maxAllowed: this.#config.get('maxIndicators')
            })
        });
    }

    async cleanup() {
        this.#cleanupIntervals.forEach(interval => clearInterval(interval));
        this.#cleanupIntervals.clear();

        // Destroy all indicators
        const destroyPromises = Array.from(this.#indicators.keys()).map(container =>
            this.#destroy(container).catch(() => {})
        );

        await Promise.allSettled(destroyPromises);

        // Cancel all animations
        this.#animationFrames.forEach((animation, container) => {
            this.#cancelAnimation(container);
        });

        this.#log('info', 'Cleanup completed');
    }
}

// ES6 Module Export
export default SecureProgressIndicator;

// 🆕 FIX: Manifest V3 Service Worker Compatibility - SAFE CHECK
// خط 666 اصلاح شده:
if (typeof self !== 'undefined' && typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope) {
    self.SecureProgressIndicator = SecureProgressIndicator;
} else if (typeof window !== 'undefined') {
    // For content script environment
    window.SecureProgressIndicator = SecureProgressIndicator;
}