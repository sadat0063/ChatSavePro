// ============================================================
// modules/AdvancedStorageManager.js — QuantumStage v3.9 / R9.9.0‑Final
// ============================================================
// Secure Asynchronous Storage Layer with Auto-Healing Mechanism
// ============================================================

import GuardianIntegrity from "./GuardianIntegrity.js";

export class AdvancedStorageManager {
    static #instance = null;

    #guardian = null;
    #storage = null;
    #cache = new Map();
    #auditTrail = [];
    #config;

    constructor(config = {}) {
        if (AdvancedStorageManager.#instance) return AdvancedStorageManager.#instance;
        AdvancedStorageManager.#instance = this;

        this.#guardian = GuardianIntegrity.getInstance();
        this.#storage = typeof chrome !== 'undefined' && chrome.storage?.local
            ? chrome.storage.local
            : null;

        this.#config = Object.freeze({
            autoHeal: true,
            maxCacheSize: 1000,
            auditRetention: 1000,
            encryptionEnabled: false,
            namespace: config.namespace || 'default',
            ...config
        });

        console.log(`💾 AdvancedStorageManager initialized for [${this.#config.namespace}]`);
    }

    static getInstance(config) {
        return AdvancedStorageManager.#instance || new AdvancedStorageManager(config);
    }

    // 🆕 برای هماهنگی با سایر ماژول‌ها
    static create(config) {
        return AdvancedStorageManager.getInstance(config);
    }

    // ============================================================
    // CORE METHODS
    // ============================================================
    async setItem(key, value) {
        try {
            if (!key) throw new Error("Storage key is required");
            this.#validateKey(key);

            const record = {
                key,
                value,
                timestamp: Date.now(),
                namespace: this.#config.namespace
            };

            await this.#persistToStorage(record);
            this.#cache.set(key, record);
            this.#trimCacheIfNeeded();

            this.#logAudit("SET", key);
        } catch (error) {
            this.#guardian?.recordFailure("AdvancedStorageManager", error);
            console.error(`Storage setItem failed for key "${key}"`, error);
        }
    }

    async getItem(key) {
        try {
            this.#validateKey(key);

            if (this.#cache.has(key)) {
                return this.#cache.get(key).value;
            }

            const fromStorage = await this.#readFromStorage(key);
            if (fromStorage) {
                this.#cache.set(key, fromStorage);
                return fromStorage.value;
            }

            return null;
        } catch (error) {
            this.#guardian?.recordFailure("AdvancedStorageManager", error);
            console.error(`Storage getItem failed for key "${key}"`, error);
            return null;
        }
    }

    async removeItem(key) {
        try {
            this.#validateKey(key);

            await this.#removeFromStorage(key);
            this.#cache.delete(key);

            this.#logAudit("REMOVE", key);
        } catch (error) {
            this.#guardian?.recordFailure("AdvancedStorageManager", error);
            console.error(`Storage removeItem failed for key "${key}"`, error);
        }
    }

    async clear() {
        try {
            this.#cache.clear();
            await this.#clearAllStorage();
            this.#logAudit("CLEAR_ALL", "all");
        } catch (error) {
            this.#guardian?.recordFailure("AdvancedStorageManager", error);
            console.error("Storage clear failed", error);
        }
    }

    // ============================================================
    // INTERNAL STORAGE OPS
    // ============================================================
    #persistToStorage(record) {
        return new Promise((resolve, reject) => {
            if (!this.#storage) return resolve();

            const value = { [record.key]: record };
            this.#storage.set(value, () => {
                const err = chrome.runtime?.lastError;
                err ? reject(err) : resolve();
            });
        });
    }

    #readFromStorage(key) {
        return new Promise((resolve, reject) => {
            if (!this.#storage) return resolve(null);
            this.#storage.get([key], (result) => {
                const err = chrome.runtime?.lastError;
                if (err) {
                    reject(err);
                } else {
                    resolve(result[key]);
                }
            });
        });
    }

    #removeFromStorage(key) {
        return new Promise((resolve, reject) => {
            if (!this.#storage) return resolve();
            this.#storage.remove(key, () => {
                const err = chrome.runtime?.lastError;
                err ? reject(err) : resolve();
            });
        });
    }

    #clearAllStorage() {
        return new Promise((resolve, reject) => {
            if (!this.#storage) return resolve();
            this.#storage.clear(() => {
                const err = chrome.runtime?.lastError;
                err ? reject(err) : resolve();
            });
        });
    }

    // ============================================================
    // AUTO‑HEAL AND VALIDATION
    // ============================================================
    #validateKey(key) {
        if (typeof key !== "string" || key.trim() === "") {
            throw new Error("Invalid storage key");
        }
        if (key.includes("__proto__") || key.includes("constructor")) {
            throw new Error("Forbidden storage key");
        }
    }

    #trimCacheIfNeeded() {
        if (this.#cache.size > this.#config.maxCacheSize) {
            const excess = this.#cache.size - this.#config.maxCacheSize;
            const keys = Array.from(this.#cache.keys()).slice(0, excess);
            keys.forEach(k => this.#cache.delete(k));
        }
    }

    async heal() {
        if (!this.#config.autoHeal) return false;

        try {
            const health = await this.#guardian.healthCheck();
            if (health.status !== "healthy") {
                console.warn("⚠️ Storage subsystem detected unhealthy state. Healing...");
                await this.clear();
                return true;
            }
        } catch (error) {
            console.error("Auto‑heal failed", error);
        }

        return false;
    }

    // ============================================================
    // AUDIT TRAIL & LOGGING
    // ============================================================
    #logAudit(action, key) {
        const entry = {
            timestamp: new Date().toISOString(),
            action,
            key,
            namespace: this.#config.namespace
        };

        this.#auditTrail.push(entry);
        if (this.#auditTrail.length > this.#config.auditRetention) {
            this.#auditTrail.shift();
        }
    }

    getAuditTrail(limit = 50) {
        return this.#auditTrail.slice(-limit);
    }

    // ============================================================
    // UTILITIES
    // ============================================================
    async exportCacheAsJSON() {
        return JSON.stringify(Object.fromEntries(this.#cache));
    }

    async importCacheFromJSON(jsonString) {
        try {
            const obj = JSON.parse(jsonString);
            if (typeof obj !== "object") throw new Error("Invalid cache import format");

            for (const [k, v] of Object.entries(obj)) {
                this.#cache.set(k, v);
            }
            console.log(`✅ Cache imported (${Object.keys(obj).length} entries)`);
        } catch (err) {
            console.error("Cache import failed:", err);
        }
    }

    destroy() {
        this.#cache.clear();
        this.#auditTrail.length = 0;
        console.log("🧹 AdvancedStorageManager destroyed");
    }

    static get version() {
        return "R9.9.0‑Final";
    }
}

export default AdvancedStorageManager;
