// ============================================================
// SelectorDatabase.js - Central Selector Management
// ============================================================

class SelectorDatabase {
    constructor() {
        this.globalConfig = new Map();
        this.userReports = [];
        this.performanceMetrics = new Map();
    }

    async initialize() {
        await this.loadGlobalConfig();
        await this.loadUserReports();
        this.startSyncService();
    }

    async loadGlobalConfig() {
        try {
            const result = await chrome.storage.local.get(['globalSelectorConfig']);
            this.globalConfig = new Map(Object.entries(result.globalSelectorConfig || {}));
        } catch (error) {
            console.error('Failed to load global config:', error);
        }
    }

    async loadUserReports() {
        try {
            const result = await chrome.storage.local.get(['selectorUserReports']);
            this.userReports = result.selectorUserReports || [];
        } catch (error) {
            console.error('Failed to load user reports:', error);
        }
    }

    async reportBrokenSelector(platform, brokenSelector, workingSelector) {
        const report = {
            platform,
            brokenSelector,
            workingSelector,
            timestamp: Date.now(),
            userAgent: navigator.userAgent,
            url: window.location.href
        };

        this.userReports.push(report);
        await this.saveUserReports();

        // ارسال گزارش به سرور (اگر فعال باشد)
        await this.submitReportToServer(report);
    }

    async submitReportToServer(report) {
        // آینده: ارسال به سرور برای آنالیز جمعی
        console.log('📊 Selector report prepared:', report);
    }

    startSyncService() {
        // سینک دوره‌ای با سرور اصلی
        setInterval(async () => {
            await this.syncWithMasterDatabase();
        }, 24 * 60 * 60 * 1000); // روزی یکبار
    }

    async syncWithMasterDatabase() {
        // آینده: دریافت آپدیت‌ها از سرور اصلی
        console.log('🔄 Checking for selector updates...');
    }

    async saveUserReports() {
        try {
            await chrome.storage.local.set({ 
                selectorUserReports: this.userReports.slice(-100) // آخرین ۱۰۰ گزارش
            });
        } catch (error) {
            console.error('Failed to save user reports:', error);
        }
    }
}