// ============================================================
// IndexedDBManager.js - SecureDBManager (ES6 Module Singleton)
// ============================================================

export class SecureDBManager {
    // Singleton instance
    static _instance = null;

    constructor() {
        if (SecureDBManager._instance) return SecureDBManager._instance;

        this.dbName = 'ChatSaveProDB';
        this.dbVersion = 1;
        this.db = null;

        SecureDBManager._instance = this;
    }

    static getInstance() {
        if (!SecureDBManager._instance) {
            SecureDBManager._instance = new SecureDBManager();
        }
        return SecureDBManager._instance;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onupgradeneeded = (event) => {
                this.db = event.target.result;
                // Create object stores if they don't exist
                if (!this.db.objectStoreNames.contains('primary')) {
                    this.db.createObjectStore('primary', { keyPath: 'id', autoIncrement: true });
                }
                if (!this.db.objectStoreNames.contains('secondary')) {
                    this.db.createObjectStore('secondary', { keyPath: 'id', autoIncrement: true });
                }
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve(true);
            };

            request.onerror = (event) => {
                console.error('SecureDBManager init error:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    getTransaction(storeName, mode = 'readonly') {
        return this.db.transaction([storeName], mode).objectStore(storeName);
    }

    async addItem(storeName, item) {
        return new Promise((resolve, reject) => {
            const tx = this.getTransaction(storeName, 'readwrite');
            const request = tx.add(item);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this.getTransaction(storeName, 'readonly');
            const request = tx.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async clearStore(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this.getTransaction(storeName, 'readwrite');
            const request = tx.clear();
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    }
}
