// ============================================================
// modules/DeepScanCoordinator.js — QuantumStage v3.9 / R9.9.0‑Final
// 14 Principles Compliant - Enhanced Version - FIXED
// ============================================================

// ✅ PRINCIPLE 14: STATIC ES6 IMPORTS
import GuardianIntegrity from './GuardianIntegrity.js';
import Logger from './Logger.js';
import SecureStatsManager from './stats-manager.js';
import DeepScan from './DeepScan.js';
import InsightAnalyticsManager from './InsightAnalyticsManager.js';
import { ModuleLoadTracker } from './ModuleLoadTracker.js';

// ✅ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Validation schemas
const COORDINATOR_SCHEMAS = Object.freeze({
    SESSION_CREATION: Object.freeze({
        required: ['id', 'tab', 'options', 'createdAt'],
        tab: {
            required: ['id', 'url'],
            id: { type: 'number', min: 0 },
            url: { type: 'string', maxLength: 2000, pattern: /^https?:\/\// }
        },
        options: {
            maxSize: 10240, // 10KB
            allowedProperties: ['incremental', 'priority', 'filters', 'maxDepth', 'timeout']
        }
    }),
    SCAN_RESULT: Object.freeze({
        required: ['sessionId', 'items', 'timestamp'],
        sessionId: { type: 'string', pattern: /^session-\d+-\d+$/ },
        items: { type: 'array', maxLength: 10000 },
        timestamp: { type: 'number', min: 1609459200000 } // Sanity check
    }),
    HEALTH_REPORT: Object.freeze({
        required: ['version', 'status', 'timestamp'],
        maxSize: 102400 // 100KB
    })
});

// ✅ PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Enhanced retry configuration
const RETRY_CONFIG = Object.freeze({
    maxRetries: 3,
    baseDelay: 1000,
    maxDelay: 10000,
    backoff: 'exponential',
    jitter: 0.2,
    timeout: 30000
});

// ✅ PRINCIPLE 7: MEMORY SEGMENTATION - Memory manager
class CoordinatorMemoryManager {
    #segments = new Map();
    #cleanupInterval = null;

    constructor() {
        this.#initializeSegments();
        this.#startCleanupCycle();
    }

    #initializeSegments() {
        this.#segments.set('sessions', new Map());      // Active sessions
        this.#segments.set('results', new Map());       // Scan results
        this.#segments.set('cache', new Map());         // Temporary cache
        this.#segments.set('metrics', new Map());       // Performance metrics
        this.#segments.set('config', new Map());        // Configuration
    }

    #startCleanupCycle() {
        this.#cleanupInterval = setInterval(() => {
            this.#cleanupExpiredData();
        }, 30000); // Clean every 30 seconds
    }

    #cleanupExpiredData() {
        const now = Date.now();
        let cleanedCount = 0;

        // Clean old sessions (older than 1 hour)
        const sessions = this.#segments.get('sessions');
        for (const [sessionId, session] of sessions) {
            if (now - session.createdAt > 3600000) {
                sessions.delete(sessionId);
                this.#segments.get('results').delete(sessionId);
                cleanedCount++;
            }
        }

        // Clean old cache entries (older than 30 minutes)
        const cache = this.#segments.get('cache');
        for (const [key, entry] of cache) {
            if (now - entry.timestamp > 1800000) {
                cache.delete(key);
                cleanedCount++;
            }
        }

        if (cleanedCount > 0) {
            console.log(`🧹 [CoordinatorMemory] Cleaned ${cleanedCount} expired items`);
        }
    }

    setSession(sessionId, session) {
        this.#segments.get('sessions').set(sessionId, {
            ...session,
            lastAccessed: Date.now()
        });
    }

    getSession(sessionId) {
        const session = this.#segments.get('sessions').get(sessionId);
        if (session) {
            session.lastAccessed = Date.now();
        }
        return session;
    }

    setResult(sessionId, result) {
        this.#segments.get('results').set(sessionId, {
            result,
            timestamp: Date.now(),
            accessCount: 0
        });
    }

    getResult(sessionId) {
        const entry = this.#segments.get('results').get(sessionId);
        if (entry) {
            entry.accessCount++;
            return entry.result;
        }
        return null;
    }

    recordMetric(metricName, value, tags = {}) {
        const metrics = this.#segments.get('metrics');
        const timestamp = Date.now();
        const metricKey = `${metricName}_${timestamp}`;
        
        metrics.set(metricKey, {
            value,
            tags,
            timestamp
        });
    }

    getSegmentStats() {
        const stats = {};
        for (const [segmentName, segment] of this.#segments) {
            stats[segmentName] = {
                size: segment.size,
                sampleKeys: Array.from(segment.keys()).slice(0, 5)
            };
        }
        return stats;
    }

    destroy() {
        if (this.#cleanupInterval) {
            clearInterval(this.#cleanupInterval);
            this.#cleanupInterval = null;
        }
        this.#segments.clear();
    }
}

// ✅ PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Enhanced pipeline
class IncrementalScanPipeline {
    constructor(coordinator) {
        this.coordinator = coordinator;
    }

    async executeWithRetry(operation, operationName, config = RETRY_CONFIG) {
        let lastError;
        
        for (let attempt = 1; attempt <= config.maxRetries; attempt++) {
            try {
                const result = await this.#executeWithTimeout(
                    operation, 
                    config.timeout, 
                    operationName
                );
                
                // 🆕 FIX: Use safe audit logging
                this.#safeAuditLog('PIPELINE_SUCCESS', {
                    operation: operationName,
                    attempt,
                    duration: Date.now() - Date.now() // Simplified for now
                });
                
                return result;
            } catch (error) {
                lastError = error;
                
                // 🆕 FIX: Use safe audit logging
                this.#safeAuditLog('PIPELINE_RETRY', {
                    operation: operationName,
                    attempt,
                    error: error.message
                });
                
                if (attempt < config.maxRetries) {
                    const delay = this.#calculateBackoff(attempt, config);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        
        // 🆕 FIX: Use safe audit logging
        this.#safeAuditLog('PIPELINE_FAILED', {
            operation: operationName,
            attempts: config.maxRetries,
            error: lastError.message
        }, 'error');
        
        throw new Error(`Pipeline operation '${operationName}' failed after ${config.maxRetries} attempts: ${lastError.message}`);
    }

    async #executeWithTimeout(operation, timeout, operationName) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Operation '${operationName}' timeout after ${timeout}ms`));
            }, timeout);

            Promise.resolve(operation())
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }

    #calculateBackoff(attempt, config) {
        let delay;
        
        switch (config.backoff) {
            case 'exponential':
                delay = Math.min(config.baseDelay * Math.pow(2, attempt - 1), config.maxDelay);
                break;
            case 'linear':
                delay = Math.min(config.baseDelay * attempt, config.maxDelay);
                break;
            default:
                delay = config.baseDelay;
        }
        
        // Add jitter
        const jitter = delay * config.jitter * Math.random();
        return delay + jitter;
    }

    // 🆕 FIX: Safe audit logging to avoid private method access
    #safeAuditLog(eventType, data, level = 'info') {
        try {
            if (this.coordinator && typeof this.coordinator.logAudit === 'function') {
                this.coordinator.logAudit(eventType, data, level);
            } else {
                console.log(`[Audit][${level}] ${eventType}:`, data);
            }
        } catch (error) {
            console.warn('⚠️ Safe audit logging failed:', error.message);
        }
    }
}

// ✅ PRINCIPLE 8: MODULAR CLEANUP - Enhanced session management
class CoordinatorSessionManager {
    constructor(coordinator) {
        this.coordinator = coordinator;
    }

    createSession(id, tab, options) {
        const session = {
            id,
            tab: this.#sanitizeTab(tab),
            options: this.#sanitizeOptions(options),
            createdAt: Date.now(),
            status: 'active',
            attempts: 0,
            lastActivity: Date.now()
        };

        // Validate session
        this.#validateSession(session);

        // Store in memory manager
        this.coordinator.memoryManager.setSession(id, session);

        // 🆕 FIX: Use safe audit logging
        this.#safeAuditLog('SESSION_CREATED', {
            sessionId: id,
            tabId: tab.id,
            url: tab.url
        });

        return session;
    }

    #sanitizeTab(tab) {
        if (!tab || typeof tab !== 'object') {
            throw new Error('Invalid tab object');
        }

        return {
            id: tab.id || -1,
            url: (tab.url || '').substring(0, 2000),
            title: (tab.title || '').substring(0, 500),
            status: tab.status || 'unknown'
        };
    }

    #sanitizeOptions(options) {
        if (!options || typeof options !== 'object') {
            return {};
        }

        const sanitized = {};
        const allowedOptions = ['incremental', 'priority', 'filters', 'maxDepth', 'timeout', 'strategy'];

        for (const key of allowedOptions) {
            if (options[key] !== undefined) {
                if (typeof options[key] === 'string') {
                    sanitized[key] = options[key].substring(0, 1000);
                } else {
                    sanitized[key] = options[key];
                }
            }
        }

        return sanitized;
    }

    #validateSession(session) {
        const schema = COORDINATOR_SCHEMAS.SESSION_CREATION;

        // Check required fields
        for (const field of schema.required) {
            if (!(field in session)) {
                throw new Error(`Missing required session field: ${field}`);
            }
        }

        // Validate tab structure
        for (const field of schema.tab.required) {
            if (!(field in session.tab)) {
                throw new Error(`Missing required tab field: ${field}`);
            }
        }

        // Validate URL pattern
        if (!schema.tab.url.pattern.test(session.tab.url)) {
            throw new Error(`Invalid tab URL: ${session.tab.url}`);
        }

        // Validate options size
        const optionsSize = JSON.stringify(session.options).length;
        if (optionsSize > schema.options.maxSize) {
            throw new Error(`Options too large: ${optionsSize} > ${schema.options.maxSize}`);
        }
    }

    getSession(sessionId) {
        return this.coordinator.memoryManager.getSession(sessionId);
    }

    updateSession(sessionId, updates) {
        const session = this.getSession(sessionId);
        if (session) {
            const updatedSession = { ...session, ...updates, lastActivity: Date.now() };
            this.coordinator.memoryManager.setSession(sessionId, updatedSession);
            return updatedSession;
        }
        return null;
    }

    cleanupExpiredSessions(timeout) {
        const now = Date.now();
        let cleanedCount = 0;
        const sessions = this.coordinator.memoryManager.getSegmentStats().sessions.sampleKeys;

        for (const sessionId of sessions) {
            const session = this.getSession(sessionId);
            if (session && now - session.lastActivity > timeout) {
                this.coordinator.memoryManager.setSession(sessionId, {
                    ...session,
                    status: 'expired'
                });
                cleanedCount++;
            }
        }

        return cleanedCount;
    }

    getActiveSessions() {
        const active = [];
        const sessions = this.coordinator.memoryManager.getSegmentStats().sessions.sampleKeys;
        
        for (const sessionId of sessions) {
            const session = this.getSession(sessionId);
            if (session && session.status === 'active') {
                active.push(session);
            }
        }
        
        return active;
    }

    // 🆕 FIX: Safe audit logging
    #safeAuditLog(eventType, data, level = 'info') {
        try {
            if (this.coordinator && typeof this.coordinator.logAudit === 'function') {
                this.coordinator.logAudit(eventType, data, level);
            } else {
                console.log(`[SessionAudit][${level}] ${eventType}:`, data);
            }
        } catch (error) {
            console.warn('⚠️ Session audit logging failed:', error.message);
        }
    }
}

export class DeepScanCoordinator {
    static #instance = null;

    #guardian;
    logger;
    stats;
    analytics;
    pipeline;
    sessionManager;
    memoryManager;
    initialized = false;
    #auditLog = [];
    #maxAuditLogSize = 1000;

    constructor(config = {}) {
        if (DeepScanCoordinator.#instance) return DeepScanCoordinator.#instance;
        DeepScanCoordinator.#instance = this;

        this.MODULE_VERSION = 'R9.9.0‑Final';
        this.config = {
            strategy: 'incremental',
            cleanupInterval: 45000,
            sessionTimeout: 180000,
            maxConcurrentSessions: 5,
            enableQuantumResync: true,
            ...config
        };

        // ✅ PRINCIPLE 7: MEMORY SEGMENTATION - Initialize memory manager
        this.memoryManager = new CoordinatorMemoryManager();

        // Initialize core modules with fallbacks
        this.#initializeCoreModules();

        // ✅ PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Enhanced pipeline
        this.pipeline = new IncrementalScanPipeline(this);
        
        // ✅ PRINCIPLE 8: MODULAR CLEANUP - Enhanced session management
        this.sessionManager = new CoordinatorSessionManager(this);

        ModuleLoadTracker.registerModule('DeepScanCoordinator', 'background', 'DeepScanCoordinator.js');
        console.log('🧠 Enhanced DeepScanCoordinator created');
    }

    // 🆕 FIX: Initialize core modules with fallbacks
    #initializeCoreModules() {
        try {
            this.#guardian = GuardianIntegrity?.getInstance?.() || this.#createFallbackGuardian();
            this.logger = Logger?.getInstance?.() || this.#createFallbackLogger();
            this.stats = SecureStatsManager?.getInstance?.() || this.#createFallbackStats();
            this.analytics = InsightAnalyticsManager?.getInstance?.() || this.#createFallbackAnalytics();
        } catch (error) {
            console.warn('⚠️ Core module initialization failed, using fallbacks:', error.message);
            this.#initializeFallbackModules();
        }
    }

    // 🆕 FIX: Fallback module implementations
    #initializeFallbackModules() {
        this.#guardian = this.#createFallbackGuardian();
        this.logger = this.#createFallbackLogger();
        this.stats = this.#createFallbackStats();
        this.analytics = this.#createFallbackAnalytics();
    }

    #createFallbackGuardian() {
        return {
            recordFailure: (module, error) => {
                console.warn(`[FallbackGuardian] ${module} failure:`, error.message);
            },
            healthCheck: () => ({ status: 'fallback', integrity: 'degraded' })
        };
    }

    #createFallbackLogger() {
        return {
            log: (level, message, data) => {
                console.log(`[FallbackLogger][${level}] ${message}`, data || '');
            }
        };
    }

    #createFallbackStats() {
        return {
            record: (metric, data) => {
                console.log(`[FallbackStats] ${metric}:`, data);
            },
            getSummaryReport: () => ({ status: 'fallback', metrics: {} })
        };
    }

    #createFallbackAnalytics() {
        return {
            processIncrementalResult: async (session, result) => {
                console.log('[FallbackAnalytics] Processing result:', { 
                    sessionId: session.id, 
                    items: result.length 
                });
                return result;
            },
            getSummary: async () => ({ status: 'fallback', data: {} }),
            recordSync: async (data) => {
                console.log('[FallbackAnalytics] Sync recorded:', data);
            }
        };
    }

    static getInstance(config = {}) {
        return DeepScanCoordinator.#instance || new DeepScanCoordinator(config);
    }

    // ============================================================
    // 🆕 CRITICAL FIX: ADD MISSING startDeepScan METHOD
    // ============================================================
    async startDeepScan(tabId) {
        try {
            console.log('🔍 [DeepScanCoordinator] Starting deep scan for tab:', tabId);

            if (!this.initialized) {
                await this.init();
            }

            // Create tab object from tabId
            const tab = {
                id: tabId,
                url: `tab://${tabId}`, // Fallback URL
                title: 'Deep Scan Tab',
                status: 'active'
            };

            // Use existing incremental scan with deep scan options
            const result = await this.executeIncrementalScan(tab, {
                strategy: 'deep',
                maxDepth: 10,
                timeout: 45000,
                priority: 'high'
            });

            this.logAudit('DEEP_SCAN_COMPLETED', {
                tabId: tabId,
                sessionId: result.sessionId,
                itemsScanned: result.items?.length || 0
            });

            return {
                success: true,
                sessionId: result.sessionId,
                scannedItems: result.items?.length || 0,
                tabId: tabId,
                completedAt: Date.now()
            };

        } catch (error) {
            console.error('❌ Deep scan failed:', error);
            
            this.logAudit('DEEP_SCAN_FAILED', {
                tabId: tabId,
                error: error.message
            }, 'error');

            return {
                success: false,
                error: error.message,
                tabId: tabId,
                failedAt: Date.now()
            };
        }
    }

    // ============================================================
    // INITIALIZATION WITH ENHANCED ERROR HANDLING
    // ============================================================
    async init() {
        if (this.initialized) return true;

        try {
            this.logAudit('INITIALIZATION_STARTED', {
                version: this.MODULE_VERSION,
                config: Object.keys(this.config)
            });

            await this.#loadConfiguration();
            this.#startCleanupInterval();
            await this.#verifyDependencies();

            this.initialized = true;

            this.logAudit('INITIALIZATION_COMPLETED', {
                version: this.MODULE_VERSION
            });

            this.logger.log('INFO', 'Enhanced Coordinator initialized', {
                version: this.MODULE_VERSION,
                config: this.config
            });

            return true;
        } catch (error) {
            this.logAudit('INITIALIZATION_FAILED', {
                error: error.message,
                stack: error.stack?.substring(0, 500)
            }, 'error');

            this.logger.log('ERROR', 'Coordinator initialization failed', {
                error: error.message
            });
            
            this.#guardian.recordFailure('DeepScanCoordinator', error);
            throw error;
        }
    }

    async #loadConfiguration() {
        return new Promise((resolve, reject) => {
            try {
                chrome.storage.local.get(
                    ['coordinatorConfig', 'maxConcurrentSessions', 'sessionTimeout'],
                    (result) => {
                        if (chrome.runtime.lastError) {
                            this.logAudit('CONFIG_LOAD_FAILED', {
                                error: chrome.runtime.lastError.message
                            }, 'warn');
                            // Continue with defaults
                            resolve();
                        } else if (result.coordinatorConfig) {
                            this.config = { ...this.config, ...result.coordinatorConfig };
                            this.logAudit('CONFIG_LOADED', {
                                keys: Object.keys(result.coordinatorConfig)
                            });
                            resolve();
                        } else {
                            resolve();
                        }
                    }
                );
            } catch (error) {
                this.logAudit('CONFIG_LOAD_ERROR', {
                    error: error.message
                }, 'error');
                reject(error);
            }
        });
    }

    async #verifyDependencies() {
        const dependencies = [
            { name: 'GuardianIntegrity', instance: this.#guardian },
            { name: 'Logger', instance: this.logger },
            { name: 'SecureStatsManager', instance: this.stats },
            { name: 'InsightAnalyticsManager', instance: this.analytics }
        ];

        for (const dep of dependencies) {
            if (!dep.instance) {
                throw new Error(`Missing dependency: ${dep.name}`);
            }
        }

        this.logAudit('DEPENDENCIES_VERIFIED', {
            dependencies: dependencies.map(d => d.name)
        });
    }

    #startCleanupInterval() {
        if (typeof setInterval !== 'undefined') {
            setInterval(() => this.#cleanupExpiredSessions(), this.config.cleanupInterval);
            
            // ✅ PRINCIPLE 11: QUANTUM RESYNC - Periodic sync
            if (this.config.enableQuantumResync) {
                setInterval(() => this.#syncWithBackground(), 60000); // Sync every minute
            }
        }
    }

    #cleanupExpiredSessions() {
        try {
            const cleaned = this.sessionManager.cleanupExpiredSessions(this.config.sessionTimeout);
            if (cleaned > 0) {
                this.logAudit('SESSIONS_CLEANED', { count: cleaned });
                this.logger.log('INFO', 'Expired sessions cleaned', { count: cleaned });
            }
        } catch (error) {
            this.logAudit('CLEANUP_ERROR', { error: error.message }, 'error');
        }
    }

    // ✅ PRINCIPLE 11: QUANTUM RESYNC - Background synchronization
    async #syncWithBackground() {
        try {
            this.logAudit('BACKGROUND_SYNC_STARTED', {});
            
            const syncData = {
                activeSessions: this.sessionManager.getActiveSessions().length,
                memoryStats: this.memoryManager.getSegmentStats(),
                timestamp: Date.now(),
                version: this.MODULE_VERSION
            };

            // Emit sync event if analytics supports it
            if (this.analytics && typeof this.analytics.recordSync === 'function') {
                await this.analytics.recordSync(syncData);
            }

            this.logAudit('BACKGROUND_SYNC_COMPLETED', {
                activeSessions: syncData.activeSessions
            });
        } catch (error) {
            this.logAudit('BACKGROUND_SYNC_FAILED', { error: error.message }, 'error');
        }
    }

    // ✅ PRINCIPLE 12: SECURE LOGGING - Audit trail (NOW PUBLIC)
    logAudit(eventType, data, level = 'info') {
        try {
            const auditEntry = {
                id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                timestamp: Date.now(),
                event: eventType,
                data: this.#sanitizeAuditData(data),
                level: level,
                version: this.MODULE_VERSION
            };

            this.#auditLog.push(auditEntry);

            // Maintain log size
            if (this.#auditLog.length > this.#maxAuditLogSize) {
                this.#auditLog.shift();
            }
        } catch (error) {
            console.warn('⚠️ Audit logging failed:', error.message);
        }
    }

    #sanitizeAuditData(data) {
        if (typeof data !== 'object' || data === null) {
            return typeof data === 'string' ? data.substring(0, 1000) : data;
        }

        const sanitized = {};
        const forbiddenKeys = ['__proto__', 'constructor', 'prototype', 'password', 'token', 'key'];

        for (const [key, value] of Object.entries(data)) {
            if (forbiddenKeys.includes(key)) {
                sanitized[key] = '***REDACTED***';
                continue;
            }

            if (typeof value === 'string') {
                sanitized[key] = value.substring(0, 1000).replace(/[<>]/g, '');
            } else if (typeof value === 'object' && value !== null) {
                sanitized[key] = this.#sanitizeAuditData(value);
            } else {
                sanitized[key] = value;
            }
        }

        return sanitized;
    }

    // ============================================================
    // ENHANCED VALIDATION LAYERS
    // ============================================================
    #validateScanStart(tab) {
        if (!tab || typeof tab !== 'object') {
            throw new Error('Invalid tab information for scan start');
        }

        if (!tab.id || typeof tab.id !== 'number' || tab.id < 0) {
            throw new Error('Invalid tab ID');
        }

        if (!tab.url || typeof tab.url !== 'string') {
            throw new Error('Invalid tab URL');
        }

        if (!tab.url.startsWith('http')) {
            throw new Error('Unsupported URL protocol');
        }
    }

    #validateIncrementalResult(result) {
        const schema = COORDINATOR_SCHEMAS.SCAN_RESULT;

        // Check required fields
        for (const field of schema.required) {
            if (!(field in result)) {
                throw new Error(`Invalid incremental result, missing: ${field}`);
            }
        }

        // Validate session ID pattern
        if (!schema.sessionId.pattern.test(result.sessionId)) {
            throw new Error(`Invalid session ID format: ${result.sessionId}`);
        }

        // Validate items array
        if (!Array.isArray(result.items)) {
            throw new Error('Items must be an array');
        }

        if (result.items.length > schema.items.maxLength) {
            throw new Error(`Too many items: ${result.items.length} > ${schema.items.maxLength}`);
        }

        // Validate timestamp
        if (result.timestamp < schema.timestamp.min) {
            throw new Error(`Invalid timestamp: ${result.timestamp}`);
        }
    }

    // ============================================================
    // ENHANCED MAIN EXECUTION PATH
    // ============================================================
    async executeIncrementalScan(tab, options = {}) {
        if (!this.initialized) {
            throw new Error('Coordinator not initialized — call init() first.');
        }

        const sessionId = this.#generateSessionId();
        
        this.logAudit('SCAN_INITIATED', { 
            tabId: tab.id, 
            sessionId,
            url: tab.url 
        });

        this.logger.log('INFO', 'Incremental scan initiated', { 
            tabId: tab.id, 
            sessionId 
        });

        try {
            // Enhanced validation
            this.#validateScanStart(tab);
            
            const session = this.sessionManager.createSession(sessionId, tab, options);
            
            // Execute with enhanced retry mechanism
            const incrementalResult = await this.pipeline.executeWithRetry(
                async () => {
                    const deepScan = await DeepScan.create({ incrementalEnabled: true });
                    return await deepScan.incrementalScan(tab.url);
                },
                `incremental_scan_${sessionId}`,
                {
                    ...RETRY_CONFIG,
                    timeout: options.timeout || RETRY_CONFIG.timeout
                }
            );

            // Validate result
            const validatedResult = {
                sessionId,
                items: incrementalResult,
                timestamp: Date.now()
            };
            this.#validateIncrementalResult(validatedResult);

            // Process with analytics
            const processed = await this.analytics.processIncrementalResult(session, incrementalResult);

            // Store result with enhanced memory management
            this.memoryManager.setResult(sessionId, processed);
            this.memoryManager.recordMetric('scan_completed', processed.length, {
                sessionId,
                tabId: tab.id
            });

            // === PATCH: Forward DeepScan results to background.js ===
            chrome.runtime.sendMessage({
                type: "DEEP_SCAN_RESULTS",
                sessionId,
                items: processed,
                timestamp: Date.now()
            });

            this.stats.record('scans', { 
                items: processed.length,
                sessionId 
            });

            // Update session status
            this.sessionManager.updateSession(sessionId, {
                status: 'completed',
                resultCount: processed.length,
                completedAt: Date.now()
            });

            this.logAudit('SCAN_COMPLETED', {
                sessionId,
                itemsProcessed: processed.length,
                duration: Date.now() - session.createdAt
            });

            this.logger.log('SUCCESS', 'Incremental scan completed', {
                sessionId,
                total: processed.length
            });

            return validatedResult;
        } catch (error) {
            // Update session with error
            this.sessionManager.updateSession(sessionId, {
                status: 'failed',
                error: error.message,
                failedAt: Date.now()
            });

            this.logAudit('SCAN_FAILED', {
                sessionId,
                error: error.message,
                tabId: tab.id
            }, 'error');

            this.logger.log('ERROR', 'Incremental scan failed', { 
                error: error.message,
                sessionId 
            });
            
            this.#guardian.recordFailure('DeepScanCoordinator', error);
            throw error;
        }
    }

    #generateSessionId() {
        return `session-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    }

    getCachedResults(sessionId) {
        return this.memoryManager.getResult(sessionId) || [];
    }

    purgeCache() {
        this.memoryManager.destroy();
        this.memoryManager = new CoordinatorMemoryManager();
        
        this.logAudit('CACHE_PURGED', {});
        this.logger.log('INFO', 'Result cache purged');
    }

    // ============================================================
    // ENHANCED HEALTH & REPORTS
    // ============================================================
    async getHealthReport() {
        try {
            const report = {
                version: this.MODULE_VERSION,
                initialized: this.initialized,
                sessions: {
                    active: this.sessionManager.getActiveSessions().length,
                    total: this.memoryManager.getSegmentStats().sessions.size
                },
                memory: this.memoryManager.getSegmentStats(),
                analytics: await this.analytics?.getSummary?.(),
                stats: this.stats.getSummaryReport(),
                guardian: this.#guardian.healthCheck(),
                audit: {
                    totalEntries: this.#auditLog.length,
                    recentEvents: this.#auditLog.slice(-5).map(e => e.event)
                },
                timestamp: Date.now(),
                status: 'healthy'
            };

            // Validate report structure
            this.#validateHealthReport(report);

            return Object.freeze(report);
        } catch (error) {
            this.logAudit('HEALTH_REPORT_FAILED', { error: error.message }, 'error');
            return {
                version: this.MODULE_VERSION,
                status: 'error',
                error: error.message,
                timestamp: Date.now()
            };
        }
    }

    #validateHealthReport(report) {
        const schema = COORDINATOR_SCHEMAS.HEALTH_REPORT;

        for (const field of schema.required) {
            if (!(field in report)) {
                throw new Error(`Missing required health report field: ${field}`);
            }
        }

        const reportSize = JSON.stringify(report).length;
        if (reportSize > schema.maxSize) {
            throw new Error(`Health report too large: ${reportSize} > ${schema.maxSize}`);
        }
    }

    getAuditTrail(limit = 100, level = null) {
        let events = this.#auditLog;
        if (level) {
            events = events.filter(entry => entry.level === level);
        }
        return events.slice(-limit).map(entry => Object.freeze({ ...entry }));
    }

    // ✅ PRINCIPLE 8: MODULAR CLEANUP - Enhanced destruction
    async destroy() {
        try {
            this.logAudit('DESTRUCTION_STARTED', {});

            // Cleanup memory manager
            this.memoryManager.destroy();

            // Clear audit log
            this.#auditLog = [];

            // Reset state
            this.initialized = false;

            this.logAudit('DESTRUCTION_COMPLETED', {});
            this.logger.log('INFO', 'Enhanced DeepScanCoordinator destroyed');
        } catch (error) {
            this.logAudit('DESTRUCTION_FAILED', { error: error.message }, 'error');
            throw error;
        }
    }
}

export default DeepScanCoordinator;
console.log('✅ Enhanced DeepScanCoordinator loaded successfully');