// modules/audio-feedback.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles 10 & 11 + Manifest V3
// ============================================================

// 🛡️ اصل ۱۱: Inter-Module Integrity - Immutable schemas
export const FEEDBACK_SCHEMA = Object.freeze({
    scanStart: Object.freeze({ type: 'string', required: true }),
    scanComplete: Object.freeze({ type: 'string', required: true }),
    exportSuccess: Object.freeze({ type: 'string', required: true }),
    error: Object.freeze({ type: 'string', required: true }),
    buttonClick: Object.freeze({ type: 'string', required: true }),
    notification: Object.freeze({ type: 'string', required: true })
});

// 🛡️ اصل ۱۰: Audit & Traceability - Secure logging configuration
export const SECURE_LOGGING = Object.freeze({
    maxLogSize: 100,
    sanitize: (data) => {
        if (typeof data !== 'string') return JSON.stringify(data);
        return data.replace(/[<>]/g, '');
    }
});

// 🛡️ اصل ۴: Enhanced Engine Abstraction
class AudioEngine {
    constructor() {
        this.context = null;
        this.oscillators = new Set();
        this.metrics = new Map();
    }

    async initialize() {
        try {
            this.context = new (window.AudioContext || window.webkitAudioContext)();
            if (this.context.state === 'suspended') {
                await this.context.resume();
            }
            
            this.metrics.set('initializedAt', Date.now());
            this.metrics.set('oscillatorsCreated', 0);
            this.metrics.set('oscillatorsCleaned', 0);
            
            return true;
        } catch (error) {
            throw new Error(`AudioEngine initialization failed: ${error.message}`);
        }
    }

    createOscillator() {
        if (!this.context) throw new Error('Audio context not initialized');
        
        const oscillator = this.context.createOscillator();
        const gainNode = this.context.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.context.destination);
        
        // 🛡️ اصل ۵: Memory Segmentation
        oscillator._metadata = Object.freeze({
            createdAt: Date.now(),
            id: `osc_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`
        });
        
        this.oscillators.add(oscillator);
        this.metrics.set('oscillatorsCreated', (this.metrics.get('oscillatorsCreated') || 0) + 1);

        oscillator.onended = () => {
            this.oscillators.delete(oscillator);
            this.metrics.set('oscillatorsCleaned', (this.metrics.get('oscillatorsCleaned') || 0) + 1);
            gainNode.disconnect();
        };

        return Object.freeze({ oscillator, gainNode });
    }

    // 🛡️ اصل ۱۰: Audit & Traceability
    getMetrics() {
        return Object.freeze({
            contextState: this.context?.state || 'not_initialized',
            activeOscillators: this.oscillators.size,
            totalOscillatorsCreated: this.metrics.get('oscillatorsCreated') || 0,
            totalOscillatorsCleaned: this.metrics.get('oscillatorsCleaned') || 0,
            uptime: this.metrics.get('initializedAt') ? Date.now() - this.metrics.get('initializedAt') : 0
        });
    }

    cleanup() {
        this.oscillators.forEach(osc => {
            try {
                osc.stop();
                osc.disconnect();
            } catch (e) {
                // Already stopped
            }
        });
        this.oscillators.clear();
        
        if (this.context) {
            this.context.close();
        }
    }
}

// 🛡️ اصل ۳: Lazy Loading & Performance
class FeedbackQueue {
    constructor() {
        this.tasks = [];
        this.isProcessing = false;
        this.maxQueueSize = 15;
        this.throttleDelay = 50;
        this.metrics = new Map();
    }

    async enqueue(operation) {
        return new Promise((resolve, reject) => {
            const task = Object.freeze({
                id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
                operation,
                resolve,
                reject,
                timestamp: Date.now()
            });

            this.tasks.push(task);

            // 🛡️ اصل ۷: Async Pipeline & Resilience
            if (this.tasks.length > this.maxQueueSize) {
                const removed = this.tasks.shift();
                console.warn('[FeedbackQueue] Queue overflow, removed task:', removed.id);
            }

            if (!this.isProcessing) {
                this.process();
            }
        });
    }

    async process() {
        if (this.isProcessing) return;
        this.isProcessing = true;

        try {
            while (this.tasks.length > 0) {
                const task = this.tasks.shift();
                
                try {
                    const result = await task.operation();
                    task.resolve(result);
                } catch (error) {
                    task.reject(error);
                }

                if (this.tasks.length > 0) {
                    await new Promise(resolve => 
                        setTimeout(resolve, this.throttleDelay)
                    );
                }
            }
        } finally {
            this.isProcessing = false;
        }
    }

    // 🛡️ اصل ۱۰: Audit & Traceability
    getMetrics() {
        return Object.freeze({
            queueSize: this.tasks.length,
            isProcessing: this.isProcessing,
            maxQueueSize: this.maxQueueSize,
            throttleDelay: this.throttleDelay
        });
    }

    clear() {
        this.tasks = [];
    }
}

// 🛡️ اصل ۱۰: Audit & Traceability
class AuditLogger {
    constructor() {
        this.logs = [];
        this.maxLogs = SECURE_LOGGING.maxLogSize;
        this.startupTime = Date.now();
    }

    log(event, data = {}) {
        const auditEntry = Object.freeze({
            id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            event: SECURE_LOGGING.sanitize(event),
            data: SECURE_LOGGING.sanitize(data),
            context: 'audio-feedback'
        });

        this.logs.push(auditEntry);

        // Maintain log size
        if (this.logs.length > this.maxLogs) {
            this.logs = this.logs.slice(-this.maxLogs);
        }

        return auditEntry;
    }

    getLogs(limit = 10) {
        return Object.freeze(this.logs.slice(-limit));
    }

    // 🛡️ اصل ۱۰: Audit & Traceability
    getMetrics() {
        return Object.freeze({
            totalLogs: this.logs.length,
            maxLogSize: this.maxLogs,
            oldestLog: this.logs[0]?.timestamp || null,
            newestLog: this.logs[this.logs.length - 1]?.timestamp || null,
            uptime: Date.now() - this.startupTime
        });
    }
}

// 🛡️ Main ES6 Module Class با اصول ۱۰ و ۱۱
export class AudioFeedbackManager {
    constructor() {
        // 🛡️ اصل ۱۱: Inter-Module Integrity - Immutable constants
        this.MODULE_VERSION = Object.freeze("3.0.0-guardian");
        this.MODULE_NAME = Object.freeze("AudioFeedbackManager");
        
        // 🛡️ اصل ۱: Context Isolation
        this.audioEngine = new AudioEngine();
        this.feedbackQueue = new FeedbackQueue();
        this.auditLogger = new AuditLogger();
        
        // 🛡️ اصل ۸: Minimal Permissions
        this.permissions = Object.freeze({
            audio: false,
            haptic: false,
            storage: false
        });
        
        // 🛡️ Law 2: No Remote Code Execution
        this.soundPresets = Object.freeze(this.#getLocalPresets());
        
        // 🛡️ اصل ۱۰: Audit & Traceability - Enhanced monitoring
        this.monitoring = new Map();
        this.monitoring.set('totalFeedback', 0);
        this.monitoring.set('errors', 0);
        this.monitoring.set('averageLatency', 0);
        this.monitoring.set('startupTime', Date.now());
        this.monitoring.set('lastActivity', Date.now());
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity - Controlled initialization
    static async init(config = {}) {
        const instance = new AudioFeedbackManager();
        await instance._initialize(config);
        
        // فریز کردن برای اصل ۱۱
        Object.freeze(instance.soundPresets);
        
        console.log('✅ AudioFeedbackManager ES6 Module loaded successfully');
        return instance;
    }

    async _initialize(config = {}) {
        try {
            await this.#validateEnvironment();
            await this.#loadPermissions();
            
            if (this.permissions.audio) {
                await this.audioEngine.initialize();
            }
            
            this.auditLogger.log('MODULE_INITIALIZED', {
                version: this.MODULE_VERSION,
                permissions: this.permissions,
                config: config
            });
            
            return this;
            
        } catch (error) {
            this.auditLogger.log('INITIALIZATION_FAILED', { error: error.message });
            this.monitoring.set('errors', (this.monitoring.get('errors') || 0) + 1);
            throw error;
        }
    }

    async #validateEnvironment() {
        if (typeof window === 'undefined') {
            throw new Error('Module requires browser environment');
        }

        if (!window.AudioContext && !window.webkitAudioContext) {
            throw new Error('Web Audio API not supported');
        }

        if (!navigator.vibrate) {
            console.warn('Vibration API not supported');
        }
    }

    async #loadPermissions() {
        return new Promise((resolve) => {
            chrome.storage.local.get([
                'audioEnabled', 
                'hapticEnabled'
            ], (result) => {
                const permissions = {
                    audio: result.audioEnabled !== false,
                    haptic: result.hapticEnabled !== false,
                    storage: true
                };
                
                // 🛡️ اصل ۱۱: Inter-Module Integrity - Freeze permissions
                this.permissions = Object.freeze(permissions);
                resolve();
            });
        });
    }

    #getLocalPresets() {
        return {
            scanStart: Object.freeze({
                type: 'beep',
                frequency: [400, 600],
                duration: 0.2,
                volume: 0.1,
                haptic: 50
            }),
            scanComplete: Object.freeze({
                type: 'beep',
                frequency: [600, 300],
                duration: 0.3,
                volume: 0.1,
                haptic: 100
            }),
            exportSuccess: Object.freeze({
                type: 'chime',
                frequencies: [523.25, 659.25, 783.99, 1046.50],
                times: [0, 0.1, 0.2, 0.3],
                duration: 0.2,
                volume: 0.15,
                haptic: 150
            }),
            error: Object.freeze({
                type: 'beep',
                frequency: [300, 150],
                duration: 0.4,
                volume: 0.1,
                haptic: 200
            }),
            buttonClick: Object.freeze({
                type: 'click',
                frequency: [200, 100],
                duration: 0.05,
                volume: 0.1,
                haptic: 30
            }),
            notification: Object.freeze({
                type: 'beep',
                frequency: [800, 600],
                duration: 0.15,
                volume: 0.08,
                haptic: 75
            })
        };
    }

    // 🛡️ اصل ۲: Strict Interface Contract
    #validateFeedbackType(type) {
        if (!FEEDBACK_SCHEMA[type]) {
            throw new Error(`Invalid feedback type: ${type}`);
        }
        return true;
    }

    // 🛡️ Public API با queue management
    async playScanStart() {
        return this.#playFeedback('scanStart');
    }

    async playScanComplete() {
        return this.#playFeedback('scanComplete');
    }

    async playExportSuccess() {
        return this.#playFeedback('exportSuccess');
    }

    async playErrorSound() {
        return this.#playFeedback('error');
    }

    async playButtonClick() {
        return this.#playFeedback('buttonClick');
    }

    async playNotification() {
        return this.#playFeedback('notification');
    }

    async #playFeedback(type) {
        this.#validateFeedbackType(type);
        
        const startTime = performance.now();
        this.monitoring.set('lastActivity', Date.now());
        
        return this.feedbackQueue.enqueue(async () => {
            try {
                const currentTotal = this.monitoring.get('totalFeedback') || 0;
                this.monitoring.set('totalFeedback', currentTotal + 1);
                
                await this.#playSound(type);
                await this.#vibrate(type);
                
                const latency = performance.now() - startTime;
                const currentAvg = this.monitoring.get('averageLatency') || 0;
                const newAvg = (currentAvg * currentTotal + latency) / (currentTotal + 1);
                this.monitoring.set('averageLatency', newAvg);
                
                this.auditLogger.log('FEEDBACK_PLAYED', {
                    type,
                    latency,
                    permissions: this.permissions
                });
                
            } catch (error) {
                const currentErrors = this.monitoring.get('errors') || 0;
                this.monitoring.set('errors', currentErrors + 1);
                
                this.auditLogger.log('FEEDBACK_ERROR', {
                    type,
                    error: error.message
                });
                throw error;
            }
        });
    }

    async #playSound(presetName) {
        if (!this.permissions.audio) return;
        
        const preset = this.soundPresets[presetName];
        if (!preset) throw new Error(`Preset not found: ${presetName}`);

        switch (preset.type) {
            case 'beep':
                return this.#playBeep(preset);
            case 'chime':
                return this.#playChime(preset);
            case 'click':
                return this.#playClick(preset);
            default:
                throw new Error(`Unknown sound type: ${preset.type}`);
        }
    }

    async #playBeep(preset) {
        const { oscillator, gainNode } = this.audioEngine.createOscillator();
        
        return new Promise((resolve) => {
            oscillator.frequency.setValueAtTime(preset.frequency[0], this.audioEngine.context.currentTime);
            oscillator.frequency.exponentialRampToValueAtTime(preset.frequency[1], 
                this.audioEngine.context.currentTime + preset.duration);
            
            gainNode.gain.setValueAtTime(preset.volume, this.audioEngine.context.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.001, 
                this.audioEngine.context.currentTime + preset.duration);
            
            oscillator.onended = resolve;
            oscillator.start();
            oscillator.stop(this.audioEngine.context.currentTime + preset.duration);
        });
    }

    async #playChime(preset) {
        const promises = preset.times.map((time, index) => 
            new Promise((resolve) => {
                const { oscillator, gainNode } = this.audioEngine.createOscillator();
                
                oscillator.frequency.setValueAtTime(preset.frequencies[index], 
                    this.audioEngine.context.currentTime + time);
                
                gainNode.gain.setValueAtTime(preset.volume, 
                    this.audioEngine.context.currentTime + time);
                gainNode.gain.exponentialRampToValueAtTime(0.001, 
                    this.audioEngine.context.currentTime + time + preset.duration);
                
                oscillator.onended = resolve;
                oscillator.start(this.audioEngine.context.currentTime + time);
                oscillator.stop(this.audioEngine.context.currentTime + time + preset.duration);
            })
        );
        
        return Promise.all(promises);
    }

    async #playClick(preset) {
        return this.#playBeep(preset);
    }

    async #vibrate(presetName) {
        if (!this.permissions.haptic) return;
        
        const preset = this.soundPresets[presetName];
        if (preset && preset.haptic) {
            navigator.vibrate(preset.haptic);
        }
    }

    // 🛡️ اصل ۶: Deterministic State Recovery
    async reset() {
        this.feedbackQueue.clear();
        this.audioEngine.cleanup();
        
        this.monitoring.set('totalFeedback', 0);
        this.monitoring.set('errors', 0);
        this.monitoring.set('averageLatency', 0);
        this.monitoring.set('lastActivity', Date.now());
        
        if (this.permissions.audio) {
            await this.audioEngine.initialize();
        }
        
        this.auditLogger.log('MODULE_RESET', {
            version: this.MODULE_VERSION
        });
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Comprehensive metrics
    getMetrics() {
        const totalFeedback = this.monitoring.get('totalFeedback') || 0;
        const errors = this.monitoring.get('errors') || 0;
        const successRate = totalFeedback > 0 ? 
            ((totalFeedback - errors) / totalFeedback) * 100 : 100;

        return Object.freeze({
            system: Object.freeze({
                version: this.MODULE_VERSION,
                name: this.MODULE_NAME,
                uptime: Date.now() - (this.monitoring.get('startupTime') || Date.now()),
                isInitialized: true,
                healthScore: this._calculateHealthScore()
            }),
            performance: Object.freeze({
                totalFeedback: totalFeedback,
                errors: errors,
                successRate: Math.round(successRate) + '%',
                averageLatency: Math.round(this.monitoring.get('averageLatency') || 0),
                lastActivity: this.monitoring.get('lastActivity')
            }),
            resources: Object.freeze({
                permissions: { ...this.permissions },
                audioEngine: this.audioEngine.getMetrics(),
                feedbackQueue: this.feedbackQueue.getMetrics(),
                auditLogger: this.auditLogger.getMetrics()
            }),
            capabilities: Object.freeze({
                availablePresets: Object.keys(this.soundPresets),
                totalPresets: Object.keys(this.soundPresets).length,
                audioSupported: !!(window.AudioContext || window.webkitAudioContext),
                hapticSupported: !!navigator.vibrate
            })
        });
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Health monitoring
    _calculateHealthScore() {
        let score = 100;
        
        const errors = this.monitoring.get('errors') || 0;
        const totalFeedback = this.monitoring.get('totalFeedback') || 0;
        
        // کسر برای خطاها
        if (errors > 0) {
            score -= Math.min(40, errors * 10);
        }
        
        // کسر برای نرخ موفقیت پایین
        if (totalFeedback > 0) {
            const successRate = (totalFeedback - errors) / totalFeedback;
            if (successRate < 0.8) {
                score -= 20;
            }
        }
        
        // کسر برای تاخیر بالا
        const avgLatency = this.monitoring.get('averageLatency') || 0;
        if (avgLatency > 500) {
            score -= 15;
        }
        
        return Math.max(0, Math.round(score));
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Integrity check
    async runIntegrityCheck() {
        const testResults = {
            timestamp: Date.now(),
            passed: true,
            checks: {}
        };
        
        try {
            // بررسی اولیه
            testResults.checks.initialization = this.monitoring.get('startupTime') > 0;
            testResults.checks.metricsAvailable = typeof this.getMetrics === 'function';
            testResults.checks.presetsFrozen = Object.isFrozen(this.soundPresets);
            
            // بررسی عملکرد
            const metrics = this.getMetrics();
            testResults.checks.metricsStructure = 
                metrics.system && metrics.performance && metrics.resources;
            testResults.checks.healthScore = metrics.system.healthScore >= 0;
            
            // بررسی قابلیت‌ها
            testResults.checks.audioEngine = this.audioEngine.getMetrics().contextState !== 'not_initialized';
            testResults.checks.feedbackQueue = this.feedbackQueue.getMetrics().maxQueueSize === 15;
            
            testResults.passed = Object.values(testResults.checks).every(check => check === true);
            
            this.auditLogger.log('INTEGRITY_CHECK_COMPLETED', testResults);
            return Object.freeze(testResults);
            
        } catch (error) {
            this.auditLogger.log('INTEGRITY_CHECK_FAILED', { error: error.message });
            testResults.passed = false;
            testResults.error = error.message;
            return Object.freeze(testResults);
        }
    }

    getAuditLogs(limit = 10) {
        return this.auditLogger.getLogs(limit);
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity - Safe destruction
    async destroy() {
        this.feedbackQueue.clear();
        this.audioEngine.cleanup();
        
        const finalMetrics = this.getMetrics();
        
        this.auditLogger.log('MODULE_DESTROYED', {
            finalMetrics: finalMetrics.performance,
            totalUptime: finalMetrics.system.uptime,
            finalHealthScore: finalMetrics.system.healthScore
        });

        return Object.freeze({
            destroyed: true,
            timestamp: Date.now(),
            finalMetrics: finalMetrics
        });
    }
}

// 🛡️ اصل ۱۱: Inter-Module Integrity - Freeze prototype
Object.freeze(AudioFeedbackManager.prototype);
Object.freeze(AudioFeedbackManager);

export default AudioFeedbackManager;