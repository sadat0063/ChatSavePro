// ============================================================
// modules/Logger.js — QuantumStage v3.9 / R9.9.0‑Final
// ============================================================
// Core Structured Logger with GuardianIntegration Bridge
// ============================================================

import GuardianIntegrity from './GuardianIntegrity.js';

export class Logger {
    static #instance = null;
    #entries = [];
    #listeners = new Set();
    #preserveLimit = 2000;

    constructor(config = {}) {
        if (Logger.#instance) return Logger.#instance;
        Logger.#instance = this;

        this.timestampEnabled = config.timestamp ?? true;
        this.guardian = config.guardian ?? GuardianIntegrity.getInstance();
        this.autoBroadcast = config.autoBroadcast ?? true;
        this.emitEvent = config.emitEvent ?? null;

        this.levelMap = Object.freeze({
            error: 0,
            warn: 1,
            info: 2,
            debug: 3
        });

        this.levelColors = {
            error: 'red',
            warn: 'orange',
            info: 'blue',
            debug: 'gray'
        };

        console.log('🪶 Logger initialized');
    }

    static getInstance(config = {}) {
        return Logger.#instance || new Logger(config);
    }

    // ============================================================
    // Main log entry point
    // ============================================================
    log(level = 'info', message = '', meta = {}) {
        try {
            level = level.toLowerCase();
            if (!this.levelMap.hasOwnProperty(level)) {
                level = 'info';
            }

            const entry = this.#buildEntry(level, message, meta);
            this.#addEntry(entry);
            this.#emitToConsole(entry);
            if (this.autoBroadcast && this.emitEvent) {
                this.emitEvent('logger:entry', entry);
            }
            return entry;
        } catch (error) {
            console.error('Logger internal failure:', error);
        }
    }

    info(message, meta = {}) { return this.log('info', message, meta); }
    warn(message, meta = {}) { return this.log('warn', message, meta); }
    error(message, meta = {}) { return this.log('error', message, meta); }
    debug(message, meta = {}) { return this.log('debug', message, meta); }

    // ============================================================
    // Entry construction helpers
    // ============================================================
    #buildEntry(level, message, meta) {
        const baseEntry = {
            id: `log-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
            level,
            message,
            meta: { ...meta },
            color: this.levelColors[level],
            timestamp: this.timestampEnabled ? new Date().toISOString() : null
        };

        // حفاظت در برابر داده‌های ناامن
        baseEntry.meta = this.#sanitizeMeta(baseEntry.meta);
        return Object.freeze(baseEntry);
    }

    #sanitizeMeta(meta) {
        const sanitized = {};
        for (const [k, v] of Object.entries(meta)) {
            if (typeof v === 'string') sanitized[k] = v.slice(0, 500);
            else if (typeof v === 'object') sanitized[k] = JSON.parse(JSON.stringify(v, (_, val) => {
                if (typeof val === 'string' && val.length > 500) return val.substring(0, 500) + '...';
                return val;
            }));
            else sanitized[k] = v;
        }
        return sanitized;
    }

    #addEntry(entry) {
        this.#entries.push(entry);
        if (this.#entries.length > this.#preserveLimit) {
            this.#entries.shift();
        }

        this.#notifyListeners(entry);
        if (entry.level === 'error') {
            this.guardian?.recordFailure('Logger', new Error(entry.message));
        }
    }

    #notifyListeners(entry) {
        for (const listener of this.#listeners) {
            try {
                listener(entry);
            } catch (err) {
                console.error('Logger listener threw:', err);
            }
        }
    }

    #emitToConsole(entry) {
        const { level, message, color, timestamp } = entry;
        const prefix = timestamp ? `[${timestamp}]` : '';
        const style = `color:${color}; font-weight:bold;`;
        const finalMsg = `${prefix} [${level.toUpperCase()}] ${message}`;

        switch (level) {
            case 'error': console.error(`%c${finalMsg}`, style, entry.meta); break;
            case 'warn': console.warn(`%c${finalMsg}`, style, entry.meta); break;
            case 'info': console.info(`%c${finalMsg}`, style, entry.meta); break;
            case 'debug': console.debug(`%c${finalMsg}`, style, entry.meta); break;
            default: console.log(`%c${finalMsg}`, style, entry.meta);
        }
    }

    // ============================================================
    // Utilities
    // ============================================================
    getLogs(limit = 100) {
        return this.#entries.slice(-limit);
    }

    clear() {
        this.#entries.length = 0;
        console.log('🧹 Logger cleared');
    }

    addListener(callback) {
        if (typeof callback !== 'function') throw new TypeError('Logger listener must be a function');
        this.#listeners.add(callback);
        return () => this.#listeners.delete(callback);
    }

    removeListener(callback) {
        this.#listeners.delete(callback);
    }

    exportAsJSON(limit = 500) {
        return JSON.stringify(this.getLogs(limit), null, 2);
    }

    exportAsText(limit = 500) {
        const logs = this.getLogs(limit);
        return logs.map(log =>
            `[${log.timestamp}] [${log.level.toUpperCase()}] ${log.message}`
        ).join('\n');
    }

    destroy() {
        this.#entries.length = 0;
        this.#listeners.clear();
        console.log('🧹 Logger destroyed');
    }

    static get version() {
        return 'R9.9.0‑Final';
    }
}

// ============================================================
export default Logger;
