// ============================================================
// PDF Exporter – v1 (Free / Stable / Offscreen Only)
// ============================================================

export async function exportToPDF({ title, content, fileName }) {
  const TIMEOUT_MS = 15000;

  try {
    // 1️⃣ درخواست تولید PDF از Offscreen v1
    const response = await Promise.race([
      chrome.runtime.sendMessage({
        type: "GENERATE_PDF_V1",
        payload: {
          title,
          content
        }
      }),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error("PDF v1 generation timeout")), TIMEOUT_MS)
      )
    ]);

    if (!response || response.success !== true || !response.data) {
      throw new Error("Invalid response from PDF v1 offscreen");
    }

    // 2️⃣ تبدیل ArrayBuffer به Blob
    const pdfBlob = new Blob(
      [response.data],
      { type: "application/pdf" }
    );

    const pdfUrl = URL.createObjectURL(pdfBlob);

    // 3️⃣ شروع دانلود
    await chrome.downloads.download({
      url: pdfUrl,
      filename: fileName || "export.pdf",
      saveAs: true
    });

    // 4️⃣ Cleanup حافظه
    setTimeout(() => {
      URL.revokeObjectURL(pdfUrl);
    }, 10000);

    return {
      success: true,
      format: "pdf",
      downloadStarted: true
    };

  } catch (error) {
    console.error("[PDFExporter v1] Export failed:", error);

    return {
      success: false,
      format: "pdf",
      error: error?.message || "PDF export failed"
    };
  }
}

// ============================================================
// توابع باقی‌مانده از نسخه Pro - فقط برای سازگاری (بلااستفاده)
// ============================================================

export default class PDFExporter {
    constructor() {
        console.warn("[PDFExporter] ⚠️ Legacy Pro class is deprecated. Use exportToPDF function instead.");
    }

    async exportToPDF({ 
        htmlContent, 
        fileName = 'report.pdf', 
        metadata = {},
        conversations,
        options
    }) {
        console.error("[PDFExporter] ❌ Legacy Pro method called. Use exportToPDF function instead.");
        throw new Error("PDF Pro export is not available. Use the free PDF v1 export.");
    }

    async testConnection() {
        return {
            success: false,
            error: "Legacy Pro method deprecated",
            timestamp: Date.now()
        };
    }

    async healthCheck() {
        return {
            success: true,
            healthy: false,
            message: "Legacy Pro class - Use PDF v1 export instead",
            timestamp: Date.now()
        };
    }

    async cleanup() {
        return { 
            success: true, 
            message: 'Legacy cleanup - no action needed',
            timestamp: Date.now() 
        };
    }
}