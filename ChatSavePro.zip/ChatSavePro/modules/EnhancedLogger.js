// modules/enhanced-logger.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles & Manifest V3

// ✅ Principle 1: Context Isolation
const LOG_CONTEXTS = Object.freeze({
    BACKGROUND: 'background',
    POPUP: 'popup',
    CONTENT_SCRIPT: 'content_script',
    STORAGE: 'storage',
    SCANNER: 'scanner',
    EXPORTER: 'exporter',
    VALIDATOR: 'validator',
    DATABASE: 'database'
});

// ✅ Principle 2: Strict Interface Contract
const LOG_LEVELS = Object.freeze({
    TRACE: { value: 0, name: 'TRACE', color: '#888' },
    DEBUG: { value: 1, name: 'DEBUG', color: '#555' },
    INFO: { value: 2, name: 'INFO', color: '#2E86AB' },
    WARN: { value: 3, name: 'WARN', color: '#F39C12' },
    ERROR: { value: 4, name: 'ERROR', color: '#E74C3C' },
    FATAL: { value: 5, name: 'FATAL', color: '#8B0000' }
});

// ✅ Principle 9: Secure Logging & Sanitization
class LogSanitizer {
    static sanitizeMessage(message) {
        if (typeof message !== 'string') {
            try {
                message = String(message);
            } catch {
                return '[Unstringifiable Message]';
            }
        }
        
        // Remove sensitive data from message
        return message.replace(/(password|token|api[_-]?key|secret|auth)=[^&\s]+/gi, '$1=***');
    }

    static sanitizeData(data) {
        if (!data) return null;

        try {
            const sanitized = { ...data };
            this.#deepSanitize(sanitized);
            return Object.keys(sanitized).length > 0 ? sanitized : null;
        } catch {
            return { sanitizationError: 'Data sanitization failed' };
        }
    }

    static #deepSanitize(obj) {
        if (typeof obj !== 'object' || obj === null) return;

        for (const key in obj) {
            if (typeof obj[key] === 'string') {
                if (this.#isSensitiveField(key)) {
                    obj[key] = '***';
                }
            } else if (typeof obj[key] === 'object') {
                this.#deepSanitize(obj[key]);
            }
        }
    }

    static #isSensitiveField(fieldName) {
        const sensitivePatterns = [
            'password', 'token', 'apiKey', 'secret', 'authorization',
            'cookie', 'session', 'credential', 'privateKey'
        ];
        return sensitivePatterns.some(pattern => 
            fieldName.toLowerCase().includes(pattern.toLowerCase())
        );
    }
}

// ✅ Principle 5: Memory Segmentation
class LogMemoryManager {
    constructor() {
        this.segments = new Map();
        this.maxLogsPerSegment = 100;
        this.#initializeSegments();
        this.metrics = {
            segmentHits: 0,
            segmentMisses: 0,
            totalStorage: 0
        };
    }

    #initializeSegments() {
        this.segments.set('session', new Map());
        this.segments.set('errors', new Map());
        this.segments.set('performance', new Map());
        this.segments.set('security', new Map());
        this.segments.set('audit', new Map());
    }

    addLog(segment, logEntry) {
        if (!this.segments.has(segment)) {
            console.warn(`[Logger] Unknown segment: ${segment}`);
            return;
        }

        const segmentStore = this.segments.get(segment);
        const timestamp = logEntry.timestamp;

        if (segmentStore.size >= this.maxLogsPerSegment) {
            const oldestKey = Array.from(segmentStore.keys())[0];
            const removed = segmentStore.get(oldestKey);
            segmentStore.delete(oldestKey);
            this.metrics.totalStorage -= this.#calculateSize(removed);
        }

        segmentStore.set(timestamp, logEntry);
        this.metrics.totalStorage += this.#calculateSize(logEntry);
        this.metrics.segmentHits++;
    }

    getLogs(segment, count = 50) {
        const segmentStore = this.segments.get(segment);
        if (!segmentStore) {
            this.metrics.segmentMisses++;
            return [];
        }

        return Array.from(segmentStore.values())
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, count);
    }

    clearSegment(segment) {
        if (this.segments.has(segment)) {
            const segmentStore = this.segments.get(segment);
            const clearedSize = Array.from(segmentStore.values())
                .reduce((size, entry) => size + this.#calculateSize(entry), 0);
            
            segmentStore.clear();
            this.metrics.totalStorage -= clearedSize;
            return true;
        }
        return false;
    }

    getSegmentStats(segment) {
        const segmentStore = this.segments.get(segment);
        if (!segmentStore) return null;

        const logs = Array.from(segmentStore.values());
        const errorCount = logs.filter(log => log.level === 'ERROR' || log.level === 'FATAL').length;
        const warnCount = logs.filter(log => log.level === 'WARN').length;

        return {
            size: segmentStore.size,
            errorCount,
            warnCount,
            memoryUsage: this.#formatBytes(logs.reduce((size, entry) => size + this.#calculateSize(entry), 0)),
            lastEntry: logs.length > 0 ? logs[0].timestamp : null
        };
    }

    getMemoryUsage() {
        const segmentStats = {};
        this.segments.forEach((store, segment) => {
            segmentStats[segment] = this.getSegmentStats(segment);
        });

        return {
            segments: Array.from(this.segments.keys()),
            totalLogs: Array.from(this.segments.values())
                .reduce((sum, segment) => sum + segment.size, 0),
            memoryUsage: this.#formatBytes(this.metrics.totalStorage),
            segmentStats,
            metrics: { ...this.metrics }
        };
    }

    #calculateSize(data) {
        try {
            return new Blob([JSON.stringify(data)]).size;
        } catch {
            return 0;
        }
    }

    #formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

// ✅ Principle 7: Async Pipeline & Resilience
class LogBatchProcessor {
    constructor() {
        this.batch = [];
        this.batchSize = 15;
        this.flushInterval = 10000;
        this.isProcessing = false;
        this.maxBatchRetries = 2;
        this.#startBatchProcessor();
    }

    addToBatch(logEntry) {
        this.batch.push(logEntry);
        
        if (this.batch.length >= this.batchSize) {
            this.#processBatch();
        }
    }

    #startBatchProcessor() {
        setInterval(() => {
            if (this.batch.length > 0 && !this.isProcessing) {
                this.#processBatch();
            }
        }, this.flushInterval);
    }

    async #processBatch() {
        if (this.isProcessing || this.batch.length === 0) return;

        this.isProcessing = true;
        const batchToProcess = [...this.batch];
        this.batch = [];

        let attempts = 0;
        let success = false;

        while (attempts < this.maxBatchRetries && !success) {
            try {
                await this.#persistBatch(batchToProcess);
                await this.#analyzeBatch(batchToProcess);
                success = true;
            } catch (error) {
                attempts++;
                console.warn(`[Logger] Batch processing attempt ${attempts} failed:`, error);
                
                if (attempts < this.maxBatchRetries) {
                    await this.#delay(1000 * attempts);
                } else {
                    console.error('[Logger] Batch processing failed after all retries:', error);
                    this.batch.unshift(...batchToProcess);
                }
            }
        }

        this.isProcessing = false;
    }

    async #persistBatch(batch) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(['systemLogs'], (result) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                    return;
                }

                const existingLogs = result.systemLogs || [];
                const updatedLogs = [...existingLogs, ...batch]
                    .sort((a, b) => b.timestamp - a.timestamp)
                    .slice(0, 2000);

                chrome.storage.local.set({ systemLogs: updatedLogs }, () => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    } else {
                        resolve();
                    }
                });
            });
        });
    }

    async #analyzeBatch(batch) {
        const errorCount = batch.filter(log => log.level === 'ERROR' || log.level === 'FATAL').length;
        const warnCount = batch.filter(log => log.level === 'WARN').length;

        if (errorCount > 10) {
            console.warn(`[Logger] High error rate detected: ${errorCount} errors in last batch`);
        }

        this.#analyzeErrorPatterns(batch);
        this.#analyzePerformance(batch);
    }

    #analyzeErrorPatterns(batch) {
        const errors = batch.filter(log => log.level === 'ERROR' || log.level === 'FATAL');
        const errorMessages = errors.map(err => err.message);
        
        const errorCounts = {};
        errorMessages.forEach(msg => {
            const key = msg.substring(0, 100);
            errorCounts[key] = (errorCounts[key] || 0) + 1;
        });

        Object.entries(errorCounts).forEach(([msg, count]) => {
            if (count > 5) {
                console.warn(`[Logger] Recurring error pattern: "${msg}" (${count} times)`);
            }
        });
    }

    #analyzePerformance(batch) {
        const performanceLogs = batch.filter(log => log.context === 'performance');
        if (performanceLogs.length === 0) return;

        const totalDuration = performanceLogs.reduce((sum, log) => {
            const duration = log.data?.duration || 0;
            return sum + duration;
        }, 0);

        const avgDuration = totalDuration / performanceLogs.length;
        
        if (avgDuration > 1000) {
            console.warn(`[Logger] High average operation duration: ${avgDuration.toFixed(2)}ms`);
        }
    }

    #delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    getQueueSize() {
        return this.batch.length;
    }

    isProcessingBatch() {
        return this.isProcessing;
    }
}

// ✅ Main ES6 Module Class
export class EnhancedLogger {
    constructor() {
        this.MODULE_NAME = 'EnhancedLogger';
        this.MODULE_VERSION = '3.1.0';
        
        this.memoryManager = new LogMemoryManager();
        this.batchProcessor = new LogBatchProcessor();
        this.currentLevel = LOG_LEVELS.INFO.value;

        this.metrics = {
            totalLogs: 0,
            logsByLevel: {},
            logsByModule: {},
            logsByContext: {},
            performance: {
                averageLogTime: 0,
                totalLogTime: 0,
                slowestLog: 0
            }
        };

        this.#initializeMetrics();
        this.#setupErrorHandling();
    }

    // ✅ Private methods for encapsulation
    #initializeMetrics() {
        Object.values(LOG_LEVELS).forEach(level => {
            this.metrics.logsByLevel[level.name] = 0;
        });

        Object.values(LOG_CONTEXTS).forEach(context => {
            this.metrics.logsByContext[context] = 0;
        });
    }

    #setupErrorHandling() {
        if (typeof window !== 'undefined') {
            window.addEventListener('error', (event) => {
                this.log(LOG_LEVELS.ERROR, 'Global', `Unhandled error: ${event.message}`, {
                    filename: event.filename,
                    lineno: event.lineno,
                    colno: event.colno,
                    error: event.error?.stack
                });
            });

            window.addEventListener('unhandledrejection', (event) => {
                this.log(LOG_LEVELS.ERROR, 'Global', `Unhandled promise rejection: ${event.reason}`, {
                    reason: event.reason?.stack || event.reason
                });
            });
        }
    }

    #createLogEntry(level, module, message, data, context) {
        const timestamp = Date.now();
        const logId = `${timestamp}_${module}_${Math.random().toString(36).substr(2, 9)}`;

        return {
            id: logId,
            timestamp,
            level: level.name,
            module,
            message: LogSanitizer.sanitizeMessage(message),
            data: LogSanitizer.sanitizeData(data),
            context,
            stack: level.value >= LOG_LEVELS.ERROR.value ? this.#getStack() : null,
            version: this.MODULE_VERSION
        };
    }

    #storeInMemorySegments(logEntry) {
        let segment = 'session';
        
        if (logEntry.level === 'ERROR' || logEntry.level === 'FATAL') {
            segment = 'errors';
        } else if (logEntry.context === 'performance') {
            segment = 'performance';
        } else if (logEntry.context === 'security') {
            segment = 'security';
        } else if (logEntry.context === 'audit') {
            segment = 'audit';
        }

        this.memoryManager.addLog(segment, logEntry);
    }

    #outputToConsole(logEntry) {
        const formattedMessage = this.#formatConsoleMessage(logEntry);
        const levelConfig = LOG_LEVELS[logEntry.level];
        const style = `color: ${levelConfig.color}; font-weight: ${logEntry.level === 'ERROR' || logEntry.level === 'FATAL' ? 'bold' : 'normal'}`;

        const consoleMethod = this.#getConsoleMethod(logEntry.level);
        
        if (logEntry.data) {
            consoleMethod(`%c${formattedMessage}`, style, logEntry.data);
        } else {
            consoleMethod(`%c${formattedMessage}`, style);
        }

        if (logEntry.stack && (logEntry.level === 'ERROR' || logEntry.level === 'FATAL')) {
            console.log('%cStack Trace:', 'color: #666; font-style: italic;', logEntry.stack);
        }
    }

    #getConsoleMethod(level) {
        switch (level) {
            case 'ERROR':
            case 'FATAL':
                return console.error;
            case 'WARN':
                return console.warn;
            case 'INFO':
                return console.info;
            default:
                return console.log;
        }
    }

    #formatConsoleMessage(logEntry) {
        const timestamp = new Date(logEntry.timestamp).toISOString();
        const context = logEntry.context !== 'system' ? `[${logEntry.context}]` : '';
        return `[${timestamp}] [${logEntry.level}] ${context} ${logEntry.module}: ${logEntry.message}`;
    }

    #getStack() {
        try {
            const stack = new Error().stack;
            if (!stack) return 'Stack unavailable';
            
            return stack.split('\n')
                .slice(3)
                .filter(line => !line.includes('EnhancedLogger'))
                .join('\n');
        } catch {
            return 'Stack generation failed';
        }
    }

    #updateMetrics(level, module, context, duration) {
        this.metrics.logsByLevel[level.name] = (this.metrics.logsByLevel[level.name] || 0) + 1;
        this.metrics.logsByModule[module] = (this.metrics.logsByModule[module] || 0) + 1;
        this.metrics.logsByContext[context] = (this.metrics.logsByContext[context] || 0) + 1;
        
        this.metrics.performance.totalLogTime += duration;
        this.metrics.performance.averageLogTime = 
            this.metrics.performance.totalLogTime / this.metrics.totalLogs;
        
        if (duration > this.metrics.performance.slowestLog) {
            this.metrics.performance.slowestLog = duration;
        }
    }

    // ✅ Public API Methods
    log(level, module, message, data = null, context = 'system') {
        const startTime = performance.now();
        this.metrics.totalLogs++;

        if (level.value < this.currentLevel) {
            return null;
        }

        const logEntry = this.#createLogEntry(level, module, message, data, context);
        
        this.#storeInMemorySegments(logEntry);
        this.batchProcessor.addToBatch(logEntry);
        this.#outputToConsole(logEntry);
        
        const duration = performance.now() - startTime;
        this.#updateMetrics(level, module, context, duration);
        
        return logEntry;
    }

    setLogLevel(level) {
        if (LOG_LEVELS[level]) {
            this.currentLevel = LOG_LEVELS[level].value;
            this.log(LOG_LEVELS.INFO, 'Logger', `Log level changed to ${level}`);
            return true;
        }
        return false;
    }

    getLogs(segment = 'session', count = 50) {
        return this.memoryManager.getLogs(segment, count);
    }

    clearLogs(segment = null) {
        if (segment) {
            return this.memoryManager.clearSegment(segment);
        } else {
            let cleared = 0;
            this.memoryManager.segments.forEach((_, seg) => {
                if (this.memoryManager.clearSegment(seg)) {
                    cleared++;
                }
            });
            return cleared > 0;
        }
    }

    getMetrics() {
        const levelDistribution = {};
        Object.entries(this.metrics.logsByLevel).forEach(([level, count]) => {
            levelDistribution[level] = {
                count,
                percentage: ((count / this.metrics.totalLogs) * 100).toFixed(2) + '%'
            };
        });

        return {
            totalLogs: this.metrics.totalLogs,
            levelDistribution,
            moduleDistribution: this.metrics.logsByModule,
            contextDistribution: this.metrics.logsByContext,
            performance: {
                averageLogTime: this.metrics.performance.averageLogTime.toFixed(2) + 'ms',
                slowestLog: this.metrics.performance.slowestLog.toFixed(2) + 'ms'
            },
            memory: this.memoryManager.getMemoryUsage(),
            batchProcessor: {
                queueSize: this.batchProcessor.getQueueSize(),
                isProcessing: this.batchProcessor.isProcessingBatch()
            },
            currentLevel: Object.keys(LOG_LEVELS).find(key => LOG_LEVELS[key].value === this.currentLevel)
        };
    }

    createModuleLogger(moduleName) {
        return {
            trace: (message, data, context) => 
                this.log(LOG_LEVELS.TRACE, moduleName, message, data, context),
            debug: (message, data, context) => 
                this.log(LOG_LEVELS.DEBUG, moduleName, message, data, context),
            info: (message, data, context) => 
                this.log(LOG_LEVELS.INFO, moduleName, message, data, context),
            warn: (message, data, context) => 
                this.log(LOG_LEVELS.WARN, moduleName, message, data, context),
            error: (message, data, context) => 
                this.log(LOG_LEVELS.ERROR, moduleName, message, data, context),
            fatal: (message, data, context) => 
                this.log(LOG_LEVELS.FATAL, moduleName, message, data, context),
            
            performance: (operation, duration, data) => 
                this.log(LOG_LEVELS.INFO, moduleName, `${operation} took ${duration}ms`, data, 'performance'),
            
            security: (event, data) => 
                this.log(LOG_LEVELS.WARN, moduleName, `Security event: ${event}`, data, 'security'),
            
            audit: (action, data) => 
                this.log(LOG_LEVELS.INFO, moduleName, `Audit: ${action}`, data, 'audit'),
            
            business: (event, data) => 
                this.log(LOG_LEVELS.INFO, moduleName, `Business: ${event}`, data, 'business')
        };
    }

    async exportLogs(format = 'json') {
        const allLogs = [];
        this.memoryManager.segments.forEach(segment => {
            segment.forEach(log => allLogs.push(log));
        });

        const exportData = {
            exportedAt: new Date().toISOString(),
            totalLogs: allLogs.length,
            metrics: this.getMetrics(),
            logs: allLogs.sort((a, b) => b.timestamp - a.timestamp)
        };

        if (format === 'json') {
            return JSON.stringify(exportData, null, 2);
        } else if (format === 'text') {
            return allLogs.map(log => 
                `[${new Date(log.timestamp).toISOString()}] [${log.level}] ${log.module}: ${log.message}`
            ).join('\n');
        }

        return exportData;
    }

    // ✅ Utility Methods
    getSupportedLevels() {
        return Object.keys(LOG_LEVELS);
    }

    getSupportedContexts() {
        return Object.values(LOG_CONTEXTS);
    }

    // ✅ Safe destruction
    destroy() {
        this.memoryManager.segments.clear();
        this.batchProcessor.batch = [];
    }

    static get LEVELS() {
        return LOG_LEVELS;
    }

    static get CONTEXTS() {
        return LOG_CONTEXTS;
    }

    static get version() {
        return '3.1.0';
    }
}

// ✅ Default export
export default EnhancedLogger;