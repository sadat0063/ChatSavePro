/* =========================================================================
 * JSON Export Renderer
 * =========================================================================
 * Input : Array (output of normalizeScanLayerExport) OR object with conversations property
 * Output: { content, mimeType, fileExtension }
 * ========================================================================= */

import { normalizeScanLayerExport } from "./normalize.js";
import { registerExportRenderer } from "../exportRegistry.js";

/* =======================================================================
 * Main Renderer Function
 * ===================================================================== */

async function renderJsonExport(inputData, options = {}) {
  console.log("[JSON_RENDER] 🚀 Rendering JSON export");

  let dataToExport;
  let source = options.source || "json_export";

  // حالت ۱: اگر آرایه مستقیم داده شده
  if (Array.isArray(inputData)) {
    console.log(`[JSON_RENDER] 📊 Processing ${inputData.length} items directly`);
    dataToExport = inputData;
  }
  // حالت ۲: اگر object با property conversations داده شده (backward compatibility)
  else if (inputData && Array.isArray(inputData.conversations)) {
    console.log(`[JSON_RENDER] 📊 Processing ${inputData.conversations.length} items from conversations property`);
    dataToExport = inputData.conversations;
    source = inputData.source || source;
  }
  // حالت ۳: داده نامعتبر
  else {
    console.error("[JSON_RENDER] ❌ Invalid input data:", inputData);
    return {
      success: false,
      error: "Invalid input data for JSON export - expected array or object with conversations array",
      content: "",
      mimeType: "application/json",
      fileExtension: "json"
    };
  }

  // اعمال normalization اگر داده‌ها raw باشند
  const normalized = normalizeScanLayerExport(dataToExport);

  if (!Array.isArray(normalized)) {
    console.error("[JSON_RENDER] ❌ Normalized data is invalid:", normalized);
    return {
      success: false,
      error: "Invalid normalized data for JSON export",
      content: "",
      mimeType: "application/json",
      fileExtension: "json"
    };
  }

  // ساخت ساختار JSON استاندارد با metadata
  const exportObject = {
    meta: {
      exportedAt: new Date().toISOString(),
      version: "1.0",
      totalItems: normalized.length,
      source: source,
      format: "json",
      exporter: "ChatSavePro"
    },
    data: normalized
  };

  const content = JSON.stringify(exportObject, null, 2);

  console.log(`[JSON_RENDER] ✅ JSON export complete: ${normalized.length} items`);

  return {
    success: true,
    content,
    mimeType: "application/json",
    fileExtension: "json"
  };
}

// ==================== REGISTER RENDERER ====================
registerExportRenderer("json", renderJsonExport);
console.log("[JSON_RENDER] ✅ JSON renderer registered");

// Optional: Export for testing
export { renderJsonExport };