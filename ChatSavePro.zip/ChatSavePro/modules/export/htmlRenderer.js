/* =========================================================================
 * HTML Export Renderer (RTL · Persian · Print/PDF Ready)
 * =========================================================================
 * Input : {conversations: Array, options: Object} OR Array
 * Output: { content, mimeType, fileExtension }
 * ========================================================================= */

import { registerExportRenderer } from "../exportRegistry.js";

/* =======================================================================
 * Main Renderer Function - MULTI-FORMAT SUPPORT
 * ===================================================================== */

async function renderHtmlExport(inputData, inputOptions = {}) {
  try {
    console.log("[HTML_RENDER] 🚀 Rendering HTML export");
    console.log("[HTML_RENDER] 📦 Input data structure:", {
      type: typeof inputData,
      isArray: Array.isArray(inputData),
      hasConversations: !!inputData?.conversations,
      conversationsCount: inputData?.conversations?.length || 0,
      inputKeys: Object.keys(inputData || {}),
      options: inputOptions
    });

    /* ---------------------------------------------------------
     * Multiple Data Format Support
     * ------------------------------------------------------ */
    let conversations = [];
    let options = { ...inputOptions };
    
    // حالت ۱: داده مستقیم آرایه (legacy format)
    if (Array.isArray(inputData)) {
      conversations = inputData;
      console.log("[HTML_RENDER] 📊 Using direct array data:", conversations.length);
    }
    // حالت ۲: داده در فیلد conversations (ExportRegistry format)
    else if (inputData?.conversations && Array.isArray(inputData.conversations)) {
      conversations = inputData.conversations;
      console.log("[HTML_RENDER] 📊 Using conversations field:", conversations.length);
      
      // options ممکن است داخل inputData باشد
      if (inputData.options && Object.keys(inputData.options).length > 0) {
        options = { ...options, ...inputData.options };
      }
    }
    // حالت ۳: داده در فیلد data
    else if (inputData?.data && Array.isArray(inputData.data)) {
      conversations = inputData.data;
      console.log("[HTML_RENDER] 📊 Using data field:", conversations.length);
    }
    // حالت ۴: object مستقیم
    else if (inputData && typeof inputData === 'object') {
      // سعی کن آرایه‌ای از conversations پیدا کنی
      const possibleArrays = Object.values(inputData).filter(v => Array.isArray(v));
      if (possibleArrays.length > 0) {
        conversations = possibleArrays[0];
        console.log("[HTML_RENDER] 📊 Found array in object:", conversations.length);
      }
    }

    if (!conversations.length) {
      console.error("[HTML_RENDER] ❌ No conversations to render after normalization");
      console.error("[HTML_RENDER] Input was:", inputData);
      
      return {
        success: false,
        content: `<html><body><h1>No Conversations</h1><p>No conversations available for export</p><pre>${escapeHtml(JSON.stringify(inputData, null, 2))}</pre></body></html>`,
        mimeType: "text/html",
        fileExtension: "html",
        error: "No conversations available after normalization"
      };
    }

    /* ---------------------------------------------------------
     * Flatten Messages
     * ------------------------------------------------------ */
    const messages = conversations.flatMap((conv) =>
      Array.isArray(conv.messages) ? conv.messages : []
    );

    console.log(
      "[HTML_RENDER] ✅ Rendering HTML",
      `(conversations: ${conversations.length}, messages: ${messages.length})`
    );

    const title = options.title || "خروجی گفتگو";
    const dateLabel = new Date().toLocaleString("fa-IR");
    const exportReason = options.reason ? `<p class="reason">${escapeHtml(options.reason)}</p>` : '';

    const messagesHtml = messages.map(renderMessage).join("\n");

    /* ---------------------------------------------------------
     * HTML Template
     * ------------------------------------------------------ */
    const content = `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${escapeHtml(title)}</title>

  <style>
/* =========================================================================
   Classic / Archival / Print-Friendly Style (Warm Cream Edition)
   ========================================================================= */

@font-face {
  font-family: "Vazirmatn";
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
  src: local("Vazirmatn"), local("Vazirmatn-Regular");
}

* { box-sizing: border-box; }

body {
  margin: 0;
  padding: 24px;
  background: #fdf9f2; /* creamy background */
  color: #1a1a1a;
  font-family: "Vazirmatn", Arial, system-ui, sans-serif;
  line-height: 1.75;
  direction: rtl;
}

.container {
  max-width: 900px;
  margin: 0 auto;
}

/* ================= Header ================= */

header {
  margin-bottom: 28px;
  padding: 18px;
  border-bottom: 2px solid #8bb9e8;
  background: #e8f2ff; /* آبی آسمانی ملایم برای خوانایی عالی */
  border-radius: 6px;
}

h1 {
  font-size: 1.6rem;
  margin: 0 0 10px;
  font-weight: 700;
  color: #1a3c5f; /* آبی تیره‌تر برای کنتراست بهتر */
}

.meta {
  font-size: 0.85rem;
  color: #2c4a6b;
  margin-bottom: 6px;
}

.stats {
  display: flex;
  gap: 10px;
  margin-top: 8px;
  font-size: 0.8rem;
}

.stat-item {
  background: #d9e7ff;
  color: #1a3c5f;
  padding: 4px 10px;
  border-radius: 4px;
  border: 1px solid #a8c6ff;
}

.reason {
  background: #fff8e1;
  color: #5a4a27;
  padding: 12px 14px;
  border-radius: 4px;
  margin-top: 14px;
  border-right: 4px solid #c9a94d;
  font-size: 0.9rem;
}

/* ================= Messages ================= */

.chat {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 22px;
}

.msg {
  max-width: 85%;
  padding: 14px 16px;
  border-radius: 6px;
  white-space: pre-wrap;
  word-wrap: break-word;
  border: 1px solid #d8cfc0;
  color: #1f1f1f;
}

.msg.user {
  align-self: flex-end;
  background: #f2f6fb; /* readable light blue */
  border-right: 4px solid #4a6fa5;
}

.msg.assistant {
  align-self: flex-start;
  background: #f4f1ec; /* warm neutral */
  border-left: 4px solid #6b8f71;
}

.role {
  font-size: 0.75rem;
  color: #333;
  margin-bottom: 6px;
  font-weight: 600;
}

.timestamp {
  font-size: 0.72rem;
  color: #555;
  margin-top: 6px;
  text-align: left;
}

/* ================= Code Blocks ================= */

pre {
  background: #eee6d8;
  color: #1a1a1a;
  padding: 12px;
  border-radius: 6px;
  overflow-x: auto;
  direction: ltr;
  font-family: ui-monospace, monospace;
  margin: 12px 0;
  font-size: 0.9rem;
  border: 1px solid #cfc4b3;
}

code {
  background: #e6dccb;
  padding: 2px 6px;
  border-radius: 4px;
  direction: ltr;
  font-family: ui-monospace, monospace;
}

/* ================= Footer ================= */

footer {
  margin-top: 42px;
  padding-top: 22px;
  border-top: 1px solid #d0c6b5;
  text-align: center;
  color: #555;
  font-size: 0.8rem;
}

/* ================= Print / PDF ================= */

@media print {
  body {
    background: #ffffff !important;
    color: #000000 !important;
    padding: 16pt;
    font-size: 11pt;
  }

  header {
    background: #e0ecff !important;
    border-color: #8bb9e8 !important;
    -webkit-print-color-adjust: exact;
    color-adjust: exact;
  }

  .msg {
    page-break-inside: avoid;
    border: 1px solid #bbbbbb !important;
  }

  .msg.user {
    background: #eef2ff !important;
  }

  .msg.assistant {
    background: #f2f2f2 !important;
  }

  .stat-item {
    border: 1px solid #bbbbbb;
  }
}
  </style>
</head>

<body>
  <div class="container">
    <header>
      <h1>${escapeHtml(title)}</h1>
      <div class="meta">تاریخ خروجی: ${dateLabel}</div>
      <div class="stats">
        <span class="stat-item">مکالمات: ${conversations.length}</span>
        <span class="stat-item">پیام‌ها: ${messages.length}</span>
      </div>
      ${exportReason}
    </header>

    <main class="chat">
      ${messagesHtml}
    </main>

    <footer>
      تولید شده توسط ChatSavePro | ${new Date().toLocaleString('fa-IR')}
    </footer>
  </div>
</body>
</html>`;

    console.log("[HTML_RENDER] ✅ HTML content generated, length:", content.length);

    return {
      success: true,
      content,
      mimeType: "text/html",
      fileExtension: "html"
    };

  } catch (error) {
    console.error("[HTML_RENDER] ❌ Renderer error:", error);
    console.error("[HTML_RENDER] ❌ Error stack:", error.stack);
    
    return {
      success: false,
      content: `<html><body><h1>Export Error</h1><p>${escapeHtml(error.message)}</p><pre>${escapeHtml(error.stack || 'No stack trace')}</pre></body></html>`,
      mimeType: "text/html",
      fileExtension: "html",
      error: error.message
    };
  }
}

/* =======================================================================
 * Message Renderer
 * ===================================================================== */

function renderMessage(msg = {}) {
  try {
    const role = msg.role === "user" ? "user" : "assistant";
    const roleLabel = msg.role === "user" ? "کاربر" : "دستیار";
    
    const timestamp = msg.timestamp ? 
      `<div class="timestamp">${new Date(msg.timestamp).toLocaleString('fa-IR')}</div>` : 
      '';

    const content = formatMessageContent(msg.content || "");

    return `
<div class="msg ${role}">
  <div class="role">${roleLabel}</div>
  <div class="content">${content}</div>
  ${timestamp}
</div>`;
  } catch (error) {
    console.error("[HTML_RENDER] ❌ Error rendering message:", error);
    return `<div class="msg assistant"><div class="role">Error</div><div class="content">Error rendering message: ${escapeHtml(error.message)}</div></div>`;
  }
}

/* =======================================================================
 * Content Formatting (SAFE)
 * ===================================================================== */

function formatMessageContent(text = "") {
  try {
    if (typeof text !== "string") {
      text = JSON.stringify(text, null, 2);
    }

    const escaped = escapeHtml(text);

    // شناسایی کدهای چندخطی
    const codeBlockPattern = /```(\w+)?\n([\s\S]*?)```/g;
    
    let formatted = escaped;
    
    // جایگزینی کدهای چندخطی
    formatted = formatted.replace(
      codeBlockPattern,
      (_, lang, code) => `<pre><code class="language-${lang || 'text'}">${escapeHtml(code.trim())}</code></pre>`
    );

    // شناسایی کدهای تک خطی
    const inlineCodePattern = /`([^`]+)`/g;
    formatted = formatted.replace(
      inlineCodePattern,
      '<code>$1</code>'
    );

    // تبدیل خطوط جدید
    formatted = formatted.replace(/\n/g, "<br>");

    return formatted;
  } catch (error) {
    console.error("[HTML_RENDER] ❌ Error formatting message content:", error);
    return `Error: ${escapeHtml(error.message)}`;
  }
}

/* =======================================================================
 * Utils
 * ===================================================================== */

function escapeHtml(str) {
  if (typeof str !== "string") {
    str = String(str);
  }
  
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// ==================== REGISTER RENDERER ====================
registerExportRenderer("html", renderHtmlExport);
console.log("[HTML_RENDER] ✅ HTML renderer registered (Multi-format support)");

// Export for testing
export { renderHtmlExport };