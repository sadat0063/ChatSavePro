// ===============================
// PDF Renderer - Stage 3 (FINAL FIX - PDFExporter Integration)
// ===============================

import { registerExportRenderer } from "../exportRegistry.js";
import PDFExporter from "../../modules/PDFExporter.js";

/**
 * Main PDF renderer (Stage 3 – REAL PDF via PDFExporter)
 */
async function pdfRenderer(normalizedData, options = {}) {
    console.log("[PDF_RENDER] 🚀 PDF renderer started (Stage 3 - PDFExporter)");

    try {
        // 1. ساخت HTML از template
        const htmlContent = buildPDFHTML(normalizedData, options);
        
        // 2. استفاده از PDFExporter جدید
        const pdfExporter = new PDFExporter();
        
        await pdfExporter.exportToPDF({
            htmlContent: htmlContent,
            fileName: options.fileName || `conversations_${Date.now()}.pdf`,
            metadata: {
                title: "ChatSavePro Export",
                subject: "Conversation Export",
                author: "ChatSavePro",
                keywords: ["chat", "export", "conversation"],
                creator: "ChatSavePro Chrome Extension"
            }
        });

        console.log("[PDF_RENDER] ✅ PDF generated via PDFExporter");

        // برگرداندن ساختار مورد انتظار Export Registry
        return {
            success: true,
            handledBy: "PDFExporter",
            fileName: options.fileName || `conversations_${Date.now()}.pdf`,
            itemCount: normalizedData?.conversations?.length || 0,
            timestamp: Date.now()
        };

    } catch (error) {
        console.error("[PDF_RENDER] ❌ PDF export failed:", error);
        
        // 🔴 NO FALLBACK - اگر PDF fail شد، خطا throw شود
        throw new Error(`PDF export failed: ${error.message}`);
    }
}

/**
 * ساخت HTML از داده‌های مکالمه برای PDF
 */
function buildPDFHTML(normalizedData, options = {}) {
    const conversations = normalizedData?.conversations || [];
    const totalMessages = conversations.reduce((sum, conv) => sum + (conv.messages?.length || 0), 0);
    
    // ساخت HTML هر مکالمه
    const conversationsHTML = conversations.map(conv => {
        const messagesHTML = (conv.messages || []).map(msg => `
            <article class="message-block ${msg.role || 'unknown'}-message">
                <div class="message-header">
                    <div class="message-role">${escapeHTML(msg.role || 'unknown')}</div>
                    <div class="message-time">${formatTimestamp(msg.timestamp)}</div>
                </div>
                <div class="message-content">
                    <p>${escapeHTML(msg.content || '')}</p>
                </div>
            </article>
        `).join('');
        
        return `
            <section class="conversation-section">
                <h2 class="conversation-title">${escapeHTML(conv.title || `Conversation from ${conv.site || 'Unknown'}`)}</h2>
                <div class="conversation-meta">
                    <span class="meta-item">Site: ${escapeHTML(conv.site || 'Unknown')}</span>
                    <span class="meta-item">Messages: ${conv.messages?.length || 0}</span>
                    <span class="meta-item">Date: ${formatTimestamp(conv.savedAt || conv.timestamp)}</span>
                </div>
                <div class="conversation-messages">
                    ${messagesHTML}
                </div>
            </section>
            <hr class="conversation-divider">
        `;
    }).join('');
    
    // HTML کامل با استفاده از template استاندارد
    return `
<!DOCTYPE html>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="UTF-8">
    <title>خروجی مکالمه - ChatSavePro</title>
    <link rel="stylesheet" href="pdf/pdf-style.css">
</head>
<body>
    <div class="page-container">
        <header class="document-header">
            <div class="header-main">
                <h1 class="document-title">خروجی مکالمه</h1>
                <div class="document-subtitle">تولید شده توسط ChatSavePro</div>
            </div>
        </header>

        <section class="metadata-section">
            <div class="metadata-grid">
                <div class="metadata-item">
                    <span class="metadata-label">تاریخ استخراج:</span>
                    <span class="metadata-value">${new Date().toLocaleDateString('fa-IR')}</span>
                </div>
                <div class="metadata-item">
                    <span class="metadata-label">تعداد مکالمه‌ها:</span>
                    <span class="metadata-value">${conversations.length}</span>
                </div>
                <div class="metadata-item">
                    <span class="metadata-label">تعداد پیام‌ها:</span>
                    <span class="metadata-value">${totalMessages}</span>
                </div>
                <div class="metadata-item">
                    <span class="metadata-label">فرمت:</span>
                    <span class="metadata-value">PDF حرفه‌ای</span>
                </div>
            </div>
        </section>

        <hr class="section-divider">

        <main class="conversation-body">
            ${conversationsHTML}
        </main>

        <footer class="document-footer">
            <div class="footer-info">
                <div class="footer-credits">
                    تولید شده توسط ChatSavePro • https://chatsave.pro
                </div>
                <div class="footer-date">
                    تاریخ تولید: ${new Date().toLocaleDateString('fa-IR')} - ${new Date().toLocaleTimeString('fa-IR')}
                </div>
            </div>
        </footer>
    </div>
</body>
</html>
    `;
}

/**
 * تابع helper برای escape HTML
 */
function escapeHTML(text) {
    if (typeof text !== 'string') return '';
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;')
        .replace(/\n/g, '<br>');
}

/**
 * فرمت کردن timestamp
 */
function formatTimestamp(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    return date.toLocaleDateString('fa-IR') + ' ' + date.toLocaleTimeString('fa-IR');
}

/**
 * ✅ Register renderer (SIDE EFFECT)
 */
registerExportRenderer("pdf", pdfRenderer);
console.log("[PDF_RENDER] ✅ PDF renderer registered");

// optional named export (debug / test)
export { pdfRenderer };