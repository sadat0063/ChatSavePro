// modules/export/normalize.js
export function normalizeScanLayerExport(raw) {
  if (!Array.isArray(raw)) {
    return [];
  }

  return raw.map((conv, index) => ({
    id: conv.id || `conv-${index + 1}`,
    createdAt: conv.createdAt || null,
    messages: Array.isArray(conv.messages)
      ? conv.messages.map((m) => ({
          role: m.role || "unknown",
          content: m.content || ""
        }))
      : []
  }));
}
