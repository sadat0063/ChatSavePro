// ============================================================
// modules/ExportManager.js - REAL DATA EXPORT MANAGER
// ============================================================

const EXPORT_SCHEMA = {
    EXPORT_REQUEST: {
        required: ['format'],
        optional: ['filters', 'fileName', 'options', 'metadata']
    },
    EXPORT_RESULT: {
        required: ['success', 'format', 'blob', 'mimeType', 'fileName'],
        optional: ['error', 'fileSize', 'conversationCount']
    }
};

class ExportLogger {
    constructor(moduleName) {
        this.moduleName = moduleName;
        this.maxLogEntries = 100;
        this.logEntries = [];
    }

    log(level, operation, data = {}) {
        const logEntry = {
            id: `export_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            module: this.moduleName,
            level,
            operation: this._sanitize(operation),
            data: this._sanitize(data)
        };

        this.logEntries.push(logEntry);

        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        console.log(`[${this.moduleName}] ${operation}`, data);
        return logEntry;
    }

    _sanitize(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return JSON.parse(JSON.stringify(input));
    }

    getLogs(limit = 20) {
        return this.logEntries.slice(-limit);
    }
}

class ExportPipeline {
    constructor() {
        this.timeout = 30000;
        this.retryConfig = {
            maxRetries: 3,
            baseDelay: 1000
        };
    }

    async executeWithRetry(operation, operationName) {
        let lastError;
        
        for (let attempt = 1; attempt <= this.retryConfig.maxRetries; attempt++) {
            try {
                return await this.executeWithTimeout(operation, operationName);
            } catch (error) {
                lastError = error;
                
                if (attempt === this.retryConfig.maxRetries) break;
                
                await this.delay(this.retryConfig.baseDelay * Math.pow(2, attempt - 1));
            }
        }
        
        throw new Error(`Operation ${operationName} failed after ${this.retryConfig.maxRetries} attempts: ${lastError.message}`);
    }

    async executeWithTimeout(operation, operationName) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Operation ${operationName} timeout after ${this.timeout}ms`));
            }, this.timeout);
            
            Promise.resolve(operation())
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

class ExportSessionManager {
    constructor() {
        this.exportSessions = new Map();
        this.exportResults = new Map();
    }

    createExportSession(exportId, format, filters = {}) {
        const session = {
            exportId,
            format,
            filters,
            startTime: Date.now(),
            status: 'processing',
            options: this._sanitize({}),
            metadata: {
                platform: 'chrome_extension',
                exportType: 'conversation_export'
            }
        };

        this.exportSessions.set(exportId, session);
        return session;
    }

    getExportSession(exportId) {
        return this.exportSessions.get(exportId);
    }

    updateExportSession(exportId, updates) {
        const session = this.exportSessions.get(exportId);
        if (session) {
            Object.assign(session, updates);
            session.lastActivity = Date.now();
        }
        return session;
    }

    saveExportResult(exportId, result) {
        this.exportResults.set(exportId, {
            ...result,
            completedAt: Date.now()
        });
        return result;
    }

    getExportResult(exportId) {
        return this.exportResults.get(exportId);
    }

    cleanupExportSession(exportId) {
        this.exportSessions.delete(exportId);
        this.exportResults.delete(exportId);
    }

    cleanupExpiredSessions(timeout) {
        const now = Date.now();
        let cleanedCount = 0;

        this.exportSessions.forEach((session, exportId) => {
            if (now - (session.lastActivity || session.startTime) > timeout) {
                this.cleanupExportSession(exportId);
                cleanedCount++;
            }
        });

        return cleanedCount;
    }

    _sanitize(data) {
        return JSON.parse(JSON.stringify(data));
    }
}

class ExportFormatHelpers {
    static generateJSON(conversations, scanData) {
        const stats = {
            conversationCount: conversations.length,
            totalMessages: conversations.reduce((sum, conv) => sum + (conv.messages?.length || 0), 0),
            scanItemCount: scanData.items ? scanData.items.length : 0
        };

        const normalizedConversations = conversations.map(conv => {
            const messages = conv.messages || [];
            return {
                id: conv.id || `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                site: conv.site || 'unknown',
                hostname: conv.hostname || null,
                url: conv.url || null,
                title: conv.title || null,
                savedAt: conv.savedAt ? new Date(conv.savedAt).toISOString() : null,
                scannedAt: conv.scannedAt ? new Date(conv.scannedAt).toISOString() : null,
                messageCount: messages.length,
                messages: messages.map((msg, index) => ({
                    index: index + 1,
                    role: msg.role || 'unknown',
                    content: msg.content || msg.text || '',
                    timestamp: msg.timestamp ? new Date(msg.timestamp).toISOString() : null
                }))
            };
        });

        const normalizedScanData = scanData.items && scanData.items.length > 0 ? {
            scanType: scanData.scanType || 'merged',
            lastScan: scanData.lastScan ? new Date(scanData.lastScan).toISOString() : null,
            items: scanData.items.slice(0, 500)
        } : null;

        const data = {
            version: "1.0",
            exportedAt: new Date().toISOString(),
            stats: stats,
            conversations: normalizedConversations,
            scanData: normalizedScanData,
            metadata: {
                source: "ChatSavePro",
                format: "json",
                generator: "ExportFormatHelpers.generateJSON"
            }
        };

        return JSON.stringify(data, null, 2);
    }

    static generateText(conversations, scanData) {
        console.warn('🔥 generateText v1.7 EXECUTED', {
            conversationsCount: conversations?.length,
            hasScanData: !!scanData
        });
        
        // Constants
        const WIDTH = 64;
        const MARGIN = 4;
        const MARGIN_SPACES = ' '.repeat(MARGIN);
        const DOUBLE_LINE = '='.repeat(WIDTH);
        const SINGLE_LINE = '-'.repeat(WIDTH);
        const BOX_TOP = '╔' + '═'.repeat(WIDTH - 2) + '╗';
        const BOX_MIDDLE = '╠' + '═'.repeat(WIDTH - 2) + '╣';
        const BOX_BOTTOM = '╚' + '═'.repeat(WIDTH - 2) + '╝';
        
        // Helper functions
        const wordWrap = (text, width) => {
            if (!text || typeof text !== 'string') return [''];
            
            const lines = [];
            const paragraphs = text.split('\n');
            
            for (const paragraph of paragraphs) {
                if (paragraph.trim() === '') {
                    lines.push('');
                    continue;
                }
                
                const words = paragraph.split(/\s+/);
                let currentLine = '';
                
                for (const word of words) {
                    const wordLength = Array.from(word).length;
                    const lineLength = Array.from(currentLine).length;
                    
                    if (lineLength + wordLength + (currentLine ? 1 : 0) <= width) {
                        currentLine += (currentLine ? ' ' : '') + word;
                    } else {
                        if (currentLine) lines.push(currentLine);
                        currentLine = word;
                    }
                }
                
                if (currentLine) lines.push(currentLine);
                lines.push('');
            }
            
            if (lines.length > 0 && lines[lines.length - 1] === '') {
                lines.pop();
            }
            
            return lines.length > 0 ? lines : [''];
        };
        
        const padToWidth = (text, width) => {
            const visualLength = Array.from(text).length;
            if (visualLength >= width) return text;
            return text + ' '.repeat(width - visualLength);
        };
        
        const centerText = (text, width) => {
            const visualLength = Array.from(text).length;
            if (visualLength >= width) return text;
            
            const leftPadding = Math.floor((width - visualLength) / 2);
            const rightPadding = width - visualLength - leftPadding;
            
            return ' '.repeat(leftPadding) + text + ' '.repeat(rightPadding);
        };
        
        const formatDateTime = (timestamp) => {
            if (!timestamp) return 'Unknown Date';
            const date = new Date(timestamp);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        };
        
        const formatTimeOnly = (timestamp) => {
            if (!timestamp) return '--:--:--';
            const date = new Date(timestamp);
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            return `${hours}:${minutes}:${seconds}`;
        };
        
        // Calculate statistics
        const totalMessages = conversations.reduce((sum, conv) => sum + (conv.messages?.length || 0), 0);
        const scanItemsCount = scanData.items ? scanData.items.length : 0;
        const generationTime = formatDateTime(Date.now());
        
        // Build output
        let output = '';
        
        // ==================== HEADER ====================
        output += MARGIN_SPACES + DOUBLE_LINE + '\n';
        output += MARGIN_SPACES + centerText('CHAT SAVEPRO – CONVERSATION ARCHIVE', WIDTH) + '\n';
        output += MARGIN_SPACES + DOUBLE_LINE + '\n';
        output += MARGIN_SPACES + `Export Version : TXT v1.7\n`;
        output += MARGIN_SPACES + `Generated At   : ${generationTime}\n`;
        output += MARGIN_SPACES + `Conversations  : ${conversations.length}\n`;
        output += MARGIN_SPACES + `Total Messages : ${totalMessages}\n`;
        output += MARGIN_SPACES + `Scan Items     : ${scanItemsCount}\n`;
        output += MARGIN_SPACES + SINGLE_LINE + '\n\n';
        
        // ==================== CONVERSATIONS ====================
        conversations.forEach((conv, convIndex) => {
            const convNumber = convIndex + 1;
            const messageCount = conv.messages?.length || 0;
            const savedTime = formatDateTime(conv.savedAt);
            
            // Conversation header box
            output += MARGIN_SPACES + BOX_TOP + '\n';
            output += MARGIN_SPACES + '║ ' + padToWidth(`CONVERSATION #${convNumber}`, WIDTH - 4) + ' ║\n';
            output += MARGIN_SPACES + BOX_MIDDLE + '\n';
            
            // Conversation metadata
            output += MARGIN_SPACES + '║ ' + padToWidth(`Site      : ${conv.site || 'unknown'}`, WIDTH - 4) + ' ║\n';
            if (conv.title) {
                const titleLines = wordWrap(`Title     : ${conv.title}`, WIDTH - 8);
                titleLines.forEach(line => {
                    output += MARGIN_SPACES + '║ ' + padToWidth(`  ${line}`, WIDTH - 4) + ' ║\n';
                });
            }
            output += MARGIN_SPACES + '║ ' + padToWidth(`Messages  : ${messageCount}`, WIDTH - 4) + ' ║\n';
            output += MARGIN_SPACES + '║ ' + padToWidth(`Saved At  : ${savedTime}`, WIDTH - 4) + ' ║\n';
            
            if (conv.url) {
                const urlLines = wordWrap(`URL       : ${conv.url}`, WIDTH - 8);
                urlLines.forEach(line => {
                    output += MARGIN_SPACES + '║ ' + padToWidth(`  ${line}`, WIDTH - 4) + ' ║\n';
                });
            }
            
            output += MARGIN_SPACES + BOX_MIDDLE + '\n\n';
            
            // Messages
            const messages = conv.messages || [];
            messages.forEach((msg, msgIndex) => {
                const msgNumber = msgIndex + 1;
                const role = msg.role || 'unknown';
                const content = msg.content || msg.text || '';
                const timestamp = formatTimeOnly(msg.timestamp);
                
                // Message header
                const headerText = ` ${role.toUpperCase()} [${msgNumber} | ${timestamp}]`;
                output += MARGIN_SPACES + '┌─' + headerText + '─'.repeat(Math.max(0, WIDTH - headerText.length - 4)) + '┐\n';
                
                // Message content
                const contentLines = wordWrap(content, WIDTH - 6);
                contentLines.forEach(line => {
                    output += MARGIN_SPACES + '│ ' + padToWidth(line, WIDTH - 6) + ' │\n';
                });
                
                // Message footer
                output += MARGIN_SPACES + '└' + '─'.repeat(WIDTH - 2) + '┘\n\n';
            });
            
            // Separator between conversations
            if (convIndex < conversations.length - 1) {
                output += MARGIN_SPACES + SINGLE_LINE + '\n\n';
            }
        });
        
        // ==================== SCAN DATA ====================
        if (scanData.items && scanData.items.length > 0) {
            output += MARGIN_SPACES + DOUBLE_LINE + '\n';
            output += MARGIN_SPACES + centerText('SCAN DATA SUMMARY', WIDTH) + '\n';
            output += MARGIN_SPACES + SINGLE_LINE + '\n\n';
            
            scanData.items.slice(0, 20).forEach((item, index) => {
                output += MARGIN_SPACES + `Scan Item ${index + 1}:\n`;
                output += MARGIN_SPACES + `  Type: ${item.type || 'unknown'}\n`;
                output += MARGIN_SPACES + `  Time: ${formatDateTime(item.timestamp)}\n`;
                
                if (item.url) {
                    output += MARGIN_SPACES + `  URL: ${item.url}\n`;
                }
                
                output += '\n';
            });
            
            if (scanData.items.length > 20) {
                output += MARGIN_SPACES + `... and ${scanData.items.length - 20} more scan items\n\n`;
            }
        }
        
        // ==================== FOOTER ====================
        output += MARGIN_SPACES + DOUBLE_LINE + '\n';
        output += MARGIN_SPACES + centerText('END OF ARCHIVE', WIDTH) + '\n';
        output += MARGIN_SPACES + DOUBLE_LINE + '\n';
        
        return output;
    }

    static generateHTML(conversations, scanData) {
        const generationTime = new Date().toISOString();
        const totalMessages = conversations.reduce((sum, conv) => sum + (conv.messages?.length || 0), 0);
        const scanItemsCount = scanData.items ? scanData.items.length : 0;
        
        const escapeHTML = (text) => {
            if (typeof text !== 'string') return text;
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        };
        
        const formatDateTime = (timestamp) => {
            if (!timestamp) return 'Unknown';
            const date = new Date(timestamp);
            return date.toLocaleString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        };
        
        let html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatSavePro Export</title>
    <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f5f5;
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Header */
        header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .meta {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
            font-size: 0.95rem;
            opacity: 0.9;
        }
        
        .meta-item {
            background: rgba(255,255,255,0.1);
            padding: 8px 16px;
            border-radius: 20px;
        }
        
        /* Conversation Section */
        .conversation {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border: 1px solid #eaeaea;
        }
        
        .conversation-header {
            border-bottom: 2px solid #667eea;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        
        .conversation-header h2 {
            font-size: 1.5rem;
            color: #667eea;
            margin-bottom: 8px;
        }
        
        .conversation-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 0.9rem;
            color: #666;
        }
        
        /* Messages */
        .message {
            display: flex;
            margin-bottom: 20px;
            animation: fadeIn 0.3s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .message.user {
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin: 0 15px;
            flex-shrink: 0;
        }
        
        .user .message-avatar {
            background: #667eea;
            color: white;
        }
        
        .assistant .message-avatar {
            background: #10b981;
            color: white;
        }
        
        .system .message-avatar {
            background: #f59e0b;
            color: white;
        }
        
        .message-content {
            flex: 1;
            max-width: calc(100% - 70px);
        }
        
        .message-bubble {
            padding: 16px 20px;
            border-radius: 18px;
            position: relative;
            word-wrap: break-word;
        }
        
        .user .message-bubble {
            background: #667eea;
            color: white;
            border-bottom-right-radius: 4px;
        }
        
        .assistant .message-bubble {
            background: #f3f4f6;
            color: #333;
            border-bottom-left-radius: 4px;
        }
        
        .system .message-bubble {
            background: #fef3c7;
            color: #92400e;
            border-bottom-left-radius: 4px;
        }
        
        .message-info {
            display: flex;
            justify-content: space-between;
            margin-top: 6px;
            font-size: 0.85rem;
        }
        
        .user .message-info {
            flex-direction: row-reverse;
        }
        
        .role {
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .time {
            color: #999;
        }
        
        .user .time {
            color: rgba(255,255,255,0.8);
        }
        
        /* Code Blocks */
        pre {
            background: #1a202c;
            color: #e2e8f0;
            padding: 16px;
            border-radius: 8px;
            overflow-x: auto;
            margin: 10px 0;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 0.9rem;
        }
        
        code {
            background: #f1f5f9;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 0.9em;
        }
        
        pre code {
            background: none;
            padding: 0;
            border-radius: 0;
        }
        
        /* Links */
        a {
            color: #667eea;
            text-decoration: none;
        }
        
        a:hover {
            text-decoration: underline;
        }
        
        /* Footer */
        footer {
            text-align: center;
            padding: 30px;
            color: #666;
            font-size: 0.9rem;
            margin-top: 40px;
            border-top: 1px solid #eaeaea;
        }
        
        /* Print Styles */
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            header {
                background: white !important;
                color: #333;
                box-shadow: none;
            }
            
            .conversation {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }
            
            .message {
                page-break-inside: avoid;
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            h1 {
                font-size: 1.8rem;
            }
            
            .message {
                flex-direction: column;
            }
            
            .user .message {
                flex-direction: column;
            }
            
            .message-avatar {
                margin: 0 0 10px 0;
                align-self: flex-start;
            }
            
            .user .message-avatar {
                align-self: flex-end;
            }
            
            .message-content {
                max-width: 100%;
            }
            
            .meta {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>ChatSavePro Export</h1>
        <p>Conversation archive for viewing and personal use</p>
        <div class="meta">
            <div class="meta-item">Generated: ${formatDateTime(Date.now())}</div>
            <div class="meta-item">Conversations: ${conversations.length}</div>
            <div class="meta-item">Total Messages: ${totalMessages}</div>
            <div class="meta-item">Scan Items: ${scanItemsCount}</div>
        </div>
    </header>`;

        // Conversations
        conversations.forEach((conv, index) => {
            const messages = conv.messages || [];
            
            html += `
    <section class="conversation">
        <div class="conversation-header">
            <h2>Conversation #${index + 1}</h2>
            <div class="conversation-meta">
                <span>Site: ${escapeHTML(conv.site || 'Unknown')}</span>
                <span>Messages: ${messages.length}</span>
                <span>Saved: ${formatDateTime(conv.savedAt)}</span>
                ${conv.url ? `<span>URL: <a href="${escapeHTML(conv.url)}" target="_blank">${escapeHTML(conv.url)}</a></span>` : ''}
            </div>
        </div>`;
            
            messages.forEach((msg, msgIndex) => {
                const role = msg.role || 'unknown';
                const content = msg.content || msg.text || '';
                const timestamp = formatDateTime(msg.timestamp);
                
                // Check for code blocks
                const processedContent = escapeHTML(content).replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
                
                html += `
        <div class="message ${role}">
            <div class="message-avatar">${role.charAt(0).toUpperCase()}</div>
            <div class="message-content">
                <div class="message-bubble">${processedContent}</div>
                <div class="message-info">
                    <span class="role">${role}</span>
                    <span class="time">${timestamp}</span>
                </div>
            </div>
        </div>`;
            });
            
            html += `
    </section>`;
        });

        // Footer
        html += `
    <footer>
        <p>Generated by ChatSavePro • ${new Date().toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        })}</p>
        <p style="margin-top: 8px; font-size: 0.8rem; color: #888;">
            This HTML export is optimized for viewing and personal use.
        </p>
    </footer>
</body>
</html>`;
        
        return html;
    }

    static generateCSV(conversations, scanData) {
        const rows = [];
        
        rows.push(['Type', 'Conversation ID', 'Site', 'Title', 'URL', 'Saved Date', 'Message Index', 'Timestamp', 'Role', 'Content']);
        
        conversations.forEach(conv => {
            const messages = conv.messages || [];
            messages.forEach((msg, msgIndex) => {
                const timestamp = msg.timestamp ? new Date(msg.timestamp).toISOString() : '';
                const role = msg.role || '';
                const content = (msg.content || msg.text || '').replace(/"/g, '""');
                
                rows.push([
                    'Conversation',
                    conv.id,
                    conv.site,
                    conv.title || '',
                    conv.url,
                    new Date(conv.savedAt).toISOString(),
                    msgIndex + 1,
                    timestamp,
                    role,
                    `"${content}"`
                ]);
            });
        });

        if (scanData.items) {
            scanData.items.forEach((item, index) => {
                rows.push([
                    'Scan',
                    item.sessionId || '',
                    item.platform || '',
                    item.type || '',
                    item.url || '',
                    new Date(item.timestamp || Date.now()).toISOString(),
                    index + 1,
                    new Date(item.timestamp || Date.now()).toISOString(),
                    'scan',
                    `"${JSON.stringify(item.data || {}).replace(/"/g, '""')}"`
                ]);
            });
        }

        return rows.map(row => row.join(',')).join('\n');
    }
}

export class ExportManager {
    constructor() {
        this.MODULE_NAME = 'ExportManager';
        this.MODULE_VERSION = '3.2.0';
        
        this.logger = new ExportLogger(this.MODULE_NAME);
        this.pipeline = new ExportPipeline();
        this.sessionManager = new ExportSessionManager();
        this.initialized = false;

        this.config = {
            maxFileSize: 10 * 1024 * 1024,
            timeout: 30000,
            cleanupInterval: 10 * 60 * 1000,
            supportedFormats: ['txt', 'json', 'csv', 'html', 'pdf', 'docx'],
            defaultFormat: 'txt'
        };

        this.metrics = {
            exports: { total: 0, successful: 0, failed: 0 },
            formats: new Map(),
            performance: new Map()
        };

        this.userIsPro = false;

        this._startCleanupInterval();
    }

    async init() {
        if (this.initialized) return true;
        
        try {
            await this._loadConfiguration();
            
            await this._checkUserPlan();
            
            this.logger.log('INFO', 'ExportManager initialized', {
                version: this.MODULE_VERSION,
                config: this.config,
                userIsPro: this.userIsPro
            });

            this.initialized = true;
            return true;

        } catch (error) {
            this.logger.log('ERROR', 'ExportManager initialization failed', {
                error: error.message
            });
            throw error;
        }
    }

    async _loadConfiguration() {
        return new Promise((resolve) => {
            try {
                chrome.storage.local.get(['exportConfig'], (result) => {
                    if (chrome.runtime.lastError) {
                        console.warn('Storage access failed, using default config');
                    } else if (result.exportConfig) {
                        this.config = { ...this.config, ...result.exportConfig };
                    }
                    resolve();
                });
            } catch (error) {
                console.warn('Config loading failed, using defaults');
                resolve();
            }
        });
    }

    async _checkUserPlan() {
        return new Promise((resolve) => {
            try {
                chrome.storage.local.get(['userPlan'], (result) => {
                    if (result.userPlan === 'pro' || result.userPlan === 'premium') {
                        this.userIsPro = true;
                        console.log('✅ User is Pro, PDF export enabled');
                    } else {
                        this.userIsPro = false;
                        console.log('⚠️ User is Free, PDF export disabled');
                    }
                    resolve();
                });
            } catch (error) {
                console.warn('User plan check failed, assuming Free user');
                this.userIsPro = false;
                resolve();
            }
        });
    }

    _startCleanupInterval() {
        if (typeof setInterval !== 'undefined') {
            setInterval(() => {
                this._cleanupExpiredSessions();
            }, this.config.cleanupInterval);
        }
    }

    _cleanupExpiredSessions() {
        const cleanedCount = this.sessionManager.cleanupExpiredSessions(this.config.timeout * 2);
        
        if (cleanedCount > 0) {
            this.logger.log('INFO', 'Expired export sessions cleaned', {
                count: cleanedCount
            });
        }
    }

    _validateExportRequest(request) {
        const schema = EXPORT_SCHEMA.EXPORT_REQUEST;
        
        schema.required.forEach(field => {
            if (!(field in request)) {
                throw new Error(`Missing required field '${field}' in export request`);
            }
        });

        if (!this.config.supportedFormats.includes(request.format)) {
            throw new Error(`Unsupported export format: ${request.format}. Supported: ${this.config.supportedFormats.join(', ')}`);
        }

        if (request.format === 'pdf' && !this.userIsPro) {
            throw new Error('PRO_ONLY_FEATURE: PDF export is only available in the Pro version. Please upgrade to access PDF export features.');
        }

        return true;
    }

    _validateExportResult(result) {
        const schema = EXPORT_SCHEMA.EXPORT_RESULT;
        
        schema.required.forEach(field => {
            if (!(field in result)) {
                throw new Error(`Missing required field '${field}' in export result`);
            }
        });

        return true;
    }

    async exportConversations(filters = {}, format = 'txt') {
        if (!this.initialized) {
            await this.init();
        }

        const exportId = this._generateExportId();
        const startTime = Date.now();

        this.logger.log('INFO', 'Export conversations started', {
            exportId,
            format,
            filters,
            userIsPro: this.userIsPro
        });

        return this.pipeline.executeWithRetry(async () => {
            try {
                const request = { format, filters };
                this._validateExportRequest(request);
                
                const session = this.sessionManager.createExportSession(exportId, format, filters);
                
                const { conversations, scanData } = await this._loadRealData(filters);
                
                if (conversations.length === 0 && (!scanData.items || scanData.items.length === 0)) {
                    throw new Error('No data found to export');
                }
                
                const exportResult = await this._generateExportOutput(format, conversations, scanData, session);
                this._validateExportResult(exportResult);
                
                const savedResult = this.sessionManager.saveExportResult(exportId, exportResult);
                
                this.sessionManager.updateExportSession(exportId, {
                    status: 'completed',
                    completedAt: Date.now(),
                    conversationCount: conversations.length,
                    scanItemCount: scanData.items ? scanData.items.length : 0
                });

                this.metrics.exports.total++;
                this.metrics.exports.successful++;
                
                if (!this.metrics.formats.has(format)) {
                    this.metrics.formats.set(format, 0);
                }
                this.metrics.formats.set(format, this.metrics.formats.get(format) + 1);

                const duration = Date.now() - startTime;
                this.metrics.performance.set(exportId, duration);

                this.logger.log('INFO', 'Export completed', {
                    exportId,
                    format,
                    duration,
                    conversationCount: conversations.length,
                    scanItemCount: scanData.items ? scanData.items.length : 0,
                    fileSize: exportResult.fileSize
                });

                return savedResult;

            } catch (error) {
                const duration = Date.now() - startTime;
                this.metrics.exports.total++;
                this.metrics.exports.failed++;
                
                this.sessionManager.updateExportSession(exportId, {
                    status: 'failed',
                    error: error.message,
                    completedAt: Date.now()
                });

                this.logger.log('ERROR', 'Export failed', {
                    exportId,
                    format,
                    error: error.message,
                    duration
                });
                
                throw this._enhanceError(error, 'exportConversations', exportId);
            }
        }, 'exportConversations');
    }

    async _loadRealData(filters = {}) {
        return new Promise((resolve, reject) => {
            try {
                chrome.storage.local.get(null, (allData) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(`Storage error: ${chrome.runtime.lastError.message}`));
                        return;
                    }

                    console.log(`📊 [ExportManager] Total storage keys: ${Object.keys(allData).length}`);
                    
                    const savedConversations = allData.savedConversations || [];
                    console.log(`📊 [ExportManager] Saved conversations: ${savedConversations.length}`);
                    
                    let filteredConversations = [...savedConversations];
                    
                    if (filters.site) {
                        filteredConversations = filteredConversations.filter(
                            conv => conv.site === filters.site
                        );
                    }
                    
                    if (filters.since) {
                        filteredConversations = filteredConversations.filter(
                            conv => conv.savedAt >= filters.since
                        );
                    }
                    
                    if (filters.startDate && filters.endDate) {
                        filteredConversations = filteredConversations.filter(
                            conv => conv.savedAt >= filters.startDate && conv.savedAt <= filters.endDate
                        );
                    }
                    
                    if (filters.limit && filteredConversations.length > filters.limit) {
                        filteredConversations = filteredConversations.slice(0, filters.limit);
                    }
                    
                    filteredConversations.sort((a, b) => b.savedAt - a.savedAt);
                    
                    const scanData = {
                        items: [],
                        scanType: 'merged',
                        lastScan: Date.now()
                    };
                    
                    Object.keys(allData).forEach(key => {
                        if (key.startsWith('deep_')) {
                            const deepScan = allData[key];
                            if (Array.isArray(deepScan)) {
                                deepScan.forEach(item => {
                                    scanData.items.push({
                                        ...item,
                                        type: 'deep_scan',
                                        sourceKey: key,
                                        timestamp: item.timestamp || Date.now()
                                    });
                                });
                            } else if (deepScan && deepScan.items && Array.isArray(deepScan.items)) {
                                deepScan.items.forEach(item => {
                                    scanData.items.push({
                                        ...item,
                                        type: 'deep_scan',
                                        sourceKey: key,
                                        timestamp: item.timestamp || Date.now()
                                    });
                                });
                            }
                        } else if (key.startsWith('live_')) {
                            const liveScan = allData[key];
                            if (liveScan && liveScan.data) {
                                scanData.items.push({
                                    data: liveScan.data,
                                    type: 'live_scan',
                                    sourceKey: key,
                                    timestamp: liveScan.timestamp || Date.now(),
                                    sessionId: liveScan.sessionId
                                });
                            }
                        }
                    });
                    
                    console.log(`📊 [ExportManager] Scan items found: ${scanData.items.length}`);
                    console.log(`📊 [ExportManager] Filtered conversations: ${filteredConversations.length}`);
                    
                    resolve({
                        conversations: filteredConversations,
                        scanData: scanData
                    });
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    async _generateExportOutput(format, conversations, scanData, session) {
        console.error('🧨 _generateExportOutput CALLED', { format });
        
        let content, mimeType, fileName;
        const dateStr = new Date().toISOString().slice(0, 10);
        const timeStr = new Date().toISOString().slice(11, 19).replace(/:/g, '-');
        
        switch (format.toLowerCase()) {
            case 'txt':
                console.error('🧨 TXT BRANCH HIT - format is', format);
                console.error('🧨 ABOUT TO CALL ExportFormatHelpers.generateText');
                content = ExportFormatHelpers.generateText(conversations, scanData);
                mimeType = 'text/plain';
                fileName = `chatsavepro_export_${dateStr}_${timeStr}.txt`;
                break;
                
            case 'json':
                content = ExportFormatHelpers.generateJSON(conversations, scanData);
                mimeType = 'application/json';
                fileName = `chatsavepro_export_${dateStr}_${timeStr}.json`;
                break;
                
            case 'html':
                content = ExportFormatHelpers.generateHTML(conversations, scanData);
                mimeType = 'text/html';
                fileName = `chatsavepro_export_${dateStr}_${timeStr}.html`;
                break;
                
            case 'csv':
                content = ExportFormatHelpers.generateCSV(conversations, scanData);
                mimeType = 'text/csv';
                fileName = `chatsavepro_export_${dateStr}_${timeStr}.csv`;
                break;
                
            case 'pdf':
                if (!this.userIsPro) {
                    throw new Error('PRO_ONLY_FEATURE: PDF export is only available in the Pro version. Please upgrade to access PDF export features.');
                }
                
                if (typeof PDFExporter !== 'undefined') {
                    try {
                        const pdfResult = await PDFExporter.exportConversations(conversations, scanData, session.options);
                        return {
                            success: true,
                            format: 'pdf',
                            blob: pdfResult.blob,
                            mimeType: 'application/pdf',
                            fileName: pdfResult.fileName || `chatsavepro_export_${dateStr}_${timeStr}.pdf`,
                            fileSize: pdfResult.blob.size,
                            conversationCount: conversations.length,
                            scanItemCount: scanData.items ? scanData.items.length : 0
                        };
                    } catch (pdfError) {
                        console.warn('PDFExporter failed, falling back to HTML:', pdfError.message);
                        content = ExportFormatHelpers.generateHTML(conversations, scanData);
                        mimeType = 'application/pdf';
                        fileName = `chatsavepro_export_${dateStr}_${timeStr}.pdf`;
                    }
                } else {
                    content = ExportFormatHelpers.generateHTML(conversations, scanData);
                    mimeType = 'application/pdf';
                    fileName = `chatsavepro_export_${dateStr}_${timeStr}.pdf`;
                }
                break;
                
            case 'docx':
                if (typeof MultiFormatExporter !== 'undefined') {
                    try {
                        const docxResult = await MultiFormatExporter.exportToDOCX(conversations, scanData, session.options);
                        return {
                            success: true,
                            format: 'docx',
                            blob: docxResult.blob,
                            mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            fileName: docxResult.fileName || `chatsavepro_export_${dateStr}_${timeStr}.docx`,
                            fileSize: docxResult.blob.size,
                            conversationCount: conversations.length,
                            scanItemCount: scanData.items ? scanData.items.length : 0
                        };
                    } catch (docxError) {
                        console.warn('MultiFormatExporter failed, falling back to HTML:', docxError.message);
                        content = ExportFormatHelpers.generateHTML(conversations, scanData);
                        mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
                        fileName = `chatsavepro_export_${dateStr}_${timeStr}.docx`;
                    }
                } else {
                    content = ExportFormatHelpers.generateHTML(conversations, scanData);
                    mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
                    fileName = `chatsavepro_export_${dateStr}_${timeStr}.docx`;
                }
                break;
                
            default:
                throw new Error(`Unsupported export format: ${format}`);
        }
        
        const blob = new Blob([content], { type: mimeType });
        
        return {
            success: true,
            format: format,
            blob: blob,
            mimeType: mimeType,
            fileName: fileName,
            fileSize: blob.size,
            conversationCount: conversations.length,
            scanItemCount: scanData.items ? scanData.items.length : 0
        };
    }

    async export(format = 'txt', filters = {}) {
        return await this.exportConversations(filters, format);
    }

    async exportData(data, format = 'txt', options = {}) {
        console.warn('exportData() is deprecated. Use exportConversations() instead.');
        return await this.exportConversations({}, format);
    }

    async exportToPDF(filters = {}) {
        return await this.exportConversations(filters, 'pdf');
    }

    async exportToJSON(filters = {}) {
        return await this.exportConversations(filters, 'json');
    }

    async exportToHTML(filters = {}) {
        return await this.exportConversations(filters, 'html');
    }

    async exportToCSV(filters = {}) {
        return await this.exportConversations(filters, 'csv');
    }

    async exportToTXT(filters = {}) {
        return await this.exportConversations(filters, 'txt');
    }

    async exportToDOCX(filters = {}) {
        return await this.exportConversations(filters, 'docx');
    }

    _generateExportId() {
        return `export_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    _enhanceError(error, context, id) {
        const enhanced = new Error(`[${this.MODULE_NAME}:${context}] ${error.message}`);
        enhanced.originalError = error;
        enhanced.context = context;
        enhanced.operationId = id;
        return enhanced;
    }

    getExportStatus(exportId) {
        const session = this.sessionManager.getExportSession(exportId);
        const result = this.sessionManager.getExportResult(exportId);

        if (!session) {
            return { found: false };
        }

        return {
            found: true,
            exportId: session.exportId,
            format: session.format,
            status: session.status,
            startTime: session.startTime,
            result: result || null
        };
    }

    getMetrics() {
        const formatStats = {};
        this.metrics.formats.forEach((count, format) => {
            formatStats[format] = count;
        });

        const performanceArray = Array.from(this.metrics.performance.values());
        const avgPerformance = performanceArray.length > 0 
            ? performanceArray.reduce((a, b) => a + b, 0) / performanceArray.length 
            : 0;

        return {
            exports: { ...this.metrics.exports },
            formats: formatStats,
            performance: {
                averageTime: avgPerformance,
                totalExports: performanceArray.length
            },
            currentSessions: this.sessionManager.exportSessions.size,
            initialized: this.initialized,
            userIsPro: this.userIsPro
        };
    }

    getLogs(limit = 20) {
        return this.logger.getLogs(limit);
    }

    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        
        try {
            chrome.storage.local.set({ exportConfig: this.config });
        } catch (error) {
            console.warn('Failed to save config to storage');
        }
        
        this.logger.log('INFO', 'Configuration updated', { config: this.config });
        return this.config;
    }

    destroy() {
        this.sessionManager.exportSessions.clear();
        this.sessionManager.exportResults.clear();
        
        this.logger.log('INFO', 'ExportManager destroyed');
    }

    static get version() {
        return '3.2.0';
    }
}

export default ExportManager;

console.log('✅ ExportManager loaded - REAL DATA EXPORT ENABLED');