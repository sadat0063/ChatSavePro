// ============================================================
// modules/MemorySegmentManager.js - PRINCIPLE 7: MEMORY SEGMENTATION
// ============================================================

export class MemorySegmentManager {
    constructor() {
        this.segments = new Map();
        this.quotas = new Map();
        this.accessLog = new Map();
        this.initialized = false;
        
        this.DEFAULT_CONFIG = Object.freeze({
            MAX_SEGMENT_SIZE: 1000,
            DEFAULT_TTL: 300000, // 5 minutes
            CLEANUP_INTERVAL: 60000, // 1 minute
            ACCESS_LOG_SIZE: 100
        });
        
        this.init();
    }

    init() {
        if (this.initialized) return;
        
        // ایجاد سگمنت‌های اصلی
        this.createSegment('cache', {
            maxSize: 500,
            defaultTTL: 300000, // 5 minutes
            persistent: false
        });

        this.createSegment('session', {
            maxSize: 200,
            defaultTTL: 1800000, // 30 minutes
            persistent: true
        });

        this.createSegment('metrics', {
            maxSize: 1000,
            defaultTTL: 3600000, // 1 hour
            persistent: true
        });

        this.createSegment('security', {
            maxSize: 100,
            defaultTTL: 900000, // 15 minutes
            persistent: true
        });

        this.createSegment('temporary', {
            maxSize: 50,
            defaultTTL: 60000, // 1 minute
            persistent: false
        });

        // شروع نظافت دوره‌ای
        this.startCleanupInterval();
        
        this.initialized = true;
        console.log('✅ MemorySegmentManager initialized');
    }

    createSegment(name, config = {}) {
        const segmentConfig = {
            maxSize: config.maxSize || this.DEFAULT_CONFIG.MAX_SEGMENT_SIZE,
            defaultTTL: config.defaultTTL || this.DEFAULT_CONFIG.DEFAULT_TTL,
            persistent: config.persistent || false,
            data: new Map(),
            createdAt: Date.now(),
            accessCount: 0
        };

        this.segments.set(name, segmentConfig);
        this.accessLog.set(name, []);
        
        console.log(`📦 Segment created: ${name}`, {
            maxSize: segmentConfig.maxSize,
            ttl: segmentConfig.defaultTTL
        });
    }

    set(segmentName, key, value, ttl = null) {
        if (!this.segments.has(segmentName)) {
            throw new Error(`Segment not found: ${segmentName}`);
        }

        const segment = this.segments.get(segmentName);
        const actualTTL = ttl || segment.defaultTTL;

        // بررسی سایز
        if (segment.data.size >= segment.maxSize) {
            this.evictOldest(segmentName);
        }

        const entry = {
            value: this.sanitizeValue(value),
            timestamp: Date.now(),
            ttl: actualTTL,
            accessCount: 0,
            lastAccess: Date.now()
        };

        segment.data.set(key, entry);
        this.logAccess(segmentName, 'SET', key);
        
        return true;
    }

    get(segmentName, key) {
        if (!this.segments.has(segmentName)) {
            return null;
        }

        const segment = this.segments.get(segmentName);
        const entry = segment.data.get(key);

        if (!entry) {
            return null;
        }

        // بررسی انقضا
        if (this.isExpired(entry)) {
            segment.data.delete(key);
            this.logAccess(segmentName, 'EXPIRED', key);
            return null;
        }

        // آپدیت آمار دسترسی
        entry.accessCount++;
        entry.lastAccess = Date.now();
        segment.accessCount++;

        this.logAccess(segmentName, 'GET', key);
        return entry.value;
    }

    has(segmentName, key) {
        if (!this.segments.has(segmentName)) {
            return false;
        }

        const segment = this.segments.get(segmentName);
        const entry = segment.data.get(key);

        if (!entry) return false;

        if (this.isExpired(entry)) {
            segment.data.delete(key);
            return false;
        }

        return true;
    }

    delete(segmentName, key) {
        if (!this.segments.has(segmentName)) {
            return false;
        }

        const segment = this.segments.get(segmentName);
        const deleted = segment.data.delete(key);
        
        if (deleted) {
            this.logAccess(segmentName, 'DELETE', key);
        }
        
        return deleted;
    }

    clearSegment(segmentName) {
        if (!this.segments.has(segmentName)) {
            return false;
        }

        const segment = this.segments.get(segmentName);
        const size = segment.data.size;
        segment.data.clear();
        segment.accessCount = 0;
        
        this.logAccess(segmentName, 'CLEAR', `cleared ${size} entries`);
        return true;
    }

    clearAll() {
        for (const [name, segment] of this.segments) {
            segment.data.clear();
            segment.accessCount = 0;
            this.logAccess(name, 'CLEAR_ALL', 'all segments cleared');
        }
        console.log('🧹 All memory segments cleared');
    }

    // utility methods
    isExpired(entry) {
        return entry.ttl && (Date.now() - entry.timestamp > entry.ttl);
    }

    evictOldest(segmentName) {
        const segment = this.segments.get(segmentName);
        let oldestKey = null;
        let oldestTime = Date.now();

        for (const [key, entry] of segment.data) {
            if (entry.lastAccess < oldestTime) {
                oldestTime = entry.lastAccess;
                oldestKey = key;
            }
        }

        if (oldestKey) {
            segment.data.delete(oldestKey);
            this.logAccess(segmentName, 'EVICTED', oldestKey);
        }
    }

    sanitizeValue(value) {
        // ساده‌ترین فرم سانیتیزیشن
        if (typeof value === 'string') {
            return value.substring(0, 10000);
        }
        return value;
    }

    logAccess(segmentName, operation, key) {
        if (!this.accessLog.has(segmentName)) {
            this.accessLog.set(segmentName, []);
        }

        const log = this.accessLog.get(segmentName);
        log.push({
            timestamp: Date.now(),
            operation,
            key: typeof key === 'string' ? key : String(key),
            segment: segmentName
        });

        // محدودیت سایز لاگ
        if (log.length > this.DEFAULT_CONFIG.ACCESS_LOG_SIZE) {
            log.shift();
        }
    }

    startCleanupInterval() {
        setInterval(() => {
            this.cleanupExpired();
        }, this.DEFAULT_CONFIG.CLEANUP_INTERVAL);
    }

    cleanupExpired() {
        const now = Date.now();
        let totalCleaned = 0;

        for (const [segmentName, segment] of this.segments) {
            for (const [key, entry] of segment.data) {
                if (this.isExpired(entry)) {
                    segment.data.delete(key);
                    totalCleaned++;
                }
            }
        }

        if (totalCleaned > 0) {
            console.log(`🧹 Cleaned ${totalCleaned} expired entries from memory segments`);
        }
    }

    // آمار و گزارش‌ها
    getSegmentStats(segmentName = null) {
        if (segmentName) {
            if (!this.segments.has(segmentName)) return null;
            
            const segment = this.segments.get(segmentName);
            return {
                name: segmentName,
                size: segment.data.size,
                maxSize: segment.maxSize,
                accessCount: segment.accessCount,
                usagePercent: Math.round((segment.data.size / segment.maxSize) * 100),
                createdAt: segment.createdAt
            };
        }

        const stats = {};
        for (const [name, segment] of this.segments) {
            stats[name] = {
                size: segment.data.size,
                maxSize: segment.maxSize,
                accessCount: segment.accessCount,
                usagePercent: Math.round((segment.data.size / segment.maxSize) * 100)
            };
        }
        
        return stats;
    }

    getAccessLog(segmentName = null, limit = 20) {
        if (segmentName) {
            const log = this.accessLog.get(segmentName) || [];
            return log.slice(-limit);
        }

        const allLogs = [];
        for (const [name, log] of this.accessLog) {
            allLogs.push(...log.slice(-limit));
        }
        
        return allLogs.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    }

    // مدیریت کووتا
    setQuota(segmentName, maxSize) {
        if (!this.segments.has(segmentName)) {
            throw new Error(`Segment not found: ${segmentName}`);
        }

        const segment = this.segments.get(segmentName);
        segment.maxSize = maxSize;
        this.quotas.set(segmentName, maxSize);

        // اگر سایز فعلی بیشتر از کووتای جدید است، قدیمی‌ها را حذف کن
        while (segment.data.size > maxSize) {
            this.evictOldest(segmentName);
        }

        console.log(`📊 Quota set for ${segmentName}: ${maxSize}`);
    }

    // سلامت سگمنت‌ها
    healthCheck() {
        const report = {
            status: 'healthy',
            segments: {},
            totalUsage: 0,
            timestamp: Date.now()
        };

        for (const [name, segment] of this.segments) {
            const usagePercent = Math.round((segment.data.size / segment.maxSize) * 100);
            report.segments[name] = {
                size: segment.data.size,
                maxSize: segment.maxSize,
                usagePercent,
                status: usagePercent > 90 ? 'critical' : usagePercent > 70 ? 'warning' : 'healthy'
            };

            report.totalUsage += usagePercent;

            if (usagePercent > 90) {
                report.status = 'critical';
            } else if (usagePercent > 70 && report.status === 'healthy') {
                report.status = 'warning';
            }
        }

        report.totalUsage = Math.round(report.totalUsage / this.segments.size);
        return report;
    }

    destroy() {
        this.clearAll();
        this.segments.clear();
        this.accessLog.clear();
        this.quotas.clear();
        console.log('🧹 MemorySegmentManager destroyed');
    }
}

// Singleton instance
let memoryManagerInstance = null;

export function getMemorySegmentManager() {
    if (!memoryManagerInstance) {
        memoryManagerInstance = new MemorySegmentManager();
    }
    return memoryManagerInstance;
}

export default MemorySegmentManager;