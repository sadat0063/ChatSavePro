// modules/debug-mode.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles & Manifest V3

// ✅ Principle 2: Strict Interface Contract
const DEBUG_SCHEMA = {
    TEST_DATA: {
        required: ['id', 'title', 'url', 'timestamp'],
        optional: ['snippet', 'metadata']
    },
    MESSAGE_LOG: {
        required: ['direction', 'target', 'timestamp'],
        optional: ['message', 'response', 'duration']
    }
};

// ✅ Principle 9: Secure Logging & Sanitization
class DebugLogger {
    constructor() {
        this.maxLogEntries = 100;
        this.logEntries = [];
    }

    log(level, context, data = {}) {
        const logEntry = {
            id: `debug_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            level,
            context: this.sanitize(context),
            data: this.sanitize(data)
        };

        this.logEntries.push(logEntry);

        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        // Send to background for centralized logging
        chrome.runtime.sendMessage({
            type: 'DEBUG_LOG',
            payload: logEntry
        }).catch(() => {
            // Fallback to local storage
            chrome.storage.local.set({
                [`debug_log_${logEntry.id}`]: logEntry
            });
        });

        return logEntry;
    }

    sanitize(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return JSON.parse(JSON.stringify(input));
    }

    getLogs(limit = 20) {
        return this.logEntries.slice(-limit);
    }

    clear() {
        this.logEntries = [];
    }
}

// ✅ Principle 7: Async Pipeline & Resilience
class DebugPipeline {
    constructor() {
        this.timeout = 5000;
    }

    async executeWithTimeout(operation, operationName) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Debug operation ${operationName} timeout after ${this.timeout}ms`));
            }, this.timeout);
            
            Promise.resolve(operation())
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }
}

// ✅ Main ES6 Module Class
export class DebugMode {
    constructor() {
        this.MODULE_NAME = 'DebugMode';
        this.MODULE_VERSION = 'R8.1.0';
        
        this.logger = new DebugLogger();
        this.pipeline = new DebugPipeline();
        
        this.isEnabled = false;
        this.originalMethods = new Map();
        
        this.#initialize();
    }

    // ✅ Private methods for encapsulation
    async #initialize() {
        try {
            await this.#loadConfiguration();
            this.logger.log('INFO', 'DebugMode initialized', {
                version: this.MODULE_VERSION,
                enabled: this.isEnabled
            });
        } catch (error) {
            this.logger.log('ERROR', 'DebugMode initialization failed', {
                error: error.message
            });
        }
    }

    async #loadConfiguration() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['debugEnabled'], (result) => {
                this.isEnabled = result.debugEnabled || false;
                resolve();
            });
        });
    }

    async #saveConfiguration() {
        return new Promise((resolve) => {
            chrome.storage.local.set({ debugEnabled: this.isEnabled }, () => {
                resolve();
            });
        });
    }

    // ✅ Principle 2: Strict Interface Contract
    #validateTestData(data) {
        const schema = DEBUG_SCHEMA.TEST_DATA;
        
        schema.required.forEach(field => {
            if (!(field in data)) {
                throw new Error(`Missing required field '${field}' in test data`);
            }
        });

        return true;
    }

    // ✅ Public API Methods
    async enable() {
        if (this.isEnabled) {
            this.logger.log('WARN', 'DebugMode already enabled');
            return;
        }

        try {
            await this.pipeline.executeWithTimeout(async () => {
                // Set global debug flag
                this.isEnabled = true;
                await this.#saveConfiguration();

                // Wrap module communication if available
                await this.#wrapModuleCommunication();

                this.logger.log('INFO', 'DebugMode enabled', {
                    timestamp: new Date().toISOString(),
                    features: ['message_logging', 'performance_monitoring']
                });

                console.log('🔧 Debug mode enabled (MV3‑Safe)');
            }, 'enable_debug_mode');

        } catch (error) {
            this.logger.log('ERROR', 'DebugMode enable failed', {
                error: error.message
            });
            throw error;
        }
    }

    async disable() {
        if (!this.isEnabled) {
            this.logger.log('WARN', 'DebugMode already disabled');
            return;
        }

        try {
            await this.pipeline.executeWithTimeout(async () => {
                // Restore original methods
                await this.#restoreOriginalMethods();

                this.isEnabled = false;
                await this.#saveConfiguration();

                this.logger.log('INFO', 'DebugMode disabled', {
                    timestamp: new Date().toISOString()
                });

                console.log('🔧 Debug mode disabled');
            }, 'disable_debug_mode');

        } catch (error) {
            this.logger.log('ERROR', 'DebugMode disable failed', {
                error: error.message
            });
            throw error;
        }
    }

    async #wrapModuleCommunication() {
        // ✅ Law 2: No Remote Code Execution - Safe method wrapping
        if (typeof self !== 'undefined' && self.moduleBridge?.sendToModule) {
            const originalSend = self.moduleBridge.sendToModule;
            
            this.originalMethods.set('sendToModule', originalSend);

            self.moduleBridge.sendToModule = async (target, message) => {
                const startTime = performance.now();
                
                this.logger.log('DEBUG', 'Module message sent', {
                    direction: 'outgoing',
                    target,
                    message: this.#sanitizeMessage(message)
                });

                try {
                    const result = await originalSend.call(self.moduleBridge, target, message);
                    const duration = performance.now() - startTime;

                    this.logger.log('DEBUG', 'Module response received', {
                        direction: 'incoming',
                        target,
                        response: this.#sanitizeMessage(result),
                        duration
                    });

                    return result;
                } catch (error) {
                    const duration = performance.now() - startTime;
                    
                    this.logger.log('ERROR', 'Module communication failed', {
                        target,
                        error: error.message,
                        duration
                    });
                    
                    throw error;
                }
            };
        } else {
            this.logger.log('WARN', 'ModuleBridge not available for debugging');
        }
    }

    async #restoreOriginalMethods() {
        // Restore original methods
        if (this.originalMethods.has('sendToModule') && self.moduleBridge) {
            self.moduleBridge.sendToModule = this.originalMethods.get('sendToModule');
            this.originalMethods.delete('sendToModule');
        }
    }

    #sanitizeMessage(message) {
        // Remove sensitive data from logs
        const sanitized = { ...message };
        
        if (sanitized.content) {
            sanitized.content = '[CONTENT_REDACTED]';
        }
        
        if (sanitized.data) {
            sanitized.data = typeof sanitized.data === 'object' ? 
                { ...sanitized.data, content: '[DATA_REDACTED]' } : 
                '[DATA_REDACTED]';
        }
        
        return sanitized;
    }

    async simulateTestData() {
        try {
            await this.pipeline.executeWithTimeout(async () => {
                const testData = [
                    {
                        id: 1,
                        title: 'Test Page 1',
                        url: 'https://example.com/page1',
                        timestamp: Date.now() - 1000000,
                        snippet: 'This is a test snippet for debugging purposes',
                        metadata: {
                            debug: true,
                            version: this.MODULE_VERSION
                        }
                    },
                    {
                        id: 2,
                        title: 'Test Page 2',
                        url: 'https://example.com/page2',
                        timestamp: Date.now() - 500000,
                        snippet: 'Another test snippet for the debug mode',
                        metadata: {
                            debug: true,
                            version: this.MODULE_VERSION
                        }
                    }
                ];

                // Validate test data
                testData.forEach(data => this.#validateTestData(data));

                // ✅ Law 3: Storage Isolation - Use chrome.storage.local
                await new Promise((resolve, reject) => {
                    chrome.storage.local.set({ debugTestData: testData }, () => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve();
                        }
                    });
                });

                this.logger.log('INFO', 'Test data generated', {
                    itemCount: testData.length,
                    dataSize: JSON.stringify(testData).length
                });

                console.log('🧪 Test data stored in chrome.storage.local:', testData);

            }, 'simulate_test_data');

        } catch (error) {
            this.logger.log('ERROR', 'Test data simulation failed', {
                error: error.message
            });
            throw error;
        }
    }

    async clearTestData() {
        try {
            await this.pipeline.executeWithTimeout(async () => {
                await new Promise((resolve, reject) => {
                    chrome.storage.local.remove(['debugTestData'], () => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve();
                        }
                    });
                });

                this.logger.log('INFO', 'Test data cleared');
                console.log('🧪 Test data cleared from storage');

            }, 'clear_test_data');

        } catch (error) {
            this.logger.log('ERROR', 'Test data clearance failed', {
                error: error.message
            });
            throw error;
        }
    }

    async runSelfTest() {
        const testResults = {
            timestamp: Date.now(),
            basic: {},
            features: {},
            performance: {}
        };

        try {
            // Basic functionality tests
            testResults.basic.initialization = true;
            testResults.basic.logging = this.logger !== null;
            testResults.basic.configuration = await this.#testConfiguration();

            // Feature tests
            testResults.features.moduleWrapping = this.originalMethods.size > 0;
            testResults.features.storageAccess = await this.#testStorageAccess();

            // Performance tests
            testResults.performance.loggingSpeed = await this.#testLoggingPerformance();

            this.logger.log('INFO', 'Self-test completed', testResults);
            return testResults;

        } catch (error) {
            this.logger.log('ERROR', 'Self-test failed', {
                error: error.message
            });
            testResults.error = error.message;
            return testResults;
        }
    }

    async #testConfiguration() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['debugEnabled'], (result) => {
                resolve(typeof result.debugEnabled !== 'undefined');
            });
        });
    }

    async #testStorageAccess() {
        return new Promise((resolve) => {
            chrome.storage.local.set({ debugTest: 'test' }, () => {
                if (chrome.runtime.lastError) {
                    resolve(false);
                } else {
                    chrome.storage.local.remove(['debugTest'], () => {
                        resolve(true);
                    });
                }
            });
        });
    }

    async #testLoggingPerformance() {
        const startTime = performance.now();
        
        for (let i = 0; i < 10; i++) {
            this.logger.log('DEBUG', 'Performance test', { iteration: i });
        }
        
        return performance.now() - startTime;
    }

    // ✅ Public API
    getStatus() {
        return {
            enabled: this.isEnabled,
            version: this.MODULE_VERSION,
            logsCount: this.logger.logEntries.length,
            wrappedMethods: Array.from(this.originalMethods.keys())
        };
    }

    getLogs(limit = 20) {
        return this.logger.getLogs(limit);
    }

    clearLogs() {
        this.logger.clear();
    }

    toggle() {
        return this.isEnabled ? this.disable() : this.enable();
    }

    // ✅ Safe destruction
    destroy() {
        this.#restoreOriginalMethods();
        this.logger.clear();
        this.originalMethods.clear();
        
        this.logger.log('INFO', 'DebugMode destroyed');
    }

    static get version() {
        return 'R8.1.0';
    }
}

// ✅ Default export
export default DebugMode;