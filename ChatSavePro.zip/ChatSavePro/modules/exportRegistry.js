// modules/exportRegistry.js - نسخه اصلاح شده بدون export تکراری

const GLOBAL_KEY = "__EXPORT_RENDERERS__";

if (!globalThis[GLOBAL_KEY]) {
  globalThis[GLOBAL_KEY] = new Map();
  console.log("[EXPORT_REGISTRY] 🆕 Global export registry created");
}

const renderers = globalThis[GLOBAL_KEY];

// تابع‌های کمکی - فقط export می‌کنیم، duplicate export نمی‌کنیم
function registerExportRenderer(format, handler) {
  if (!format || typeof handler !== "function") {
    throw new Error("[EXPORT_REGISTRY] Invalid renderer registration");
  }

  const key = format.toLowerCase();
  renderers.set(key, handler);

  console.log(`[EXPORT_REGISTRY] ✅ Renderer registered: ${key}`);
  return true;
}

function getExportRenderer(format) {
  return renderers.get(format?.toLowerCase());
}

function hasExportRenderer(format) {
  return renderers.has(format?.toLowerCase());
}

function getSupportedExportFormats() {
  return Array.from(renderers.keys());
}

// ==================== کلاس اصلی ExportRegistry ====================
class ExportRegistry {
  static register(format, handler) {
    return registerExportRenderer(format, handler);
  }

  static render(format, data) {
    const renderer = getExportRenderer(format);
    if (!renderer) {
      throw new Error(`[ExportRegistry] No renderer registered for format: ${format}`);
    }
    
    console.log(`[ExportRegistry] 🎨 Rendering ${format} with data:`, {
      conversations: data?.conversations?.length || 0,
      options: data?.options || {}
    });
    
    try {
      const result = renderer(data);
      console.log(`[ExportRegistry] ✅ ${format} render completed successfully`);
      return result;
    } catch (error) {
      console.error(`[ExportRegistry] ❌ ${format} render failed:`, error);
      throw new Error(`Render failed for format ${format}: ${error.message}`);
    }
  }

  static getRenderer(format) {
    return getExportRenderer(format);
  }

  static hasRenderer(format) {
    return hasExportRenderer(format);
  }

  static getSupportedFormats() {
    return getSupportedExportFormats();
  }

  static getStats() {
    return {
      totalRenderers: renderers.size,
      supportedFormats: Array.from(renderers.keys()),
      globalKey: GLOBAL_KEY
    };
  }
}

// ==================== Export اصلی ====================
// Export default برای سازگاری با import در background.js
export default ExportRegistry;

// همچنین توابع کمکی را به صورت named export می‌کنیم
// اما از export duplicate جلوگیری می‌کنیم
export { 
  registerExportRenderer, 
  getExportRenderer, 
  hasExportRenderer, 
  getSupportedExportFormats 
};