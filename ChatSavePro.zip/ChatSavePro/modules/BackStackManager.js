// modules/back-stack-manager.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles & Manifest V3

// ✅ Principle 2: Strict Interface Contract
const STATE_SCHEMA = {
    id: { type: 'string', required: true },
    timestamp: { type: 'number', required: true },
    type: { type: 'string', required: true },
    data: { type: 'object', required: true }
};

// ✅ Principle 9: Secure Logging & Sanitization
class SecureLogger {
    constructor(moduleName) {
        this.moduleName = moduleName;
        this.maxLogEntries = 50;
        this.logEntries = [];
    }

    log(level, message, data = {}) {
        const logEntry = {
            id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            module: this.moduleName,
            level,
            message: this.sanitize(message),
            data: this.sanitize(data)
        };

        this.logEntries.push(logEntry);

        // Maintain log size
        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        // Send to background for storage
        chrome.runtime.sendMessage({
            type: 'MODULE_LOG',
            payload: logEntry
        }).catch(() => {
            // Store locally if background not ready
            chrome.storage.local.set({
                [`${this.moduleName}_log_${logEntry.id}`]: logEntry
            });
        });

        return logEntry;
    }

    sanitize(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return JSON.parse(JSON.stringify(input)); // Deep clone
    }

    getLogs(limit = 10) {
        return this.logEntries.slice(-limit);
    }
}

// ✅ Principle 5: Memory Segmentation
class MemoryManager {
    constructor(maxSize) {
        this.maxSize = maxSize;
        this.cleanupThreshold = 0.8;
    }

    shouldCleanup(currentSize) {
        return currentSize >= this.maxSize * this.cleanupThreshold;
    }

    calculateCleanupCount(currentSize) {
        const targetSize = Math.floor(this.maxSize * 0.6); // Keep 60%
        return Math.max(0, currentSize - targetSize);
    }

    estimateSize(state) {
        try {
            return new Blob([JSON.stringify(state)]).size;
        } catch {
            return 0;
        }
    }
}

// ✅ Principle 7: Async Pipeline & Resilience
class OperationQueue {
    constructor(maxSize = 20) {
        this.tasks = [];
        this.isProcessing = false;
        this.maxSize = maxSize;
    }

    async enqueue(operation, ...args) {
        return new Promise((resolve, reject) => {
            const task = {
                id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
                operation,
                args,
                resolve,
                reject,
                timestamp: Date.now()
            };

            this.tasks.push(task);

            // Manage overflow
            if (this.tasks.length > this.maxSize) {
                const removed = this.tasks.shift();
                console.warn('[OperationQueue] Queue overflow, removed task:', removed.id);
            }

            if (!this.isProcessing) {
                this.process();
            }
        });
    }

    async process() {
        if (this.isProcessing) return;
        this.isProcessing = true;

        try {
            while (this.tasks.length > 0) {
                const task = this.tasks.shift();
                
                try {
                    const result = await task.operation(...task.args);
                    task.resolve(result);
                } catch (error) {
                    task.reject(error);
                }

                // Prevent blocking
                if (this.tasks.length > 0) {
                    await new Promise(resolve => setTimeout(resolve, 10));
                }
            }
        } finally {
            this.isProcessing = false;
        }
    }

    clear() {
        this.tasks = [];
    }

    getMetrics() {
        return {
            size: this.tasks.length,
            isProcessing: this.isProcessing,
            maxSize: this.maxSize
        };
    }
}

// ✅ Main ES6 Module Class
export class BackStackManager {
    constructor(maxStackSize = 10) {
        // ✅ Principle 1: Context Isolation
        this.MODULE_NAME = 'BackStackManager';
        this.MODULE_VERSION = '3.0.0';
        
        this.memoryManager = new MemoryManager(maxStackSize);
        this.operationQueue = new OperationQueue();
        this.logger = new SecureLogger(this.MODULE_NAME);
        
        // ✅ Principle 5: Memory Segmentation
        this.stack = [];
        this.maxStackSize = maxStackSize;
        this.currentState = null;
        this.isRestoring = false;

        // ✅ Principle 10: Audit & Traceability
        this.monitoring = {
            pushCount: 0,
            popCount: 0,
            restoreCount: 0,
            errorCount: 0,
            averageRestoreTime: 0,
            lastOperationTime: null
        };

        this.#initialize();
    }

    // ✅ Private methods for encapsulation
    async #initialize() {
        try {
            await this.#validateEnvironment();
            await this.#loadConfiguration();
            
            this.logger.log('INFO', 'Module initialized successfully', {
                version: this.MODULE_VERSION,
                maxStackSize: this.maxStackSize
            });
            
        } catch (error) {
            this.logger.log('ERROR', 'Initialization failed', { error: error.message });
            throw error;
        }
    }

    async #validateEnvironment() {
        // ✅ Law 8: World Isolation
        if (typeof window === 'undefined') {
            throw new Error('Module requires browser environment');
        }

        // ✅ Law 9: Frozen Globals - No global modifications
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.storage) {
            throw new Error('Chrome extension APIs not available');
        }
    }

    async #loadConfiguration() {
        return new Promise((resolve) => {
            // ✅ Law 4: Declarative Permissions
            chrome.storage.local.get([
                'backStackSize',
                'enableAnimations'
            ], (result) => {
                if (result.backStackSize) {
                    this.maxStackSize = result.backStackSize;
                    this.memoryManager.maxSize = result.backStackSize;
                }
                resolve();
            });
        });
    }

    // ✅ Principle 2: Strict Interface Contract
    #validateState(state) {
        if (!state || typeof state !== 'object') {
            throw new Error('State must be a valid object');
        }

        if (!state.type || typeof state.type !== 'string') {
            throw new Error('State must have a type string');
        }

        if (!state.data || typeof state.data !== 'object') {
            throw new Error('State must have a data object');
        }

        return true;
    }

    // ✅ Public API with queue management
    async pushState(state) {
        this.#validateState(state);
        
        return this.operationQueue.enqueue(async () => {
            const startTime = performance.now();
            
            try {
                // ✅ Principle 5: Memory Management - Auto cleanup
                if (this.memoryManager.shouldCleanup(this.stack.length)) {
                    this.#performCleanup();
                }

                // Enforce size limit
                if (this.stack.length >= this.maxStackSize) {
                    const removed = this.stack.shift();
                    this.logger.log('INFO', 'Removed oldest state from stack', {
                        id: removed.id,
                        stackSize: this.stack.length
                    });
                }

                const stateWithMetadata = {
                    ...state,
                    id: this.#generateStateId(),
                    timestamp: Date.now(),
                    size: this.memoryManager.estimateSize(state)
                };

                this.stack.push(stateWithMetadata);
                this.currentState = stateWithMetadata;

                this.monitoring.pushCount++;
                this.monitoring.lastOperationTime = Date.now();

                // ✅ Principle 7: Async Resilience
                await this.#updateUI();

                this.logger.log('INFO', 'State pushed to stack', {
                    id: stateWithMetadata.id,
                    type: stateWithMetadata.type,
                    stackSize: this.stack.length
                });

                return stateWithMetadata.id;

            } catch (error) {
                this.monitoring.errorCount++;
                this.logger.log('ERROR', 'Failed to push state', {
                    error: error.message,
                    stateType: state.type
                });
                throw error;
            }
        });
    }

    async popState() {
        return this.operationQueue.enqueue(async () => {
            if (this.isRestoring) {
                throw new Error('Cannot pop state while restoring');
            }

            if (this.stack.length <= 1) {
                this.logger.log('INFO', 'Cannot pop state - minimum stack size reached');
                return null;
            }

            const poppedState = this.stack.pop();
            this.currentState = this.stack[this.stack.length - 1];

            this.monitoring.popCount++;
            this.monitoring.lastOperationTime = Date.now();

            await this.#updateUI();

            this.logger.log('INFO', 'State popped from stack', {
                id: poppedState.id,
                remainingStack: this.stack.length
            });

            return poppedState;
        });
    }

    async handleBackAction() {
        if (this.isRestoring) {
            this.logger.log('WARN', 'Back action ignored - already restoring');
            return false;
        }

        return this.operationQueue.enqueue(async () => {
            try {
                this.isRestoring = true;
                const previousState = await this.popState();
                
                if (previousState) {
                    const restoreStartTime = performance.now();
                    
                    await this.#restoreState(previousState);
                    
                    const restoreTime = performance.now() - restoreStartTime;
                    this.monitoring.restoreCount++;
                    this.monitoring.averageRestoreTime = 
                        (this.monitoring.averageRestoreTime * (this.monitoring.restoreCount - 1) + restoreTime) / 
                        this.monitoring.restoreCount;

                    this.logger.log('INFO', 'State restoration completed', {
                        id: previousState.id,
                        duration: `${restoreTime}ms`
                    });
                    
                    return true;
                }
                
                return false;
                
            } catch (error) {
                this.monitoring.errorCount++;
                this.logger.log('ERROR', 'Back action handling failed', {
                    error: error.message
                });
                return false;
            } finally {
                this.isRestoring = false;
            }
        });
    }

    async #restoreState(state) {
        if (!state) {
            throw new Error('Invalid state for restoration');
        }

        const restorationTasks = [];

        // ✅ Principle 3: Lazy Loading - Deferred restoration
        if (state.data.modal) {
            restorationTasks.push(this.#showModal(state.data.modal));
        }
        
        if (state.data.description) {
            restorationTasks.push(this.#showDescription(state.data.description));
        }
        
        if (state.data.scanLevel) {
            restorationTasks.push(this.#setScanLevel(state.data.scanLevel));
        }

        // Execute in parallel with error handling
        const results = await Promise.allSettled(restorationTasks);
        
        // Check for failures
        const failures = results.filter(result => result.status === 'rejected');
        if (failures.length > 0) {
            throw new Error(`Restoration partially failed: ${failures.length} tasks`);
        }

        // ✅ Optional animation
        await this.#animateRestoration();
    }

    async #showModal(modalType) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                type: 'SHOW_MODAL',
                payload: { modalType }
            }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else if (response && response.success) {
                    resolve();
                } else {
                    reject(new Error('Modal display failed'));
                }
            });
        });
    }

    async #showDescription(description) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                type: 'UPDATE_DESCRIPTION',
                payload: { description }
            }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else if (response && response.success) {
                    resolve();
                } else {
                    reject(new Error('Description update failed'));
                }
            });
        });
    }

    async #setScanLevel(level) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                type: 'SET_SCAN_LEVEL',
                payload: { level }
            }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else if (response && response.success) {
                    resolve();
                } else {
                    reject(new Error('Scan level update failed'));
                }
            });
        });
    }

    async #animateRestoration() {
        return new Promise((resolve) => {
            // ✅ Law 6: CSP Hardened - No inline styles if possible
            // Animation would be handled by CSS classes
            setTimeout(resolve, 150);
        });
    }

    async #updateUI() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({
                type: 'UPDATE_BACK_BUTTON',
                payload: {
                    canGoBack: this.stack.length > 1,
                    stackSize: this.stack.length
                }
            }, () => {
                resolve();
            });
        });
    }

    #performCleanup() {
        const itemsToRemove = this.memoryManager.calculateCleanupCount(this.stack.length);
        
        if (itemsToRemove > 0) {
            const removedItems = this.stack.splice(0, itemsToRemove);
            this.logger.log('INFO', 'Memory cleanup performed', {
                removed: removedItems.length,
                remaining: this.stack.length
            });
        }
    }

    #generateStateId() {
        return `state_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    // ✅ Principle 6: Deterministic State Recovery
    async reset() {
        return this.operationQueue.enqueue(async () => {
            const previousSize = this.stack.length;
            
            this.stack = [];
            this.currentState = null;
            this.operationQueue.clear();
            
            await this.#updateUI();
            
            this.logger.log('INFO', 'Stack reset', {
                previousSize,
                queueCleared: true
            });
        });
    }

    // ✅ Principle 10: Audit & Traceability
    getMetrics() {
        const totalMemory = this.stack.reduce((sum, state) => sum + (state.size || 0), 0);
        
        return {
            version: this.MODULE_VERSION,
            stack: {
                size: this.stack.length,
                maxSize: this.maxStackSize,
                memoryUsage: totalMemory,
                currentState: this.currentState ? {
                    id: this.currentState.id,
                    type: this.currentState.type,
                    timestamp: this.currentState.timestamp
                } : null
            },
            monitoring: {
                ...this.monitoring,
                successRate: this.monitoring.pushCount > 0 ? 
                    (this.monitoring.pushCount - this.monitoring.errorCount) / this.monitoring.pushCount : 1,
                healthScore: this.#calculateHealthScore()
            },
            queue: this.operationQueue.getMetrics(),
            memory: {
                cleanupThreshold: this.memoryManager.cleanupThreshold,
                needsCleanup: this.memoryManager.shouldCleanup(this.stack.length)
            }
        };
    }

    #calculateHealthScore() {
        let score = 100;
        
        if (this.monitoring.errorCount > 0) {
            score -= Math.min(30, this.monitoring.errorCount * 5);
        }
        
        if (this.operationQueue.tasks.length > this.operationQueue.maxSize * 0.8) {
            score -= 20;
        }
        
        if (this.stack.length > this.maxStackSize * 0.9) {
            score -= 15;
        }
        
        return Math.max(0, score);
    }

    getStackSnapshot() {
        return this.stack.map(state => ({
            id: state.id,
            type: state.type,
            timestamp: state.timestamp,
            size: state.size
        }));
    }

    getLogs(limit = 10) {
        return this.logger.getLogs(limit);
    }

    // ✅ Safe destruction
    destroy() {
        this.operationQueue.clear();
        this.stack = [];
        this.currentState = null;
        
        this.logger.log('INFO', 'Module destroyed', {
            finalMetrics: this.getMetrics()
        });
    }
}

// ✅ Law 2: No Remote Code Execution - Pure ES6 Module
export default BackStackManager;