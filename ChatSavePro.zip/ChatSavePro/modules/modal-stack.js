// File: modules/modal-stack.js
// ============================================================
// Guardian Principles + Manifest V3 Compatible Modal Stack
// ============================================================

class SecureModalStack {
    #stack = [];
    #backHandlers = new Map();
    #escapeHandlers = new Map();
    #operationQueue = new Map();
    #cleanupIntervals = new Set();
    #metrics = new Map();
    #config = new Map();

    static #instance = null;

    constructor(maxStackSize = 10) {
        if (SecureModalStack.#instance) {
            return SecureModalStack.#instance;
        }

        this.#initializeConfiguration(maxStackSize);
        this.#applySecurityHardening();
        this.#setupMonitoring();
        
        SecureModalStack.#instance = this;
        Object.freeze(this);
    }

    static getInstance(maxStackSize = 10) {
        if (!this.#instance) {
            this.#instance = new SecureModalStack(maxStackSize);
        }
        return this.#instance;
    }

    #initializeConfiguration(maxStackSize) {
        this.#config.set('maxStackSize', Math.max(1, Math.min(maxStackSize, 20)));
        this.#config.set('cleanupThreshold', 0.8);
        this.#config.set('maxQueueSize', 15);
        this.#config.set('throttleDelay', 50);
        this.#config.set('animationDuration', 300);
        this.#config.set('backdropOpacity', 0.5);
        
        // Security settings
        this.#config.set('maxModalSize', 5 * 1024 * 1024); // 5MB
        this.#config.set('allowedModalTypes', ['dialog', 'div', 'section']);
        this.#config.set('sanitizeContent', true);
    }

    #applySecurityHardening() {
        Object.freeze(this.constructor.prototype);
        Object.freeze(SecureModalStack);
        
        // Prevent prototype pollution
        Object.setPrototypeOf(this, null);
    }

    #setupMonitoring() {
        this.#metrics.set('operations', {
            pushCount: 0,
            popCount: 0,
            escapeCount: 0,
            backdropCount: 0,
            errorCount: 0
        });

        this.#metrics.set('performance', {
            totalShowTime: 0,
            totalHideTime: 0,
            averageShowTime: 0,
            averageHideTime: 0,
            lastOperationTime: null
        });

        this.#metrics.set('health', {
            score: 100,
            lastCheck: Date.now()
        });
    }

    async init() {
        try {
            await this.#waitForDOM();
            this.#setupGlobalHandlers();
            this.#startHealthMonitoring();
            
            this.#log('info', 'ModalStack initialized successfully', {
                maxStackSize: this.#config.get('maxStackSize'),
                security: {
                    sanitizeContent: this.#config.get('sanitizeContent'),
                    maxModalSize: this.#config.get('maxModalSize')
                }
            });

            return true;
        } catch (error) {
            this.#log('error', 'Initialization failed', { error: error.message });
            throw error;
        }
    }

    async #waitForDOM() {
        return new Promise((resolve) => {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', resolve);
            } else {
                resolve();
            }
        });
    }

    #setupGlobalHandlers() {
        // Secure escape key handler
        let escapeTimeout;
        const escapeHandler = (e) => {
            if (e.key === 'Escape' && this.#stack.length > 0) {
                clearTimeout(escapeTimeout);
                escapeTimeout = setTimeout(() => {
                    const currentModal = this.#getCurrent();
                    if (currentModal && currentModal.options.closeOnEscape) {
                        this.#recordMetric('escapeCount');
                        this.pop().catch(error => {
                            this.#log('error', 'Escape handler failed', { error: error.message });
                        });
                    }
                }, 50);
            }
        };

        document.addEventListener('keydown', escapeHandler);
        this.#escapeHandlers.set('global', escapeHandler);

        // Secure backdrop click handler
        const backdropHandler = (e) => {
            if (e.target.classList.contains('modal-backdrop') && this.#stack.length > 0) {
                const currentModal = this.#getCurrent();
                if (currentModal && currentModal.options.closeOnBackdrop) {
                    this.#recordMetric('backdropCount');
                    this.pop().catch(error => {
                        this.#log('error', 'Backdrop handler failed', { error: error.message });
                    });
                }
            }
        };

        document.addEventListener('click', backdropHandler);
        this.#escapeHandlers.set('backdrop', backdropHandler);

        // Secure history state management
        const popStateHandler = (e) => {
            if (this.#stack.length > 0) {
                e.preventDefault();
                this.pop().catch(error => {
                    this.#log('error', 'PopState handler failed', { error: error.message });
                });
            }
        };

        window.addEventListener('popstate', popStateHandler);
        this.#escapeHandlers.set('popstate', popStateHandler);
    }

    #startHealthMonitoring() {
        const interval = setInterval(() => {
            this.#updateHealthScore();
        }, 30000); // Every 30 seconds

        this.#cleanupIntervals.add(interval);
    }

    async #queueOperation(operationType, operation, ...args) {
        const operationId = this.#generateId(operationType);
        
        return new Promise((resolve, reject) => {
            const queueItem = Object.freeze({
                id: operationId,
                operation,
                args,
                resolve,
                reject,
                timestamp: Date.now(),
                type: operationType
            });

            this.#operationQueue.set(operationId, queueItem);

            // Manage queue size
            if (this.#operationQueue.size > this.#config.get('maxQueueSize')) {
                const oldestKey = Array.from(this.#operationQueue.keys())[0];
                const removed = this.#operationQueue.get(oldestKey);
                this.#operationQueue.delete(oldestKey);
                
                removed.reject(new Error('Operation queue overflow'));
            }

            // Process queue asynchronously
            this.#processOperationQueue().catch(error => {
                this.#log('error', 'Queue processing failed', { error: error.message });
            });
        });
    }

    async #processOperationQueue() {
        if (this.#operationQueue.size === 0) return;

        const operations = Array.from(this.#operationQueue.values())
            .sort((a, b) => a.timestamp - b.timestamp);

        for (const queueItem of operations) {
            this.#operationQueue.delete(queueItem.id);

            try {
                const result = await queueItem.operation(...queueItem.args);
                queueItem.resolve(result);
            } catch (error) {
                queueItem.reject(error);
            }

            // Throttle operations
            if (this.#operationQueue.size > 0) {
                await new Promise(resolve => 
                    setTimeout(resolve, this.#config.get('throttleDelay'))
                );
            }
        }
    }

    async push(modalElement, options = {}) {
        return this.#queueOperation('push', async () => {
            const startTime = performance.now();
            
            try {
                // Validate input
                await this.#validateModal(modalElement);
                await this.#validateOptions(options);

                // Auto-cleanup before push
                this.#autoCleanupStack();

                const {
                    backdrop = true,
                    closeOnEscape = true,
                    closeOnBackdrop = true,
                    onClose = null,
                    onOpen = null,
                    animation = true
                } = options;

                // Hide previous modal
                if (this.#stack.length > 0) {
                    const previousModal = this.#stack[this.#stack.length - 1];
                    await this.#hideModal(previousModal);
                }

                // Create backdrop
                let backdropElement;
                if (backdrop) {
                    backdropElement = await this.#createBackdrop();
                }

                // Show new modal
                await this.#showModal(modalElement, { animation });

                // Safe callback execution
                if (onOpen) {
                    await this.#executeCallback(onOpen, 'onOpen');
                }

                // Create modal data
                const modalData = Object.freeze({
                    element: modalElement,
                    backdrop: backdropElement,
                    options: Object.freeze({
                        closeOnEscape,
                        closeOnBackdrop,
                        onClose,
                        animation
                    }),
                    id: modalElement.id,
                    timestamp: Date.now(),
                    pushTime: startTime
                });

                this.#stack.push(modalData);

                // Update history state
                if (this.#stack.length === 1) {
                    window.history.pushState({ modalStack: true }, '');
                }

                // Setup handlers
                this.#setupBackHandler(modalElement);

                // Update metrics
                this.#recordMetric('pushCount');
                const showTime = performance.now() - startTime;
                this.#recordPerformance('show', showTime);

                this.#log('info', 'Modal pushed to stack', {
                    modalId: modalElement.id,
                    stackSize: this.#stack.length,
                    showTime: `${showTime}ms`
                });

                return Object.freeze({ ...modalData });

            } catch (error) {
                this.#recordMetric('errorCount');
                this.#log('error', 'Push operation failed', { 
                    error: error.message,
                    modalId: modalElement.id 
                });
                throw error;
            }
        });
    }

    async pop() {
        return this.#queueOperation('pop', async () => {
            const startTime = performance.now();
            
            try {
                if (this.#stack.length === 0) {
                    this.#log('warn', 'Attempted to pop from empty stack');
                    return null;
                }

                const modalData = this.#stack.pop();
                
                // Hide current modal
                await this.#hideModal(modalData);
                
                // Remove backdrop
                if (modalData.backdrop) {
                    await this.#removeBackdrop(modalData.backdrop);
                }

                // Safe callback execution
                if (modalData.options.onClose) {
                    await this.#executeCallback(modalData.options.onClose, 'onClose');
                }

                // Show previous modal
                if (this.#stack.length > 0) {
                    const previousModal = this.#stack[this.#stack.length - 1];
                    await this.#showModal(previousModal.element, { 
                        animation: previousModal.options.animation 
                    });
                    
                    if (previousModal.backdrop) {
                        document.body.appendChild(previousModal.backdrop);
                    }
                } else {
                    // Update history state
                    if (window.history.state?.modalStack) {
                        window.history.back();
                    }
                }

                // Cleanup handlers
                this.#cleanupHandlers(modalData.element);

                // Update metrics
                this.#recordMetric('popCount');
                const hideTime = performance.now() - startTime;
                this.#recordPerformance('hide', hideTime);

                this.#log('info', 'Modal popped from stack', {
                    modalId: modalData.id,
                    stackSize: this.#stack.length,
                    hideTime: `${hideTime}ms`
                });

                return Object.freeze({ ...modalData });

            } catch (error) {
                this.#recordMetric('errorCount');
                this.#log('error', 'Pop operation failed', { error: error.message });
                throw error;
            }
        });
    }

    async #validateModal(modalElement) {
        if (!modalElement || !(modalElement instanceof HTMLElement)) {
            throw new Error('Invalid modal element: must be HTMLElement');
        }

        if (!modalElement.id) {
            throw new Error('Modal element must have an ID');
        }

        if (!this.#config.get('allowedModalTypes').includes(modalElement.tagName.toLowerCase())) {
            throw new Error(`Invalid modal type: ${modalElement.tagName}`);
        }

        // Size validation
        const modalSize = new TextEncoder().encode(modalElement.outerHTML).length;
        if (modalSize > this.#config.get('maxModalSize')) {
            throw new Error(`Modal too large: ${modalSize} bytes`);
        }

        // Security: Sanitize content if enabled
        if (this.#config.get('sanitizeContent')) {
            this.#sanitizeModalContent(modalElement);
        }

        return true;
    }

    async #validateOptions(options) {
        const validOptions = ['backdrop', 'closeOnEscape', 'closeOnBackdrop', 'onClose', 'onOpen', 'animation'];
        const invalidKeys = Object.keys(options).filter(key => !validOptions.includes(key));
        
        if (invalidKeys.length > 0) {
            throw new Error(`Invalid options: ${invalidKeys.join(', ')}`);
        }

        // Validate callback functions
        if (options.onClose && typeof options.onClose !== 'function') {
            throw new Error('onClose must be a function');
        }

        if (options.onOpen && typeof options.onOpen !== 'function') {
            throw new Error('onOpen must be a function');
        }

        return true;
    }

    #sanitizeModalContent(modalElement) {
        // Remove potentially dangerous attributes and elements
        const dangerousAttributes = ['onload', 'onerror', 'onclick', 'onsubmit'];
        const dangerousTags = ['script', 'iframe', 'object', 'embed'];
        
        dangerousAttributes.forEach(attr => {
            modalElement.querySelectorAll(`[${attr}]`).forEach(el => {
                el.removeAttribute(attr);
            });
        });

        dangerousTags.forEach(tag => {
            modalElement.querySelectorAll(tag).forEach(el => {
                el.remove();
            });
        });
    }

    #autoCleanupStack() {
        const currentSize = this.#stack.length;
        const threshold = this.#config.get('maxStackSize') * this.#config.get('cleanupThreshold');
        
        if (currentSize >= threshold) {
            const itemsToRemove = currentSize - Math.floor(this.#config.get('maxStackSize') * 0.6);
            if (itemsToRemove > 0) {
                const removedItems = this.#stack.splice(0, itemsToRemove);
                
                removedItems.forEach(modalData => {
                    this.#hideModal(modalData).catch(() => {});
                    if (modalData.backdrop) {
                        this.#removeBackdrop(modalData.backdrop).catch(() => {});
                    }
                    this.#cleanupHandlers(modalData.element);
                });
                
                this.#log('info', 'Auto-cleanup performed', {
                    removed: removedItems.length,
                    remaining: this.#stack.length
                });
            }
        }
    }

    async #showModal(modalElement, options = {}) {
        return new Promise((resolve) => {
            if (options.animation && this.#supportsAnimations()) {
                modalElement.style.display = 'block';
                modalElement.style.opacity = '0';
                modalElement.style.transition = `opacity ${this.#config.get('animationDuration')}ms ease-in-out`;
                
                requestAnimationFrame(() => {
                    modalElement.style.opacity = '1';
                });
                
                setTimeout(resolve, this.#config.get('animationDuration'));
            } else {
                modalElement.style.display = 'block';
                resolve();
            }
        });
    }

    async #hideModal(modalData) {
        return new Promise((resolve) => {
            const { element, options } = modalData;
            
            if (options.animation && this.#supportsAnimations()) {
                element.style.opacity = '0';
                element.style.transition = `opacity ${this.#config.get('animationDuration')}ms ease-in-out`;
                
                setTimeout(() => {
                    element.style.display = 'none';
                    element.style.opacity = '1';
                    element.style.transition = '';
                    resolve();
                }, this.#config.get('animationDuration'));
            } else {
                element.style.display = 'none';
                resolve();
            }
        });
    }

    async #createBackdrop() {
        return new Promise((resolve) => {
            const backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop';
            backdrop.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, ${this.#config.get('backdropOpacity')});
                z-index: 999;
                opacity: 0;
                transition: opacity ${this.#config.get('animationDuration')}ms ease-in-out;
            `;
            
            document.body.appendChild(backdrop);
            
            requestAnimationFrame(() => {
                backdrop.style.opacity = '1';
                resolve(backdrop);
            });
        });
    }

    async #removeBackdrop(backdrop) {
        return new Promise((resolve) => {
            if (backdrop.parentNode) {
                if (this.#supportsTransitions()) {
                    backdrop.style.opacity = '0';
                    backdrop.style.transition = `opacity ${this.#config.get('animationDuration') / 2}ms ease-in-out`;
                    
                    setTimeout(() => {
                        if (backdrop.parentNode) {
                            backdrop.parentNode.removeChild(backdrop);
                        }
                        resolve();
                    }, this.#config.get('animationDuration') / 2);
                } else {
                    backdrop.parentNode.removeChild(backdrop);
                    resolve();
                }
            } else {
                resolve();
            }
        });
    }

    #supportsAnimations() {
        return !!(window.CSS && CSS.supports && CSS.supports('animation', 'fade 0.3s'));
    }

    #supportsTransitions() {
        return !!(window.CSS && CSS.supports && CSS.supports('transition', 'opacity 0.3s'));
    }

    #setupBackHandler(modalElement) {
        const backButton = modalElement.querySelector('[data-modal-back]');
        if (backButton) {
            const handler = () => {
                this.pop().catch(error => {
                    this.#log('error', 'Back handler failed', { error: error.message });
                });
            };
            
            backButton.addEventListener('click', handler);
            this.#backHandlers.set(backButton, handler);
        }
    }

    #cleanupHandlers(modalElement) {
        const backButton = modalElement.querySelector('[data-modal-back]');
        if (backButton && this.#backHandlers.has(backButton)) {
            const handler = this.#backHandlers.get(backButton);
            backButton.removeEventListener('click', handler);
            this.#backHandlers.delete(backButton);
        }
    }

    async #executeCallback(callback, context) {
        try {
            if (typeof callback === 'function') {
                await callback();
            }
        } catch (error) {
            this.#log('error', `Callback failed in ${context}`, { error: error.message });
            throw error;
        }
    }

    #recordMetric(metric) {
        const operations = this.#metrics.get('operations');
        if (operations[metric] !== undefined) {
            operations[metric]++;
        }
    }

    #recordPerformance(type, duration) {
        const performance = this.#metrics.get('performance');
        performance.lastOperationTime = Date.now();

        if (type === 'show') {
            performance.totalShowTime += duration;
            performance.averageShowTime = performance.totalShowTime / this.#metrics.get('operations').pushCount;
        } else {
            performance.totalHideTime += duration;
            performance.averageHideTime = performance.totalHideTime / this.#metrics.get('operations').popCount;
        }
    }

    #updateHealthScore() {
        const health = this.#metrics.get('health');
        const operations = this.#metrics.get('operations');
        
        let score = 100;
        
        // Deduct for errors
        if (operations.errorCount > 0) {
            score -= Math.min(30, operations.errorCount * 5);
        }
        
        // Deduct for queue issues
        if (this.#operationQueue.size > this.#config.get('maxQueueSize') * 0.8) {
            score -= 20;
        }
        
        // Deduct for stack size issues
        if (this.#stack.length > this.#config.get('maxStackSize') * 0.9) {
            score -= 15;
        }
        
        health.score = Math.max(0, Math.min(100, score));
        health.lastCheck = Date.now();
    }

    #generateId(prefix) {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
    }

    #log(level, message, meta = {}) {
        const entry = Object.freeze({
            timestamp: new Date().toISOString(),
            level,
            message,
            module: 'SecureModalStack',
            ...meta
        });
        
        console[level](`[SecureModalStack] ${message}`, entry);
    }




    // --------------------------
    // PRIVATE INTERNAL CURRENT
    // --------------------------
    #getCurrent() {
        return this.#stack.length > 0
            ? this.#stack[this.#stack.length - 1]
            : null;
    }


    // ==================== PUBLIC API ====================
    getCurrent() {
        return this.#stack.length > 0 ? Object.freeze({ ...this.#stack[this.#stack.length - 1] }) : null;
    }

    getStackSize() {
        return this.#stack.length;
    }

    getStackInfo() {
        const operations = this.#metrics.get('operations');
        const performance = this.#metrics.get('performance');
        const health = this.#metrics.get('health');
        
        return Object.freeze({
            size: this.#stack.length,
            maxSize: this.#config.get('maxStackSize'),
            current: this.getCurrent(),
            monitoring: Object.freeze({
                ...operations,
                successRate: operations.pushCount > 0 ? 
                    (operations.pushCount - operations.errorCount) / operations.pushCount : 1,
                totalOperationTime: performance.totalShowTime + performance.totalHideTime
            }),
            performance: Object.freeze({
                ...performance,
                queue: Object.freeze({
                    size: this.#operationQueue.size,
                    maxSize: this.#config.get('maxQueueSize')
                })
            }),
            health: Object.freeze({ ...health })
        });
    }

    async clear() {
        return this.#queueOperation('clear', async () => {
            while (this.#stack.length > 0) {
                await this.pop();
            }
            
            // Cleanup all handlers
            this.#backHandlers.forEach((handler, element) => {
                element.removeEventListener('click', handler);
            });
            this.#backHandlers.clear();

            // Clear operation queue
            this.#operationQueue.clear();

            this.#log('info', 'Modal stack cleared');
        });
    }

    async destroy() {
        await this.clear();
        
        // Cleanup global handlers
        this.#escapeHandlers.forEach((handler, type) => {
            switch (type) {
                case 'global':
                    document.removeEventListener('keydown', handler);
                    break;
                case 'backdrop':
                    document.removeEventListener('click', handler);
                    break;
                case 'popstate':
                    window.removeEventListener('popstate', handler);
                    break;
            }
        });
        this.#escapeHandlers.clear();

        // Clear intervals
        this.#cleanupIntervals.forEach(interval => clearInterval(interval));
        this.#cleanupIntervals.clear();

        this.#log('info', 'ModalStack destroyed');
    }
}

// ES6 Module Export
export default SecureModalStack;

// Manifest V3 Service Worker Compatibility
if (typeof self !== 'undefined' && self instanceof ServiceWorkerGlobalScope) {
    self.SecureModalStack = SecureModalStack;
}