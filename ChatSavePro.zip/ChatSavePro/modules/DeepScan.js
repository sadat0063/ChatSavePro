// ============================================================
// modules/DeepScan.js — QuantumStage v3.9 / R9.9.1‑Final - REAL DOM VERSION
// Full hybrid deep‑scan engine with REAL DOM scanning
// ============================================================

export const CONTEXTS = Object.freeze({
    CHAT: 'chat',
    FORUM: 'forum',
    SOCIAL: 'social',
    GENERAL: 'general'
});

export class DeepScan {
    constructor(config = {}) {
        this.config = {
            contexts: config.contexts || [CONTEXTS.CHAT],
            incrementalEnabled: config.incrementalEnabled || false,
            maxDepth: config.maxDepth || 5,
            timeout: config.timeout || 30000,
            ...config
        };

        // 🔧 REAL SCANNING STATE
        this.isScanning = false; // Not auto-started - user must start
        this.isLiveScanning = false; // Not auto-started
        this.scanResults = [];
        this.checksums = new Map();
        this.scanModules = null;
        this.liveScanInterval = null;
        this.cache = null;
        this.cacheCleanupInterval = null;
        this.messageCache = new Set();

        // 🔧 REAL SELECTOR FOR DEEPSEEK MESSAGES
        this.SELECTOR = '[class*="chat"] [data-role="message"], .message, .chat-message, [class*="message"], div[class*="message"], .prose, .markdown, [data-testid*="message"], article, section[class*="message"], .message-bubble';

        console.log('✅ DeepScan instance created - REAL DOM Scanner');
    }

    static async create(config = {}) {
        const instance = new DeepScan(config);
        await instance.initialize();
        return instance;
    }

    async initialize() {
        try {
            console.log('🔄 Initializing DeepScan engine with REAL DOM Scanner...');
            await this._loadScanModules();
            await this._initializeCache();
            console.log('✅ DeepScan initialized successfully');
            return this;
        } catch (error) {
            console.error('❌ DeepScan initialization failed:', error);
            throw error;
        }
    }

    async _loadScanModules() {
        try {
            // Load real scan modules
            this.scanModules = {
                domScanner: { scan: async (context) => await this._realDOMScan(context) },
                contentExtractor: { extract: async (element) => this._extractRealContent(element) },
                structureAnalyzer: { analyze: async (content) => this._analyzeStructure(content) }
            };
        } catch (error) {
            console.warn('⚠️ Scan module loading failed:', error);
            this.scanModules = this._getDefaultScanModules();
        }
    }

    async _initializeCache() {
        this.cache = new Map();
        this.cacheConfig = {
            maxSize: 1000,
            ttl: 300000,
            cleanupInterval: 60000
        };

        this.cacheCleanupInterval = setInterval(() => this._cleanupCache(), this.cacheConfig.cleanupInterval);
        console.log('✅ Cache initialized');
    }

    _cleanupCache() {
        const now = Date.now();
        for (const [key, value] of this.cache.entries()) {
            if (now - value.timestamp > this.cacheConfig.ttl) {
                this.cache.delete(key);
            }
        }
    }

    _getDefaultScanModules() {
        return {
            domScanner: { scan: async (context) => await this._realDOMScan(context) },
            contentExtractor: { extract: async (element) => this._extractRealContent(element) },
            structureAnalyzer: { analyze: async (content) => this._analyzeStructure(content) }
        };
    }

    // ============================================================
    // 🔥 REAL DOM SCANNING METHODS
    // ============================================================

    // 🔧 SCAN ALL MESSAGES FROM DOM (REAL IMPLEMENTATION)
    scanAllMessages() {
        try {
            const results = [];
            
            if (!document || !document.querySelectorAll) {
                console.warn('⚠️ DOM not available for scanning');
                return results;
            }

            const nodes = document.querySelectorAll(this.SELECTOR);
            
            console.log(`🔍 [DeepScan] Found ${nodes.length} potential message nodes`);
            
            nodes.forEach((node, index) => {
                const message = this.extractMessage(node, index);
                if (message && message.text && message.text.trim()) {
                    
                    // Deduplication check
                    const messageHash = this._calculateMessageHash(message.text);
                    if (!this.messageCache.has(messageHash)) {
                        results.push(message);
                        this.messageCache.add(messageHash);
                        console.log(`📝 [DeepScan] Extracted message ${index + 1}:`, {
                            length: message.text.length,
                            role: message.role,
                            preview: message.text.substring(0, 100) + '...'
                        });
                    } else {
                        console.log(`♻️ [DeepScan] Duplicate message skipped: ${messageHash.substring(0, 20)}...`);
                    }
                }
            });

            console.log(`✅ [DeepScan] Total ${results.length} unique messages extracted`);
            return results;
            
        } catch (error) {
            console.error('❌ DOM scan failed:', error);
            return [];
        }
    }

    // 🔧 EXTRACT MESSAGE FROM DOM NODE (REAL EXTRACTOR)
    extractMessage(node, index) {
        try {
            let text = '';
            
            // REAL EXTRACTION: Get text content
            if (node.innerText) {
                text = node.innerText.trim();
            } else if (node.textContent) {
                text = node.textContent.trim();
            } else if (node.querySelector && node.querySelector('.content, .text, .message-content, .markdown')) {
                const contentNode = node.querySelector('.content, .text, .message-content, .markdown');
                text = contentNode ? (contentNode.innerText || contentNode.textContent || '').trim() : '';
            }
            
            // Skip empty messages
            if (!text || text.length < 2) return null;
            
            // Determine role
            let role = 'unknown';
            const classList = node.className || '';
            
            // تشخیص role بر اساس class
            if (classList.includes('message-bubble') || 
                classList.includes('chat-message') ||
                classList.includes('assistant') || 
                classList.includes('bot') || 
                classList.includes('ai') ||
                node.matches && node.matches('.message-bubble, .chat-message')) {
                role = 'assistant';
            } else if (classList.includes('user') || 
                      classList.includes('human') || 
                      classList.includes('you') ||
                      node.querySelector && node.querySelector('[class*="user"], [class*="human"]')) {
                role = 'user';
            }
            
            // Fallback: اگر تشخیص داده نشد، بر اساس محتوا حدس بزن
            if (role === 'unknown') {
                const lowerText = text.toLowerCase();
                if (lowerText.includes('you:') || lowerText.startsWith('user:')) {
                    role = 'user';
                } else if (lowerText.includes('assistant:') || lowerText.includes('ai:')) {
                    role = 'assistant';
                }
            }
            
            return {
                id: 'deep_' + Date.now() + '_' + Math.random().toString(36).slice(2),
                text: text,
                content: text, // For compatibility
                role: role,
                timestamp: Date.now(),
                source: 'deep',
                nodeIndex: index,
                platform: this._detectPlatform(),
                type: 'text' // Required for integrity validation
            };
        } catch (error) {
            console.warn('⚠️ Message extraction failed:', error);
            return null;
        }
    }

    // 🔧 CALCULATE MESSAGE HASH FOR DEDUPLICATION
    _calculateMessageHash(text) {
        // Simple hash for deduplication (first 500 chars)
        const content = text.substring(0, 500).replace(/\s+/g, ' ').trim();
        return btoa(encodeURIComponent(content)).substring(0, 50);
    }

    // 🔧 DETECT CURRENT PLATFORM
    _detectPlatform() {
        const url = window.location.href || '';
        if (url.includes('deepseek.com')) return 'deepseek';
        if (url.includes('chat.openai.com') || url.includes('chatgpt.com')) return 'chatgpt';
        if (url.includes('claude.ai')) return 'claude';
        if (url.includes('web.telegram.org')) return 'telegram';
        if (url.includes('web.whatsapp.com')) return 'whatsapp';
        return 'generic';
    }

    // ============================================================
    // SCAN EXECUTION - REAL DOM SCANNING
    // ============================================================
    
    async toggleDeepScan() {
        if (this.isScanning) {
            return await this.stopDeepScan();
        } else {
            return await this.startDeepScan();
        }
    }

    async toggleLiveScan() {
        if (this.isLiveScanning) {
            return await this.stopLiveScan();
        } else {
            return await this.startLiveScan();
        }
    }

    async startDeepScan(scanConfig = {}) {
        if (this.isScanning) {
            return {
                success: true,
                status: 'already_active',
                message: 'Deep scan is already running',
                timestamp: Date.now()
            };
        }

        try {
            const config = { ...this.config, ...scanConfig };
            this.isScanning = true;
            
            // Perform initial deep scan
            const results = await this.deepScan();
            
            console.log('🔍 Deep scan started - REAL DOM Scanning');
            return {
                success: true,
                status: 'deep_scan_started',
                timestamp: Date.now(),
                initialResults: results.length,
                config: {
                    contexts: config.contexts,
                    maxDepth: config.maxDepth
                }
            };
        } catch (error) {
            console.error('❌ Deep scan start failed:', error);
            this.isScanning = false;
            throw error;
        }
    }

    async stopDeepScan() {
        if (!this.isScanning) {
            return {
                success: true,
                status: 'already_stopped',
                message: 'Deep scan is already stopped',
                timestamp: Date.now()
            };
        }

        this.isScanning = false;
        console.log('🛑 Deep scan stopped');

        return { 
            success: true, 
            status: 'deep_scan_stopped', 
            timestamp: Date.now(),
            scannedItems: this.scanResults.length
        };
    }

    async startLiveScan(scanConfig = {}) {
        if (this.isLiveScanning) {
            return {
                success: true,
                status: 'already_active',
                message: 'Live scan is already running',
                timestamp: Date.now()
            };
        }

        try {
            const config = { ...this.config, ...scanConfig, liveMode: true };

            this.liveScanInterval = setInterval(() => {
                this._performLiveScan(config);
            }, config.interval || 5000);

            this.isLiveScanning = true;
            return {
                success: true,
                status: 'live_scan_started',
                interval: config.interval || 5000,
                timestamp: Date.now()
            };
        } catch (error) {
            console.error('❌ Live scan start failed:', error);
            this.isLiveScanning = false;
            throw error;
        }
    }

    async stopLiveScan() {
        if (!this.isLiveScanning) {
            return {
                success: true,
                status: 'already_stopped', 
                message: 'Live scan is already stopped',
                timestamp: Date.now()
            };
        }

        if (this.liveScanInterval) {
            clearInterval(this.liveScanInterval);
            this.liveScanInterval = null;
        }
        
        this.isLiveScanning = false;
        console.log('🛑 Live scan stopped');

        return { 
            success: true, 
            status: 'live_scan_stopped', 
            timestamp: Date.now(),
            scannedItems: this.scanResults.length
        };
    }

    // 🔧 REAL DOM SCAN EXECUTION (NO MOCK DATA)
    async _executeScan(config) {
        try {
            // Perform real DOM scan
            const realMessages = this.scanAllMessages();
            
            // Filter by context if specified
            const filteredMessages = realMessages.filter(msg => {
                if (!config.contexts || config.contexts.length === 0) return true;
                return config.contexts.some(ctx => 
                    msg.platform === ctx || msg.source === ctx
                );
            });
            
            // Add to results
            this.scanResults = [...this.scanResults, ...filteredMessages];
            
            return filteredMessages;
            
        } catch (error) {
            console.error('❌ Real scan execution failed:', error);
            return [];
        }
    }

    // 🔧 PERFORM LIVE SCAN (REAL DOM)
    async _performLiveScan(config) {
        try {
            const newItems = await this._executeScan(config);
            if (newItems.length > 0) {
                console.log(`🔄 Live scan found ${newItems.length} new messages`);
                
                // Store results
                this.scanResults = [...this.scanResults, ...newItems];
                
                // Emit event for coordinator
                this._emitScanResults(newItems);
            }
        } catch (error) {
            console.warn('Live scan iteration failed:', error);
        }
    }

    // 🔧 EMIT SCAN RESULTS TO COORDINATOR
    _emitScanResults(items) {
        try {
            if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    type: "DEEP_SCAN_RESULTS",
                    sessionId: `deep_${Date.now()}`,
                    items: items,
                    timestamp: Date.now()
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.warn('⚠️ Background response error:', chrome.runtime.lastError.message);
                    } else {
                        console.log('✅ Deep scan results sent to background');
                    }
                });
            }
        } catch (error) {
            console.warn('⚠️ Failed to emit scan results:', error);
        }
    }

    // ============================================================
    // PUBLIC SCAN METHODS - REAL DOM
    // ============================================================

    // 🔧 DEEP SCAN (REAL DOM)
    async deepScan() {
        const results = this.scanAllMessages();
        
        // Emit results if any found
        if (results.length > 0) {
            this._emitScanResults(results);
        }
        
        return results;
    }

    // 🔧 INCREMENTAL SCAN (REAL DOM)
    async incrementalScan(context) {
        if (!this.config.incrementalEnabled) {
            return await this.scanAllMessages();
        }

        const checksum = this._calculateChecksum(context);
        const previous = this.checksums.get(context);

        if (checksum === previous) {
            console.log('♻️ No changes detected in incremental scan');
            return [];
        }
        
        this.checksums.set(context, checksum);
        const results = await this.scanAllMessages();
        
        // Emit results if any found
        if (results.length > 0) {
            this._emitScanResults(results);
        }
        
        return results;
    }

    // 🔧 REAL DOM SCAN IMPLEMENTATION
    async _realDOMScan(context) {
        const messages = this.scanAllMessages();
        
        return {
            elements: messages.map(m => m.id),
            count: messages.length,
            context,
            timestamp: Date.now()
        };
    }

    // 🔧 REAL CONTENT EXTRACTION
    _extractRealContent(element) {
        const text = element.innerText || element.textContent || '';
        return {
            text: text.trim(),
            content: text.trim(),
            type: 'text',
            metadata: { 
                source: element.tagName,
                className: element.className,
                nodeType: element.nodeType
            }
        };
    }

    // 🔧 STRUCTURE ANALYSIS
    _analyzeStructure(content) {
        const textLength = content.text ? content.text.length : 0;
        return {
            complexity: textLength > 1000 ? 'high' : textLength > 500 ? 'medium' : 'low',
            elements: ['message', 'content', 'metadata'],
            patterns: ['conversation', 'qna', 'discussion'],
            characterCount: textLength
        };
    }

    // ============================================================
    // RESULTS & REPORTS - REAL DATA
    // ============================================================
    async getScanResults() {
        return {
            success: true,
            items: this.scanResults,
            total: this.scanResults.length,
            timestamp: Date.now(),
            scanState: {
                isScanning: this.isScanning,
                isLiveScanning: this.isLiveScanning,
                hasRealData: this.scanResults.length > 0,
                platform: this._detectPlatform()
            }
        };
    }

    async getResults() { 
        return this.getScanResults(); 
    }

    async exportData() { 
        return this.getScanResults(); 
    }

    async clearResults() {
        this.scanResults = [];
        this.messageCache.clear();
        console.log('🧹 Scan results cleared');
        return { 
            success: true, 
            message: 'Results cleared', 
            timestamp: Date.now() 
        };
    }

    async getStats() {
        const platform = this._detectPlatform();
        const lastScanTime = this.scanResults.length > 0 ? 
            new Date(this.scanResults[this.scanResults.length - 1].timestamp).toLocaleTimeString() : 
            'Never';
        
        return {
            totalScans: this.scanResults.length,
            isScanning: this.isScanning,
            isLiveScanning: this.isLiveScanning,
            contexts: this.config.contexts,
            incrementalEnabled: this.config.incrementalEnabled,
            platform: platform,
            scanStatus: this.isScanning ? 'ACTIVE' : 'STOPPED',
            liveScanStatus: this.isLiveScanning ? 'ACTIVE' : 'STOPPED',
            realData: true,
            lastScanTime: lastScanTime,
            uniqueMessages: this.messageCache.size,
            selector: this.SELECTOR.substring(0, 50) + '...'
        };
    }

    // ============================================================
    // AUXILIARY METHODS
    // ============================================================
    _calculateChecksum(context) {
        // Calculate checksum based on current DOM state
        try {
            const allText = this.scanAllMessages()
                .map(m => m.text)
                .join('|');
            return btoa(encodeURIComponent(allText)).substring(0, 50);
        } catch (error) {
            return `checksum-error-${Date.now()}`;
        }
    }

    // ============================================================
    // EXPORT & CLEANUP
    // ============================================================
    async exportToFormat(format = 'json') {
        const results = await this.getScanResults();

        switch (format.toLowerCase()) {
            case 'json': 
                return JSON.stringify(results, null, 2);
            case 'csv': 
                return this._convertToCSV(results.items);
            case 'txt': 
                return this._convertToTXT(results.items);
            default: 
                throw new Error(`Unsupported format: ${format}`);
        }
    }

    _convertToCSV(items) {
        if (!items.length) return '';
        const headers = ['id', 'text', 'role', 'timestamp', 'source', 'platform'];
        const rows = items.map(item =>
            headers.map(header => {
                const value = item[header] || '';
                return `"${String(value).replace(/"/g, '""')}"`;
            }).join(',')
        );
        return [headers.join(','), ...rows].join('\n');
    }

    _convertToTXT(items) {
        if (!items.length) return 'No messages found.';
        
        return items.map((item, index) =>
            `[Message ${index + 1}]
ID: ${item.id}
Text: ${item.text.substring(0, 500)}${item.text.length > 500 ? '...' : ''}
Role: ${item.role}
Time: ${new Date(item.timestamp).toLocaleString()}
Source: ${item.source}
Platform: ${item.platform}
---`
        ).join('\n\n');
    }

    destroy() {
        if (this.liveScanInterval) clearInterval(this.liveScanInterval);
        if (this.cacheCleanupInterval) clearInterval(this.cacheCleanupInterval);
        
        this.isScanning = false;
        this.isLiveScanning = false;
        this.scanResults = [];
        this.messageCache.clear();
        
        console.log('✅ DeepScan destroyed - REAL DOM Scanner stopped');
    }
}

export default DeepScan;