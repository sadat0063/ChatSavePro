// modules/enhanced-export-manager.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles & Manifest V3

// ✅ Principle 1: Context Isolation
const EXPORT_CONTEXTS = Object.freeze({
    SINGLE: 'single',
    STREAMING: 'streaming',
    BATCH: 'batch',
    MULTI_FORMAT: 'multi_format'
});

// ✅ Principle 2: Strict Interface Contract
const EXPORT_FORMATS = Object.freeze({
    JSON: { 
        name: 'JSON', 
        mime: 'application/json', 
        icon: '📊',
        streaming: true,
        schema: {
            required: ['scanResults', 'statistics'],
            maxSize: 10 * 1024 * 1024
        }
    },
    CSV: { 
        name: 'CSV', 
        mime: 'text/csv', 
        icon: '📈',
        streaming: true,
        schema: {
            required: ['scanResults'],
            maxSize: 5 * 1024 * 1024
        }
    },
    TXT: { 
        name: 'Text', 
        mime: 'text/plain', 
        icon: '📄',
        streaming: true,
        schema: {
            required: ['scanResults'],
            maxSize: 2 * 1024 * 1024
        }
    },
    JSONL: { 
        name: 'JSONL', 
        mime: 'application/jsonl', 
        icon: '📑',
        streaming: true,
        schema: {
            required: ['scanResults'],
            maxSize: 10 * 1024 * 1024
        }
    }
});

// ✅ Principle 9: Secure Logging & Sanitization
class ExportLogger {
    constructor() {
        this.maxLogEntries = 100;
        this.logEntries = [];
    }

    log(level, operation, data = {}) {
        const logEntry = {
            id: `export_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            level,
            operation: this.sanitize(operation),
            data: this.sanitize(data)
        };

        this.logEntries.push(logEntry);

        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        // Send to background for centralized logging
        chrome.runtime.sendMessage({
            type: 'EXPORT_LOG',
            payload: logEntry
        }).catch(() => {
            // Fallback to local storage
            chrome.storage.local.set({
                [`export_log_${logEntry.id}`]: logEntry
            });
        });

        return logEntry;
    }

    sanitize(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return JSON.parse(JSON.stringify(input));
    }

    getLogs(limit = 20) {
        return this.logEntries.slice(-limit);
    }
}

// ✅ Principle 5: Memory Segmentation
class ExportMemoryManager {
    constructor() {
        this.segments = new Map();
        this.#initializeSegments();
        this.metrics = {
            exportsProcessed: 0,
            cacheHits: 0,
            cacheMisses: 0
        };
    }

    #initializeSegments() {
        this.segments.set('streaming_sessions', new Map());
        this.segments.set('export_cache', new Map());
        this.segments.set('history', new Map());
    }

    setStreamingSession(sessionId, sessionData) {
        const sessions = this.segments.get('streaming_sessions');
        if (sessions.size >= 50) {
            const oldestKey = Array.from(sessions.keys())[0];
            sessions.delete(oldestKey);
        }
        sessions.set(sessionId, { ...sessionData, lastAccess: Date.now() });
    }

    getStreamingSession(sessionId) {
        const sessions = this.segments.get('streaming_sessions');
        const session = sessions.get(sessionId);
        if (session) {
            session.lastAccess = Date.now();
            this.metrics.cacheHits++;
        } else {
            this.metrics.cacheMisses++;
        }
        return session;
    }

    deleteStreamingSession(sessionId) {
        return this.segments.get('streaming_sessions').delete(sessionId);
    }

    cacheExportResult(key, result) {
        const cache = this.segments.get('export_cache');
        if (cache.size >= 100) {
            const oldestKey = Array.from(cache.keys())[0];
            cache.delete(oldestKey);
        }
        cache.set(key, { ...result, cachedAt: Date.now() });
    }

    getCachedExport(key) {
        const cache = this.segments.get('export_cache');
        const cached = cache.get(key);
        if (cached) {
            this.metrics.cacheHits++;
            if (Date.now() - cached.cachedAt < 10 * 60 * 1000) {
                return cached;
            }
            cache.delete(key);
        }
        this.metrics.cacheMisses++;
        return null;
    }

    addToHistory(exportResult) {
        const history = this.segments.get('history');
        if (history.size >= 20) {
            const oldestKey = Array.from(history.keys())[0];
            history.delete(oldestKey);
        }
        history.set(exportResult.id, exportResult);
    }

    getMetrics() {
        const hitRate = this.metrics.cacheHits + this.metrics.cacheMisses > 0 
            ? (this.metrics.cacheHits / (this.metrics.cacheHits + this.metrics.cacheMisses) * 100).toFixed(2)
            : 0;

        return {
            ...this.metrics,
            hitRate: `${hitRate}%`,
            segments: Array.from(this.segments.entries()).map(([name, segment]) => ({
                name,
                size: segment.size
            }))
        };
    }
}

// ✅ Principle 7: Async Pipeline & Resilience
class ExportPipeline {
    constructor() {
        this.retryConfig = {
            maxRetries: 3,
            baseDelay: 1000,
            maxDelay: 10000
        };
        this.timeout = 30000;
    }

    async executeWithRetry(operation, operationName) {
        let lastError;
        
        for (let attempt = 1; attempt <= this.retryConfig.maxRetries; attempt++) {
            try {
                return await this.#executeWithTimeout(operation, operationName);
            } catch (error) {
                lastError = error;
                
                if (attempt < this.retryConfig.maxRetries) {
                    const delay = Math.min(
                        this.retryConfig.baseDelay * Math.pow(2, attempt - 1),
                        this.retryConfig.maxDelay
                    );
                    
                    await this.#delay(delay);
                }
            }
        }
        
        throw new Error(`Export operation ${operationName} failed after ${this.retryConfig.maxRetries} attempts: ${lastError.message}`);
    }

    async #executeWithTimeout(operation, operationName) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Export operation ${operationName} timeout after ${this.timeout}ms`));
            }, this.timeout);
            
            Promise.resolve(operation())
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }

    #delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// ✅ Format Generators
class JSONGenerator {
    async generate(data, timestamp, options) {
        const content = JSON.stringify(data, null, 2);
        return {
            content,
            filename: `chatsavepro-export-${timestamp}.json`,
            mimeType: 'application/json'
        };
    }
}

class CSVGenerator {
    async generate(data, timestamp, options) {
        const content = this.#convertToCSV(data);
        return {
            content,
            filename: `chatsavepro-export-${timestamp}.csv`,
            mimeType: 'text/csv'
        };
    }

    #convertToCSV(data) {
        if (!data.scanResults || data.scanResults.length === 0) {
            return "Type,Platform,URL,Timestamp,Messages\nNo data available";
        }
        
        const headers = ['Type', 'Platform', 'URL', 'Timestamp', 'Messages'];
        let csvContent = headers.join(',') + '\n';
        
        data.scanResults.forEach(scan => {
            const row = [
                scan.scanType || 'unknown',
                scan.platform || 'unknown',
                `"${scan.url || 'N/A'}"`,
                new Date(scan.timestamp).toISOString(),
                scan.messageCount || 1
            ].map(field => `"${String(field).replace(/"/g, '""')}"`);
            
            csvContent += row.join(',') + '\n';
        });
        
        return csvContent;
    }
}

class TXTGenerator {
    async generate(data, timestamp, options) {
        const content = this.#convertToTXT(data);
        return {
            content,
            filename: `chatsavepro-export-${timestamp}.txt`,
            mimeType: 'text/plain'
        };
    }

    #convertToTXT(data) {
        let content = `ChatSavePro Export\n`;
        content += `Generated: ${new Date().toLocaleString()}\n`;
        content += `Total Records: ${data.scanResults?.length || 0}\n`;
        content += "=".repeat(50) + "\n\n";
        
        if (!data.scanResults || data.scanResults.length === 0) {
            content += 'No scan results available.\n';
            return content;
        }
        
        data.scanResults.forEach((scan, index) => {
            content += `Record #${index + 1}:\n`;
            content += `  Type: ${scan.scanType || 'unknown'}\n`;
            content += `  Platform: ${scan.platform || 'unknown'}\n`;
            content += `  URL: ${scan.url || 'N/A'}\n`;
            content += `  Time: ${new Date(scan.timestamp).toLocaleString()}\n`;
            content += `  Messages: ${scan.messageCount || 1}\n`;
            content += "-".repeat(30) + "\n";
        });
        
        return content;
    }
}

class JSONLGenerator {
    async generate(data, timestamp, options) {
        const lines = data.scanResults?.map(result => JSON.stringify(result)) || [];
        const content = lines.join('\n');
        return {
            content,
            filename: `chatsavepro-export-${timestamp}.jsonl`,
            mimeType: 'application/jsonl'
        };
    }
}

// ✅ Main ES6 Module Class
export class EnhancedExportManager {
    constructor() {
        this.MODULE_NAME = 'EnhancedExportManager';
        this.MODULE_VERSION = '4.0.0';
        
        this.logger = new ExportLogger();
        this.pipeline = new ExportPipeline();
        this.memoryManager = new ExportMemoryManager();
        
        this.generators = new Map();
        this.isInitialized = false;

        this.config = {
            compression: true,
            maxFileSize: 50 * 1024 * 1024,
            autoCleanup: true,
            cleanupInterval: 24 * 60 * 60 * 1000
        };

        this.#initialize();
    }

    // ✅ Private methods for encapsulation
    async #initialize() {
        try {
            await this.#loadConfiguration();
            await this.#initializeGenerators();
            this.#startAutoCleanup();
            
            this.isInitialized = true;
            
            this.logger.log('INFO', 'Export manager initialized', {
                version: this.MODULE_VERSION,
                generators: this.generators.size
            });

        } catch (error) {
            this.logger.log('ERROR', 'Export manager initialization failed', {
                error: error.message
            });
            throw error;
        }
    }

    async #loadConfiguration() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['exportConfig'], (result) => {
                if (result.exportConfig) {
                    this.config = { ...this.config, ...result.exportConfig };
                }
                resolve();
            });
        });
    }

    async #initializeGenerators() {
        this.generators.set('json', new JSONGenerator());
        this.generators.set('csv', new CSVGenerator());
        this.generators.set('txt', new TXTGenerator());
        this.generators.set('jsonl', new JSONLGenerator());
    }

    #startAutoCleanup() {
        if (this.config.autoCleanup) {
            setInterval(() => {
                this.#cleanupOldSessions();
            }, this.config.cleanupInterval);
        }
    }

    #cleanupOldSessions() {
        const sessions = this.memoryManager.segments.get('streaming_sessions');
        const now = Date.now();
        let cleaned = 0;

        for (const [sessionId, session] of sessions.entries()) {
            if (now - session.lastAccess > 60 * 60 * 1000) {
                sessions.delete(sessionId);
                cleaned++;
            }
        }

        if (cleaned > 0) {
            this.logger.log('INFO', 'Old sessions cleaned', { count: cleaned });
        }
    }

    // ✅ Principle 2: Strict Interface Contract
    #validateFormat(format) {
        if (!EXPORT_FORMATS[format.toUpperCase()]) {
            throw new Error(`Unsupported export format: ${format}`);
        }
    }

    #validateData(data, format) {
        const schema = EXPORT_FORMATS[format.toUpperCase()].schema;
        
        schema.required.forEach(field => {
            if (!(field in data)) {
                throw new Error(`Missing required field '${field}' for ${format} export`);
            }
        });

        const dataSize = new Blob([JSON.stringify(data)]).size;
        if (dataSize > schema.maxSize) {
            throw new Error(`Data too large for ${format} export: ${dataSize} > ${schema.maxSize}`);
        }
    }

    #validateExportResult(result, format) {
        if (!result.content || !result.filename || !result.mimeType) {
            throw new Error(`Invalid export result for ${format}: missing required fields`);
        }

        if (result.content.length > this.config.maxFileSize) {
            throw new Error(`Export result too large: ${result.content.length} > ${this.config.maxFileSize}`);
        }
    }

    // ✅ Public API Methods
    async exportData(data, format, options = {}) {
        this.#validateFormat(format);
        this.#validateData(data, format);

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const cacheKey = this.#generateCacheKey(data, format, options);

        if (options.useCache !== false) {
            const cached = this.memoryManager.getCachedExport(cacheKey);
            if (cached) {
                this.logger.log('INFO', 'Using cached export', { format, cacheKey });
                return cached;
            }
        }

        return this.pipeline.executeWithRetry(async () => {
            const result = await this.#generateExport(data, format, timestamp, options);
            
            this.memoryManager.cacheExportResult(cacheKey, result);
            this.memoryManager.metrics.exportsProcessed++;
            
            await this.#recordExportHistory(result);

            this.logger.log('INFO', 'Export completed', {
                format,
                dataSize: result.content.length,
                cacheKey
            });

            return result;

        }, `export_${format}`);
    }

    async #generateExport(data, format, timestamp, options) {
        const generator = this.generators.get(format);
        if (!generator) {
            throw new Error(`No generator available for format: ${format}`);
        }

        const preparedData = this.#prepareExportData(data, format);
        const result = await generator.generate(preparedData, timestamp, options);

        this.#validateExportResult(result, format);

        return {
            ...result,
            format,
            timestamp: new Date().toISOString(),
            dataSize: result.content.length,
            id: this.#generateExportId()
        };
    }

    async startStreamingExport(sessionId, format = 'jsonl', options = {}) {
        this.#validateFormat(format);

        if (!EXPORT_FORMATS[format.toUpperCase()]?.streaming) {
            throw new Error(`Format ${format} does not support streaming`);
        }

        const streamInfo = {
            sessionId,
            format,
            startTime: Date.now(),
            recordCount: 0,
            chunks: [],
            options,
            metadata: {
                version: this.MODULE_VERSION,
                startedAt: new Date().toISOString()
            }
        };

        this.memoryManager.setStreamingSession(sessionId, streamInfo);

        this.logger.log('INFO', 'Streaming export started', {
            sessionId,
            format
        });

        return {
            success: true,
            sessionId,
            format,
            message: 'Streaming export started'
        };
    }

    async appendToStream(sessionId, data) {
        const streamInfo = this.memoryManager.getStreamingSession(sessionId);
        if (!streamInfo) {
            throw new Error(`Stream session not found: ${sessionId}`);
        }

        const chunk = {
            timestamp: Date.now(),
            data,
            recordCount: data.length,
            chunkId: this.#generateChunkId()
        };

        streamInfo.chunks.push(chunk);
        streamInfo.recordCount += data.length;
        streamInfo.lastActivity = Date.now();

        this.memoryManager.setStreamingSession(sessionId, streamInfo);

        this.logger.log('INFO', 'Data appended to stream', {
            sessionId,
            recordCount: data.length,
            totalRecords: streamInfo.recordCount
        });

        return {
            success: true,
            sessionId,
            appendedCount: data.length,
            totalRecords: streamInfo.recordCount,
            chunkId: chunk.chunkId
        };
    }

    async finalizeStream(sessionId) {
        const streamInfo = this.memoryManager.getStreamingSession(sessionId);
        if (!streamInfo) {
            throw new Error(`Stream session not found: ${sessionId}`);
        }

        const allData = streamInfo.chunks.flatMap(chunk => chunk.data);
        
        const exportData = {
            metadata: {
                exportType: 'streaming',
                sessionId,
                startTime: streamInfo.startTime,
                endTime: Date.now(),
                totalRecords: streamInfo.recordCount,
                totalChunks: streamInfo.chunks.length,
                duration: Date.now() - streamInfo.startTime
            },
            data: allData
        };

        const result = await this.exportData(exportData, streamInfo.format, streamInfo.options);

        this.memoryManager.deleteStreamingSession(sessionId);

        this.logger.log('INFO', 'Streaming export finalized', {
            sessionId,
            totalRecords: streamInfo.recordCount,
            totalChunks: streamInfo.chunks.length
        });

        return {
            ...result,
            streamInfo: {
                sessionId,
                duration: Date.now() - streamInfo.startTime,
                totalChunks: streamInfo.chunks.length,
                totalRecords: streamInfo.recordCount
            }
        };
    }

    async exportAllFormats(data, options = {}) {
        const formats = options.formats || Object.keys(EXPORT_FORMATS);
        const results = [];

        for (const format of formats) {
            try {
                const result = await this.exportData(data, format.toLowerCase(), options);
                results.push({ 
                    success: true, 
                    format,
                    ...result 
                });
            } catch (error) {
                results.push({ 
                    success: false, 
                    format, 
                    error: error.message 
                });
            }
        }

        const successful = results.filter(r => r.success).length;
        
        this.logger.log('INFO', 'Multi-format export completed', {
            total: results.length,
            successful,
            failed: results.length - successful
        });

        return {
            success: successful > 0,
            results,
            summary: {
                total: results.length,
                successful,
                failed: results.length - successful
            }
        };
    }

    // ✅ Utility Methods
    #prepareExportData(data, format) {
        return {
            ...data,
            exportInfo: {
                ...data.exportInfo,
                exportedAt: new Date().toISOString(),
                version: this.MODULE_VERSION,
                format,
                availableFormats: Object.keys(EXPORT_FORMATS)
            }
        };
    }

    #generateCacheKey(data, format, options) {
        try {
            return `${format}_${JSON.stringify(data)}_${JSON.stringify(options)}`;
        } catch {
            return `${format}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }
    }

    #generateExportId() {
        return `export_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    #generateChunkId() {
        return `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    async #recordExportHistory(exportResult) {
        const historyEntry = {
            ...exportResult,
            id: exportResult.id || this.#generateExportId(),
            timestamp: new Date().toISOString()
        };

        this.memoryManager.addToHistory(historyEntry);
    }

    // ✅ Public API
    getSupportedFormats() {
        return EXPORT_FORMATS;
    }

    getStreamingFormats() {
        return Object.entries(EXPORT_FORMATS)
            .filter(([_, config]) => config.streaming)
            .map(([format]) => format.toLowerCase());
    }

    getExportHistory(limit = 10) {
        return Array.from(this.memoryManager.segments.get('history').values())
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, limit);
    }

    clearExportHistory() {
        this.memoryManager.segments.get('history').clear();
        this.logger.log('INFO', 'Export history cleared');
    }

    getMetrics() {
        return {
            version: this.MODULE_VERSION,
            initialized: this.isInitialized,
            generators: this.generators.size,
            memory: this.memoryManager.getMetrics(),
            config: this.config
        };
    }

    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        
        chrome.storage.local.set({ exportConfig: this.config });
        
        this.logger.log('INFO', 'Configuration updated', { config: this.config });
        return this.config;
    }

    getLogs(limit = 20) {
        return this.logger.getLogs(limit);
    }

    destroy() {
        this.memoryManager.segments.clear();
        this.generators.clear();
        
        this.logger.log('INFO', 'Export manager destroyed');
    }

    static get CONTEXTS() {
        return EXPORT_CONTEXTS;
    }

    static get FORMATS() {
        return EXPORT_FORMATS;
    }

    static get version() {
        return '4.0.0';
    }
}

// ✅ Default export
export default EnhancedExportManager;