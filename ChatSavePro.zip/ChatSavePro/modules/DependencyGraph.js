// ============================================================
// modules/DependencyGraph.js - PRINCIPLE 13: DYNAMIC DEPENDENCY GRAPH
// ============================================================

export class DependencyGraph {
    constructor() {
        this.nodes = new Map();
        this.edges = new Map();
        this.circularDependencies = new Set();
        this.healthMetrics = new Map();
        this.changeListeners = new Set();
        
        this.CONFIG = Object.freeze({
            MAX_DEPTH: 10,
            CIRCULAR_CHECK_INTERVAL: 30000,
            HEALTH_CHECK_INTERVAL: 60000,
            MAX_NODES: 1000,
            MAX_EDGES_PER_NODE: 50
        });

        this.init();
    }

    init() {
        // شروع مانیتورینگ دوره‌ای
        this.startCircularDependencyCheck();
        this.startHealthMonitoring();
        
        console.log('✅ DependencyGraph initialized');
    }

    // ثبت ماژول جدید
    registerModule(moduleInfo) {
        const {
            id,
            name,
            type = 'module',
            version = '1.0.0',
            dependencies = [],
            provides = [],
            metadata = {}
        } = moduleInfo;

        if (!id || !name) {
            throw new Error('Module must have id and name');
        }

        const node = {
            id,
            name,
            type,
            version,
            dependencies: [],
            dependents: [],
            provides: provides,
            metadata: this.sanitizeMetadata(metadata),
            status: 'healthy',
            registeredAt: Date.now(),
            lastHealthCheck: Date.now(),
            loadTime: 0,
            errorCount: 0
        };

        this.nodes.set(id, node);

        // ثبت وابستگی‌ها
        dependencies.forEach(dep => {
            this.addDependency(id, dep);
        });

        this.notifyChange('MODULE_REGISTERED', { moduleId: id, dependencies });
        console.log(`📦 Module registered: ${name} (${id})`);
    }

    // اضافه کردن وابستگی
    addDependency(sourceId, targetId, dependencyType = 'requires') {
        if (!this.nodes.has(sourceId)) {
            throw new Error(`Source module not found: ${sourceId}`);
        }

        if (!this.nodes.has(targetId)) {
            // اگر ماژول هدف وجود ندارد، به صورت lazy ثبت کن
            this.registerModule({
                id: targetId,
                name: targetId,
                type: 'unknown',
                status: 'unknown'
            });
        }

        const edgeId = `${sourceId}->${targetId}`;
        
        const edge = {
            id: edgeId,
            source: sourceId,
            target: targetId,
            type: dependencyType,
            createdAt: Date.now(),
            weight: 1,
            healthy: true
        };

        this.edges.set(edgeId, edge);

        // آپدیت nodeها
        const sourceNode = this.nodes.get(sourceId);
        const targetNode = this.nodes.get(targetId);

        sourceNode.dependencies.push(targetId);
        targetNode.dependents.push(sourceId);

        // بررسی circular dependency
        this.detectCircularDependencies(sourceId);

        this.notifyChange('DEPENDENCY_ADDED', { sourceId, targetId, type: dependencyType });
    }

    // حذف وابستگی
    removeDependency(sourceId, targetId) {
        const edgeId = `${sourceId}->${targetId}`;
        
        if (!this.edges.has(edgeId)) {
            return false;
        }

        this.edges.delete(edgeId);

        // آپدیت nodeها
        const sourceNode = this.nodes.get(sourceId);
        const targetNode = this.nodes.get(targetId);

        if (sourceNode) {
            sourceNode.dependencies = sourceNode.dependencies.filter(dep => dep !== targetId);
        }

        if (targetNode) {
            targetNode.dependents = targetNode.dependents.filter(dep => dep !== sourceId);
        }

        this.notifyChange('DEPENDENCY_REMOVED', { sourceId, targetId });
        return true;
    }

    // تشخیص circular dependencies
    detectCircularDependencies(startNodeId) {
        const visited = new Set();
        const recursionStack = new Set();
        const cycles = [];

        const dfs = (nodeId, path = []) => {
            if (recursionStack.has(nodeId)) {
                // circular dependency پیدا شد
                const cycleStart = path.indexOf(nodeId);
                const cycle = path.slice(cycleStart);
                cycles.push([...cycle, nodeId]);
                return;
            }

            if (visited.has(nodeId)) {
                return;
            }

            visited.add(nodeId);
            recursionStack.add(nodeId);

            const node = this.nodes.get(nodeId);
            if (node) {
                for (const depId of node.dependencies) {
                    dfs(depId, [...path, nodeId]);
                }
            }

            recursionStack.delete(nodeId);
        };

        dfs(startNodeId);

        // ثبت circular dependencies
        cycles.forEach(cycle => {
            const cycleId = cycle.join('->');
            this.circularDependencies.add(cycleId);
            
            console.warn(`🔄 Circular dependency detected: ${cycleId}`);
            this.notifyChange('CIRCULAR_DEPENDENCY_DETECTED', { cycle });
        });

        return cycles;
    }

    // بررسی سلامت ماژول
    updateModuleHealth(moduleId, healthStatus) {
        if (!this.nodes.has(moduleId)) {
            throw new Error(`Module not found: ${moduleId}`);
        }

        const module = this.nodes.get(moduleId);
        const previousStatus = module.status;

        module.status = healthStatus.status || 'unknown';
        module.lastHealthCheck = Date.now();
        
        if (healthStatus.error) {
            module.errorCount++;
        }

        if (healthStatus.loadTime) {
            module.loadTime = healthStatus.loadTime;
        }

        // آپدیت سلامت وابستگی‌ها
        this.updateDependencyHealth(moduleId, healthStatus.status === 'healthy');

        if (previousStatus !== module.status) {
            this.notifyChange('MODULE_HEALTH_CHANGED', { 
                moduleId, 
                previousStatus, 
                newStatus: module.status 
            });
        }
    }

    // آپدیت سلامت وابستگی‌ها
    updateDependencyHealth(moduleId, isHealthy) {
        const module = this.nodes.get(moduleId);
        if (!module) return;

        // آپدیت edgeهای خروجی
        module.dependencies.forEach(depId => {
            const edgeId = `${moduleId}->${depId}`;
            const edge = this.edges.get(edgeId);
            if (edge) {
                edge.healthy = isHealthy;
                edge.lastHealthCheck = Date.now();
            }
        });

        // آپدیت edgeهای ورودی
        module.dependents.forEach(depId => {
            const edgeId = `${depId}->${moduleId}`;
            const edge = this.edges.get(edgeId);
            if (edge) {
                edge.healthy = isHealthy;
                edge.lastHealthCheck = Date.now();
            }
        });
    }

    // پیدا کردن مسیر بین دو ماژول
    findPath(sourceId, targetId, maxDepth = this.CONFIG.MAX_DEPTH) {
        if (!this.nodes.has(sourceId) || !this.nodes.has(targetId)) {
            return null;
        }

        const queue = [{ node: sourceId, path: [sourceId] }];
        const visited = new Set([sourceId]);

        while (queue.length > 0) {
            const { node, path } = queue.shift();

            if (path.length > maxDepth) {
                continue;
            }

            if (node === targetId) {
                return path;
            }

            const currentNode = this.nodes.get(node);
            if (!currentNode) continue;

            for (const depId of currentNode.dependencies) {
                if (!visited.has(depId)) {
                    visited.add(depId);
                    queue.push({
                        node: depId,
                        path: [...path, depId]
                    });
                }
            }
        }

        return null;
    }

    // پیدا کردن تمام وابستگی‌های یک ماژول
    getAllDependencies(moduleId, includeTransitive = true) {
        if (!this.nodes.has(moduleId)) {
            return new Set();
        }

        const dependencies = new Set();
        const visited = new Set();

        const collectDeps = (currentId) => {
            if (visited.has(currentId)) return;
            visited.add(currentId);

            const node = this.nodes.get(currentId);
            if (!node) return;

            node.dependencies.forEach(depId => {
                dependencies.add(depId);
                if (includeTransitive) {
                    collectDeps(depId);
                }
            });
        };

        collectDeps(moduleId);
        return dependencies;
    }

    // پیدا کردن تمام ماژول‌هایی که به این ماژول وابسته‌اند
    getAllDependents(moduleId, includeTransitive = true) {
        if (!this.nodes.has(moduleId)) {
            return new Set();
        }

        const dependents = new Set();
        const visited = new Set();

        const collectDependents = (currentId) => {
            if (visited.has(currentId)) return;
            visited.add(currentId);

            const node = this.nodes.get(currentId);
            if (!node) return;

            node.dependents.forEach(depId => {
                dependents.add(depId);
                if (includeTransitive) {
                    collectDependents(depId);
                }
            });
        };

        collectDependents(moduleId);
        return dependents;
    }

    // آنالیز تاثیر ماژول
    analyzeImpact(moduleId) {
        if (!this.nodes.has(moduleId)) {
            return null;
        }

        const dependencies = this.getAllDependencies(moduleId, true);
        const dependents = this.getAllDependents(moduleId, true);
        
        const module = this.nodes.get(moduleId);
        const health = this.calculateModuleHealth(moduleId);

        return {
            module: {
                id: moduleId,
                name: module.name,
                status: module.status,
                health: health
            },
            dependencies: {
                direct: module.dependencies.length,
                transitive: dependencies.size,
                modules: Array.from(dependencies)
            },
            dependents: {
                direct: module.dependents.length,
                transitive: dependents.size,
                modules: Array.from(dependents)
            },
            criticality: this.calculateCriticality(moduleId),
            risk: this.calculateRisk(moduleId)
        };
    }

    // محاسبه سلامت ماژول
    calculateModuleHealth(moduleId) {
        const module = this.nodes.get(moduleId);
        if (!module) return 0;

        let healthScore = 100;

        // جریمه برای خطاها
        healthScore -= module.errorCount * 10;

        // جریمه برای وضعیت ناسالم
        if (module.status !== 'healthy') {
            healthScore -= 30;
        }

        // جریمه برای circular dependencies
        if (this.hasCircularDependency(moduleId)) {
            healthScore -= 20;
        }

        // جریمه برای وابستگی‌های ناسالم
        const unhealthyDeps = module.dependencies.filter(depId => {
            const dep = this.nodes.get(depId);
            return dep && dep.status !== 'healthy';
        }).length;

        healthScore -= unhealthyDeps * 5;

        return Math.max(0, healthScore);
    }

    // محاسبه criticality
    calculateCriticality(moduleId) {
        const dependents = this.getAllDependents(moduleId, true).size;
        
        if (dependents > 20) return 'HIGH';
        if (dependents > 10) return 'MEDIUM';
        if (dependents > 5) return 'LOW';
        return 'MINIMAL';
    }

    // محاسبه risk
    calculateRisk(moduleId) {
        const health = this.calculateModuleHealth(moduleId);
        const criticality = this.calculateCriticality(moduleId);
        
        const criticalityWeight = {
            'HIGH': 1.0,
            'MEDIUM': 0.7,
            'LOW': 0.4,
            'MINIMAL': 0.1
        };

        const riskScore = (100 - health) * criticalityWeight[criticality];
        
        if (riskScore > 70) return 'HIGH';
        if (riskScore > 40) return 'MEDIUM';
        if (riskScore > 20) return 'LOW';
        return 'MINIMAL';
    }

    // بررسی circular dependency
    hasCircularDependency(moduleId) {
        for (const cycleId of this.circularDependencies) {
            if (cycleId.includes(moduleId)) {
                return true;
            }
        }
        return false;
    }

    // سانیتایز metadata
    sanitizeMetadata(metadata) {
        if (typeof metadata !== 'object' || metadata === null) {
            return {};
        }

        const sanitized = {};
        for (const [key, value] of Object.entries(metadata)) {
            if (['__proto__', 'constructor', 'prototype'].includes(key)) {
                continue;
            }

            if (typeof value === 'string') {
                sanitized[key] = value.substring(0, 1000);
            } else {
                sanitized[key] = value;
            }
        }

        return sanitized;
    }

    // سیستم notification
    addChangeListener(listener) {
        this.changeListeners.add(listener);
    }

    removeChangeListener(listener) {
        this.changeListeners.delete(listener);
    }

    notifyChange(eventType, data) {
        this.changeListeners.forEach(listener => {
            try {
                listener(eventType, data);
            } catch (error) {
                console.error('DependencyGraph listener error:', error);
            }
        });
    }

    // مانیتورینگ دوره‌ای
    startCircularDependencyCheck() {
        setInterval(() => {
            this.checkAllCircularDependencies();
        }, this.CONFIG.CIRCULAR_CHECK_INTERVAL);
    }

    startHealthMonitoring() {
        setInterval(() => {
            this.performHealthCheck();
        }, this.CONFIG.HEALTH_CHECK_INTERVAL);
    }

    checkAllCircularDependencies() {
        this.circularDependencies.clear();
        
        for (const moduleId of this.nodes.keys()) {
            this.detectCircularDependencies(moduleId);
        }
    }

    performHealthCheck() {
        const now = Date.now();
        let unhealthyCount = 0;

        for (const [moduleId, module] of this.nodes) {
            // ماژول‌هایی که مدت زیادی است health check نداشته‌اند
            if (now - module.lastHealthCheck > 300000) { // 5 minutes
                module.status = 'unknown';
                unhealthyCount++;
            }
        }

        if (unhealthyCount > 0) {
            console.warn(`⚠️ ${unhealthyCount} modules have unknown health status`);
        }
    }

    // گزارش‌گیری
    generateReport() {
        const report = {
            generatedAt: Date.now(),
            summary: {
                totalModules: this.nodes.size,
                totalDependencies: this.edges.size,
                circularDependencies: this.circularDependencies.size,
                unhealthyModules: Array.from(this.nodes.values())
                    .filter(m => m.status !== 'healthy').length
            },
            modules: {},
            criticalPaths: this.findCriticalPaths(),
            recommendations: this.generateRecommendations()
        };

        // اطلاعات ماژول‌ها
        for (const [moduleId, module] of this.nodes) {
            report.modules[moduleId] = {
                name: module.name,
                status: module.status,
                health: this.calculateModuleHealth(moduleId),
                dependencies: module.dependencies.length,
                dependents: module.dependents.length,
                criticality: this.calculateCriticality(moduleId),
                risk: this.calculateRisk(moduleId)
            };
        }

        return report;
    }

    // پیدا کردن critical paths
    findCriticalPaths() {
        const criticalPaths = [];
        const highRiskModules = Array.from(this.nodes.entries())
            .filter(([_, module]) => this.calculateRisk(module.id) === 'HIGH')
            .map(([id]) => id);

        for (const moduleId of highRiskModules) {
            const path = this.findLongestDependencyPath(moduleId);
            if (path && path.length > 3) {
                criticalPaths.push({
                    module: moduleId,
                    path: path,
                    length: path.length,
                    risk: 'HIGH'
                });
            }
        }

        return criticalPaths;
    }

    // پیدا کردن طولانی‌ترین مسیر وابستگی
    findLongestDependencyPath(startModuleId) {
        let longestPath = [];
        
        const dfs = (currentId, path) => {
            if (path.length > this.CONFIG.MAX_DEPTH) {
                return;
            }

            if (path.length > longestPath.length) {
                longestPath = [...path];
            }

            const node = this.nodes.get(currentId);
            if (!node) return;

            for (const depId of node.dependencies) {
                if (!path.includes(depId)) { // جلوگیری از circular
                    dfs(depId, [...path, depId]);
                }
            }
        };

        dfs(startModuleId, [startModuleId]);
        return longestPath;
    }

    // تولید توصیه‌ها
    generateRecommendations() {
        const recommendations = [];

        // توصیه برای circular dependencies
        if (this.circularDependencies.size > 0) {
            recommendations.push({
                type: 'CIRCULAR_DEPENDENCY',
                severity: 'HIGH',
                message: `Found ${this.circularDependencies.size} circular dependencies`,
                action: 'Review and break circular dependencies'
            });
        }

        // توصیه برای ماژول‌های پرریسک
        const highRiskModules = Array.from(this.nodes.values())
            .filter(m => this.calculateRisk(m.id) === 'HIGH');

        if (highRiskModules.length > 0) {
            recommendations.push({
                type: 'HIGH_RISK_MODULES',
                severity: 'HIGH',
                message: `${highRiskModules.length} high-risk modules detected`,
                action: 'Implement fallbacks for high-risk modules'
            });
        }

        return recommendations;
    }

    // پاک‌سازی
    cleanup() {
        // حذف ماژول‌های قدیمی که وابستگی ندارند
        const now = Date.now();
        const oneHourAgo = now - (60 * 60 * 1000);

        for (const [moduleId, module] of this.nodes) {
            if (module.dependents.length === 0 && 
                module.registeredAt < oneHourAgo) {
                this.nodes.delete(moduleId);
                
                // حذف edgeهای مرتبط
                for (const [edgeId, edge] of this.edges) {
                    if (edge.source === moduleId || edge.target === moduleId) {
                        this.edges.delete(edgeId);
                    }
                }
            }
        }
    }

    destroy() {
        this.nodes.clear();
        this.edges.clear();
        this.circularDependencies.clear();
        this.healthMetrics.clear();
        this.changeListeners.clear();
        console.log('🧹 DependencyGraph destroyed');
    }
}

// Singleton instance
let dependencyGraphInstance = null;

export function getDependencyGraph() {
    if (!dependencyGraphInstance) {
        dependencyGraphInstance = new DependencyGraph();
    }
    return dependencyGraphInstance;
}

export default DependencyGraph;