// ============================================================
// modules/ScanSystem.js — QuantumStage v3.9 / R9.9.0‑Final
// ============================================================
// Unified Scan Orchestration Layer bridging DeepScan & LiveScan
// ============================================================

import GuardianIntegrity from './GuardianIntegrity.js';
import Logger from './Logger.js';
import EventBus from './EventBus.js';
import SecureStatsManager from './stats-manager.js';
import DeepScan from './DeepScan.js';
import LiveScanManager from './LiveScanManager.js';

export class ScanSystem {
    static #instance = null;

    #guardian;
    #logger;
    #eventBus;
    #stats;
    #deepScan;
    #liveScan;
    #config;
    #initialized = false;

    constructor(config = {}) {
        if (ScanSystem.#instance) return ScanSystem.#instance;
        ScanSystem.#instance = this;

        this.#guardian = GuardianIntegrity.getInstance();
        this.#logger = Logger.getInstance();
        this.#eventBus = EventBus.getInstance();
        this.#stats = SecureStatsManager.getInstance();
        this.#config = {
            liveEnabled: true,
            deepInterval: 30000,
            recoveryRetries: 3,
            ...config
        };

        console.log('⚙️ ScanSystem engine created');
    }

    static getInstance(config = {}) {
        return ScanSystem.#instance || new ScanSystem(config);
    }

    // ============================================================
    // INIT & LINK
    // ============================================================
    async init() {
        if (this.#initialized) return true;

        try {
            this.#logger.info('Initializing ScanSystem...');

            // Core engines
            this.#deepScan = await DeepScan.create({ incrementalEnabled: true });
            this.#liveScan = new LiveScanManager();

            // Event bindings
            this.#linkEvents();

            this.#initialized = true;
            this.#logger.info('ScanSystem initialized successfully');
            return true;
        } catch (error) {
            this.#logger.error('ScanSystem initialization failed', { error: error.message });
            this.#guardian.recordFailure('ScanSystem', error);
            return false;
        }
    }

    #linkEvents() {
        this.#eventBus.on('scan:trigger', async payload => {
            await this.executeScan(payload);
        });

        this.#eventBus.on('scan:clear', async () => {
            await this.clearResults();
        });

        this.#logger.debug('ScanSystem event links established');
    }

    // ============================================================
    // EXECUTION LAYER
    // ============================================================
    async executeScan(payload = {}) {
        try {
            this.#logger.info('Scan execution started', payload);

            const deepResults = await this.#deepScan._executeScan(payload);
            const liveResults = this.#config.liveEnabled
                ? await this.#startLiveScan(payload)
                : [];

            const mergedResults = [...deepResults, ...liveResults];

            this.#stats.record('scans', { count: mergedResults.length });
            this.#logger.info('Scan completed', { total: mergedResults.length });

            return mergedResults;
        } catch (error) {
            this.#logger.error('Scan execution failed', { error: error.message });
            this.#guardian.recordFailure('ScanSystem', error);
            throw error;
        }
    }

    async #startLiveScan(payload) {
        try {
            await this.#liveScan.start(payload);
            return [{ id: `live-${Date.now()}`, type: 'live', status: 'started' }];
        } catch (error) {
            this.#logger.warn('LiveScan start failed', { error: error.message });
            return [];
        }
    }

    async stopLiveScan() {
        try {
            await this.#liveScan.stop();
            this.#logger.info('Live scan stopped manually');
        } catch (error) {
            this.#logger.warn('Live scan stop error', { error: error.message });
        }
    }

    async clearResults() {
        try {
            await this.#deepScan.clearResults();
            await this.#stats.clearHistorical();
            this.#logger.info('All scan results cleared');
        } catch (error) {
            this.#logger.error('Clear results failed', { error: error.message });
        }
    }

    // ============================================================
    // REPORTING & HEALTH
    // ============================================================
    async getSystemReport() {
        const status = {
            deepScan: this.#deepScan?.healthCheck(),
            liveScan: (await this.#liveScan?.getHealth?.()) || { status: 'unknown' },
            guardian: this.#guardian.healthCheck(),
            stats: this.#stats.getSummaryReport()
        };

        const globalHealth = Object.values(status)
            .map(s => s.status || s.health || 'unknown')
            .every(v => v === 'healthy' || v === 'HEALTHY') ? 'HEALTHY' : 'DEGRADED';

        return {
            globalHealth,
            status,
            timestamp: Date.now()
        };
    }

    async exportAll(format = 'json') {
        try {
            const deepData = await this.#deepScan.exportToFormat(format);
            this.#logger.info('All scans exported', { format });
            return deepData;
        } catch (error) {
            this.#logger.error('Export failed', { error: error.message });
            throw error;
        }
    }

    // ============================================================
    // CLEANUP
    // ============================================================
    destroy() {
        try {
            this.#deepScan?.destroy();
            this.#liveScan?.destroy?.();
            this.#logger.info('ScanSystem destroyed');
        } catch (error) {
            console.error('ScanSystem destruction failed', error);
        }
    }

    static get version() {
        return 'R9.9.0‑Final';
    }
}

export default ScanSystem;
