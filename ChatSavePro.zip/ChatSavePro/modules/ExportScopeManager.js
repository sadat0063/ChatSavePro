// modules/export-scope-manager.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles & Manifest V3

// ✅ Principle 2: Strict Interface Contract
const SCOPE_TYPES = Object.freeze({
    FULL: {
        name: 'Full Data Export',
        description: 'Export all available fields including metadata and analytics',
        includes: ['content', 'metadata', 'analytics', 'performance', 'raw_data', 'timestamps'],
        excludes: [],
        icon: '📊',
        securityLevel: 'high',
        requiresAuth: true,
        maxSize: 50 * 1024 * 1024,
        allowedFormats: ['json', 'jsonl', 'html']
    },
    SUMMARY: {
        name: 'Summary Data',
        description: 'Essential information only - title, URL, snippet and basic metadata',
        includes: ['title', 'url', 'snippet', 'timestamp', 'platform', 'message_count'],
        excludes: ['raw_content', 'performance_data', 'analytics', 'sensitive_metadata'],
        icon: '📋',
        securityLevel: 'medium',
        requiresAuth: false,
        maxSize: 5 * 1024 * 1024,
        allowedFormats: ['json', 'csv', 'txt', 'html']
    },
    ANALYTICS: {
        name: 'Analytics Only',
        description: 'Statistical and analytical data for reporting',
        includes: ['statistics', 'analytics', 'performance', 'trends', 'metrics'],
        excludes: ['raw_content', 'personal_data', 'sensitive_info'],
        icon: '📈',
        securityLevel: 'medium',
        requiresAuth: true,
        maxSize: 10 * 1024 * 1024,
        allowedFormats: ['json', 'csv']
    },
    CUSTOM: {
        name: 'Custom Selection',
        description: 'Choose specific fields and data types to export',
        includes: [],
        excludes: [],
        icon: '🎛️',
        securityLevel: 'variable',
        requiresAuth: true,
        maxSize: 25 * 1024 * 1024,
        allowedFormats: ['json', 'csv', 'txt', 'html', 'jsonl']
    }
});

// ✅ Principle 2: Strict Interface Contract
const FIELD_DEFINITIONS = Object.freeze({
    // Content fields
    title: { 
        category: 'content', 
        sensitive: false, 
        required: false,
        description: 'Page title or chat title'
    },
    url: { 
        category: 'content', 
        sensitive: true, 
        required: true,
        description: 'Page URL (may contain sensitive information)'
    },
    content: { 
        category: 'content', 
        sensitive: true, 
        required: false,
        description: 'Full message content'
    },
    snippet: { 
        category: 'content', 
        sensitive: false, 
        required: false,
        description: 'Content preview snippet'
    },
    
    // Metadata fields
    metadata: { 
        category: 'metadata', 
        sensitive: false, 
        required: false,
        description: 'Technical metadata'
    },
    timestamp: { 
        category: 'metadata', 
        sensitive: false, 
        required: true,
        description: 'Scan timestamp'
    },
    platform: { 
        category: 'metadata', 
        sensitive: false, 
        required: false,
        description: 'Platform identifier'
    },
    
    // Analytics fields
    analytics: { 
        category: 'analytics', 
        sensitive: false, 
        required: false,
        description: 'Analytical data and insights'
    },
    statistics: { 
        category: 'analytics', 
        sensitive: false, 
        required: false,
        description: 'Statistical information'
    },
    performance: { 
        category: 'analytics', 
        sensitive: false, 
        required: false,
        description: 'Performance metrics'
    },
    
    // System fields
    raw_data: { 
        category: 'system', 
        sensitive: true, 
        required: false,
        description: 'Raw unprocessed data'
    },
    message_count: { 
        category: 'system', 
        sensitive: false, 
        required: false,
        description: 'Total message count'
    }
});

// ✅ Import SecureFilterManager (اصلاح 1)
import SecureFilterManager from './filter-manager.js';

// ✅ Principle 9: Secure Logging & Sanitization
class ScopeLogger {
    constructor() {
        this.maxLogEntries = 100;
        this.logEntries = [];
    }

    log(level, operation, data = {}) {
        const logEntry = {
            id: `scope_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            level,
            operation: this.sanitize(operation),
            data: this.sanitize(data)
        };

        this.logEntries.push(logEntry);

        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        // Send to background for centralized logging
        chrome.runtime.sendMessage({
            type: 'SCOPE_LOG',
            payload: logEntry
        }).catch(() => {
            // Fallback to local storage
            chrome.storage.local.set({
                [`scope_log_${logEntry.id}`]: logEntry
            });
        });

        return logEntry;
    }

    sanitize(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return JSON.parse(JSON.stringify(input));
    }

    getLogs(limit = 20) {
        return this.logEntries.slice(-limit);
    }
}

// ✅ Principle 5: Memory Segmentation
class ScopeMemoryManager {
    constructor() {
        this.currentScope = 'FULL';
        this.customFields = [];
        this.metrics = {
            exportsByScope: new Map(),
            fieldUsage: new Map(),
            validationErrors: 0,
            successfulExports: 0,
            startTime: Date.now()
        };
        this.#initializeMetrics();
    }

    #initializeMetrics() {
        Object.keys(SCOPE_TYPES).forEach(scope => {
            this.metrics.exportsByScope.set(scope, 0);
        });

        Object.keys(FIELD_DEFINITIONS).forEach(field => {
            this.metrics.fieldUsage.set(field, 0);
        });
    }

    setCurrentScope(scope) {
        this.currentScope = scope;
    }

    getCurrentScope() {
        return this.currentScope;
    }

    setCustomFields(fields) {
        this.customFields = [...new Set(fields)];
    }

    getCustomFields() {
        return this.customFields;
    }

    recordExport(scope) {
        const currentCount = this.metrics.exportsByScope.get(scope) || 0;
        this.metrics.exportsByScope.set(scope, currentCount + 1);
        this.metrics.successfulExports++;
    }

    recordValidationError() {
        this.metrics.validationErrors++;
    }

    recordFieldUsage(field) {
        const currentCount = this.metrics.fieldUsage.get(field) || 0;
        this.metrics.fieldUsage.set(field, currentCount + 1);
    }

    getMetrics() {
        const uptime = Date.now() - this.metrics.startTime;
        const totalExports = this.metrics.successfulExports + this.metrics.validationErrors;
        
        return {
            timestamp: new Date().toISOString(),
            usage: {
                totalExports: this.metrics.successfulExports,
                validationErrors: this.metrics.validationErrors,
                successRate: totalExports > 0 ? 
                    (this.metrics.successfulExports / totalExports) * 100 : 0
            },
            scopes: Object.fromEntries(this.metrics.exportsByScope),
            fields: Object.fromEntries(this.metrics.fieldUsage),
            currentScope: this.currentScope,
            customFieldsCount: this.customFields.length
        };
    }

    clear() {
        this.customFields = [];
        this.metrics.exportsByScope.clear();
        this.metrics.fieldUsage.clear();
        this.metrics.validationErrors = 0;
        this.metrics.successfulExports = 0;
        this.metrics.startTime = Date.now();
        this.#initializeMetrics();
    }
}

// ✅ Main ES6 Module Class
export class ExportScopeManager {
    constructor() {
        this.MODULE_NAME = 'ExportScopeManager';
        this.MODULE_VERSION = '4.0.0';
        
        this.logger = new ScopeLogger();
        this.memoryManager = new ScopeMemoryManager();
        
        // ✅ ساخت یک instance ثابت از SecureFilterManager (اصلاح 2)
        this.filterManager = new SecureFilterManager();
        
        this.exportConfig = {
            defaultScope: 'FULL',
            enableCustomFields: true,
            autoValidate: true,
            maxCustomFields: 20,
            security: {
                enforceScopeLimits: true,
                validateFieldAccess: true,
                logExportActivities: true
            }
        };

        this.isInitialized = false;
        this.#initialize();
    }

    // ✅ Private methods for encapsulation
    async #initialize() {
        try {
            await this.#loadConfiguration();
            this.isInitialized = true;
            
            this.logger.log('INFO', 'ExportScopeManager initialized', {
                version: this.MODULE_VERSION,
                defaultScope: this.exportConfig.defaultScope
            });

        } catch (error) {
            this.logger.log('ERROR', 'ExportScopeManager initialization failed', {
                error: error.message
            });
            throw error;
        }
    }

    async #loadConfiguration() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['exportScopeConfig'], (result) => {
                if (result.exportScopeConfig) {
                    this.exportConfig = { ...this.exportConfig, ...result.exportScopeConfig };
                }
                resolve();
            });
        });
    }

    async #saveConfiguration() {
        return new Promise((resolve) => {
            chrome.storage.local.set({ 
                exportScopeConfig: this.exportConfig 
            }, () => {
                resolve();
            });
        });
    }

    // ✅ Principle 2: Strict Interface Contract
    #validateScope(scope) {
        if (!SCOPE_TYPES[scope]) {
            throw new Error(`Invalid scope: ${scope}`);
        }
    }

    #validateCustomFields(fields) {
        if (!Array.isArray(fields)) {
            throw new Error('Custom fields must be an array');
        }

        if (fields.length > this.exportConfig.maxCustomFields) {
            throw new Error(`Maximum ${this.exportConfig.maxCustomFields} custom fields allowed`);
        }

        fields.forEach(field => {
            if (!FIELD_DEFINITIONS[field]) {
                throw new Error(`Invalid field: ${field}`);
            }
        });

        this.#checkFieldConflicts(fields);
    }

    #checkFieldConflicts(fields) {
        // Check for field conflicts logic could be implemented here
        // For example, mutually exclusive fields
    }

    #validateFieldAccess(field, options = {}) {
        const fieldDef = FIELD_DEFINITIONS[field];
        
        if (fieldDef.sensitive && !options.elevatedPermissions) {
            throw new Error(`Elevated permissions required for field: ${field}`);
        }
    }

    // ✅ Public API Methods
    async changeScope(scope, options = {}) {
        this.#validateScope(scope);
        
        const operationId = this.#generateOperationId('scopeChange');
        
        try {
            await this.#checkScopePermissions(scope, options);
            
            const previousScope = this.memoryManager.getCurrentScope();
            this.memoryManager.setCurrentScope(scope);
            
            if (scope === 'CUSTOM' && options.fields) {
                await this.updateCustomFields(options.fields);
            }
            
            this.logger.log('INFO', 'Scope changed', {
                operationId,
                previousScope,
                newScope: scope,
                authenticated: options.authenticated || false
            });

            return {
                success: true,
                operationId,
                previousScope,
                newScope: scope,
                config: this.getScopeConfig(scope)
            };

        } catch (error) {
            this.logger.log('ERROR', 'Scope change failed', {
                operationId,
                error: error.message,
                scope
            });
            
            throw this.#enhanceError(error, 'changeScope', operationId);
        }
    }

    async updateCustomFields(fields, options = {}) {
        this.#validateCustomFields(fields);
        
        const operationId = this.#generateOperationId('updateCustomFields');
        
        try {
            this.memoryManager.setCustomFields(fields);
            
            this.logger.log('INFO', 'Custom fields updated', {
                operationId,
                fieldCount: fields.length,
                fields
            });

            return {
                success: true,
                operationId,
                fieldCount: fields.length,
                fields,
                estimatedSize: this.#estimateExportSize('CUSTOM')
            };

        } catch (error) {
            this.logger.log('ERROR', 'Custom fields update failed', {
                operationId,
                error: error.message
            });
            
            throw this.#enhanceError(error, 'updateCustomFields', operationId);
        }
    }

    async #checkScopePermissions(scope, options = {}) {
        const scopeConfig = SCOPE_TYPES[scope];
        
        if (scopeConfig.requiresAuth && !options.authenticated) {
            throw new Error(`Authentication required for scope: ${scope}`);
        }

        if (scopeConfig.securityLevel === 'high' && !options.elevatedPermissions) {
            throw new Error(`Elevated permissions required for scope: ${scope}`);
        }

        if (options.format && !scopeConfig.allowedFormats.includes(options.format)) {
            throw new Error(`Format ${options.format} not allowed for scope ${scope}`);
        }
    }

    async getExportConfig(options = {}) {
        const currentScope = this.memoryManager.getCurrentScope();
        const scopeConfig = SCOPE_TYPES[currentScope];
        const fields = currentScope === 'CUSTOM' ? 
            this.memoryManager.getCustomFields() : 
            scopeConfig.includes;
        
        return {
            scope: currentScope,
            fields: fields,
            timestamp: Date.now(),
            config: scopeConfig,
            security: {
                level: scopeConfig.securityLevel,
                requiresAuth: scopeConfig.requiresAuth,
                sensitiveFields: this.#getSensitiveFields(currentScope)
            },
            validation: {
                requiredFields: this.#getRequiredFields(fields),
                sizeLimit: scopeConfig.maxSize,
                format: options.format || 'json'
            },
            metadata: {
                version: this.MODULE_VERSION,
                generatedBy: this.MODULE_NAME,
                operationId: this.#generateOperationId('export')
            }
        };
    }

    async getScopedExportData(rawData, options = {}) {
        const exportConfig = await this.getExportConfig(options);
        const operationId = this.#generateOperationId('getScopedExportData');
        
        try {
            // Step 1: Filter data based on scope
            let exportData = this.#filterDataByScope(rawData, exportConfig);
            
            // Step 2: Validate the filtered data
            const validation = this.validateExportData(exportData, exportConfig);
            
            if (!validation.isValid) {
                throw new Error(`Export data validation failed: ${validation.errors.join(', ')}`);
            }
            
            // Step 3: Apply SecureFilterManager filters (اصلاح 3)
            const filteredData = await this.filterManager.applyFilters(exportData);
            
            // ✅ لاگ تست موقت (اصلاح 4)
            console.log('[ExportScope] Filters applied', {
                before: exportData?.length || 'object',
                after: filteredData?.length || 'object',
                operationId,
                scope: exportConfig.scope
            });
            
            // Step 4: Add metadata
            const finalData = {
                data: filteredData,
                metadata: {
                    exportConfig: {
                        scope: exportConfig.scope,
                        fields: exportConfig.fields,
                        timestamp: exportConfig.timestamp
                    },
                    validation: validation,
                    security: exportConfig.security,
                    metadata: exportConfig.metadata
                }
            };
            
            this.logger.log('INFO', 'Export data prepared', {
                operationId,
                scope: exportConfig.scope,
                dataSize: this.#getPayloadSize(finalData),
                validationStatus: validation.isValid
            });
            
            return finalData;

        } catch (error) {
            this.logger.log('ERROR', 'Export data preparation failed', {
                operationId,
                error: error.message,
                scope: exportConfig.scope
            });
            
            throw this.#enhanceError(error, 'getScopedExportData', operationId);
        }
    }

    validateExportData(data, config = null) {
        const exportConfig = config || this.getExportConfig();
        const validation = {
            isValid: true,
            errors: [],
            warnings: [],
            missingFields: [],
            sensitiveFields: []
        };

        try {
            // Check required fields
            const requiredFields = exportConfig.validation.requiredFields;
            validation.missingFields = requiredFields.filter(field => 
                !data[field] && data[field] !== 0 && data[field] !== false
            );

            if (validation.missingFields.length > 0) {
                validation.errors.push(`Missing required fields: ${validation.missingFields.join(', ')}`);
            }

            // Check sensitive fields
            validation.sensitiveFields = exportConfig.security.sensitiveFields.filter(field => 
                data[field] !== undefined
            );

            if (validation.sensitiveFields.length > 0 && !exportConfig.config.requiresAuth) {
                validation.warnings.push(`Export contains sensitive fields: ${validation.sensitiveFields.join(', ')}`);
            }

            // Check data size
            const dataSize = this.#getPayloadSize(data);
            if (dataSize > exportConfig.validation.sizeLimit) {
                validation.errors.push(`Data size ${this.#formatBytes(dataSize)} exceeds limit ${this.#formatBytes(exportConfig.validation.sizeLimit)}`);
            }

            validation.isValid = validation.errors.length === 0;
            
            if (validation.isValid) {
                this.memoryManager.recordExport(exportConfig.scope);
            } else {
                this.memoryManager.recordValidationError();
            }

            return validation;

        } catch (error) {
            this.logger.log('ERROR', 'Export data validation failed', {
                error: error.message
            });
            
            validation.isValid = false;
            validation.errors.push(`Validation error: ${error.message}`);
            return validation;
        }
    }

    // ✅ Utility Methods
    getScopeConfig(scope = null) {
        const targetScope = scope || this.memoryManager.getCurrentScope();
        const scopeConfig = SCOPE_TYPES[targetScope];
        
        if (!scopeConfig) {
            throw new Error(`Scope not found: ${targetScope}`);
        }

        return {
            ...scopeConfig,
            fields: this.#getScopeFields(targetScope),
            fieldCount: this.#getScopeFields(targetScope).length,
            estimatedSize: this.#estimateExportSize(targetScope),
            security: {
                level: scopeConfig.securityLevel,
                requiresAuth: scopeConfig.requiresAuth,
                sensitiveFields: this.#getSensitiveFields(targetScope)
            },
            compatibility: {
                formats: scopeConfig.allowedFormats,
                maxSize: scopeConfig.maxSize
            }
        };
    }

    getAvailableFields(options = {}) {
        let fields = Object.entries(FIELD_DEFINITIONS);
        
        if (options.category) {
            fields = fields.filter(([_, def]) => def.category === options.category);
        }
        
        if (options.sensitive !== undefined) {
            fields = fields.filter(([_, def]) => def.sensitive === options.sensitive);
        }
        
        if (options.required !== undefined) {
            fields = fields.filter(([_, def]) => def.required === options.required);
        }

        return fields.map(([name, definition]) => ({
            name: name,
            ...definition
        }));
    }

    #filterDataByScope(rawData, exportConfig) {
        // This is a placeholder - actual implementation would filter data
        // based on the fields specified in exportConfig.fields
        const filteredData = {};
        
        exportConfig.fields.forEach(field => {
            if (rawData[field] !== undefined) {
                filteredData[field] = rawData[field];
            }
        });
        
        return filteredData;
    }

    #getScopeFields(scope) {
        const scopeConfig = SCOPE_TYPES[scope];
        return scope === 'CUSTOM' ? this.memoryManager.getCustomFields() : scopeConfig.includes;
    }

    #getSensitiveFields(scope) {
        const fields = this.#getScopeFields(scope);
        return fields.filter(field => 
            FIELD_DEFINITIONS[field] && FIELD_DEFINITIONS[field].sensitive
        );
    }

    #getRequiredFields(fields) {
        return fields.filter(field => 
            FIELD_DEFINITIONS[field] && FIELD_DEFINITIONS[field].required
        );
    }

    #estimateExportSize(scope) {
        const fields = this.#getScopeFields(scope);
        const baseSize = fields.length * 100;
        const sensitiveMultiplier = this.#getSensitiveFields(scope).length * 50;
        return baseSize + sensitiveMultiplier;
    }

    #getPayloadSize(payload) {
        try {
            return new Blob([JSON.stringify(payload)]).size;
        } catch {
            return 0;
        }
    }

    #formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    #generateOperationId(prefix) {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    }

    #enhanceError(error, context, id = '') {
        const enhancedError = new Error(`[${context}] ${error.message}`);
        enhancedError.originalError = error;
        enhancedError.context = context;
        enhancedError.id = id;
        return enhancedError;
    }

    // ✅ Public API
    getStatus() {
        return {
            initialized: this.isInitialized,
            currentScope: this.memoryManager.getCurrentScope(),
            customFields: this.memoryManager.getCustomFields().length,
            config: { ...this.exportConfig },
            metrics: this.memoryManager.getMetrics(),
            filterManager: this.filterManager ? 'Available' : 'Not available'
        };
    }

    requiresAuthentication(scope = null) {
        const targetScope = scope || this.memoryManager.getCurrentScope();
        return SCOPE_TYPES[targetScope]?.requiresAuth || false;
    }

    getSecurityLevel(scope = null) {
        const targetScope = scope || this.memoryManager.getCurrentScope();
        return SCOPE_TYPES[targetScope]?.securityLevel || 'medium';
    }

    getMetrics() {
        return this.memoryManager.getMetrics();
    }

    getLogs(limit = 20) {
        return this.logger.getLogs(limit);
    }

    updateConfig(newConfig) {
        this.exportConfig = { ...this.exportConfig, ...newConfig };
        this.#saveConfiguration();
        
        this.logger.log('INFO', 'Configuration updated', {
            config: this.exportConfig
        });
        
        return this.exportConfig;
    }

    destroy() {
        this.memoryManager.clear();
        this.logger.log('INFO', 'ExportScopeManager destroyed');
    }

    static get SCOPE_TYPES() {
        return SCOPE_TYPES;
    }

    static get FIELD_DEFINITIONS() {
        return FIELD_DEFINITIONS;
    }

    static get version() {
        return '4.0.0';
    }
}

// ✅ Default export
export default ExportScopeManager;