// modules/db-handler.js
// ============================================================
// 🛡️ DBHandler - Real-time Data Manager - UPDATED VERSION
// ✅ FULLY Manifest V3 COMPLIANT - chrome.storage ONLY
// ✅ Guardian Principles Applied - Singleton, Trace & Cache
// ============================================================

const DATABASE_CONTEXTS = Object.freeze({
    SCANS: 'scans',
    LIVE_DATA: 'live_data', 
    EXPORT_HISTORY: 'export_history',
    SETTINGS: 'settings',
    ANALYTICS: 'analytics',
    SESSIONS: 'sessions',
    INCREMENTAL_CHUNKS: 'incremental_chunks',
    INCREMENTAL_MERGE: 'incremental_merge'
});

const DATABASE_SCHEMAS = Object.freeze({
    INCREMENTAL_CHUNKS: {
        required: ['id', 'sessionId', 'timestamp', 'newMessages', 'checksum'],
        optional: ['previousChecksum', 'parentScanId', 'metadata', 'chunkSize'],
        maxSize: 0.5 * 1024 * 1024
    },
    INCREMENTAL_MERGE: {
        required: ['id', 'sessionId', 'mergedAt', 'totalMessages'],
        optional: ['chunks', 'metadata', 'performance', 'compressionRatio'],
        maxSize: 1 * 1024 * 1024
    }
});

// ============================================================
// Secure Logging & Sanitization
// ============================================================
class SecureDatabaseLogger {
    constructor() {
        this.maxLogEntries = 50;
        this.logEntries = [];
    }

    log(level, operation, data = {}) {
        const logEntry = {
            id: `db_log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            level,
            operation: this.sanitize(operation),
            data: this.sanitize(data)
        };

        this.logEntries.push(logEntry);
        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        return logEntry;
    }

    sanitize(input) {
        if (typeof input === 'string') return input.replace(/[<>]/g, '');
        return JSON.parse(JSON.stringify(input));
    }

    getLogs(limit = 20) {
        return this.logEntries.slice(-limit);
    }
}

// ============================================================
// Memory Segmentation
// ============================================================
class DatabaseMemoryManager {
    constructor() {
        this.segments = new Map();
        this.metrics = {
            operations: 0,
            cacheHits: 0,
            cacheMisses: 0,
            incrementalOperations: 0,
            chunksStored: 0,
            mergesCompleted: 0
        };
        this._initializeSegments();
    }

    _initializeSegments() {
        this.segments.set('chunk_cache', new Map());
        this.segments.set('merge_cache', new Map());
        this.segments.set('query_cache', new Map());
    }

    cacheIncrementalChunk(chunkId, chunkData) {
        const cache = this.segments.get('chunk_cache');
        if (cache.size >= 100) this._evictOldestFromCache(cache);

        cache.set(chunkId, {
            ...chunkData,
            cachedAt: Date.now(),
            accessCount: 0
        });

        this.metrics.incrementalOperations++;
        this.metrics.chunksStored++;
    }

    getCachedChunk(chunkId) {
        const cache = this.segments.get('chunk_cache');
        const cached = cache.get(chunkId);
        if (cached && Date.now() - cached.cachedAt < 300000) {
            cached.accessCount++;
            this.metrics.cacheHits++;
            return cached;
        }
        this.metrics.cacheMisses++;
        return null;
    }

    cacheQueryResult(cacheKey, query, results) {
        const cache = this.segments.get('query_cache');
        if (cache.size >= 50) this._evictOldestFromCache(cache);
        cache.set(cacheKey, { query, results, cachedAt: Date.now(), accessCount: 0 });
    }

    getCachedQuery(cacheKey) {
        const cache = this.segments.get('query_cache');
        const cached = cache.get(cacheKey);
        if (cached && Date.now() - cached.cachedAt < 60000) {
            cached.accessCount++;
            this.metrics.cacheHits++;
            return cached.results;
        }
        this.metrics.cacheMisses++;
        return null;
    }

    _evictOldestFromCache(cache) {
        let oldestKey = null;
        let oldestTime = Infinity;
        for (const [key, value] of cache.entries()) {
            if (value.cachedAt < oldestTime) {
                oldestTime = value.cachedAt;
                oldestKey = key;
            }
        }
        if (oldestKey) cache.delete(oldestKey);
    }

    getMetrics() {
        return {
            operations: this.metrics.operations,
            cache: {
                hits: this.metrics.cacheHits,
                misses: this.metrics.cacheMisses,
                hitRate: this.metrics.cacheHits + this.metrics.cacheMisses > 0 ? 
                    (this.metrics.cacheHits / (this.metrics.cacheHits + this.metrics.cacheMisses)) * 100 : 0
            },
            incremental: {
                operations: this.metrics.incrementalOperations,
                chunksStored: this.metrics.chunksStored,
                mergesCompleted: this.metrics.mergesCompleted
            },
            cacheSizes: {
                chunk_cache: this.segments.get('chunk_cache').size,
                merge_cache: this.segments.get('merge_cache').size,
                query_cache: this.segments.get('query_cache').size
            }
        };
    }
}

// ============================================================
// Async Pipeline & Retry
// ============================================================
class DatabasePipeline {
    constructor() {
        this.retryConfig = { maxRetries: 3, baseDelay: 1000, maxDelay: 5000 };
    }

    async executeWithRetry(operation, operationName = 'unknown') {
        let lastError;
        for (let attempt = 1; attempt <= this.retryConfig.maxRetries; attempt++) {
            try { return await operation(); } 
            catch (error) { lastError = error; if (attempt === this.retryConfig.maxRetries) break; await this._delay(this.retryConfig.baseDelay * attempt); }
        }
        throw new Error(`Operation ${operationName} failed: ${lastError.message}`);
    }

    _delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
}

// ============================================================
// DBHandler - Singleton
// ============================================================
class DBHandler {
    constructor() {
        if (DBHandler._instance) return DBHandler._instance;

        this.initialized = false;
        this.memoryManager = new DatabaseMemoryManager();
        this.pipeline = new DatabasePipeline();
        this.logger = new SecureDatabaseLogger();
        this.config = {
            enableCaching: true,
            cacheTTL: 300000,
            maxChunkSize: 0.5 * 1024 * 1024,
            autoCleanup: true,
            cleanupInterval: 3600000
        };

        DBHandler._instance = this;
    }

    static getInstance() {
        if (!DBHandler._instance) DBHandler._instance = new DBHandler();
        return DBHandler._instance;
    }

    // Initialization & Storage Test
    async init() {
        if (this.initialized) return;
        try {
            await this._testStorageAccess();
            this.initialized = true;
            this.logger.log('INFO', 'DBHandler initialized', { storage: 'chrome.storage.local' });
            if (this.config.autoCleanup) this._startCleanupInterval();
        } catch (error) {
            this.logger.log('ERROR', 'DBHandler initialization failed', { error: error.message });
            throw error;
        }
    }

    async _testStorageAccess() {
        return new Promise((resolve, reject) => {
            if (!chrome.storage) return reject(new Error('chrome.storage not available'));
            chrome.storage.local.get(['db_handler_test'], result => {
                chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve();
            });
        });
    }

    _startCleanupInterval() {
        setInterval(() => this._performCleanup(), this.config.cleanupInterval);
    }

    async _performCleanup() {
        try {
            const threshold = Date.now() - (24*60*60*1000);
            const oldChunks = (await this._getAllFromStorage('incremental_chunks')).filter(c => c.timestamp < threshold);
            for (const chunk of oldChunks) await this._deleteFromStorage('incremental_chunks', chunk.id);
            if (oldChunks.length) this.logger.log('INFO', 'Cleanup performed', { chunksRemoved: oldChunks.length });
        } catch (error) {
            this.logger.log('WARN', 'Cleanup failed', { error: error.message });
        }
    }

    // Storage Helpers
    async _saveToStorage(namespace, key, data) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.set({ [`${namespace}_${key}`]: data }, () => {
                chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve();
            });
        });
    }

    async _getAllFromStorage(namespace) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(null, items => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                const results = [];
                const prefix = `${namespace}_`;
                for (const [key, value] of Object.entries(items)) if (key.startsWith(prefix)) results.push(value);
                resolve(results);
            });
        });
    }

    async _deleteFromStorage(namespace, key) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.remove([`${namespace}_${key}`], () => {
                chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve();
            });
        });
    }

    // Public API
    async saveIncrementalChunk(chunkData) {
        await this.init();
        const operationId = this._generateId('chunk');
        try {
            const enhancedChunk = { ...chunkData, id: chunkData.id || operationId, storedAt: Date.now(), traceId: this._generateTraceId() };
            await this._saveToStorage('incremental_chunks', enhancedChunk.id, enhancedChunk);
            this.memoryManager.cacheIncrementalChunk(enhancedChunk.id, enhancedChunk);
            this.logger.log('INFO', 'Incremental chunk saved', { id: enhancedChunk.id, traceId: enhancedChunk.traceId });
            return { success: true, id: enhancedChunk.id, operationId, traceId: enhancedChunk.traceId };
        } catch (error) {
            throw this._enhanceError(error, 'saveIncrementalChunk', operationId);
        }
    }

    async getIncrementalChunksByParent(parentId) {
        await this.init();
        const cacheKey = `parent_${parentId}`;
        const cached = this.memoryManager.getCachedQuery(cacheKey);
        if (cached) return cached;
        const allChunks = await this._getAllFromStorage('incremental_chunks');
        const filtered = allChunks.filter(c => c.parentScanId === parentId).sort((a,b)=>a.timestamp-b.timestamp);
        this.memoryManager.cacheQueryResult(cacheKey, { parentId }, filtered);
        return filtered;
    }

    _generateId(prefix) { return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2,9)}`; }
    _generateTraceId() { return `trace_${Date.now()}_${Math.random().toString(36).substr(2,6)}`; }
    _enhanceError(error, context, id) { const e = new Error(`[DB:${context}] ${error.message} (ID: ${id})`); e.originalError = error; e.context = context; e.id = id; e.traceId = this._generateTraceId(); return e; }

    getMetrics() { return this.memoryManager.getMetrics(); }
    getLogs(limit=20) { return this.logger.getLogs(limit); }
}

DBHandler._instance = null;
export { DBHandler as default };
