/* ============================================================
   ScanLayer Loader - Stage‑3 Quantum Routing (MV3 Safe Final)
   Runs in ISOLATED world, injects core to PageWorld
   Author: ChatSavePro QuantumStage 4.2-GS
   ============================================================ */

(function() {
    'use strict';
    
    console.log("[ScanLayer-CS Loader] Booting…");

    // ------------------------------------------------------------
    // 0) HARD ANTI-DUPLICATE GUARD (Stage‑3 Requirement)
    // ------------------------------------------------------------
    if (window.__SCAN_LAYER_LOADER__) {
        console.warn("[ScanLayer-CS Loader] Duplicate loader blocked.");
        return;
    }
    window.__SCAN_LAYER_LOADER__ = {
        startedAt: Date.now(),
        version: '4.2-GS-Final',
        world: 'ISOLATED'
    };

    // ------------------------------------------------------------
    // 1) Ensure Chrome APIs are available (ISOLATED world check)
    // ------------------------------------------------------------
    if (!chrome || !chrome.runtime) {
        console.warn("[ScanLayer-Loader] Extension runtime API not available");
        
        window.dispatchEvent(new CustomEvent("SCANLAYER_LOADER_ERROR", {
            detail: { 
                error: "Chrome runtime API not available",
                timestamp: Date.now()
            }
        }));
        
        return;
    }

    // ------------------------------------------------------------
    // 🔥 CRITICAL FIX: تعریف تابع در scope جهانی
    // ------------------------------------------------------------
    window.__SCANLAYER_EXTRACT_MESSAGES__ = function extractMessagesFromDOM() {
        const messages = [];
        
        try {
            console.log("[ScanLayer-Loader] Starting DeepSeek-optimized message extraction...");
            
            // 🔧 SELECTORهای بهینه‌شده برای DEEPSEEK
            const deepseekSelectors = [
                // اولویت 1: کلاس اصلی DeepSeek
                '.ds-message',
                '[class*="ds-message"]',
                
                // اولویت 2: عناصر عمومی پیام
                '[data-testid*="message"]',
                '[role="article"]',
                'article',
                
                // اولویت 3: containerهای محتوا
                'div[class*="message"]',
                'div[class*="chat"]',
                'div[class*="conversation"]'
            ];
            
            // تلاش برای یافتن پیام‌ها با selectorهای مختلف
            let nodes = [];
            for (const selector of deepseekSelectors) {
                try {
                    const found = document.querySelectorAll(selector);
                    if (found.length > 0) {
                        console.log(`[ScanLayer-Loader] Found ${found.length} nodes with selector: ${selector}`);
                        nodes = Array.from(found);
                        break;
                    }
                } catch (e) {
                    // ignore selector errors
                }
            }
            
            console.log(`[ScanLayer-Loader] Processing ${nodes.length} potential message nodes`);
            
            // 🔧 پردازش هر node با قوانین بهبود یافته
            nodes.forEach((node, index) => {
                // 🔧 تشخیص نقش (role) - بهبود یافته
                let role = 'unknown';
                
                // روش 1: از data attributes
                const dataRole = node.getAttribute('data-message-author-role') || 
                                node.getAttribute('data-role') ||
                                node.getAttribute('data-type');
                
                if (dataRole === 'assistant' || dataRole === 'user') {
                    role = dataRole;
                }
                // روش 2: از ساختار DOM DeepSeek
                else {
                    const classList = Array.from(node.classList || []);
                    const text = node.textContent?.toLowerCase() || '';
                    const html = node.innerHTML?.toLowerCase() || '';
                    
                    // نشانگرهای DeepSeek assistant
                    const assistantIndicators = [
                        // کلاس‌ها
                        'assistant', 'ai', 'bot', 'model', 'deepseek',
                        // متن‌ها
                        'به عنوان یک', 'من یک مدل', 'as an ai',
                        'می‌توانم', 'کمکتان', 'کمکتون'
                    ];
                    
                    // نشانگرهای user
                    const userIndicators = [
                        // کلاس‌ها  
                        'user', 'human', 'person', 'me', 'my',
                        // متن‌ها
                        'من ', 'سوال', 'لطفا', 'می‌خواهم',
                        'میشه', 'می‌شه', '؟', '!'
                    ];
                    
                    // محاسبه امتیاز برای هر role
                    let assistantScore = 0;
                    let userScore = 0;
                    
                    // امتیاز بر اساس کلاس
                    classList.forEach(cls => {
                        if (assistantIndicators.some(i => cls.includes(i))) assistantScore++;
                        if (userIndicators.some(i => cls.includes(i))) userScore++;
                    });
                    
                    // امتیاز بر اساس متن
                    assistantIndicators.forEach(indicator => {
                        if (text.includes(indicator) || html.includes(indicator)) assistantScore++;
                    });
                    
                    userIndicators.forEach(indicator => {
                        if (text.includes(indicator) || html.includes(indicator)) userScore++;
                    });
                    
                    // تشخیص بر اساس امتیاز
                    if (assistantScore > userScore && assistantScore >= 2) {
                        role = 'assistant';
                    } else if (userScore > assistantScore && userScore >= 2) {
                        role = 'user';
                    } else {
                        // روش 3: تشخیص بر اساس موقعیت در صفحه
                        const rect = node.getBoundingClientRect();
                        if (rect.left > window.innerWidth / 2) {
                            role = 'user'; // معمولاً در سمت راست
                        } else {
                            role = 'assistant'; // معمولاً در سمت چپ
                        }
                    }
                }
                
                // 🔧 استخراج محتوا با پاکسازی پیشرفته
                let content = '';
                
                // 1. ابتدا از direct children با محتوای اصلی
                const contentSelectors = [
                    ':scope > p',
                    ':scope > div[class*="content"]',
                    ':scope > div[class*="text"]',
                    ':scope > div[class*="message-content"]',
                    ':scope > div[class*="markdown"]'
                ];
                
                for (const selector of contentSelectors) {
                    const contentEl = node.querySelector(selector);
                    if (contentEl && contentEl.textContent?.trim()) {
                        content = contentEl.textContent.trim();
                        break;
                    }
                }
                
                // 2. اگر پیدا نشد، از تمام text nodes با فیلتر هوشمند
                if (!content) {
                    const textNodes = [];
                    const walker = document.createTreeWalker(
                        node,
                        NodeFilter.SHOW_TEXT,
                        {
                            acceptNode: function(node) {
                                // فیلتر nodes با متن معقول
                                const text = node.textContent.trim();
                                const isReasonable = text.length > 3 && 
                                                     text.length < 1000 &&
                                                     !text.match(/^\d+:\d+$/) && // زمان
                                                     !text.match(/^[٠-٩0-9]+$/) && // اعداد خالی
                                                     !text.match(/^[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+$/); // symbols
                                return isReasonable ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
                            }
                        },
                        false
                    );
                    
                    let textNode;
                    while (textNode = walker.nextNode()) {
                        textNodes.push(textNode.textContent.trim());
                    }
                    
                    if (textNodes.length > 0) {
                        content = textNodes.join(' ').trim();
                    }
                }
                
                // 3. آخرین راه‌حل: innerText کامل با پاکسازی
                if (!content && node.innerText) {
                    content = node.innerText.trim();
                }
                
                // 🔧 پاکسازی نهایی محتوا
                if (content) {
                    // حذف خطوط کوتاه و system noise
                    content = content.split('\n')
                        .map(line => line.trim())
                        .filter(line => {
                            // فیلتر noiseها
                            const isNoise = 
                                line.length < 3 ||
                                line.match(/^(Copy|Edit|Delete|Share|Like|👍|👎|↻|🔄|📋)/i) ||
                                line.match(/^\d{1,2}:\d{2}/) || // زمان
                                line.match(/^\d+\s*(min|hour|day|ثانیه|دقیقه|ساعت|روز)/i) ||
                                line.match(/^(Today|Yesterday|Just now|امروز|دیروز|الان)/i);
                            
                            return !isNoise;
                        })
                        .join('\n')
                        .trim();
                    
                    // حذف فاصله‌های اضافی
                    content = content.replace(/\s+/g, ' ').trim();
                }
                
                // 🔧 اعتبارسنجی نهایی
                if (!content || content.length < 10) {
                    console.debug(`[ScanLayer-Loader] Skipping node ${index} - insufficient content`);
                    return;
                }
                
                if (role === 'unknown') {
                    console.debug(`[ScanLayer-Loader] Skipping node ${index} - unknown role`);
                    return;
                }
                
                // 🔧 ایجاد پیام معتبر
                const message = {
                    role: role,
                    content: content,
                    timestamp: Date.now(),
                    source: 'deepseek_optimized_v2',
                    charCount: content.length,
                    nodeIndex: index,
                    hasDeepSeekClass: node.classList?.contains('ds-message') || false
                };
                
                messages.push(message);
                
                console.log(`[ScanLayer-Loader] Extracted message ${index}: role=${role}, chars=${content.length}`);
            });
            
            // 🔧 حذف duplicateها با منطق هوشمندانه
            const uniqueMessages = [];
            const seenContent = new Map();
            
            messages.forEach(msg => {
                // ایجاد key منحصربه‌فرد
                const contentKey = msg.role + ':' + 
                    msg.content.substring(0, 80)
                        .toLowerCase()
                        .replace(/\s+/g, ' ')
                        .replace(/[^\w\u0600-\u06FF\s]/g, '') // حذف علائم نگارشی
                        .trim();
                
                const existing = seenContent.get(contentKey);
                
                if (!existing) {
                    // پیام جدید
                    seenContent.set(contentKey, msg);
                    uniqueMessages.push(msg);
                } else if (msg.content.length > existing.content.length) {
                    // جایگزینی با نسخه طولانی‌تر
                    const index = uniqueMessages.indexOf(existing);
                    if (index > -1) {
                        uniqueMessages[index] = msg;
                        seenContent.set(contentKey, msg);
                    }
                }
            });
            
            // 🔧 مرتب‌سازی بر اساس موقعیت در DOM
            uniqueMessages.sort((a, b) => a.nodeIndex - b.nodeIndex);
            
            console.log(`[ScanLayer-Loader] Extraction complete: ${uniqueMessages.length} unique messages`);
            
            // 🔧 گزارش آماری
            const roleStats = {
                assistant: uniqueMessages.filter(m => m.role === 'assistant').length,
                user: uniqueMessages.filter(m => m.role === 'user').length,
                unknown: uniqueMessages.filter(m => m.role === 'unknown').length
            };
            
            console.log(`[ScanLayer-Loader] Role statistics:`, roleStats);
            
            // =====================================================
            // 🔥 NEW: SEND EXTRACTED DATA TO BACKGROUND (FIXED VERSION)
            // =====================================================
            try {
                console.log(`[ScanLayer-Loader] 📤 Sending ${uniqueMessages.length} messages to Background...`);
                
                const now = Date.now();
                const messageData = {
                    action: "SCANLAYER_DATA_READY",
                    payload: {
                        messages: uniqueMessages,
                        source: "scanlayer",
                        timestamp: now,
                        timestampISO: new Date(now).toISOString(),
                        version: "4.2-GS-Final",
                        stats: roleStats,
                        sourceUrl: window.location.href,
                        extractionMethod: "deepseek_optimized_v2"
                    },
                    // 🔥 اضافه کردن timestamp در root level هم برای compatibility
                    timestamp: now,
                    source: "scanlayer-loader",
                    tabId: chrome.devtools?.inspectedWindow?.tabId || null
                };
                
                console.log("[ScanLayer-Loader] Full message to send:", messageData);
                
                chrome.runtime.sendMessage(messageData, (response) => {
                    if (chrome.runtime.lastError) {
                        console.error("[ScanLayer-Loader] ❌ Background error:", chrome.runtime.lastError.message);
                    } else {
                        console.log(`[ScanLayer-Loader] ✅ Data sent to Background: ${uniqueMessages.length} messages`, 
                                  response ? `Response: ${JSON.stringify(response)}` : '');
                    }
                });
            } catch (e) {
                console.error("[ScanLayer-Loader] ❌ Failed to send data to Background", e);
                
                // Fallback: ارسال از طریق event
                window.dispatchEvent(new CustomEvent("SCANLAYER_DATA_EXTRACTED", {
                    detail: {
                        messages: uniqueMessages,
                        timestamp: Date.now(),
                        error: e.message
                    }
                }));
            }
            // =====================================================
            // END: SEND TO BACKGROUND
            // =====================================================
            
            return uniqueMessages;
            
        } catch (error) {
            console.error('[ScanLayer-Loader] Error extracting messages:', error);
            
            window.dispatchEvent(new CustomEvent("SCANLAYER_EXTRACTION_ERROR", {
                detail: { 
                    error: error.message,
                    timestamp: Date.now()
                }
            }));
            
            return [];
        }
    };
    
    console.log("[ScanLayer-Loader] ✅ Extraction function attached to window object");

    // ------------------------------------------------------------
    // 3) MAIN CORE INJECTION FUNCTION
    // ------------------------------------------------------------
    function injectCoreScript() {
        if (window.__SCANLAYER_CORE_INJECTED__) {
            console.warn("[ScanLayer-Loader] Duplicate core injection blocked");
            return;
        }
        window.__SCANLAYER_CORE_INJECTED__ = true;
        
        try {
            const coreUrl = chrome.runtime.getURL("modules/scan-layer.js");
            console.log("[ScanLayer-Loader] Injecting core to PageWorld:", coreUrl);
            
            const script = document.createElement("script");
            script.src = coreUrl;
            script.id = "scanlayer-core-script";
            script.type = "text/javascript";
            script.dataset.injected = "scanlayer";
            script.dataset.version = "4.2-GS-Final";
            script.dataset.timestamp = Date.now();

            script.onload = () => {
                console.log("[ScanLayer-Loader] ✅ Core script injected successfully");
                
                // تأیید دسترسی به runtime API
                if (chrome.runtime && chrome.runtime.sendMessage) {
                    console.log("[ScanLayer-Loader] ✅ Runtime API accessible");
                    window.__SCANLAYER_RUNTIME_ACCESS__ = true;
                }
                
                // 🔥 CRITICAL: Set loaded flag
                window.__SCANLAYER_LOADED__ = true;
                window.__SCANLAYER_EXTRACTION_READY__ = true;
                
                try {
                    window.postMessage({
                        source: "SCANLAYER_LOADER",
                        type: "EXPOSE_SCANLAYER_REQUEST",
                        timestamp: Date.now(),
                        version: "4.2-GS-Final",
                        capabilities: {
                            domExtraction: true,
                            deepseekOptimized: true,
                            strictMode: true,
                            version: "2.0"
                        }
                    }, "*");

                    console.log("[ScanLayer-Loader] 📡 Exposure request sent to PageWorld");
                } catch (ex) {
                    console.warn("[ScanLayer-Loader] Exposure request failed:", ex);
                }
                
                window.dispatchEvent(new CustomEvent("CORE_INJECTED", {
                    detail: { 
                        version: "4.2-GS-Final",
                        timestamp: Date.now(),
                        method: "direct_injection",
                        success: true,
                        domExtractionReady: true
                    }
                }));
                
                window.postMessage({
                    source: "SCANLAYER_LOADER",
                    type: "CORE_INJECTED",
                    success: true,
                    timestamp: Date.now(),
                    version: "4.2-GS-Final",
                    domExtraction: true
                }, "*");
                
                window.__SCANLAYER_LOAD_TIMESTAMP__ = Date.now();
                window.__SCANLAYER_VERSION__ = "4.2-GS-Final";
                
                console.log("[ScanLayer-Loader] ✅ ScanLayer fully loaded and announced");
                
                // 🔥 CRITICAL: تست خودکار پس از لود
                setTimeout(() => {
                    console.log("[ScanLayer-Loader] 🔍 Post-injection status check:");
                    console.log(" - __SCANLAYER_EXTRACT_MESSAGES__:", typeof window.__SCANLAYER_EXTRACT_MESSAGES__);
                    console.log(" - __SCANLAYER_LOADED__:", window.__SCANLAYER_LOADED__);
                    console.log(" - __SCANLAYER_CORE_INJECTED__:", window.__SCANLAYER_CORE_INJECTED__);
                    
                    if (typeof window.__SCANLAYER_EXTRACT_MESSAGES__ === 'function') {
                        console.log("[ScanLayer-Loader] 🧪 Running auto-extraction test...");
                        try {
                            const testMessages = window.__SCANLAYER_EXTRACT_MESSAGES__();
                            console.log("[ScanLayer-Loader] 🧪 Auto-extraction result:", testMessages.length, "messages");
                            
                            if (testMessages && testMessages.length > 0) {
                                const now = Date.now();
                                chrome.runtime.sendMessage({
                                    action: "SCANLAYER_DATA_READY",
                                    payload: {
                                        messages: testMessages,
                                        source: "scanlayer_auto_test",
                                        timestamp: now,
                                        timestampISO: new Date(now).toISOString(),
                                        autoExtracted: true
                                    },
                                    timestamp: now,
                                    source: "scanlayer-loader-auto"
                                }, (response) => {
                                    console.log("[ScanLayer-Loader] 🧪 Auto-send response:", response);
                                });
                            }
                        } catch (e) {
                            console.error("[ScanLayer-Loader] 🧪 Auto-extraction failed:", e);
                        }
                    }
                }, 1000);
            };

            script.onerror = (e) => {
                console.error("[ScanLayer-Loader] ❌ Failed to inject core:", e);
                
                window.dispatchEvent(new CustomEvent("CORE_INJECTION_FAILED", {
                    detail: { 
                        error: e.message || 'Unknown error',
                        timestamp: Date.now()
                    }
                }));
                
                window.__SCANLAYER_LOAD_ERROR__ = e.message || 'Script load error';
            };

            document.documentElement.appendChild(script);
            
        } catch (e) {
            console.error("[ScanLayer-Loader] ❌ Failed to inject ScanLayer core", e);
            
            window.dispatchEvent(new CustomEvent("SCANLAYER_INJECTION_ERROR", {
                detail: { 
                    error: e.message,
                    timestamp: Date.now()
                }
            }));
            
            window.__SCANLAYER_LOAD_ERROR__ = e.message;
        }
    }

    // ------------------------------------------------------------
    // 4) STARTUP LOGIC
    // ------------------------------------------------------------
    function startInjection() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(injectCoreScript, 50);
            });
        } else {
            setTimeout(injectCoreScript, 50);
        }
    }

    startInjection();

    setTimeout(() => {
        if (!window.__SCANLAYER_LOADED__ && !window.__SCANLAYER_LOAD_ERROR__) {
            console.warn("[ScanLayer-Loader] ⚠️ Injection may have stalled, retrying...");
            injectCoreScript();
        }
    }, 3000);

    // ------------------------------------------------------------
    // 5) MESSAGE LISTENERS
    // ------------------------------------------------------------
    window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        
        const data = event.data;
        
        if (data && data.type === "REQUEST_SCANLAYER_INJECTION") {
            console.log("[ScanLayer-Loader] Received injection request");
            injectCoreScript();
        }
        
        if (data && data.type === "SCANLAYER_INSTANCE_READY") {
            console.log("[ScanLayer-Loader] 🎉 ScanLayer instance acknowledged:", data);
            window.__SCANLAYER_STAGE_READY__ = true;
        }
        
        if (data && data.type === "REQUEST_MESSAGES_EXTRACTION") {
            console.log("[ScanLayer-Loader] Received extraction request from core");
            const messages = window.__SCANLAYER_EXTRACT_MESSAGES__();
            
            window.postMessage({
                source: "SCANLAYER_LOADER",
                type: "MESSAGES_EXTRACTED",
                timestamp: Date.now(),
                messages: messages,
                count: messages.length,
                deepseekOptimized: true,
                validMessages: messages.filter(m => m.role !== 'unknown' && m.content.length >= 10).length,
                stats: {
                    assistant: messages.filter(m => m.role === 'assistant').length,
                    user: messages.filter(m => m.role === 'user').length
                }
            }, "*");
        }
    });

    // ------------------------------------------------------------
    // 6) FINAL INITIALIZATION
    // ------------------------------------------------------------
    console.log("[ScanLayer-Loader] ✅ Loader initialized and ready");
    console.log("[ScanLayer-Loader] DOM Extraction: DEEPSEEK OPTIMIZED v2.0 FINAL");

    window.postMessage({
        direction: "PAGEWORLD_BRIDGE",
        channel: "SCANLAYER_STATUS",
        status: "LOADER_READY",
        payload: {
            loader: true,
            version: "4.2-GS-Final",
            timestamp: Date.now(),
            capabilities: {
                domExtraction: true,
                deepseekOptimized: true,
                strictMode: true,
                contentCleaning: true,
                duplicateRemoval: true
            }
        }
    }, "*");

    window.__SCAN_LAYER_LOADER_READY__ = true;

    // 🔥 CRITICAL: اضافه کردن تست initial
    setTimeout(() => {
        console.log("[ScanLayer-Loader] 🔍 Initial status check (after 500ms):");
        console.log(" - __SCAN_LAYER_LOADER__:", window.__SCAN_LAYER_LOADER__);
        console.log(" - __SCANLAYER_EXTRACT_MESSAGES__:", typeof window.__SCANLAYER_EXTRACT_MESSAGES__);
        console.log(" - chrome.runtime available:", !!chrome.runtime);
    }, 500);

})();