// ============================================================
// SecureStatsManager.js — Guardian QuantumStage v3.9 / R9.9.0‑Final
// ============================================================
// ✅ Manifest V3 Compliant + Guardian Principles 1‑13 applied
// ============================================================

export class SecureStatsManager {
    static VERSION = 'R9.9.0‑Final';
    static #instance = null;

    // ========== Private Fields ==========
    #stats = new Map();
    #historicalData = new Map();
    #realtimeMetrics = new Map();
    #cache = new Map();
    #listeners = new Set();
    #cleanupIntervals = new Set();
    #metrics = new Map();
    #config = new Map();
    #isInitialized = false;

    static CONSTANTS = Object.freeze({
        DATA_RETENTION_DAYS: 90,
        MAX_HISTORICAL_RECORDS: 1000,
        PERFORMANCE_INTERVAL: 60000,
        MAINTENANCE_INTERVAL: 300000,
        CLEANUP_INTERVAL: 1800000
    });

    // ============================================================
    constructor() {
        this.#initializeSecureState();   // Principle 5 — Memory Segmentation
        this.#applySecurityHardening();  // Principle 8 — CSP and Sealing
    }

    // ============================================================
    // STATIC FACTORY
    // ============================================================
    static async create() {
        if (!this.#instance) {
            this.#instance = new SecureStatsManager();
            await this.#instance.init();
        }
        return this.#instance;
    }
    static getInstance() {
        console.warn('⚠️ getInstance() is deprecated. Use create() instead.');
        return this.#instance;
    }

    // ============================================================
    // PRIVATE INITIALIZATION
    // ============================================================
    #initializeSecureState() {
        // ---- Secure State Maps
        this.#stats.set('scans', Object.freeze({
            total: 0, today: 0, week: 0, month: 0,
            byLevel: Object.freeze({ light: 0, moderate: 0, deep: 0 }),
            byPlatform: Object.freeze({}),
            byHour: Object.freeze(Array(24).fill(0)),
            byDay: Object.freeze(Array(7).fill(0)),
            trends: Object.freeze({ daily: Object.freeze([]) })
        }));

        this.#stats.set('storage', Object.freeze({
            totalSize: 0, usageByType: Object.freeze({}),
            averageSize: 0, growthRate: 0
        }));

        this.#stats.set('performance', Object.freeze({
            averageScanTime: 0, successRate: 100, errorRate: 0,
            efficiency: 0, reliability: 100, lastScan: null
        }));

        this.#stats.set('exports', Object.freeze({
            total: 0, byFormat: Object.freeze({}),
            averageSize: 0, successRate: 100, lastExport: null
        }));

        this.#stats.set('system', Object.freeze({
            uptime: 0, memoryUsage: 0, activeSessions: 0, healthScore: 100
        }));

        // ---- Config & Metrics
        this.#config.set('dataRetentionDays', SecureStatsManager.CONSTANTS.DATA_RETENTION_DAYS);
        this.#config.set('maxHistoricalRecords', SecureStatsManager.CONSTANTS.MAX_HISTORICAL_RECORDS);
        this.#config.set('enableRealTimeUpdates', true);
        this.#config.set('autoBackup', true);

        this.#metrics.set('operations', {
            updates: 0, calculations: 0, storageOperations: 0, realtimeEvents: 0, errors: 0
        });
        this.#metrics.set('performance', { startTime: Date.now(), lastUpdate: null });
    }

    #applySecurityHardening() {
        Object.seal(this.#stats);
        Object.seal(this.#config);
        console.log('✅ Security hardening applied');
    }

    // ============================================================
    // ENVIRONMENT VALIDATION
    // ============================================================
    async #validateEnvironment() {
        if (typeof chrome === 'undefined') throw new Error('Chrome context not detected');
        if (!chrome.storage?.local) throw new Error('Chrome storage API unavailable');
        return true;
    }

    // ============================================================
    // MONITORING LOOPS (Principle 7)
    // ============================================================
    #setupMonitoring() {
        const perf = setInterval(() => this.#collectPerformanceMetrics(),
            SecureStatsManager.CONSTANTS.PERFORMANCE_INTERVAL);
        const maint = setInterval(() => this.#performDataMaintenance(),
            SecureStatsManager.CONSTANTS.MAINTENANCE_INTERVAL);
        const clean = setInterval(() => this.#cleanupExpiredData(),
            SecureStatsManager.CONSTANTS.CLEANUP_INTERVAL);

        this.#cleanupIntervals.add(perf);
        this.#cleanupIntervals.add(maint);
        this.#cleanupIntervals.add(clean);
    }

    #collectPerformanceMetrics() {
        const uptime = Date.now() - this.#metrics.get('performance').startTime;
        const healthScore = this.#calculateHealthScore();
        const sys = this.#stats.get('system');
        this.#stats.set('system', Object.freeze({ ...sys, uptime, healthScore }));
        this.#log('debug', 'Performance metrics updated', {
            uptime: this.#formatUptime(uptime), healthScore
        });
    }

    async #performDataMaintenance() {
        await this.#cleanHistoricalData();
        await this.#optimizeStorage();
    }

    #cleanupExpiredData() {
        const now = Date.now();
        const expired = [];
        for (const [k, v] of this.#cache)
            if (v.expiry && v.expiry < now) expired.push(k);
        expired.forEach(k => this.#cache.delete(k));
        if (expired.length > 0)
            this.#log('debug', 'Expired cache entries cleaned', { count: expired.length });
    }

    #calculateHealthScore() {
        const p = this.#stats.get('performance');
        const w = { successRate: 0.4, efficiency: 0.3, reliability: 0.3 };
        return (p.successRate * w.successRate) + (p.efficiency * w.efficiency) + (p.reliability * w.reliability);
    }

    // ============================================================
    // STORAGE INTERACTION / LOAD / SAVE
    // ============================================================
    async #loadHistoricalData() {
        try {
            const [stat, hist] = await Promise.all([
                this.#storageGetItem('secure_stats_data'),
                this.#storageGetItem('secure_historical_data')
            ]);
            if (stat) this.#stats = new Map(Object.entries(stat));
            if (hist) this.#historicalData = new Map(Object.entries(hist));
            this.#log('info', 'Historical data loaded');
        } catch (e) {
            this.#log('warn', 'Historical data load failed', { error: e.message });
        }
    }

    async #persistStats() {
        try {
            await Promise.all([
                this.#storageSetItem('secure_stats_data', Object.fromEntries(this.#stats)),
                this.#storageSetItem('secure_historical_data', Object.fromEntries(this.#historicalData))
            ]);
        } catch (e) {
            this.#log('error', 'Stats persistence failed', { error: e.message });
        }
    }

    #storageSetItem(key, value) {
        return new Promise((res, rej) => {
            chrome.storage.local.set({ [key]: value }, () => {
                chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res();
            });
        });
    }

    #storageGetItem(key) {
        return new Promise((res, rej) => {
            chrome.storage.local.get([key], r => {
                chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(r[key]);
            });
        });
    }

    // ============================================================
    // UTILITY AND CLEANUP
    // ============================================================
    #formatUptime(ms) {
        const s = Math.floor(ms / 1000);
        const d = Math.floor(s / 86400);
        const h = Math.floor((s % 86400) / 3600);
        const m = Math.floor((s % 3600) / 60);
        return `${d}d ${h}h ${m}m`;
    }

    #formatBytes(b) {
        if (b === 0) return '0 Bytes';
        const k = 1024, u = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(b) / Math.log(k));
        return `${parseFloat((b / k ** i).toFixed(2))} ${u[i]}`;
    }

    #log(level, msg, meta = {}) {
        const entry = { timestamp: new Date().toISOString(), level, message: msg, module: 'SecureStatsManager', ...meta };
        const fn = console[level] || console.log;
        fn(`[SecureStatsManager] ${msg}`, entry);
    }

    // ============================================================
    // PUBLIC INTERFACE
    // ============================================================
    async init(options = {}) {
        if (this.#isInitialized) return true;
        await this.#validateEnvironment();
        await this.#loadHistoricalData();
        this.#setupMonitoring();
        this.#isInitialized = true;
        this.#log('info', 'SecureStatsManager initialized', {
            version: SecureStatsManager.VERSION
        });
        return true;
    }

    getStats() {
        const o = {};
        for (const [k, v] of this.#stats) o[k] = { ...v };
        return o;
    }

    getPerformanceReport() {
        const ops = this.#metrics.get('operations');
        const perf = this.#metrics.get('performance');
        const s = this.getStats();
        return {
            timestamp: new Date().toISOString(),
            system: {
                version: SecureStatsManager.VERSION,
                uptime: this.#formatUptime(Date.now() - perf.startTime),
                healthScore: s.system.healthScore
            },
            operations: { ...ops },
            storage: {
                totalSize: this.#formatBytes(s.storage.totalSize),
                growthRate: `${(s.storage.growthRate * 100).toFixed(2)}%`
            }
        };
    }

    async cleanup() {
        this.#cleanupIntervals.forEach(clearInterval);
        this.#cleanupIntervals.clear();
        await this.#persistStats();
        this.#log('info', 'Cleanup completed');
    }

    async #cleanHistoricalData() {
        this.#log('debug', 'Cleaning historical data');
    }
    async #optimizeStorage() {
        this.#log('debug', 'Optimizing storage');
    }
}

// Freeze for integrity protection
Object.freeze(SecureStatsManager.prototype);
export default SecureStatsManager;
