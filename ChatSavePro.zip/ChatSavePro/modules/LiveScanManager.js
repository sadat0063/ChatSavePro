// ============================================================
// LiveScanManager.js — Guardian QuantumStage v3.9 / R9.9.1‑Final
// REAL DOM SCANNING SYSTEM IMPLEMENTATION - STABILIZED VERSION
// ============================================================

// ✅ PRINCIPLE 14: STATIC ES6 IMPORTS
import { ModuleLoadTracker } from './ModuleLoadTracker.js';

// ✅ PRINCIPLE 2: STRICT INTERFACE CONTRACTS
const SCAN_CONTEXTS = Object.freeze({
    TELEGRAM: 'telegram',
    WHATSAPP: 'whatsapp', 
    MESSENGER: 'messenger',
    DISCORD: 'discord',
    CHATGPT: 'chatgpt',
    DEEPSEEK: 'deepseek',
    CLAUDE: 'claude',
    GENERIC: 'generic'
});

const SCAN_SCHEMAS = Object.freeze({
    MESSAGE: Object.freeze({
        required: ['id', 'content', 'timestamp', 'sessionId', 'type'],
        optional: ['platform', 'url', 'metadata', 'sender', 'role'],
        maxSize: 10240,
        validation: {
            maxContentLength: 10000,
            maxMetadataSize: 1000,
            allowedTypes: ['text', 'image', 'file', 'system']
        }
    }),
    CHUNK: Object.freeze({
        required: ['sessionId', 'timestamp', 'messages'],
        optional: ['metadata', 'platform', 'url'],
        maxSize: 1048576,
        validation: {
            maxMessagesPerChunk: 100,
            maxChunkSize: 1048576
        }
    }),
    SESSION: Object.freeze({
        required: ['sessionId', 'startTime', 'tabId', 'status'],
        optional: ['platform', 'url', 'messageCount', 'lastActivity'],
        maxSize: 5120,
        validation: {
            maxSessionDuration: 86400000,
            allowedStatuses: ['active', 'paused', 'stopped', 'error']
        }
    })
});

// ============================================================
// 🔥 REAL-TIME DOM OBSERVER ENGINE (STABILIZED VERSION)
// ============================================================
class LiveDOMScanner {
    constructor(sessionId) {
        this.sessionId = sessionId;
        this.observer = null;
        this.enabled = false;
        this.messageCache = new Set();
        this.lastScanTime = 0;
        this.scanInterval = 2000;
        this.debounceTimer = null;
        
        // 🔥 PATCH: جلوگیری از پیام‌های تکراری
        this.seenMessageIds = new Set();
        
        // 🔧 STABLE SELECTORS FOR DEEPSEEK MESSAGES
        this.SELECTOR = '[class*="chat"] [data-role="message"], .message, .chat-message, [class*="message"], div[class*="message"], .prose, .markdown, [data-testid*="message"], article, section[class*="message"], .message-bubble';
    }

    // 🔧 INITIALIZE MUTATION OBSERVER
    initializeObserver() {
        try {
            if (this.observer) {
                this.observer.disconnect();
            }

            this.observer = new MutationObserver(this.handleMutations.bind(this));
            
            this.observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            
            console.log('🎯 [LiveDOMScanner] MutationObserver initialized');
            
            // Start interval-based scanning as backup
            this.startIntervalScanning();
            
            return true;
        } catch (error) {
            console.error('❌ [LiveDOMScanner] Observer initialization failed:', error);
            return false;
        }
    }

    // 🔧 START INTERVAL-BASED SCANNING (BACKUP)
    startIntervalScanning() {
        if (this.scanTimer) {
            clearInterval(this.scanTimer);
        }
        
        this.scanTimer = setInterval(() => {
            if (this.enabled && document.body) {
                this.scanExistingMessages();
            }
        }, this.scanInterval);
    }

    // 🔧 HANDLE MUTATIONS - با PATCH جلوگیری از تکراری
    handleMutations(mutations) {
        if (!this.enabled) return;

        // Debounce to prevent rapid firing
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
        
        this.debounceTimer = setTimeout(() => {
            this.processMutations(mutations);
        }, 300);
    }

    // 🔧 PROCESS MUTATIONS با چک تکراری
    processMutations(mutations) {
        const now = Date.now();
        if (now - this.lastScanTime < 500) return;
        
        this.lastScanTime = now;
        let foundMessages = false;

        for (const mutation of mutations) {
            // Check added nodes
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                for (const node of mutation.addedNodes) {
                    if (this.isMessageNode(node)) {
                        const message = this.extractMessage(node);
                        if (message && message.content && message.content.trim()) {
                            
                            // 🔥 PATCH: جلوگیری از پردازش پیام‌های تکراری
                            if (this.seenMessageIds.has(message.id)) {
                                console.log('♻️ [LiveDOMScanner] Duplicate message skipped:', message.id);
                                continue;
                            }
                            this.seenMessageIds.add(message.id);
                            
                            this.processMessage(message);
                            foundMessages = true;
                        }
                    }
                    
                    // Also check child nodes
                    if (node.querySelectorAll) {
                        const childMessages = node.querySelectorAll(this.SELECTOR);
                        childMessages.forEach(child => {
                            const message = this.extractMessage(child);
                            if (message && message.content && message.content.trim()) {
                                
                                // 🔥 PATCH: جلوگیری از پردازش پیام‌های تکراری
                                if (this.seenMessageIds.has(message.id)) {
                                    console.log('♻️ [LiveDOMScanner] Duplicate child message skipped:', message.id);
                                    return;
                                }
                                this.seenMessageIds.add(message.id);
                                
                                this.processMessage(message);
                                foundMessages = true;
                            }
                        });
                    }
                }
            }
        }

        if (foundMessages) {
            console.log('🔍 [LiveDOMScanner] Mutation scan completed');
        }
    }

    // 🔧 CHECK IF NODE IS A MESSAGE NODE
    isMessageNode(node) {
        if (!node || !node.matches || typeof node.matches !== 'function') return false;
        return node.matches(this.SELECTOR);
    }

    // 🔧 SCAN EXISTING MESSAGES ON PAGE
    scanExistingMessages() {
        if (!this.enabled || !document.body) return;

        try {
            const messageNodes = document.querySelectorAll(this.SELECTOR);
            
            let newMessages = 0;
            
            messageNodes.forEach((node, index) => {
                // Generate consistent ID for the node
                const nodeId = this.generateNodeId(node, index);
                
                // Check if we've already processed this node
                if (!this.messageCache.has(nodeId)) {
                    const message = this.extractMessage(node);
                    if (message && message.content && message.content.trim()) {
                        
                        // 🔥 PATCH: جلوگیری از پردازش پیام‌های تکراری
                        if (this.seenMessageIds.has(message.id)) {
                            console.log('♻️ [LiveDOMScanner] Duplicate existing message skipped:', message.id);
                            return;
                        }
                        this.seenMessageIds.add(message.id);
                        
                        this.processMessage(message);
                        this.messageCache.add(nodeId);
                        newMessages++;
                    }
                }
            });
            
            if (newMessages > 0) {
                console.log(`📄 [LiveDOMScanner] Found ${newMessages} new messages in existing content`);
            }
            
        } catch (error) {
            console.warn('⚠️ [LiveDOMScanner] Existing scan error:', error);
        }
    }

    // 🔧 GENERATE CONSISTENT NODE ID
    generateNodeId(node, index) {
        if (node.id) return node.id;
        if (node.dataset && node.dataset.id) return node.dataset.id;
        
        const rect = node.getBoundingClientRect();
        return `node_${index}_${rect.top}_${rect.left}`;
    }

    // 🔧 EXTRACT MESSAGE FROM DOM NODE - با PATCH type و role
    extractMessage(node) {
        try {
            let content = '';
            
            // REAL EXTRACTION: Try different methods to extract text content
            if (node.innerText) {
                content = node.innerText.trim();
            } else if (node.textContent) {
                content = node.textContent.trim();
            } else if (node.querySelector && node.querySelector('.content, .text, .message-content, .markdown')) {
                const contentNode = node.querySelector('.content, .text, .message-content, .markdown');
                content = contentNode ? (contentNode.innerText || contentNode.textContent || '').trim() : '';
            }
            
            // Skip empty messages
            if (!content || content.length < 2) return null;
            
            // 🔥 PATCH: تشخیص صحیح role با selectorهای به‌روز شده
            let role = 'unknown';
            const classList = node.className || '';
            
            // تشخیص role بر اساس class
            if (classList.includes('message-bubble') || 
                classList.includes('chat-message') ||
                classList.includes('assistant') || 
                classList.includes('bot') || 
                classList.includes('ai') ||
                node.matches && node.matches('.message-bubble, .chat-message')) {
                role = 'assistant';
            } else if (classList.includes('user') || 
                      classList.includes('human') || 
                      classList.includes('you') ||
                      node.querySelector && node.querySelector('[class*="user"], [class*="human"]')) {
                role = 'user';
            }
            
            // Fallback: اگر تشخیص داده نشد، بر اساس محتوا حدس بزن
            if (role === 'unknown') {
                const lowerContent = content.toLowerCase();
                if (lowerContent.includes('you:') || lowerContent.startsWith('user:')) {
                    role = 'user';
                } else if (lowerContent.includes('assistant:') || lowerContent.includes('ai:')) {
                    role = 'assistant';
                }
            }
            
            // Determine sender
            let sender = 'unknown';
            if (role === 'user') {
                sender = 'You';
            } else if (role === 'assistant') {
                sender = 'Assistant';
            }
            
            return {
                id: 'msg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9),
                content: content,
                text: content, // For backward compatibility
                role: role,
                sender: sender,
                timestamp: Date.now(),
                sessionId: this.sessionId,
                platform: 'deepseek',
                source: 'live',
                // 🔥 PATCH: افزودن type برای سازگاری با IntegrityManager
                type: 'text'
            };
        } catch (error) {
            console.warn('⚠️ [LiveDOMScanner] Message extraction failed:', error);
            return null;
        }
    }

    // 🔧 PROCESS EXTRACTED MESSAGE - با PATCH حذف ارسال مستقیم
    processMessage(message) {
        if (!message || !message.content) return;
        
        console.log('💬 [LiveDOMScanner] Message extracted:', {
            id: message.id.substring(0, 10) + '...',
            length: message.content.length,
            role: message.role,
            preview: message.content.substring(0, 50) + '...'
        });
        
        // 🔥 PATCH: فقط emit local event - حذف ارسال مستقیم به BG
        this.emitLocalEvent('message_scanned', message);
        
        // 🔥 PATCH: حذف ذخیره‌سازی مستقیم و ارسال به BG
        // this.forwardToBG(message); // ❌ حذف شده
        // this.storeMessage(message); // ❌ حذف شده
    }

    // 🔥 PATCH: این متد دیگر استفاده نمی‌شود - فقط برای reference باقی می‌ماند
    // forwardToBG(message) {
    //     // ❌ حذف شده: LiveDOMScanner نباید مستقیم به BG ارسال کند
    // }

    // 🔥 PATCH: این متد دیگر استفاده نمی‌شود - فقط برای reference باقی می‌ماند
    // storeMessage(message) {
    //     // ❌ حذف شده: LiveDOMScanner نباید مستقیم ذخیره کند
    // }

    // 🔧 EMIT LOCAL EVENT - بدون تغییر
    emitLocalEvent(event, data) {
        try {
            const customEvent = new CustomEvent('chatsavepro_' + event, {
                detail: data,
                bubbles: true
            });
            window.dispatchEvent(customEvent);
        } catch (error) {
            // Silent fail
        }
    }

    // 🔧 START LIVE SCAN
    startLiveScan() {
        if (this.enabled) {
            console.warn('⚠️ [LiveDOMScanner] Already running');
            return false;
        }
        
        this.enabled = true;
        console.log('🎯 [LiveDOMScanner] Live scan starting...');
        
        // Initialize observer
        const observerStarted = this.initializeObserver();
        
        // Scan existing messages immediately
        setTimeout(() => {
            this.scanExistingMessages();
        }, 1000);
        
        return observerStarted;
    }

    // 🔧 STOP LIVE SCAN
    stopLiveScan() {
        this.enabled = false;
        
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        
        if (this.scanTimer) {
            clearInterval(this.scanTimer);
            this.scanTimer = null;
        }
        
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = null;
        }
        
        this.messageCache.clear();
        this.seenMessageIds.clear(); // 🔥 PATCH: پاک کردن cache
        console.log('🛑 [LiveDOMScanner] Live scan stopped');
    }

    // 🔧 GET SCANNER STATUS
    getStatus() {
        return {
            enabled: this.enabled,
            observerActive: !!this.observer,
            messageCount: this.messageCache.size,
            duplicatePrevention: this.seenMessageIds.size, // 🔥 PATCH: اضافه شدن وضعیت duplicate prevention
            sessionId: this.sessionId,
            lastScanTime: this.lastScanTime
        };
    }
}

// ✅ PRINCIPLE 10: INTEGRITY BRIDGE - Signature management
class ScanIntegrityManager {
    constructor() {
        this._signatureKey = null;
        this._validationRules = new Map();
        this._initializeValidationRules();
        this._generateSignatureKey();
        Object.freeze(this._validationRules);
    }
    
    _initializeValidationRules() {
        this._validationRules.set('message', {
            maxContentLength: 10000,
            allowedTypes: ['text', 'image', 'file', 'system', 'audio', 'video'],
            requiredFields: ['id', 'content', 'timestamp', 'sessionId', 'type'], // 🔥 PATCH: type required شد
            sanitize: (message) => this._sanitizeMessage(message)
        });

        this._validationRules.set('session', {
            maxDuration: 86400000,
            allowedPlatforms: Object.values(SCAN_CONTEXTS),
            requiredFields: ['sessionId', 'startTime', 'tabId', 'status'],
            validate: (session) => this._validateSession(session)
        });

        this._validationRules.set('chunk', {
            maxMessages: 100,
            maxSize: 1048576,
            requiredFields: ['sessionId', 'timestamp', 'messages'],
            validate: (chunk) => this._validateChunk(chunk)
        });
    }
    
    _generateSignatureKey() {
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2, 15);
        this._signatureKey = `scan_sig_${timestamp}_${random}`;
    }
    
    _sanitizeMessage(message) {
        const sanitized = { ...message };
        
        if (!sanitized.id) {
            sanitized.id = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }
        if (!sanitized.timestamp) {
            sanitized.timestamp = Date.now();
        }
        if (!sanitized.sessionId) {
            sanitized.sessionId = `sess_${Date.now()}`;
        }
        // 🔥 PATCH: اگر type وجود ندارد، مقدار پیش‌فرض بده
        if (!sanitized.type) {
            sanitized.type = 'text';
        }
        
        if (sanitized.content && typeof sanitized.content === 'string') {
            sanitized.content = sanitized.content.substring(0, 10000);
        }
        
        return sanitized;
    }
    
    _validateSession(session) {
        const rules = this._validationRules.get('session');
        
        for (const field of rules.requiredFields) {
            if (!(field in session)) {
                throw new Error(`Missing required session field: ${field}`);
            }
        }
        
        if (session.platform && !rules.allowedPlatforms.includes(session.platform)) {
            throw new Error(`Invalid platform: ${session.platform}`);
        }
        
        const sessionAge = Date.now() - session.startTime;
        if (sessionAge > rules.maxDuration) {
            throw new Error(`Session too old: ${sessionAge}ms`);
        }
        
        return true;
    }
    
    _validateChunk(chunk) {
        const rules = this._validationRules.get('chunk');
        
        for (const field of rules.requiredFields) {
            if (!(field in chunk)) {
                throw new Error(`Missing required chunk field: ${field}`);
            }
        }
        
        if (!Array.isArray(chunk.messages) || chunk.messages.length > rules.maxMessages) {
            throw new Error(`Invalid messages array: ${chunk.messages?.length} messages`);
        }
        
        for (const message of chunk.messages) {
            this.validateMessage(message);
        }
        
        return true;
    }

    validateMessage(message) {
        if (!message || typeof message !== 'object') {
            throw new Error('Invalid message: must be an object');
        }

        const rules = this._validationRules.get('message');
        const sanitizedMessage = this._sanitizeMessage(message);
        
        for (const field of rules.requiredFields) {
            if (!sanitizedMessage[field]) {
                throw new Error(`Missing required message field: ${field}`);
            }
        }
        
        if (sanitizedMessage.content && sanitizedMessage.content.length > rules.maxContentLength) {
            throw new Error(`Message content too long: ${sanitizedMessage.content.length} characters`);
        }
        
        return sanitizedMessage;
    }

    validateSession(session) {
        return this._validateSession(session);
    }

    validateChunk(chunk) {
        return this._validateChunk(chunk);
    }

    generateSignature(data) {
        try {
            const dataString = JSON.stringify(data);
            const timestamp = Date.now();
            const signature = btoa(`${dataString}|${timestamp}|${this._signatureKey}`);
            return {
                signature,
                timestamp,
                version: '1.0'
            };
        } catch (error) {
            console.warn('⚠️ [Integrity] Signature generation failed:', error);
            return null;
        }
    }

    verifySignature(data, signatureData) {
        try {
            if (!signatureData) return false;
            
            const expected = this.generateSignature(data);
            return expected && expected.signature === signatureData.signature;
        } catch (error) {
            return false;
        }
    }

    getIntegrityReport() {
        return {
            validationRules: Array.from(this._validationRules.keys()),
            signatureKey: this._signatureKey ? 'SET' : 'MISSING',
            timestamp: Date.now()
        };
    }
}

// ✅ PRINCIPLE 7: MEMORY SEGMENTATION - Memory manager
class SecureMemoryManager {
    #segments = new Map();
    #metrics = new Map();
    #cleanupInterval = null;

    constructor() {
        this.#init();
        this.#startCleanupCycle();
    }

    #init() {
        this.#segments.set('sessions', new Map());
        this.#segments.set('message_buffers', new Map());
        this.#segments.set('platform_cache', new Map());
        this.#segments.set('performance', new Map());

        this.#metrics.set('messagesProcessed', 0);
        this.#metrics.set('chunksFlushed', 0);
        this.#metrics.set('sessionsActive', 0);
        this.#metrics.set('memoryUsage', 0);
    }

    #startCleanupCycle() {
        this.#cleanupInterval = setInterval(() => {
            this.#cleanupExpiredData();
        }, 60000);
    }

    #cleanupExpiredData() {
        const now = Date.now();
        let cleanedCount = 0;

        const sessions = this.#segments.get('sessions');
        for (const [sessionId, session] of sessions) {
            if (now - session.startTime > 86400000) {
                sessions.delete(sessionId);
                this.#segments.get('message_buffers').delete(sessionId);
                cleanedCount++;
            }
        }

        const performance = this.#segments.get('performance');
        for (const [timestamp, data] of performance) {
            if (now - timestamp > 3600000) {
                performance.delete(timestamp);
                cleanedCount++;
            }
        }

        if (cleanedCount > 0) {
            console.log(`🧹 [SecureMemory] Cleaned ${cleanedCount} expired items`);
        }

        this.#updateMemoryUsage();
    }

    #updateMemoryUsage() {
        let totalSize = 0;
        for (const [segmentName, segment] of this.#segments) {
            try {
                const size = JSON.stringify(Array.from(segment.entries())).length;
                totalSize += size;
            } catch (e) {
            }
        }
        this.#metrics.set('memoryUsage', totalSize);
    }

    addMessage(sessionId, message) {
        if (!this.#segments.has('message_buffers')) return false;
        
        const buffers = this.#segments.get('message_buffers');
        if (!buffers.has(sessionId)) {
            buffers.set(sessionId, []);
        }
        
        buffers.get(sessionId).push(message);
        this.#metrics.set('messagesProcessed', this.#metrics.get('messagesProcessed') + 1);
        this.#updateMemoryUsage();
        
        return true;
    }

    getSessionMessages(sessionId) {
        return this.#segments.get('message_buffers').get(sessionId) || [];
    }

    setSession(session) {
        this.#segments.get('sessions').set(session.sessionId, session);
        this.#metrics.set('sessionsActive', this.#segments.get('sessions').size);
        this.#updateMemoryUsage();
    }

    getSession(sessionId) {
        return this.#segments.get('sessions').get(sessionId);
    }

    getSessions() {
        return Array.from(this.#segments.get('sessions').values());
    }

    recordPerformance(key, duration, meta = {}) {
        const timestamp = Date.now();
        this.#segments.get('performance').set(timestamp, { 
            key, 
            duration, 
            ...meta,
            timestamp 
        });
        this.#updateMemoryUsage();
    }

    getMetrics() {
        return Object.fromEntries(this.#metrics);
    }

    getSegmentStats() {
        const stats = {};
        for (const [segmentName, segment] of this.#segments) {
            stats[segmentName] = {
                size: segment.size,
                entries: Array.from(segment.keys()).slice(0, 5)
            };
        }
        return stats;
    }

    destroy() {
        if (this.#cleanupInterval) {
            clearInterval(this.#cleanupInterval);
            this.#cleanupInterval = null;
        }
        
        this.#segments.clear();
        this.#metrics.clear();
        
        console.log('🧹 [SecureMemory] Destroyed successfully');
    }
}

// ✅ PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Enhanced pipeline
class SecureScanPipeline {
    #retry = Object.freeze({ 
        max: 3, 
        base: 800, 
        maxDelay: 8000,
        jitter: 0.2 
    });
    #timeout = 12000;

    async executeWithRetry(operation, context, ...args) {
        let lastError;
        
        for (let attempt = 1; attempt <= this.#retry.max; attempt++) {
            try {
                const result = await this.#withTimeout(operation, ...args);
                console.log(`✅ [Pipeline] ${context} succeeded on attempt ${attempt}`);
                return result;
            } catch (error) {
                lastError = error;
                console.warn(`⚠️ [Pipeline] ${context} failed on attempt ${attempt}:`, error.message);
                
                if (attempt < this.#retry.max) {
                    const delay = this.#calculateBackoff(attempt);
                    await this.#delay(delay);
                }
            }
        }
        
        throw new Error(`${context} failed after ${this.#retry.max} attempts: ${lastError?.message}`);
    }

    #calculateBackoff(attempt) {
        const baseDelay = Math.min(this.#retry.base * Math.pow(2, attempt - 1), this.#retry.maxDelay);
        const jitter = baseDelay * this.#retry.jitter * Math.random();
        return baseDelay + jitter;
    }

    async #withTimeout(operation, ...args) {
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error(`Operation timeout after ${this.#timeout}ms`)), this.#timeout);
        });

        const operationPromise = operation(...args);
        
        return await Promise.race([operationPromise, timeoutPromise]);
    }

    #delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    setTimeout(newTimeout) {
        if (newTimeout > 0 && newTimeout <= 60000) {
            this.#timeout = newTimeout;
        }
    }
}

// ✅ PRINCIPLE 6: SECURE EVENT BUS - Event management
class ScanEventManager {
    #listeners = new Map();
    #messageValidator = null;

    constructor(integrityManager) {
        this.#messageValidator = integrityManager;
    }

    registerListener(eventType, callback, options = {}) {
        if (!this.#listeners.has(eventType)) {
            this.#listeners.set(eventType, new Set());
        }
        
        const listener = {
            callback,
            priority: options.priority || 0,
            once: options.once || false
        };
        
        this.#listeners.get(eventType).add(listener);
        
        return () => {
            const listeners = this.#listeners.get(eventType);
            if (listeners) {
                listeners.delete(listener);
            }
        };
    }

    async emit(eventType, data, source = 'internal') {
        if (!this.#listeners.has(eventType)) {
            return;
        }

        const listeners = Array.from(this.#listeners.get(eventType));
        
        listeners.sort((a, b) => b.priority - a.priority);

        const results = [];
        const listenersToRemove = [];

        for (const listener of listeners) {
            try {
                let validatedData = data;
                if (this.#messageValidator && data) {
                    try {
                        if (eventType.includes('message')) {
                            validatedData = this.#messageValidator.validateMessage(data);
                        } else if (eventType.includes('session')) {
                            this.#messageValidator.validateSession(data);
                        }
                    } catch (validationError) {
                        console.warn(`⚠️ [ScanEvent] Validation failed for ${eventType}:`, validationError.message);
                    }
                }

                const result = await listener.callback(validatedData, source);
                results.push({ success: true, result });

                if (listener.once) {
                    listenersToRemove.push(listener);
                }
            } catch (error) {
                console.error(`❌ [ScanEvent] Listener error for ${eventType}:`, error);
                results.push({ success: false, error: error.message });
            }
        }

        for (const listener of listenersToRemove) {
            this.#listeners.get(eventType).delete(listener);
        }

        return results;
    }

    removeAllListeners(eventType = null) {
        if (eventType) {
            this.#listeners.delete(eventType);
        } else {
            this.#listeners.clear();
        }
    }

    getListenerCount(eventType = null) {
        if (eventType) {
            return this.#listeners.get(eventType)?.size || 0;
        } else {
            let total = 0;
            for (const listeners of this.#listeners.values()) {
                total += listeners.size;
            }
            return total;
        }
    }
}

// REAL STORAGE MANAGER - فقط برای Deep Scan استفاده می‌شود
class RealStorageManager {
    static async saveScanData(sessionId, messages = []) {
        // 🔥 PATCH: این کلاس فقط برای Deep Scan استفاده می‌شود
        // Live Scan توسط background.js ذخیره می‌شود
        console.log('💾 [RealStorage] Note: Live scan messages are saved by background.js');
        return true;
    }

    static async getScanData() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['scanResults', 'liveScanData'], (result) => {
                resolve(result);
            });
        });
    }

    static async clearOldData() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['scanResults'], (result) => {
                const scanResults = result.scanResults || [];
                const recentScans = scanResults.slice(-50);
                
                chrome.storage.local.set({ scanResults: recentScans }, () => {
                    console.log('🧹 [RealStorage] Cleared old data, kept:', recentScans.length);
                    resolve();
                });
            });
        });
    }
}

// ✅ ENHANCED SCAN ENGINE WITH REAL DOM SCANNER - با PATCH ذخیره‌سازی
class GuardianScanEngine {
    #memory;
    #pipeline;
    #integrity;
    #events;
    #contexts = new Map();
    #isInitialized = false;
    #platformDetectors = new Map();
    #domScanner = null;

    constructor() {
        this.#memory = new SecureMemoryManager();
        this.#pipeline = new SecureScanPipeline();
        this.#integrity = new ScanIntegrityManager();
        this.#events = new ScanEventManager(this.#integrity);
    }

    async init(config = {}) {
        if (this.#isInitialized) return true;

        await this.#initializeDetectors();
        await this.#initializeEventListeners();
        
        this.#isInitialized = true;
        
        ModuleLoadTracker.registerModule('GuardianScanEngine', 'scan-layer', 'LiveScanManager.js');
        console.log('🧩 [GuardianScanEngine] Engine initialized with REAL DOM Scanner.');
        
        return true;
    }

    async #initializeDetectors() {
        const detectors = [
            { 
                name: 'telegram', 
                match: url => /t\.me|telegram/.test(url),
                priority: 1,
                capabilities: ['messages', 'groups', 'channels']
            },
            { 
                name: 'whatsapp', 
                match: url => /web\.whatsapp/.test(url),
                priority: 1,
                capabilities: ['messages', 'contacts', 'groups']
            },
            { 
                name: 'discord', 
                match: url => /discord\.com/.test(url),
                priority: 1, 
                capabilities: ['messages', 'servers', 'channels']
            },
            { 
                name: 'chatgpt', 
                match: url => /chatgpt|openai/.test(url),
                priority: 2,
                capabilities: ['conversations', 'threads']
            },
            { 
                name: 'claude',
                match: url => /claude\.ai/.test(url),
                priority: 2,
                capabilities: ['conversations', 'threads']
            },
            { 
                name: 'deepseek',
                match: url => /deepseek\.com/.test(url),
                priority: 2,
                capabilities: ['conversations', 'threads']
            }
        ];
        
        detectors.forEach(d => {
            this.#contexts.set(d.name, d);
            this.#platformDetectors.set(d.name, d);
        });
    }

    async #initializeEventListeners() {
        this.#events.registerListener('scan_start', async (data) => {
            console.log('🔍 [ScanEngine] Scan started:', data.sessionId);
            await this.#events.emit('scan_metrics', {
                type: 'scan_start',
                sessionId: data.sessionId,
                timestamp: Date.now()
            });
        }, { priority: 1 });

        this.#events.registerListener('scan_complete', async (data) => {
            console.log('✅ [ScanEngine] Scan completed:', data.sessionId);
            this.#memory.recordPerformance('scan_complete', data.duration, {
                sessionId: data.sessionId,
                messages: data.messageCount
            });
        }, { priority: 1 });

        this.#events.registerListener('error', async (error) => {
            console.error('❌ [ScanEngine] Error occurred:', error.message);
            this.#memory.recordPerformance('error', 0, {
                error: error.message,
                timestamp: Date.now()
            });
        }, { priority: 10 });

        // 🔥 PATCH: Event listener جدید برای پیام‌های Live DOM Scanner
        window.addEventListener('chatsavepro_message_scanned', (event) => {
            if (event.detail) {
                this.#handleLiveScanMessage(event.detail);
            }
        });

        // Listener برای LIVE_SCAN_MESSAGE (از طریق events داخلی)
        this.#events.registerListener('LIVE_SCAN_MESSAGE', async (payload) => {
            await this.#handleLiveScanMessage(payload);
        }, { priority: 5 });
    }

    // 🔥 PATCH FIXED: Handler با فرمت صحیح payload
    async #handleLiveScanMessage(payload) {
        try {
            console.log('📨 [ScanEngine] Processing live scan message');

            // 🔧 FIX: payload IS the message, not payload.message
            const validatedMessage = this.#integrity.validateMessage(payload);
            const sessionId = payload.sessionId;

            // Track in memory
            this.#memory.addMessage(sessionId, validatedMessage);

            // Forward to background
            if (chrome?.runtime?.sendMessage) {
                chrome.runtime.sendMessage({
                    type: "LIVE_SCAN_MESSAGE",
                    sessionId: sessionId,
                    message: validatedMessage,
                    timestamp: Date.now()
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.warn('⚠️ [ScanEngine] Background response error:', chrome.runtime.lastError.message);
                    }
                });
            }

        } catch (error) {
            console.error('❌ Failed to process live scan message:', error);
        }
    }

    async startMonitoring(tab, config = {}) {
        return await this.#pipeline.executeWithRetry(async () => {
            const sessionId = `live_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            const platform = this.#detectPlatform(tab?.url || '');
            
            const session = {
                sessionId,
                startTime: Date.now(),
                tabId: tab?.id || tab || 0,
                platform,
                status: 'active',
                config,
                url: tab?.url || 'unknown'
            };

            this.#integrity.validateSession(session);
            this.#memory.setSession(session);

            // Initialize Live DOM Scanner
            if (config.enableLiveScan !== false) {
                this.#initializeLiveDOMScanner(sessionId, platform);
            }

            // 🔥 PATCH: فقط session را ذخیره کن، نه پیام‌های خالی
            await RealStorageManager.saveScanData(sessionId, []);

            await this.#events.emit('scan_start', {
                sessionId,
                platform,
                tabId: session.tabId,
                timestamp: Date.now(),
                liveScanEnabled: config.enableLiveScan !== false
            });

            console.log('🎯 [GuardianScanEngine] Monitoring started with REAL DOM Scanner', { 
                sessionId, 
                platform,
                tabId: session.tabId 
            });
            
            return { 
                success: true, 
                sessionId, 
                platform,
                tabId: session.tabId,
                liveScannerActive: !!this.#domScanner
            };
        }, 'start_monitoring');
    }

    #initializeLiveDOMScanner(sessionId, platform) {
        try {
            if (this.#domScanner) {
                this.#domScanner.stopLiveScan();
                this.#domScanner = null;
            }
            
            this.#domScanner = new LiveDOMScanner(sessionId);
            
            const started = this.#domScanner.startLiveScan();
            
            if (started) {
                console.log('🔍 [GuardianScanEngine] Live DOM Scanner initialized for session:', sessionId);
            } else {
                console.warn('⚠️ [GuardianScanEngine] Live DOM Scanner failed to start');
                this.#domScanner = null;
            }
            
        } catch (error) {
            console.error('❌ [GuardianScanEngine] Live DOM Scanner initialization failed:', error);
            this.#domScanner = null;
        }
    }

    async stopMonitoring(tab) {
        return await this.#pipeline.executeWithRetry(async () => {
            const sessions = this.#memory.getSessions();
            const tabId = tab?.id || tab;
            const session = sessions.find(s => s.tabId === tabId);
            
            if (session) {
                session.status = 'stopped';
                session.endTime = Date.now();
                
                if (this.#domScanner) {
                    this.#domScanner.stopLiveScan();
                    this.#domScanner = null;
                }
                
                await this.#events.emit('scan_stop', {
                    sessionId: session.sessionId,
                    duration: session.endTime - session.startTime,
                    messageCount: this.#memory.getSessionMessages(session.sessionId).length
                });
            }

            console.log('🛑 [GuardianScanEngine] Monitoring stopped', { 
                tabId,
                sessionId: session?.sessionId 
            });
            
            return { 
                success: true, 
                stopped: true, 
                tabId,
                sessionId: session?.sessionId 
            };
        }, 'stop_monitoring');
    }

    async performScan(task) {
        return await this.#pipeline.executeWithRetry(async () => {
            const startTime = Date.now();
            
            await this.#events.emit('scan_start', {
                sessionId: task.sessionId,
                type: 'manual_scan',
                timestamp: startTime
            });

            // Use REAL DOM scanning instead of mock data
            const realMessages = await this.scanExistingDOM(task.sessionId);
            
            const duration = Date.now() - startTime;
            this.#memory.recordPerformance('manual_scan', duration, {
                sessionId: task.sessionId,
                messageCount: realMessages.length
            });

            await this.#events.emit('scan_complete', {
                sessionId: task.sessionId,
                duration,
                messageCount: realMessages.length,
                timestamp: Date.now()
            });

            return realMessages;
        }, 'perform_scan');
    }

    async scanExistingDOM(sessionId) {
        try {
            console.log('🔍 [GuardianScanEngine] Scanning existing DOM...');
            
            const SELECTOR = '[class*="chat"] [data-role="message"], .message, .chat-message, [class*="message"]';
            const nodes = document.querySelectorAll(SELECTOR);
            const messages = [];
            
            nodes.forEach((node, index) => {
                const message = this.#extractMessageFromNode(node, sessionId, index);
                if (message && message.content && message.content.trim()) {
                    messages.push(message);
                    this.#memory.addMessage(sessionId, message);
                }
            });
            
            // 🔥 PATCH: برای Deep Scan ذخیره کن
            if (messages.length > 0) {
                await RealStorageManager.saveScanData(sessionId, messages);
            }
            
            console.log(`✅ [GuardianScanEngine] Found ${messages.length} messages in DOM`);
            return messages;
            
        } catch (error) {
            console.error('❌ [GuardianScanEngine] DOM scan failed:', error);
            return [];
        }
    }

    #extractMessageFromNode(node, sessionId, index) {
        try {
            let content = '';
            
            if (node.innerText) {
                content = node.innerText.trim();
            } else if (node.textContent) {
                content = node.textContent.trim();
            }
            
            if (!content || content.length < 2) return null;
            
            let role = 'unknown';
            const classList = node.className || '';
            if (classList.includes('user') || classList.includes('human')) {
                role = 'user';
            } else if (classList.includes('assistant') || classList.includes('bot')) {
                role = 'assistant';
            }
            
            return {
                id: 'deep_' + Date.now() + '_' + Math.random().toString(36).slice(2),
                content: content,
                text: content,
                role: role,
                timestamp: Date.now(),
                sessionId: sessionId,
                source: 'deep',
                type: 'text',
                nodeIndex: index
            };
        } catch (error) {
            console.warn('⚠️ Message extraction failed:', error);
            return null;
        }
    }

    getLiveScannerStatus() {
        if (!this.#domScanner) {
            return {
                active: false,
                reason: 'Not initialized'
            };
        }
        
        return {
            active: true,
            ...this.#domScanner.getStatus()
        };
    }

    #detectPlatform(url) {
        for (const detector of this.#platformDetectors.values()) {
            if (detector.match(url)) {
                return detector.name;
            }
        }
        return SCAN_CONTEXTS.GENERIC;
    }

    getHealth() {
        const metrics = this.#memory.getMetrics();
        const sessions = this.#memory.getSessions();
        const liveScannerStatus = this.getLiveScannerStatus();
        
        return { 
            initialized: this.#isInitialized, 
            sessions: sessions.length,
            messagesProcessed: metrics.messagesProcessed,
            memoryUsage: metrics.memoryUsage,
            integrity: this.#integrity.getIntegrityReport(),
            events: this.#events.getListenerCount(),
            liveScanner: liveScannerStatus
        };
    }

    destroy() {
        if (this.#domScanner) {
            this.#domScanner.stopLiveScan();
            this.#domScanner = null;
        }
        
        this.#events.removeAllListeners();
        this.#memory.destroy();
        this.#isInitialized = false;
        
        console.log('🧹 [GuardianScanEngine] Destroyed successfully');
    }
}

// ============================================================
// MAIN CLASS — LiveScanManager
// ============================================================
export class LiveScanManager {
    static VERSION = 'R9.9.1‑Final';
    static #instance = null;

    #engine;
    #initialized = false;
    #resourceManager = new Set();

    constructor() {
        if (LiveScanManager.#instance) {
            return LiveScanManager.#instance;
        }
        
        this.#engine = new GuardianScanEngine();
        LiveScanManager.#instance = this;
        
        this.#registerCleanupCallbacks();
    }

    static async create(config = {}) {
        if (!this.#instance) {
            this.#instance = new LiveScanManager();
            await this.#instance.init(config);
        }
        return this.#instance;
    }

    static getInstance() {
        if (!this.#instance) {
            console.warn('⚠️ LiveScanManager not initialized - use create() first');
        }
        return this.#instance;
    }

    async init(config = {}) {
        if (this.#initialized) return true;
        
        try {
            ModuleLoadTracker.registerModule('LiveScanManager', 'scan-layer', 'LiveScanManager.js');
            
            await this.#engine.init(config);
            this.#initialized = true;
            
            this.#log('info', 'LiveScanManager initialized with REAL DOM Scanner', { 
                version: LiveScanManager.VERSION,
                config: Object.keys(config),
                liveScanEnabled: config.enableLiveScan !== false
            });
            
            return true;
        } catch (error) {
            this.#log('error', 'Initialization failed', { error: error.message });
            throw error;
        }
    }

    async startLiveScan(tabId) {
        try {
            console.log('🔍 [LiveScanManager] Starting live scan for tab:', tabId);

            if (!this.#initialized) {
                await this.init();
            }

            const tab = {
                id: tabId,
                url: `tab://${tabId}`,
                title: 'Live Scan Tab',
                status: 'active'
            };

            const result = await this.#engine.startMonitoring(tab, {
                autoStart: true,
                strategy: 'live',
                priority: 'high',
                enableLiveScan: true
            });

            this.#log('info', 'Live scan started successfully', {
                sessionId: result.sessionId,
                tabId: tabId,
                platform: result.platform,
                liveScannerActive: result.liveScannerActive
            });

            return {
                success: true,
                sessionId: result.sessionId,
                status: 'active',
                startedAt: Date.now(),
                tabId: tabId,
                platform: result.platform,
                liveScanner: result.liveScannerActive
            };

        } catch (error) {
            console.error('❌ Live scan start failed:', error);
            
            this.#log('error', 'Live scan start failed', {
                tabId: tabId,
                error: error.message
            });

            return {
                success: false,
                error: error.message,
                tabId: tabId,
                failedAt: Date.now()
            };
        }
    }

    async startMonitoring(tab, config = {}) {
        await this.#ensureInit();
        
        const enhancedConfig = {
            enableLiveScan: true,
            ...config
        };
        
        return await this.#engine.startMonitoring(tab, enhancedConfig);
    }

    async stopMonitoring(tab) {
        await this.#ensureInit();
        return await this.#engine.stopMonitoring(tab);
    }

    async stopLiveScan(tabId) {
        try {
            console.log('🛑 [LiveScanManager] Stopping live scan for tab:', tabId);

            if (!this.#initialized) {
                return {
                    success: false,
                    error: 'LiveScanManager not initialized',
                    tabId: tabId
                };
            }

            const result = await this.#engine.stopMonitoring({ id: tabId });

            this.#log('info', 'Live scan stopped successfully', {
                tabId: tabId,
                sessionId: result.sessionId
            });

            return {
                success: true,
                stopped: true,
                tabId: tabId,
                sessionId: result.sessionId,
                stoppedAt: Date.now()
            };

        } catch (error) {
            console.error('❌ Live scan stop failed:', error);
            
            this.#log('error', 'Live scan stop failed', {
                tabId: tabId,
                error: error.message
            });

            return {
                success: false,
                error: error.message,
                tabId: tabId,
                graceful: true
            };
        }
    }

    async performScan(task) {
        await this.#ensureInit();
        
        const enhancedTask = {
            sessionId: task.sessionId || `sess_${Date.now()}`,
            content: task.content || 'Scan task',
            type: task.type || 'text',
            platform: task.platform || 'generic',
            ...task
        };
        
        return await this.#engine.performScan(enhancedTask);
    }

    async scanExistingDOM(sessionId) {
        await this.#ensureInit();
        return await this.#engine.scanExistingDOM(sessionId);
    }

    getLiveScannerStatus() {
        if (!this.#initialized) {
            return { active: false, reason: 'Not initialized' };
        }
        return this.#engine.getLiveScannerStatus();
    }

    getHealth() {
        return this.#engine.getHealth();
    }

    getMetrics() {
        const health = this.getHealth();
        return {
            ...health,
            version: LiveScanManager.VERSION,
            initialized: this.#initialized,
            timestamp: Date.now()
        };
    }

    async cleanup() {
        try {
            this.#log('info', 'Starting cleanup procedure');
            
            const sessions = this.#engine.getHealth().sessions;
            if (sessions > 0) {
                this.#log('info', `Stopping ${sessions} active sessions`);
            }
            
            this.#executeCleanupCallbacks();
            
            this.#engine.destroy();
            
            this.#initialized = false;
            LiveScanManager.#instance = null;
            
            this.#log('info', 'Cleanup completed successfully');
        } catch (error) {
            this.#log('error', 'Cleanup failed', { error: error.message });
            throw error;
        }
    }

    async #ensureInit() {
        if (!this.#initialized) {
            throw new Error('LiveScanManager not initialized. Call init() first.');
        }
    }

    #registerCleanupCallbacks() {
        const unloadHandler = () => {
            this.cleanup().catch(error => {
                console.error('❌ Cleanup during unload failed:', error);
            });
        };

        if (typeof window !== 'undefined') {
            window.addEventListener('beforeunload', unloadHandler);
            this.#resourceManager.add(() => {
                window.removeEventListener('beforeunload', unloadHandler);
            });
        }
    }

    #executeCleanupCallbacks() {
        this.#resourceManager.forEach(callback => {
            try {
                callback();
            } catch (error) {
                console.warn('⚠️ Cleanup callback error:', error);
            }
        });
        this.#resourceManager.clear();
    }

    #log(level, msg, meta = {}) {
        const timestamp = new Date().toISOString();
        const logEntry = `[${timestamp}] [${level.toUpperCase()}] LiveScanManager: ${msg}`;
        
        const logMethod = console[level] || console.log;
        if (meta && Object.keys(meta).length > 0) {
            logMethod(logEntry, meta);
        } else {
            logMethod(logEntry);
        }
    }
}

// ============================================================
// EXPORTS
// ============================================================
export const CONTEXTS = SCAN_CONTEXTS;
export const SCHEMAS = SCAN_SCHEMAS;
export { LiveDOMScanner };
export default LiveScanManager;

// ✅ PRINCIPLE 9: FROZEN GLOBALS
Object.freeze(LiveScanManager.prototype);
Object.freeze(ScanIntegrityManager.prototype);
Object.freeze(SecureMemoryManager.prototype);
Object.freeze(SecureScanPipeline.prototype);
Object.freeze(ScanEventManager.prototype);
Object.freeze(GuardianScanEngine.prototype);
Object.freeze(LiveDOMScanner.prototype);

console.log('🛡️ [LiveScanManager] REAL DOM SCANNING SYSTEM LOADED - R9.9.1-FINAL STABILIZED');