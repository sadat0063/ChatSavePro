// modules/diagnostic-runner.js
// ============================================================
// 🛡️ ES6 Module compliant with Guardian Principles & Manifest V3

// ✅ Principle 2: Strict Interface Contract
const DIAGNOSTIC_SCHEMA = {
    TEST_CASE: {
        required: ['name', 'action'],
        optional: ['params', 'expected', 'timeout']
    },
    TEST_RESULT: {
        required: ['name', 'status'],
        optional: ['details', 'duration', 'error']
    }
};

// ✅ Principle 9: Secure Logging & Sanitization
class DiagnosticLogger {
    constructor() {
        this.maxLogEntries = 50;
        this.logEntries = [];
    }

    log(level, testName, data = {}) {
        const logEntry = {
            id: `diag_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            level,
            testName: this.sanitize(testName),
            data: this.sanitize(data)
        };

        this.logEntries.push(logEntry);

        if (this.logEntries.length > this.maxLogEntries) {
            this.logEntries = this.logEntries.slice(-this.maxLogEntries);
        }

        // Send to background for storage
        chrome.runtime.sendMessage({
            type: 'DIAGNOSTIC_LOG',
            payload: logEntry
        }).catch(() => {
            // Store locally if background not ready
            chrome.storage.local.set({
                [`diag_log_${logEntry.id}`]: logEntry
            });
        });

        return logEntry;
    }

    sanitize(input) {
        if (typeof input === 'string') {
            return input.replace(/[<>]/g, '');
        }
        return JSON.parse(JSON.stringify(input));
    }

    getLogs(limit = 20) {
        return this.logEntries.slice(-limit);
    }
}

// ✅ Principle 7: Async Pipeline & Resilience
class TestPipeline {
    constructor() {
        this.timeout = 10000;
    }

    async executeWithTimeout(operation, operationName) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Test operation ${operationName} timeout after ${this.timeout}ms`));
            }, this.timeout);
            
            Promise.resolve(operation())
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }

    validateTestResult(result, schema) {
        if (!result || typeof result !== 'object') {
            throw new Error('Invalid test result format');
        }

        schema.required.forEach(field => {
            if (!(field in result)) {
                throw new Error(`Missing required field '${field}' in test result`);
            }
        });

        return true;
    }
}

// ✅ Main ES6 Module Class
export class DiagnosticRunner {
    constructor() {
        this.MODULE_NAME = 'DiagnosticRunner';
        this.MODULE_VERSION = '2.1.0';
        
        this.logger = new DiagnosticLogger();
        this.pipeline = new TestPipeline();
        
        this.testResults = [];
        this.globalPass = true;
    }

    // ✅ Private methods for encapsulation
    #logResult(name, status, details = {}) {
        const isPass = status === 'PASS';
        const result = {
            name,
            status,
            details: JSON.stringify(details, null, 2),
            timestamp: Date.now()
        };

        this.testResults.push(result);
        
        if (!isPass) {
            this.globalPass = false;
        }

        this.logger.log(isPass ? 'INFO' : 'ERROR', name, {
            status,
            details: Object.keys(details).length > 0 ? details : undefined
        });

        return result;
    }

    #mockHandleMessage(message, controller) {
        return new Promise((resolve) => {
            const mockRespond = (response) => {
                resolve(response);
            };
            
            // Use controller's internal message handling
            if (controller._handleMessage) {
                controller._handleMessage(message, {}, mockRespond);
            } else {
                resolve({ 
                    success: false, 
                    error: 'Controller message handling not available' 
                });
            }
        });
    }

    #validateController(controller) {
        if (!controller || typeof controller !== 'object') {
            throw new Error('Invalid controller instance provided');
        }

        if (typeof controller._handleMessage !== 'function') {
            throw new Error('Controller does not support message handling');
        }

        return true;
    }

    // ✅ Public API Methods
    async runDiagnostics(controller) {
        this.#validateController(controller);
        
        this.testResults = [];
        this.globalPass = true;

        this.logger.log('INFO', 'Diagnostics started', {
            version: this.MODULE_VERSION,
            timestamp: new Date().toISOString()
        });

        try {
            // ✅ Test 1: Core Controller Status Check
            await this.#testCoreStatus(controller);
            
            // ✅ Test 2: Communication Ping Check
            await this.#testCommunication(controller);
            
            // ✅ Test 3: Scanner Lifecycle Check
            await this.#testScannerLifecycle(controller);
            
            // ✅ Test 4: Storage Read/Write/Clear Check
            await this.#testStorageOperations(controller);
            
            // ✅ Test 5: Exporter Availability Check
            await this.#testExporterAvailability(controller);

        } catch (error) {
            this.logger.log('ERROR', 'Diagnostics execution failed', {
                error: error.message
            });
            throw error;
        }

        return this.#generateFinalReport();
    }

    async #testCoreStatus(controller) {
        const testName = 'Core Status (getStatus)';
        
        return this.pipeline.executeWithTimeout(async () => {
            try {
                const message = { action: 'getStatus' };
                const response = await this.#mockHandleMessage(message, controller);

                if (response.success && 
                    response.status?.controller === 'initialized' && 
                    response.status?.storage === 'ready') {
                    return this.#logResult(testName, 'PASS', response.status);
                } else {
                    return this.#logResult(testName, 'FAIL', { 
                        response, 
                        expected: 'Initialized/Ready' 
                    });
                }
            } catch (error) {
                return this.#logResult(testName, 'FAIL (Exception)', { 
                    error: error.message 
                });
            }
        }, testName);
    }

    async #testCommunication(controller) {
        const testName = 'Communication (ping)';
        
        return this.pipeline.executeWithTimeout(async () => {
            try {
                const message = { action: 'ping' };
                const response = await this.#mockHandleMessage(message, controller);

                if (response.success && 
                    response.message === 'pong' && 
                    response.controller === 'active') {
                    return this.#logResult(testName, 'PASS', response);
                } else {
                    return this.#logResult(testName, 'FAIL', { 
                        response, 
                        expected: 'pong/active' 
                    });
                }
            } catch (error) {
                return this.#logResult(testName, 'FAIL (Exception)', { 
                    error: error.message 
                });
            }
        }, testName);
    }

    async #testScannerLifecycle(controller) {
        const testName = 'Scanner Lifecycle';
        
        return this.pipeline.executeWithTimeout(async () => {
            try {
                if (!controller.scanManager) {
                    return this.#logResult(testName, 'WARN', {
                        message: 'ScanManager not available, skipping tests'
                    });
                }

                // Test Start Scan
                const startMessage = { action: 'startScan' };
                const startResponse = await this.#mockHandleMessage(startMessage, controller);
                
                if (!startResponse.success) {
                    return this.#logResult(testName, 'FAIL', {
                        operation: 'startScan',
                        error: startResponse.error
                    });
                }

                // Test Stop Scan
                const stopMessage = { action: 'stopScan' };
                const stopResponse = await this.#mockHandleMessage(stopMessage, controller);
                
                if (!stopResponse.success) {
                    return this.#logResult(testName, 'FAIL', {
                        operation: 'stopScan',
                        error: stopResponse.error
                    });
                }

                return this.#logResult(testName, 'PASS', {
                    startScan: startResponse.success,
                    stopScan: stopResponse.success
                });

            } catch (error) {
                return this.#logResult(testName, 'FAIL (Exception)', { 
                    error: error.message 
                });
            }
        }, testName);
    }

    async #testStorageOperations(controller) {
        const testName = 'Storage R/W Operations';
        const TEST_KEY = 'diagnostic_test_key';
        const TEST_VALUE = 'R8_CORE_STABILITY_CHECK';
        
        return this.pipeline.executeWithTimeout(async () => {
            try {
                // Test Write
                await this.#mockHandleMessage({
                    action: 'setSetting',
                    key: TEST_KEY,
                    value: TEST_VALUE
                }, controller);

                // Test Read
                const readResponse = await this.#mockHandleMessage({
                    action: 'getSetting',
                    key: TEST_KEY
                }, controller);

                if (!readResponse.success || readResponse.data !== TEST_VALUE) {
                    return this.#logResult(testName, 'FAIL', {
                        operation: 'read',
                        expected: TEST_VALUE,
                        actual: readResponse.data
                    });
                }

                // Test Clear
                await this.#mockHandleMessage({
                    action: 'removeSetting',
                    key: TEST_KEY
                }, controller);

                const clearResponse = await this.#mockHandleMessage({
                    action: 'getSetting',
                    key: TEST_KEY
                }, controller);

                if (!clearResponse.success || clearResponse.data !== undefined) {
                    return this.#logResult(testName, 'FAIL', {
                        operation: 'clear',
                        expected: 'undefined',
                        actual: clearResponse.data
                    });
                }

                return this.#logResult(testName, 'PASS', {
                    operations: ['write', 'read', 'clear'],
                    allSuccessful: true
                });

            } catch (error) {
                return this.#logResult(testName, 'FAIL (Exception)', { 
                    error: error.message 
                });
            }
        }, testName);
    }

    async #testExporterAvailability(controller) {
        const testName = 'Exporter Availability';
        
        return this.pipeline.executeWithTimeout(async () => {
            try {
                const message = { action: 'export' };
                const response = await this.#mockHandleMessage(message, controller);

                // Consider exporter available if we get any response other than "not available"
                if (response.success || 
                    (response.error && !response.error.includes('Exporter not available'))) {
                    return this.#logResult(testName, 'PASS', {
                        available: true,
                        response: response.success ? 'success' : 'controlled_failure'
                    });
                } else {
                    return this.#logResult(testName, 'FAIL', {
                        error: response.error || 'Exporter module missing or failed to init'
                    });
                }
            } catch (error) {
                return this.#logResult(testName, 'FAIL (Exception)', { 
                    error: error.message 
                });
            }
        }, testName);
    }

    #generateFinalReport() {
        const finalStatus = this.globalPass ? 'PASS' : 'FAIL';
        
        this.logger.log('INFO', 'Diagnostics completed', {
            finalStatus,
            totalTests: this.testResults.length,
            passedTests: this.testResults.filter(r => r.status === 'PASS').length,
            failedTests: this.testResults.filter(r => r.status.includes('FAIL')).length
        });

        return {
            results: this.testResults,
            finalStatus,
            htmlOutput: this.#generateHTMLReport(),
            summary: {
                total: this.testResults.length,
                passed: this.testResults.filter(r => r.status === 'PASS').length,
                failed: this.testResults.filter(r => r.status.includes('FAIL')).length,
                warnings: this.testResults.filter(r => r.status === 'WARN').length
            }
        };
    }

    #generateHTMLReport() {
        const finalStatus = this.globalPass ? 'PASS' : 'FAIL';
        
        return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ChatSavePro Diagnostics Runner V2</title>
    <style>
        body { 
            font-family: system-ui, sans-serif; 
            padding: 20px; 
            background-color: #f4f7f9; 
            margin: 0;
        }
        .report-container { 
            max-width: 800px; 
            margin: 0 auto; 
            background-color: #fff; 
            padding: 30px; 
            border-radius: 8px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
        }
        h1 { 
            color: #1e3a8a; 
            border-bottom: 3px solid #bfdbfe; 
            padding-bottom: 10px;
            margin-top: 0;
        }
        .status-box { 
            padding: 15px; 
            border-radius: 6px; 
            margin-bottom: 20px; 
            text-align: center; 
            font-size: 1.5em; 
            font-weight: bold; 
        }
        .PASS { 
            background-color: #d1fae5; 
            color: #065f46; 
            border: 1px solid #a7f3d0; 
        }
        .FAIL { 
            background-color: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca; 
        }
        .test-result { 
            margin-bottom: 15px; 
            padding: 15px; 
            border-left: 5px solid; 
            border-radius: 4px; 
            background-color: #f9f9f9; 
        }
        .test-result.PASS { 
            border-left-color: #10b981; 
        }
        .test-result.FAIL { 
            border-left-color: #ef4444; 
        }
        .test-result.WARN { 
            border-left-color: #f59e0b; 
        }
        .test-name { 
            font-weight: bold; 
            margin-bottom: 8px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .test-details { 
            font-size: 0.85em; 
            color: #555; 
            white-space: pre-wrap; 
            background-color: #eee; 
            padding: 10px; 
            border-radius: 4px; 
            margin-top: 8px; 
            max-height: 200px; 
            overflow-y: auto; 
            font-family: monospace;
        }
        .tag { 
            padding: 4px 12px; 
            border-radius: 4px; 
            font-size: 0.8em; 
            font-weight: bold;
        }
        .tag.PASS { background-color: #10b981; color: white; }
        .tag.FAIL { background-color: #ef4444; color: white; }
        .tag.WARN { background-color: #f59e0b; color: white; }
        .summary { 
            display: grid; 
            grid-template-columns: repeat(4, 1fr); 
            gap: 10px; 
            margin: 20px 0; 
        }
        .summary-item { 
            text-align: center; 
            padding: 15px; 
            border-radius: 6px; 
            background-color: #f8fafc; 
        }
        .summary-value { 
            font-size: 1.5em; 
            font-weight: bold; 
            display: block; 
        }
    </style>
</head>
<body>
    <div class="report-container">
        <h1>ChatSavePro R8 Core Diagnostics (Runner V2)</h1>
        
        <div class="status-box ${finalStatus}">
            FINAL STATUS: ${finalStatus}
        </div>
        
        <div class="summary">
            <div class="summary-item">
                <span class="summary-value">${this.testResults.length}</span>
                <span>Total Tests</span>
            </div>
            <div class="summary-item">
                <span class="summary-value" style="color: #10b981;">${this.testResults.filter(r => r.status === 'PASS').length}</span>
                <span>Passed</span>
            </div>
            <div class="summary-item">
                <span class="summary-value" style="color: #ef4444;">${this.testResults.filter(r => r.status.includes('FAIL')).length}</span>
                <span>Failed</span>
            </div>
            <div class="summary-item">
                <span class="summary-value" style="color: #f59e0b;">${this.testResults.filter(r => r.status === 'WARN').length}</span>
                <span>Warnings</span>
            </div>
        </div>
        
        <h2>Individual Test Results</h2>
        
        ${this.testResults.map(result => `
            <div class="test-result ${result.status}">
                <div class="test-name">
                    <span>${result.name}</span>
                    <span class="tag ${result.status}">${result.status}</span>
                </div>
                ${result.status !== 'PASS' ? `
                    <pre class="test-details"><code>${result.details}</code></pre>
                ` : ''}
            </div>
        `).join('')}
    </div>
</body>
</html>`;
    }

    // ✅ Public API
    getTestResults() {
        return this.testResults;
    }

    getLogs(limit = 20) {
        return this.logger.getLogs(limit);
    }

    reset() {
        this.testResults = [];
        this.globalPass = true;
        this.logger.log('INFO', 'Diagnostic runner reset');
    }

    static get version() {
        return '2.1.0';
    }
}

// ✅ Default export
export default DiagnosticRunner;