// ============================================================
// ThemeManager.js - ES6 Module with Guardian Principles 10 & 11
// ============================================================

// 🛡️ اصل ۱۱: Inter-Module Integrity - Immutable constants
export const THEME_CONTEXTS = Object.freeze({
    LIGHT: 'light',
    DARK: 'dark',
    AUTO: 'auto'
});

// 🛡️ اصل ۱۱: Inter-Module Integrity - Frozen schemas
export const THEME_SCHEMAS = Object.freeze({
    LIGHT: Object.freeze({
        name: 'Light',
        icon: '🌙',
        colors: Object.freeze({
            '--primary-color': '#4a90e2',
            '--primary-dark': '#357abd',
            '--secondary-color': '#6c757d',
            '--success-color': '#28a745',
            '--danger-color': '#dc3545',
            '--warning-color': '#ffc107',
            '--info-color': '#17a2b8',
            '--light-color': '#f8f9fa',
            '--dark-color': '#343a40',
            '--border-color': '#dee2e6',
            '--bg-primary': '#ffffff',
            '--bg-secondary': '#f8f9fa',
            '--text-primary': '#333333',
            '--text-secondary': '#6c757d',
            '--shadow': '0 2px 10px rgba(0,0,0,0.1)',
            '--card-bg': '#ffffff',
            '--input-bg': '#ffffff',
            '--hover-color': '#f8f9fa'
        })
    }),
    DARK: Object.freeze({
        name: 'Dark',
        icon: '☀️',
        colors: Object.freeze({
            '--primary-color': '#6b8cff',
            '--primary-dark': '#5a7ae6',
            '--secondary-color': '#a0aec0',
            '--success-color': '#48bb78',
            '--danger-color': '#f56565',
            '--warning-color': '#ed8936',
            '--info-color': '#4299e1',
            '--light-color': '#2d3748',
            '--dark-color': '#e2e8f0',
            '--border-color': '#4a5568',
            '--bg-primary': '#1a202c',
            '--bg-secondary': '#2d3748',
            '--text-primary': '#e2e8f0',
            '--text-secondary': '#a0aec0',
            '--shadow': '0 2px 10px rgba(0,0,0,0.3)',
            '--card-bg': '#2d3748',
            '--input-bg': '#2d3748',
            '--hover-color': '#4a5568'
        })
    })
});

// 🛡️ اصل ۷: Async Pipeline & Resilience
class ThemePipeline {
    constructor() {
        this.tasks = [];
        this.isProcessing = false;
        this.maxQueueSize = 10;
        this.throttleDelay = 30;
        this.metrics = new Map();
    }

    async queueOperation(operation, ...args) {
        return new Promise((resolve, reject) => {
            const task = Object.freeze({
                operation,
                args,
                resolve,
                reject,
                timestamp: Date.now(),
                id: `theme_op_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`
            });

            this.tasks.push(task);

            // 🛡️ اصل ۵: Memory Segmentation - مدیریت صف
            if (this.tasks.length > this.maxQueueSize) {
                const removed = this.tasks.shift();
                console.warn('[ThemeManager] Queue overflow, removed task:', removed.id);
            }

            if (!this.isProcessing) {
                this._processQueue();
            }
        });
    }

    async _processQueue() {
        if (this.isProcessing || this.tasks.length === 0) return;
        
        this.isProcessing = true;
        const startTime = Date.now();

        try {
            while (this.tasks.length > 0) {
                const task = this.tasks.shift();
                const taskStart = Date.now();

                try {
                    const result = await task.operation(...task.args);
                    task.resolve(result);
                    
                    // 🛡️ اصل ۱۰: Audit & Traceability
                    const processed = this.metrics.get('processed') || 0;
                    this.metrics.set('processed', processed + 1);
                } catch (error) {
                    task.reject(error);
                    const errors = this.metrics.get('errors') || 0;
                    this.metrics.set('errors', errors + 1);
                }

                // Throttle برای عملکرد بهتر
                if (this.tasks.length > 0) {
                    await new Promise(resolve => 
                        setTimeout(resolve, this.throttleDelay)
                    );
                }
            }
        } finally {
            this.isProcessing = false;
            const totalTime = Date.now() - startTime;
            const processed = this.metrics.get('processed') || 0;
            this.metrics.set('averageTime', processed > 0 ? totalTime / processed : 0);
        }
    }

    // 🛡️ اصل ۱۰: Audit & Traceability
    getMetrics() {
        return Object.freeze({
            processed: this.metrics.get('processed') || 0,
            errors: this.metrics.get('errors') || 0,
            averageTime: this.metrics.get('averageTime') || 0,
            queueSize: this.tasks.length,
            isProcessing: this.isProcessing,
            maxQueueSize: this.maxQueueSize
        });
    }
}

// 🛡️ اصل ۹: Secure Logging & Sanitization
class ThemeLogger {
    constructor() {
        this.enabled = true;
        this.maxLogSize = 100;
        this.logs = [];
        this.startupTime = Date.now();
    }

    log(level, message, data = null) {
        if (!this.enabled) return;

        const logEntry = Object.freeze({
            timestamp: Date.now(),
            level,
            message,
            data: this.sanitizeData(data),
            context: 'theme-manager'
        });

        this.logs.push(logEntry);

        // مدیریت اندازه لاگ‌ها
        if (this.logs.length > this.maxLogSize) {
            this.logs = this.logs.slice(-this.maxLogSize);
        }

        // سازگار با MV3 - بدون process.env
        if (typeof process === 'undefined' || !process.env || process.env.NODE_ENV === 'development') {
            const consoleMethod = console[level] || console.log;
            consoleMethod(`[ThemeManager][${level}] ${message}`, data || '');
        }
    }

    sanitizeData(data) {
        if (!data) return null;
        
        try {
            // حذف داده‌های حساس
            const sanitized = JSON.parse(JSON.stringify(data));
            delete sanitized.sensitive;
            delete sanitized.password;
            delete sanitized.token;
            return sanitized;
        } catch {
            return { error: 'Unable to sanitize data' };
        }
    }

    getLogs() {
        return Object.freeze([...this.logs]);
    }

    // 🛡️ اصل ۱۰: Audit & Traceability
    getMetrics() {
        return Object.freeze({
            totalLogs: this.logs.length,
            maxLogSize: this.maxLogSize,
            oldestLog: this.logs[0]?.timestamp || null,
            newestLog: this.logs[this.logs.length - 1]?.timestamp || null,
            uptime: Date.now() - this.startupTime
        });
    }

    clearLogs() {
        this.logs = [];
    }
}

// 🛡️ اصل ۴: Enhanced Engine Abstraction
export class ThemeManager {
    constructor() {
        this.currentTheme = THEME_CONTEXTS.LIGHT;
        this.availableThemes = Object.freeze(Object.values(THEME_CONTEXTS));
        this.themeListeners = new Set();
        
        // 🛡️ اصل ۳: Lazy Loading & Performance
        this.pipeline = new ThemePipeline();
        this.logger = new ThemeLogger();
        
        // 🛡️ اصل ۶: Deterministic State Recovery
        this.monitoring = new Map();
        this.monitoring.set('themeChanges', 0);
        this.monitoring.set('systemPreferenceChanges', 0);
        this.monitoring.set('storageOperations', 0);
        this.monitoring.set('errorCount', 0);
        this.monitoring.set('averageApplyTime', 0);
        this.monitoring.set('lastChangeTime', null);
        this.monitoring.set('startupTime', Date.now());

        this.performance = Object.freeze({
            cssVariablesSupported: this._checkCSSVariablesSupport(),
            systemPreferenceSupported: !!(window.matchMedia),
            localStorageSupported: this._checkLocalStorageSupport(),
            animationSupported: this._checkAnimationSupport()
        });

        this.cleanupInterval = null;
        this.systemPreferenceHandler = null;

        this.logger.log('info', 'ThemeManager instance created', {
            features: this.performance
        });
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity - Controlled initialization
    static async init(config = {}) {
        const instance = new ThemeManager();
        await instance._initialize(config);
        
        // فریز کردن برای اصل ۱۱
        Object.freeze(instance.availableThemes);
        Object.freeze(instance.performance);
        
        console.log('✅ ThemeManager ES6 Module loaded successfully');
        return instance;
    }

    async _initialize(config = {}) {
        try {
            await this._waitForDOM();
            await this._loadSavedTheme();
            this._setupSystemPreferenceListener();
            this._setupCleanupInterval();
            
            this.logger.log('info', 'ThemeManager initialized successfully', {
                currentTheme: this.currentTheme,
                performance: this.performance,
                config: config
            });
            
            return this;
        } catch (error) {
            this.logger.log('error', 'Initialization failed', { error: error.message });
            this.monitoring.set('errorCount', (this.monitoring.get('errorCount') || 0) + 1);
            
            // Fallback به تم پیش‌فرض
            await this.applyTheme(THEME_CONTEXTS.LIGHT);
            throw error;
        }
    }

    async _waitForDOM() {
        return new Promise((resolve) => {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', resolve);
            } else {
                resolve();
            }
        });
    }

    _checkCSSVariablesSupport() {
        return !!(window.CSS && CSS.supports && CSS.supports('color', 'var(--test)'));
    }

    _checkLocalStorageSupport() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch {
            return false;
        }
    }

    _checkAnimationSupport() {
        return !!(window.CSS && CSS.supports && CSS.supports('transition', 'all 0.3s'));
    }

    async _loadSavedTheme() {
        return this.pipeline.queueOperation(async () => {
            try {
                let theme = THEME_CONTEXTS.LIGHT;
                
                if (this.performance.localStorageSupported) {
                    const savedTheme = localStorage.getItem('chatsavepro_theme');
                    if (savedTheme && this.availableThemes.includes(savedTheme)) {
                        theme = savedTheme;
                    } else if (this.performance.systemPreferenceSupported) {
                        theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 
                            THEME_CONTEXTS.DARK : THEME_CONTEXTS.LIGHT;
                    }
                }
                
                this.monitoring.set('storageOperations', (this.monitoring.get('storageOperations') || 0) + 1);
                await this.applyTheme(theme);
                
            } catch (error) {
                this.logger.log('warn', 'Failed to load saved theme', { error: error.message });
                this.monitoring.set('errorCount', (this.monitoring.get('errorCount') || 0) + 1);
                await this.applyTheme(THEME_CONTEXTS.LIGHT);
            }
        });
    }

    // 🛡️ اصل ۲: Strict Interface Contract
    async applyTheme(theme) {
        return this.pipeline.queueOperation(async () => {
            const startTime = Date.now();
            
            try {
                if (!this.availableThemes.includes(theme)) {
                    throw new Error(`Invalid theme: ${theme}`);
                }

                // مدیریت تم auto
                if (theme === THEME_CONTEXTS.AUTO) {
                    theme = this.performance.systemPreferenceSupported && 
                           window.matchMedia('(prefers-color-scheme: dark)').matches ? 
                           THEME_CONTEXTS.DARK : THEME_CONTEXTS.LIGHT;
                }

                const previousTheme = this.currentTheme;
                this.currentTheme = theme;

                // اعمال تم به DOM
                this._applyToDOM(theme);
                
                // ذخیره ترجیح کاربر
                await this._saveThemePreference(theme);
                
                // بروزرسانی UI
                await this._updateThemeToggles();
                
                // 🛡️ اصل ۱۰: Audit & Traceability
                this._updateMonitoring(startTime, previousTheme);
                
                // اطلاع‌رسانی به listeners
                this._notifyThemeChange(theme, previousTheme);

                this.logger.log('info', 'Theme applied successfully', {
                    theme,
                    previousTheme,
                    applyTime: Date.now() - startTime
                });

                return true;

            } catch (error) {
                this.monitoring.set('errorCount', (this.monitoring.get('errorCount') || 0) + 1);
                this.logger.log('error', 'Failed to apply theme', { 
                    theme, 
                    error: error.message 
                });
                throw error;
            }
        });
    }

    _applyToDOM(theme) {
        const config = THEME_SCHEMAS[theme.toUpperCase()];
        if (!config) return;

        const root = document.documentElement;
        
        // تنظیم attributeها
        root.setAttribute('data-theme', theme);
        document.body.className = `theme-${theme}`;
        
        // اعمال CSS variables
        this._applyCSSVariables(config.colors);
    }

    _applyCSSVariables(colors) {
        const root = document.documentElement;
        
        if (this.performance.animationSupported) {
            root.style.transition = 'all 0.3s ease-in-out';
            
            Object.entries(colors).forEach(([variable, value]) => {
                root.style.setProperty(variable, value);
            });
            
            setTimeout(() => {
                root.style.transition = '';
            }, 300);
        } else {
            Object.entries(colors).forEach(([variable, value]) => {
                root.style.setProperty(variable, value);
            });
        }
    }

    async _saveThemePreference(theme) {
        if (!this.performance.localStorageSupported) return;
        
        try {
            localStorage.setItem('chatsavepro_theme', theme);
            this.monitoring.set('storageOperations', (this.monitoring.get('storageOperations') || 0) + 1);
        } catch (error) {
            this.logger.log('warn', 'Failed to save theme preference', { 
                error: error.message 
            });
        }
    }

    _setupSystemPreferenceListener() {
        if (!this.performance.systemPreferenceSupported) return;

        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        
        this.systemPreferenceHandler = (e) => {
            this.monitoring.set('systemPreferenceChanges', (this.monitoring.get('systemPreferenceChanges') || 0) + 1);
            
            const currentSavedTheme = this.performance.localStorageSupported ? 
                localStorage.getItem('chatsavepro_theme') : null;
            
            if (!currentSavedTheme || currentSavedTheme === THEME_CONTEXTS.AUTO) {
                const newTheme = e.matches ? THEME_CONTEXTS.DARK : THEME_CONTEXTS.LIGHT;
                this.applyTheme(newTheme);
            }
        };
        
        mediaQuery.addEventListener('change', this.systemPreferenceHandler);
    }

    _setupCleanupInterval() {
        this.cleanupInterval = setInterval(() => {
            this._cleanupOldData();
        }, 24 * 60 * 60 * 1000); // تمیزکاری روزانه
    }

    _cleanupOldData() {
        // مدیریت داده‌های قدیمی
        this.logger.clearLogs();
    }

    async _updateThemeToggles() {
        const config = THEME_SCHEMAS[this.currentTheme.toUpperCase()];
        if (!config) return;

        const toggles = document.querySelectorAll('.theme-toggle');
        toggles.forEach(toggle => {
            toggle.innerHTML = config.icon;
            toggle.title = `Switch to ${this._getNextTheme().name} theme`;
            toggle.setAttribute('aria-label', `Current theme: ${config.name}. Switch to ${this._getNextTheme().name} theme`);
        });
    }

    _getNextTheme() {
        const currentIndex = this.availableThemes.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % this.availableThemes.length;
        const nextTheme = this.availableThemes[nextIndex];
        const config = THEME_SCHEMAS[nextTheme.toUpperCase()];
        
        return Object.freeze({
            name: nextTheme === THEME_CONTEXTS.AUTO ? 'Auto' : config?.name || nextTheme,
            value: nextTheme,
            icon: nextTheme === THEME_CONTEXTS.AUTO ? '⚙️' : config?.icon || '🎨'
        });
    }

    _updateMonitoring(startTime, previousTheme) {
        this.monitoring.set('themeChanges', (this.monitoring.get('themeChanges') || 0) + 1);
        this.monitoring.set('lastChangeTime', Date.now());
        
        const applyTime = Date.now() - startTime;
        const themeChanges = this.monitoring.get('themeChanges') || 1;
        const currentAvg = this.monitoring.get('averageApplyTime') || 0;
        const newAvg = (currentAvg * (themeChanges - 1) + applyTime) / themeChanges;
        this.monitoring.set('averageApplyTime', newAvg);
    }

    _notifyThemeChange(newTheme, oldTheme) {
        // اطلاع‌رسانی به listeners داخلی
        this.themeListeners.forEach(callback => {
            try {
                callback(newTheme, oldTheme);
            } catch (error) {
                this.logger.log('error', 'Theme listener error', { error: error.message });
            }
        });
        
        // ارسال event جهانی
        window.dispatchEvent(new CustomEvent('themeChanged', { 
            detail: Object.freeze({ 
                theme: newTheme, 
                oldTheme: oldTheme,
                timestamp: Date.now()
            }) 
        }));
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity
    async toggleTheme() {
        const currentIndex = this.availableThemes.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % this.availableThemes.length;
        const nextTheme = this.availableThemes[nextIndex];
        
        return await this.applyTheme(nextTheme);
    }

    addThemeListener(callback) {
        if (typeof callback === 'function') {
            this.themeListeners.add(callback);
        }
    }

    removeThemeListener(callback) {
        this.themeListeners.delete(callback);
    }

    getCurrentTheme() {
        return this.currentTheme;
    }

    isDarkMode() {
        return this.currentTheme === THEME_CONTEXTS.DARK;
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Comprehensive metrics
    getMetrics() {
        const themeChanges = this.monitoring.get('themeChanges') || 0;
        const errorCount = this.monitoring.get('errorCount') || 0;
        const successRate = themeChanges > 0 ? 
            ((themeChanges - errorCount) / themeChanges) * 100 : 100;
        const totalApplyTime = (this.monitoring.get('averageApplyTime') || 0) * themeChanges;

        return Object.freeze({
            system: Object.freeze({
                version: '2.0.0-guardian',
                uptime: Date.now() - (this.monitoring.get('startupTime') || Date.now()),
                isInitialized: true,
                healthScore: this._calculateHealthScore()
            }),
            current: Object.freeze({
                theme: this.currentTheme,
                name: THEME_SCHEMAS[this.currentTheme.toUpperCase()]?.name || this.currentTheme,
                config: THEME_SCHEMAS[this.currentTheme.toUpperCase()]
            }),
            performance: Object.freeze({
                themeChanges: themeChanges,
                systemPreferenceChanges: this.monitoring.get('systemPreferenceChanges') || 0,
                storageOperations: this.monitoring.get('storageOperations') || 0,
                errorCount: errorCount,
                successRate: Math.round(successRate) + '%',
                averageApplyTime: Math.round(this.monitoring.get('averageApplyTime') || 0),
                totalOperationTime: Math.round(totalApplyTime),
                lastChangeTime: this.monitoring.get('lastChangeTime')
            }),
            resources: Object.freeze({
                availableThemes: this.availableThemes.map(theme => 
                    Object.freeze({
                        value: theme,
                        name: theme === THEME_CONTEXTS.AUTO ? 'Auto' : THEME_SCHEMAS[theme.toUpperCase()]?.name || theme,
                        icon: theme === THEME_CONTEXTS.AUTO ? '⚙️' : THEME_SCHEMAS[theme.toUpperCase()]?.icon || '🎨'
                    })
                ),
                activeListeners: this.themeListeners.size,
                pipeline: this.pipeline.getMetrics(),
                logger: this.logger.getMetrics()
            }),
            capabilities: Object.freeze({
                cssVariables: this.performance.cssVariablesSupported,
                systemPreference: this.performance.systemPreferenceSupported,
                localStorage: this.performance.localStorageSupported,
                animations: this.performance.animationSupported
            })
        });
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Health monitoring
    _calculateHealthScore() {
        let score = 100;
        
        const errorCount = this.monitoring.get('errorCount') || 0;
        const themeChanges = this.monitoring.get('themeChanges') || 0;
        
        // کسر برای خطاها
        if (errorCount > 0) {
            score -= Math.min(40, errorCount * 10);
        }
        
        // کسر برای نرخ موفقیت پایین
        if (themeChanges > 0) {
            const successRate = (themeChanges - errorCount) / themeChanges;
            if (successRate < 0.8) {
                score -= 20;
            }
        }
        
        // کسر برای تاخیر بالا
        const avgApplyTime = this.monitoring.get('averageApplyTime') || 0;
        if (avgApplyTime > 500) {
            score -= 15;
        }
        
        return Math.max(0, Math.round(score));
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Integrity check
    async runIntegrityCheck() {
        const testResults = {
            timestamp: Date.now(),
            passed: true,
            checks: {}
        };
        
        try {
            // بررسی اولیه
            testResults.checks.initialization = this.monitoring.get('startupTime') > 0;
            testResults.checks.metricsAvailable = typeof this.getMetrics === 'function';
            testResults.checks.schemasFrozen = Object.isFrozen(THEME_SCHEMAS);
            
            // بررسی عملکرد
            const metrics = this.getMetrics();
            testResults.checks.metricsStructure = 
                metrics.system && metrics.performance && metrics.resources;
            testResults.checks.healthScore = metrics.system.healthScore >= 0;
            
            // بررسی قابلیت‌ها
            testResults.checks.cssVariables = this.performance.cssVariablesSupported;
            testResults.checks.pipeline = this.pipeline.getMetrics().maxQueueSize === 10;
            
            testResults.passed = Object.values(testResults.checks).every(check => check === true);
            
            this.logger.log('info', 'Integrity check completed', testResults);
            return Object.freeze(testResults);
            
        } catch (error) {
            this.logger.log('error', 'Integrity check failed', { error: error.message });
            testResults.passed = false;
            testResults.error = error.message;
            return Object.freeze(testResults);
        }
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity - Safe destruction
    async destroy() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
        }
        
        if (this.systemPreferenceHandler) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            mediaQuery.removeEventListener('change', this.systemPreferenceHandler);
            this.systemPreferenceHandler = null;
        }
        
        this.themeListeners.clear();
        
        const finalMetrics = this.getMetrics();
        
        this.logger.log('info', 'ThemeManager destroyed', {
            finalTheme: this.currentTheme,
            totalChanges: finalMetrics.performance.themeChanges,
            finalHealthScore: finalMetrics.system.healthScore
        });

        return Object.freeze({
            destroyed: true,
            timestamp: Date.now(),
            finalMetrics: finalMetrics
        });
    }
}

// 🛡️ اصل ۱۱: Inter-Module Integrity - Freeze prototype
Object.freeze(ThemeManager.prototype);
Object.freeze(ThemeManager);

export default ThemeManager;