// modules/scan-layer.js - ChatSavePro Scan Layer Loader
// Self-contained script for PageWorld execution
// Version: 4.2-GS-NoModule - FIXED SCANLAYER_STATUS CONTRACT

(function() {
    'use strict';

    // ==================== DEEPSCAN ENGINE (کلاس جدید) ====================
    class DeepScanEngine {
        constructor() {
            this.name = 'DeepScanEngine';
            this.version = '1.0';
            this.scanDepth = 0;
            this.maxDepth = 5;
        }

        async analyzeConversationStructure(conversation) {
            return {
                success: true,
                totalMessages: conversation.messages?.length || 0,
                hasCodeBlocks: this.detectCodeBlocks(conversation),
                hasImages: this.detectImages(conversation),
                conversationFlow: this.analyzeFlow(conversation),
                topics: this.extractTopics(conversation),
                timestamp: Date.now()
            };
        }

        detectCodeBlocks(conversation) {
            let codeBlockCount = 0;
            const messages = conversation.messages || [];
            
            messages.forEach(msg => {
                const content = msg.content || '';
                if (content.includes('```') || 
                    content.includes('function') || 
                    content.includes('const ') || 
                    content.includes('let ') || 
                    content.includes('var ')) {
                    codeBlockCount++;
                }
            });
            
            return codeBlockCount;
        }

        detectImages(conversation) {
            const messages = conversation.messages || [];
            let imageCount = 0;
            
            messages.forEach(msg => {
                const content = msg.content || '';
                if (content.includes('![') || 
                    content.includes('.png') || 
                    content.includes('.jpg') || 
                    content.includes('.gif')) {
                    imageCount++;
                }
            });
            
            return imageCount;
        }

        analyzeFlow(conversation) {
            const messages = conversation.messages || [];
            const flow = {
                userTurns: 0,
                assistantTurns: 0,
                avgTurnLength: 0,
                questionCount: 0
            };
            
            messages.forEach(msg => {
                const role = msg.role || '';
                const content = msg.content || '';
                
                if (role === 'user') flow.userTurns++;
                if (role === 'assistant') flow.assistantTurns++;
                if (content.includes('?')) flow.questionCount++;
                
                flow.avgTurnLength += content.length;
            });
            
            if (messages.length > 0) {
                flow.avgTurnLength = Math.round(flow.avgTurnLength / messages.length);
            }
            
            return flow;
        }

        extractTopics(conversation) {
            const messages = conversation.messages || [];
            const topics = new Set();
            const keywords = [
                'code', 'programming', 'algorithm', 'function', 'class',
                'database', 'API', 'server', 'client', 'frontend', 'backend',
                'React', 'Vue', 'Angular', 'Node.js', 'Python', 'JavaScript',
                'machine learning', 'AI', 'model', 'training', 'data',
                'security', 'authentication', 'encryption', 'JWT',
                'performance', 'optimization', 'scalability', 'cache'
            ];
            
            messages.forEach(msg => {
                const content = (msg.content || '').toLowerCase();
                keywords.forEach(keyword => {
                    if (content.includes(keyword.toLowerCase())) {
                        topics.add(keyword);
                    }
                });
            });
            
            return Array.from(topics);
        }

        async performDeepAnalysis(scanData) {
            try {
                console.log('🧠 [DeepScanEngine] Performing deep analysis...');
                
                const analysis = {
                    metadata: {
                        engine: this.name,
                        version: this.version,
                        timestamp: Date.now(),
                        url: window.location.href,
                        hostname: window.location.hostname
                    },
                    conversationStructure: await this.analyzeConversationStructure(scanData),
                    contentAnalysis: this.analyzeContent(scanData),
                    patterns: this.detectPatterns(scanData),
                    insights: this.generateInsights(scanData)
                };
                
                return {
                    success: true,
                    analysis,
                    scanId: `deepscan_${Date.now()}`,
                    duration: Date.now() - analysis.metadata.timestamp
                };
                
            } catch (error) {
                console.error('❌ [DeepScanEngine] Deep analysis failed:', error);
                return {
                    success: false,
                    error: error.message,
                    scanId: `deepscan_error_${Date.now()}`
                };
            }
        }

        analyzeContent(scanData) {
            const messages = scanData.messages || [];
            const contentAnalysis = {
                totalCharacters: 0,
                totalWords: 0,
                languages: new Set(),
                sentiment: 'neutral'
            };
            
            messages.forEach(msg => {
                const content = msg.content || '';
                contentAnalysis.totalCharacters += content.length;
                contentAnalysis.totalWords += content.split(/\s+/).length;
                
                // تشخیص ساده زبان
                if (content.includes('def ') || content.includes('import ')) contentAnalysis.languages.add('Python');
                if (content.includes('function(') || content.includes('const ')) contentAnalysis.languages.add('JavaScript');
                if (content.includes('public class') || content.includes('void ')) contentAnalysis.languages.add('Java');
                if (content.includes('<?php') || content.includes('$')) contentAnalysis.languages.add('PHP');
            });
            
            contentAnalysis.languages = Array.from(contentAnalysis.languages);
            
            return contentAnalysis;
        }

        detectPatterns(scanData) {
            const messages = scanData.messages || [];
            const patterns = {
                codePatterns: 0,
                questionPatterns: 0,
                explanationPatterns: 0,
                errorPatterns: 0
            };
            
            messages.forEach(msg => {
                const content = msg.content || '';
                if (content.includes('```') || content.includes('function(')) patterns.codePatterns++;
                if (content.includes('?')) patterns.questionPatterns++;
                if (content.includes('explain') || content.includes('means') || content.includes('definition')) patterns.explanationPatterns++;
                if (content.includes('error') || content.includes('Exception') || content.includes('failed')) patterns.errorPatterns++;
            });
            
            return patterns;
        }

        generateInsights(scanData) {
            const messages = scanData.messages || [];
            const insights = [];
            
            if (messages.length >= 10) {
                insights.push('Long conversation detected');
            }
            
            const codeBlocks = this.detectCodeBlocks(scanData);
            if (codeBlocks > 0) {
                insights.push(`Contains ${codeBlocks} code block(s)`);
            }
            
            const topics = this.extractTopics(scanData);
            if (topics.length > 0) {
                insights.push(`Topics: ${topics.join(', ')}`);
            }
            
            return insights;
        }
    }

    // ==================== DEEPSCAN COORDINATOR (کلاس جدید) ====================
    class DeepScanCoordinator {
        constructor(engine) {
            this.engine = engine;
            this.activeScans = new Map();
            this.maxConcurrentScans = 3;
        }

        async startDeepScan(options = {}) {
            const sessionId = options.sessionId || `deepscan_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            
            console.log(`🚀 [DeepScanCoordinator] Starting deep scan: ${sessionId}`);
            
            try {
                // ابتدا یک اسکن سطحی انجام بده
                const shallowScan = AISiteScanner.scanCurrentSite();
                
                if (!shallowScan.success) {
                    throw new Error(`Shallow scan failed: ${shallowScan.error}`);
                }
                
                // سپس آنالیز عمیق انجام بده
                const deepAnalysis = await this.engine.performDeepAnalysis(shallowScan);
                
                const result = {
                    success: true,
                    sessionId,
                    shallowScan,
                    deepAnalysis,
                    timestamp: Date.now(),
                    url: window.location.href,
                    metadata: {
                        scanType: 'deep_analysis',
                        depth: 'conversation_structure',
                        version: '1.0'
                    }
                };
                
                // ذخیره نتیجه
                this.activeScans.set(sessionId, {
                    result,
                    status: 'completed',
                    completedAt: Date.now()
                });
                
                // ارسال نتیجه
                this.dispatchDeepScanResult(sessionId, result);
                
                return result;
                
            } catch (error) {
                console.error(`❌ [DeepScanCoordinator] Deep scan failed:`, error);
                
                const errorResult = {
                    success: false,
                    sessionId,
                    error: error.message,
                    timestamp: Date.now()
                };
                
                this.activeScans.set(sessionId, {
                    result: errorResult,
                    status: 'failed',
                    completedAt: Date.now()
                });
                
                return errorResult;
            }
        }

        async runDeepScan(options = {}) {
            return this.startDeepScan(options);
        }

        dispatchDeepScanResult(sessionId, result) {
            try {
                // ✅ FIXED: Using correct SCANLAYER_STATUS contract
                const payload = {
                    type: "SCANLAYER_STATUS",
                    data: {
                        phase: 'deep_scan_complete',
                        items: result.shallowScan?.messages?.length || 0,
                        ts: Date.now(),
                        sessionId: sessionId,
                        scanType: 'deep',
                        success: result.success || false,
                        source: 'deepscan_engine'
                    }
                };

                window.postMessage(
                    {
                        direction: "PAGEWORLD_TO_CS",
                        payload
                    },
                    "*"
                );

                console.log("📡 [DeepScanCoordinator] SCANLAYER_STATUS dispatched:", payload);
                return true;

            } catch (err) {
                console.error("❌ dispatchDeepScanResult failed:", err);
                return false;
            }
        }

        getActiveScans() {
            return Array.from(this.activeScans.entries()).map(([id, data]) => ({
                id,
                status: data.status,
                completedAt: data.completedAt
            }));
        }

        cleanupOldScans(maxAge = 3600000) { // 1 hour
            const now = Date.now();
            let cleaned = 0;
            
            for (const [id, data] of this.activeScans.entries()) {
                if (now - data.completedAt > maxAge) {
                    this.activeScans.delete(id);
                    cleaned++;
                }
            }
            
            return cleaned;
        }
    }

    // بقیه کلاس‌های موجود (SecurityFreezer, SecureMemoryManager, etc.)...
    // ==================== SECURITY FREEZER ====================
    class SecurityFreezer {
        static freezeCriticalObjects() {
            try {
                const safeFreeze = (obj) => {
                    if (obj && typeof obj === 'object' && !Object.isFrozen(obj)) {
                        try {
                            Object.freeze(obj);
                            Object.seal(obj);
                            return true;
                        } catch {
                            return false;
                        }
                    }
                    return false;
                };

                const prototypes = [Object.prototype, Array.prototype, Function.prototype];
                let frozenCount = 0;

                prototypes.forEach(proto => {
                    if (safeFreeze(proto)) frozenCount++;
                });

                return frozenCount;
            } catch (error) {
                console.warn('⚠️ Security freezing partial:', error.message);
                return 0;
            }
        }
    }

    // ==================== SECURE MEMORY MANAGER ====================
    class SecureMemoryManager {
        constructor() {
            this.segments = new Map();
            this.initializeSecureSegments();
        }

        initializeSecureSegments() {
            const segmentsConfig = {
                'session': { maxSize: 100, ttl: 3600000 },
                'cache': { maxSize: 500, ttl: 300000 },
                'metrics': { maxSize: 1000, ttl: 86400000 },
                'config': { maxSize: 50, ttl: null },
                'pending_transfer': { maxSize: 200, ttl: 1800000 }
            };

            Object.entries(segmentsConfig).forEach(([name, config]) => {
                this.segments.set(name, {
                    store: new Map(),
                    config,
                    accessCount: 0,
                    created: Date.now()
                });
            });
        }

        set(segment, key, value, customTTL = null) {
            if (!this.segments.has(segment)) return false;

            const segmentData = this.segments.get(segment);
            const { maxSize, ttl } = segmentData.config;

            if (segmentData.store.size >= maxSize) {
                this.evictOldest(segment);
            }

            const data = {
                value,
                timestamp: Date.now(),
                ttl: customTTL || ttl,
                accessCount: 0,
                lastAccessed: Date.now()
            };

            segmentData.store.set(key, data);
            segmentData.accessCount++;
            return true;
        }

        get(segment, key) {
            if (!this.segments.has(segment)) return null;

            const segmentData = this.segments.get(segment);
            const data = segmentData.store.get(key);
            
            if (!data) return null;

            if (data.ttl !== null && Date.now() - data.timestamp > data.ttl) {
                segmentData.store.delete(key);
                return null;
            }

            data.accessCount++;
            data.lastAccessed = Date.now();
            return data.value;
        }

        evictOldest(segment) {
            const segmentData = this.segments.get(segment);
            let oldestKey = null;
            let oldestTime = Infinity;

            for (const [key, data] of segmentData.store) {
                if (data.lastAccessed < oldestTime) {
                    oldestTime = data.lastAccessed;
                    oldestKey = key;
                }
            }

            if (oldestKey) segmentData.store.delete(oldestKey);
        }

        getSegmentStats() {
            const stats = {};
            for (const [name, data] of this.segments) {
                stats[name] = {
                    size: data.store.size,
                    accessCount: data.accessCount,
                    utilization: Math.round((data.store.size / data.config.maxSize) * 100)
                };
            }
            return stats;
        }

        cleanupExpired() {
            const now = Date.now();
            let cleaned = 0;

            for (const [_, segmentData] of this.segments) {
                for (const [key, data] of segmentData.store) {
                    if (data.ttl !== null && now - data.timestamp > data.ttl) {
                        segmentData.store.delete(key);
                        cleaned++;
                    }
                }
            }
            return cleaned;
        }
    }

    // ==================== RESILIENT OPERATIONS ====================
    class ResilientOperation {
        static async executeWithRetry(operation, options = {}) {
            const {
                maxRetries = 3,
                timeout = 5000,
                backoffMultiplier = 2,
                initialDelay = 1000,
                shouldRetry = () => true
            } = options;

            let lastError;
            const startTime = Date.now();
            
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    const result = await Promise.race([
                        operation(attempt),
                        new Promise((_, reject) => 
                            setTimeout(() => reject(new Error('Operation timeout')), timeout)
                        )
                    ]);

                    return { 
                        success: true, 
                        result, 
                        attempt, 
                        duration: Date.now() - startTime 
                    };
                    
                } catch (error) {
                    lastError = error;

                    if (!shouldRetry(error) || attempt === maxRetries) {
                        break;
                    }

                    const delay = initialDelay * Math.pow(backoffMultiplier, attempt - 1);
                    await this.delay(delay);
                }
            }

            return { 
                success: false, 
                error: lastError, 
                attempts: maxRetries,
                final: true 
            };
        }

        static delay(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        static createCircuitBreaker(options = {}) {
            const {
                failureThreshold = 5,
                resetTimeout = 60000,
                halfOpenMaxAttempts = 3
            } = options;

            let state = 'CLOSED';
            let failureCount = 0;
            let lastFailureTime = 0;
            let halfOpenAttempts = 0;

            return {
                async execute(operation) {
                    const now = Date.now();

                    if (state === 'OPEN') {
                        if (now - lastFailureTime > resetTimeout) {
                            state = 'HALF_OPEN';
                            halfOpenAttempts = 0;
                        } else {
                            throw new Error('Circuit breaker is OPEN');
                        }
                    }

                    try {
                        const result = await operation();
                        
                        if (state === 'HALF_OPEN') {
                            halfOpenAttempts++;
                            if (halfOpenAttempts >= halfOpenMaxAttempts) {
                                state = 'CLOSED';
                                failureCount = 0;
                            }
                        }
                        
                        return result;
                        
                    } catch (error) {
                        if (state === 'HALF_OPEN') {
                            state = 'OPEN';
                            lastFailureTime = now;
                        } else {
                            failureCount++;
                            if (failureCount >= failureThreshold) {
                                state = 'OPEN';
                                lastFailureTime = now;
                            }
                        }
                        throw error;
                    }
                },

                getState() {
                    return { state, failureCount, lastFailureTime };
                }
            };
        }
    }

    // ==================== SECURE EVENT BUS ====================
    class SecureEventBus {
        constructor() {
            this.handlers = new Map();
            this.middleware = [];
        }

        registerMiddleware(middleware) {
            this.middleware.push(middleware);
        }

        on(event, handler, options = {}) {
            if (!this.handlers.has(event)) {
                this.handlers.set(event, new Set());
            }

            const handlerWrapper = {
                handler,
                once: options.once || false,
                context: options.context || null
            };

            this.handlers.get(event).add(handlerWrapper);
            return () => this.off(event, handler);
        }

        off(event, handler) {
            if (!this.handlers.has(event)) return;

            const handlers = this.handlers.get(event);
            for (const wrapper of handlers) {
                if (wrapper.handler === handler) {
                    handlers.delete(wrapper);
                    break;
                }
            }
        }

        async emit(event, data, options = {}) {
            for (const middleware of this.middleware) {
                const result = await middleware(event, data, options);
                if (result === false) {
                    return { success: false, blocked: true };
                }
            }

            if (!this.handlers.has(event)) {
                return { success: true, handled: false };
            }

            const handlers = this.handlers.get(event);
            const results = [];
            const toRemove = [];

            for (const wrapper of handlers) {
                try {
                    const context = wrapper.context || this;
                    const result = await wrapper.handler.call(context, data, options);
                    results.push({ success: true, result });

                    if (wrapper.once) toRemove.push(wrapper);
                } catch (error) {
                    console.error(`Event handler error for ${event}:`, error);
                    results.push({ success: false, error: error.message });
                }
            }

            toRemove.forEach(wrapper => handlers.delete(wrapper));

            return {
                success: true,
                handled: true,
                results,
                handlerCount: handlers.size
            };
        }

        clear() {
            this.handlers.clear();
            this.middleware = [];
        }
    }

    // ==================== INTERFACE VALIDATOR ====================
    class InterfaceValidator {
        static validateMessageContract(message) {
            const contract = {
                required: ['action', 'timestamp'],
                optional: ['data', 'metadata', 'correlationId'],
                constraints: {
                    action: { type: 'string', maxLength: 100, pattern: /^[a-zA-Z_][a-zA-Z0-9_]*$/ },
                    timestamp: { type: 'number', min: 0 },
                    data: { type: 'object', nullable: true },
                    metadata: { type: 'object', nullable: true }
                }
            };

            for (const field of contract.required) {
                if (!(field in message)) {
                    throw new Error(`Missing required field: ${field}`);
                }
            }

            for (const [field, constraint] of Object.entries(contract.constraints)) {
                if (field in message) {
                    this.validateField(message[field], constraint, field);
                }
            }

            this.validateSecurity(message);
            return true;
        }

        static validateField(value, constraint, fieldName) {
            if (constraint.nullable && value === null) return;

            if (constraint.type && typeof value !== constraint.type) {
                throw new Error(`Field ${fieldName} must be ${constraint.type}`);
            }

            if (constraint.maxLength && value.length > constraint.maxLength) {
                throw new Error(`Field ${fieldName} exceeds max length ${constraint.maxLength}`);
            }

            if (constraint.pattern && !constraint.pattern.test(value)) {
                throw new Error(`Field ${fieldName} has invalid format`);
            }

            if (constraint.min !== undefined && value < constraint.min) {
                throw new Error(`Field ${fieldName} must be at least ${constraint.min}`);
            }
        }

        static validateSecurity(message) {
            const dangerousPatterns = [
                /eval\(/i, /function\(/i, /constructor/i, /prototype/i,
                /script\(/i, /import\(/i, /require\(/i, /setTimeout\(/i
            ];

            const messageString = JSON.stringify(message).toLowerCase();
            
            for (const pattern of dangerousPatterns) {
                if (pattern.test(messageString)) {
                    throw new Error('Potentially dangerous content detected');
                }
            }
        }

        static sanitizeData(data) {
            if (typeof data !== 'object' || data === null) return data;

            const sanitized = {};
            for (const [key, value] of Object.entries(data)) {
                if (typeof value === 'string') {
                    sanitized[key] = value.slice(0, 10000).replace(/[<>]/g, '');
                } else if (typeof value === 'number' && isFinite(value)) {
                    sanitized[key] = value;
                } else if (typeof value === 'boolean') {
                    sanitized[key] = value;
                } else if (Array.isArray(value)) {
                    sanitized[key] = value.slice(0, 1000);
                } else if (typeof value === 'object' && value !== null) {
                    sanitized[key] = this.sanitizeData(value);
                }
            }
            return sanitized;
        }
    }

    // ==================== INTEGRITY VALIDATOR ====================
    class IntegrityValidator {
        static generateChecksum(data) {
            if (typeof data !== 'string') {
                data = JSON.stringify(data);
            }
            
            let hash = 0;
            for (let i = 0; i < data.length; i++) {
                const char = data.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash;
            }
            return Math.abs(hash).toString(36);
        }

        static validateModuleIntegrity(module, expectedExports = []) {
            const issues = [];

            if (!module) {
                issues.push('Module is null or undefined');
                return { valid: false, issues };
            }

            for (const exportName of expectedExports) {
                if (!(exportName in module)) {
                    issues.push(`Missing export: ${exportName}`);
                }
            }

            const dangerousProps = ['eval', 'Function', 'setTimeout', 'setInterval'];
            for (const prop of dangerousProps) {
                if (prop in module && typeof module[prop] === 'function') {
                    issues.push(`Suspicious function: ${prop}`);
                }
            }

            return {
                valid: issues.length === 0,
                issues,
                exports: Object.keys(module),
                checksum: this.generateChecksum(module)
            };
        }

        static createIntegrityGuard() {
            const knownHashes = new Map();
            
            return {
                registerModule(name, module, expectedHash) {
                    const currentHash = this.generateChecksum(module);
                    knownHashes.set(name, { hash: currentHash, timestamp: Date.now() });
                    
                    if (expectedHash && currentHash !== expectedHash) {
                        throw new Error(`Integrity violation for module ${name}`);
                    }
                    
                    return currentHash;
                },
                
                verifyModule(name, module) {
                    const known = knownHashes.get(name);
                    if (!known) {
                        return true;
                    }
                    
                    const currentHash = this.generateChecksum(module);
                    const isValid = currentHash === known.hash;
                    
                    return isValid;
                },
                
                getKnownModules() {
                    return Array.from(knownHashes.keys());
                }
            };
        }
    }

    // ==================== QUANTUM RESYNC MANAGER ====================
    class QuantumResyncManager {
        constructor() {
            this.connectionState = {
                background: true,
                lastSuccessfulSync: Date.now(),
                retryCount: 0,
                backoffDelay: 1000,
                maxBackoff: 30000
            };
            
            this.syncQueue = [];
            this.isSyncing = false;
            this.eventBus = new SecureEventBus();
            this._lastQuantumPingSent = 0;
            this._quantumPingDebounceMs = 60000;
        }

        async initialize() {
            this.startSyncProcessor();
            return this;
        }

        async checkBackgroundConnection() {
            this.connectionState.background = true;
            this.connectionState.lastSuccessfulSync = Date.now();
            return { success: true, simulated: true };
        }

        async sendQuantumPing() {
            return { 
                success: true, 
                response: { simulated: true, quantumPing: 'disabled' } 
            };
        }

        async sendSingleQuantumPing() {
            const now = Date.now();
            
            if (this._lastQuantumPingSent && (now - this._lastQuantumPingSent < this._quantumPingDebounceMs)) {
                return { 
                    success: true, 
                    debounced: true,
                    lastSent: this._lastQuantumPingSent
                };
            }

            try {
                this._lastQuantumPingSent = now;
                this.connectionState.lastSuccessfulSync = now;
                
                return { 
                    success: true, 
                    response: { simulated: true },
                    timestamp: now
                };
                
            } catch (error) {
                return { 
                    success: false, 
                    error: error.message,
                    timestamp: now
                };
            }
        }

        startSyncProcessor() {
            const processor = async () => {
                if (this.isSyncing || this.syncQueue.length === 0) return;
                
                this.isSyncing = true;
                try {
                    while (this.syncQueue.length > 0 && this.connectionState.background) {
                        const syncItem = this.syncQueue[0];
                        try {
                            this.syncQueue.shift();
                        } catch (error) {
                            console.error('Sync item processing error:', error);
                            this.syncQueue.shift();
                        }
                    }
                } finally {
                    this.isSyncing = false;
                }
            };

            const processorInterval = setInterval(processor, 2000);
        }

        queueSyncItem(type, payload, priority = false) {
            const syncItem = {
                id: `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                type,
                payload,
                timestamp: Date.now(),
                priority
            };

            if (priority) {
                this.syncQueue.unshift(syncItem);
            } else {
                this.syncQueue.push(syncItem);
            }

            this.eventBus.emit('resync:item:queued', {
                type,
                id: syncItem.id,
                queueLength: this.syncQueue.length,
                priority
            });

            return syncItem.id;
        }

        getSyncStatus() {
            return {
                connected: this.connectionState.background,
                queueLength: this.syncQueue.length,
                isSyncing: this.isSyncing,
                lastSuccessfulSync: this.connectionState.lastSuccessfulSync,
                retryCount: this.connectionState.retryCount,
                queuedTypes: [...new Set(this.syncQueue.map(item => item.type))]
            };
        }

        cleanup() {
            this.syncQueue = [];
            this.isSyncing = false;
            this._lastQuantumPingSent = 0;
        }
    }

    // ==================== SECURE LOGGER ====================
    class SecureLogger {
        constructor() {
            this.logs = [];
            this.maxLogs = 1000;
            this.sensitivePatterns = [
                /password=['"]?([^'"]+)['"]?/gi,
                /token=['"]?([^'"]+)['"]?/gi,
                /api[_-]?key=['"]?([^'"]+)['"]?/gi,
                /secret=['"]?([^'"]+)['"]?/gi
            ];
        }

        sanitize(message) {
            if (typeof message !== 'string') {
                message = JSON.stringify(message);
            }

            let sanitized = message;
            this.sensitivePatterns.forEach(pattern => {
                sanitized = sanitized.replace(pattern, (match, capture) => {
                    return match.replace(capture, '***');
                });
            });

            return sanitized;
        }

        log(level, message, data = null) {
            const logEntry = {
                timestamp: Date.now(),
                level,
                message: this.sanitize(message),
                data: data ? this.sanitize(data) : null
            };

            this.logs.push(logEntry);

            if (this.logs.length > this.maxLogs) {
                this.logs = this.logs.slice(-this.maxLogs);
            }

            return logEntry;
        }

        error(message, data = null) {
            return this.log('error', message, data);
    }

        warn(message, data = null) {
            return this.log('warn', message, data);
        }

        info(message, data = null) {
            return this.log('info', message, data);
        }

        debug(message, data = null) {
            return this.log('debug', message, data);
        }

        getLogs(filter = {}) {
            let filteredLogs = this.logs;

            if (filter.level) {
                filteredLogs = filteredLogs.filter(log => log.level === filter.level);
            }

            if (filter.since) {
                filteredLogs = filteredLogs.filter(log => log.timestamp >= filter.since);
            }

            if (filter.until) {
                filteredLogs = filteredLogs.filter(log => log.timestamp <= filter.until);
            }

            return filteredLogs;
        }

        exportLogs(format = 'json') {
            const logs = this.getLogs();
            
            switch (format) {
                case 'json':
                    return JSON.stringify(logs, null, 2);
                case 'text':
                    return logs.map(log => 
                        `[${new Date(log.timestamp).toISOString()}] ${log.level}: ${log.message}`
                    ).join('\n');
                default:
                    throw new Error(`Unsupported log format: ${format}`);
            }
        }
    }

    // ==================== DEPENDENCY GRAPH ====================
    class DependencyGraph {
        constructor() {
            this.modules = new Map();
            this.dependencies = new Map();
        }

        registerModule(name, metadata = {}) {
            this.modules.set(name, {
                name,
                loaded: false,
                loadTime: null,
                dependencies: new Set(),
                metadata,
                ...metadata
            });
            return this;
        }

        addDependency(moduleName, dependencyName) {
            if (!this.modules.has(moduleName)) {
                this.registerModule(moduleName);
            }

            if (!this.modules.has(dependencyName)) {
                this.registerModule(dependencyName);
            }

            const module = this.modules.get(moduleName);
            module.dependencies.add(dependencyName);

            if (!this.dependencies.has(moduleName)) {
                this.dependencies.set(moduleName, new Set());
            }
            this.dependencies.get(moduleName).add(dependencyName);

            this.detectCircularDependencies(moduleName);
            return this;
        }

        detectCircularDependencies(startModule, path = new Set()) {
            if (path.has(startModule)) {
                const cycle = Array.from(path).join(' -> ') + ' -> ' + startModule;
                throw new Error(`Circular dependency detected: ${cycle}`);
            }

            path.add(startModule);
            const dependencies = this.dependencies.get(startModule) || new Set();
            
            for (const dep of dependencies) {
                this.detectCircularDependencies(dep, new Set(path));
            }
        }

        markAsLoaded(moduleName) {
            if (this.modules.has(moduleName)) {
                const module = this.modules.get(moduleName);
                module.loaded = true;
                module.loadTime = Date.now();
            }
        }

        getLoadOrder() {
            const loaded = new Set();
            const order = [];

            const visit = (moduleName) => {
                if (loaded.has(moduleName)) return;

                const module = this.modules.get(moduleName);
                if (!module) return;

                for (const dep of module.dependencies) {
                    if (!loaded.has(dep)) visit(dep);
                }

                loaded.add(moduleName);
                order.push(moduleName);
            };

            for (const moduleName of this.modules.keys()) {
                if (!loaded.has(moduleName)) visit(moduleName);
            }

            return order;
        }

        getModuleStatus(moduleName) {
            const module = this.modules.get(moduleName);
            if (!module) return null;

            const missingDeps = Array.from(module.dependencies).filter(
                dep => !this.modules.get(dep)?.loaded
            );

            return {
                ...module,
                canLoad: missingDeps.length === 0,
                missingDependencies: missingDeps,
                allDependenciesLoaded: missingDeps.length === 0
            };
        }

        visualize() {
            const nodes = [];
            const edges = [];

            for (const [name, module] of this.modules) {
                nodes.push({
                    id: name,
                    label: name,
                    loaded: module.loaded,
                    group: module.metadata.group || 'default'
                });

                for (const dep of module.dependencies) {
                    edges.push({
                        from: name,
                        to: dep,
                        arrows: 'to'
                    });
                }
            }

            return { nodes, edges };
        }
    }

    // ==================== AI SITE SCANNERS ====================
    class AISiteScanner {
        static SITE_CONFIGS = {
            'chat.deepseek.com': {
                name: 'DeepSeek',
                version: 'v3',
                selectors: {
                    messages: '.flex.flex-col.items-center.text-sm',
                    messageGroups: '.group.w-full',
                    userMessages: '[data-message-author-role="user"]',
                    assistantMessages: '[data-message-author-role="assistant"]',
                    chatContainer: 'main, [class*="chat"]',
                    messageContent: '.whitespace-pre-wrap, .markdown, .prose'
                },
                extractor: 'deepseekV3'
            },
            'chat.openai.com': {
                name: 'ChatGPT',
                selectors: {
                    messages: '[data-message-author-role]',
                    userMessages: '[data-message-author-role="user"]',
                    assistantMessages: '[data-message-author-role="assistant"]',
                    messageContent: '.markdown, .prose'
                },
                extractor: 'chatgpt'
            },
            'claude.ai': {
                name: 'Claude',
                selectors: {
                    messages: '[class*="message"]',
                    userMessages: '[class*="user-message"]',
                    assistantMessages: '[class*="assistant-message"]',
                    messageContent: '.content, .text'
                },
                extractor: 'claude'
            },
            'gemini.google.com': {
                name: 'Gemini',
                selectors: {
                    messages: '.message-line',
                    userMessages: '[data-role="user"]',
                    assistantMessages: '[data-role="model"]',
                    messageContent: '.text-content'
                },
                extractor: 'gemini'
            },
            'copilot.microsoft.com': {
                name: 'Copilot',
                selectors: {
                    messages: '[role="listitem"]',
                    userMessages: '[data-author="user"]',
                    assistantMessages: '[data-author="assistant"]',
                    messageContent: '.markdown'
                },
                extractor: 'copilot'
            }
        };

        static scanCurrentSite() {
            const hostname = window.location.hostname;
            const config = this.SITE_CONFIGS[hostname];
            
            if (!config) {
                console.warn(`No scanner config for: ${hostname}`);
                return { success: false, error: 'Unsupported site', hostname };
            }

            console.log(`🔍 Scanning ${config.name}...`);
            
            try {
                const result = this.extractConversation(config);
                return {
                    success: true,
                    site: config.name,
                    hostname,
                    timestamp: Date.now(),
                    ...result
                };
            } catch (error) {
                return {
                    success: false,
                    error: error.message,
                    site: config.name,
                    hostname
                };
            }
        }

        static extractConversation(config) {
            switch (config.extractor) {
                case 'deepseekV3':
                    return this.extractDeepSeekV3(config);
                case 'chatgpt':
                    return this.extractChatGPT(config);
                case 'claude':
                    return this.extractClaude(config);
                case 'gemini':
                    return this.extractGemini(config);
                case 'copilot':
                    return this.extractCopilot(config);
                default:
                    return this.extractGeneric(config);
            }
        }

        static extractDeepSeekV3(config) {
            const messages = [];
            const selectors = config.selectors;
            
            // روش 1: جستجوی مستقیم با selectorهای مشخص
            const messageElements = document.querySelectorAll(selectors.messages);
            
            if (messageElements.length > 0) {
                messageElements.forEach((el, index) => {
                    const text = this.extractTextFromElement(el);
                    if (text && text.trim().length > 5) {
                        const role = this.detectRole(el, config);
                        messages.push({
                            id: `msg_${Date.now()}_${index}`,
                            role,
                            content: text,
                            timestamp: Date.now() - (messageElements.length - index) * 1000,
                            element: el.tagName
                        });
                    }
                });
            } else {
                // روش 2: جستجوی fallback - همه divهای حاوی متن
                const allDivs = document.querySelectorAll('div');
                let conversationDivs = [];
                
                allDivs.forEach(div => {
                    const text = div.textContent || '';
                    if (text.trim().length > 20 && 
                        (text.includes('?') || text.includes('!') || text.length > 50)) {
                        conversationDivs.push({
                            element: div,
                            text: text.trim(),
                            children: div.children.length
                        });
                    }
                });
                
                // مرتب‌سازی بر اساس عمق در DOM
                conversationDivs.sort((a, b) => b.children - a.children);
                
                conversationDivs.slice(0, 20).forEach((item, index) => {
                    const role = this.detectRoleFromText(item.text);
                    messages.push({
                        id: `msg_fallback_${Date.now()}_${index}`,
                        role,
                        content: item.text.substring(0, 5000),
                        timestamp: Date.now() - (conversationDivs.length - index) * 2000,
                        source: 'fallback'
                    });
                });
            }
            
            return {
                messages,
                totalMessages: messages.length,
                siteVersion: config.version,
                url: window.location.href,
                title: document.title,
                scanMethod: messageElements.length > 0 ? 'direct' : 'fallback'
            };
        }

        static extractChatGPT(config) {
            const messages = [];
            const messageElements = document.querySelectorAll(config.selectors.messages);
            
            messageElements.forEach((el, index) => {
                const role = el.getAttribute('data-message-author-role') || 'unknown';
                const text = this.extractTextFromElement(el);
                
                if (text && text.trim()) {
                    messages.push({
                        id: `chatgpt_${Date.now()}_${index}`,
                        role,
                        content: text,
                        timestamp: Date.now() - (messageElements.length - index) * 1000
                    });
                }
            });
            
            return {
                messages,
                totalMessages: messages.length,
                siteVersion: 'chatgpt'
            };
        }

        static extractClaude(config) {
            const messages = [];
            const messageElements = document.querySelectorAll(config.selectors.messages);
            
            messageElements.forEach((el, index) => {
                const className = el.className || '';
                let role = 'unknown';
                
                if (className.includes('user-message')) role = 'user';
                if (className.includes('assistant-message')) role = 'assistant';
                
                const text = this.extractTextFromElement(el);
                
                if (text && text.trim()) {
                    messages.push({
                        id: `claude_${Date.now()}_${index}`,
                        role,
                        content: text,
                        timestamp: Date.now() - (messageElements.length - index) * 1000
                    });
                }
            });
            
            return {
                messages,
                totalMessages: messages.length,
                siteVersion: 'claude'
            };
        }

        static extractGemini(config) {
            const messages = [];
            const messageElements = document.querySelectorAll(config.selectors.messages);
            
            messageElements.forEach((el, index) => {
                const roleAttr = el.getAttribute('data-role');
                const role = roleAttr || 'unknown';
                const text = this.extractTextFromElement(el);
                
                if (text && text.trim()) {
                    messages.push({
                        id: `gemini_${Date.now()}_${index}`,
                        role,
                        content: text,
                        timestamp: Date.now() - (messageElements.length - index) * 1000
                    });
                }
            });
            
            return {
                messages,
                totalMessages: messages.length,
                siteVersion: 'gemini'
            };
        }

        static extractCopilot(config) {
            const messages = [];
            const messageElements = document.querySelectorAll(config.selectors.messages);
            
            messageElements.forEach((el, index) => {
                const authorAttr = el.getAttribute('data-author');
                const role = authorAttr || 'unknown';
                const text = this.extractTextFromElement(el);
                
                if (text && text.trim()) {
                    messages.push({
                        id: `copilot_${Date.now()}_${index}`,
                        role,
                        content: text,
                        timestamp: Date.now() - (messageElements.length - index) * 1000
                    });
                }
            });
            
            return {
                messages,
                totalMessages: messages.length,
                siteVersion: 'copilot'
            };
        }

        static extractGeneric(config) {
            const messages = [];
            
            // جستجوی همه المان‌های ممکن
            const allElements = document.querySelectorAll('div, p, span, li');
            
            allElements.forEach((el, index) => {
                const text = el.textContent || '';
                if (text.trim().length > 30) {
                    const role = this.detectRoleFromText(text);
                    messages.push({
                        id: `generic_${Date.now()}_${index}`,
                        role,
                        content: text.substring(0, 1000),
                        timestamp: Date.now() - (allElements.length - index) * 100
                    });
                }
            });
            
            // محدود کردن تعداد
            const limitedMessages = messages.slice(0, 50);
            
            return {
                messages: limitedMessages,
                totalMessages: limitedMessages.length,
                siteVersion: 'generic',
                note: 'Using fallback scanning method'
            };
        }

        static extractTextFromElement(element) {
            // استخراج متن پاک از المان
            let text = '';
            
            // سعی کن متن را از محتوای المان بگیر
            if (element.textContent) {
                text = element.textContent.trim();
            }
            
            // اگر المان markdown دارد
            const markdown = element.querySelector('.markdown, .prose');
            if (markdown) {
                text = markdown.textContent || text;
            }
            
            // حذف whitespace اضافی
            text = text.replace(/\s+/g, ' ').trim();
            
            return text;
        }

        static detectRole(element, config) {
            // تشخیص role از class یا attributes
            const className = element.className || '';
            const roleAttr = element.getAttribute('data-message-author-role');
            
            if (roleAttr) return roleAttr;
            
            if (className.includes('user') || className.includes('User')) return 'user';
            if (className.includes('assistant') || className.includes('Assistant')) return 'assistant';
            if (className.includes('system')) return 'system';
            
            // تشخیص از متن
            const text = (element.textContent || '').toLowerCase();
            if (text.includes('you:') || text.includes('user:')) return 'user';
            if (text.includes('assistant:') || text.includes('ai:')) return 'assistant';
            
            return 'unknown';
        }

        static detectRoleFromText(text) {
            const lowerText = text.toLowerCase();
            if (lowerText.includes('you:') || lowerText.includes('user:')) return 'user';
            if (lowerText.includes('assistant:') || lowerText.includes('ai:')) return 'assistant';
            if (lowerText.includes('system:')) return 'system';
            
            // اگر متن سوالی است، احتمالاً پاسخ assistant است
            if (text.includes('?')) return 'assistant';
            
            return 'unknown';
        }

        // تابع جدید: اسکن سریع برای تست
        static quickScan() {
            const hostname = window.location.hostname;
            const config = this.SITE_CONFIGS[hostname];
            
            if (!config) {
                return { success: false, site: hostname, supported: false };
            }
            
            const selectors = config.selectors;
            const stats = {};
            
            // بررسی selectorها
            Object.entries(selectors).forEach(([name, selector]) => {
                const elements = document.querySelectorAll(selector);
                stats[name] = elements.length;
            });
            
            return {
                success: true,
                site: config.name,
                hostname,
                stats,
                timestamp: Date.now()
            };
        }
    }

    // ==================== INLINE MODULES ====================
    class LiveScanManager {
        constructor() {
            this.active = false;
            this.sessionId = null;
        }

        async start(options = {}) {
            this.active = true;
            this.sessionId = `live_${Date.now()}`;
            return { success: true, sessionId: this.sessionId };
        }

        stop() {
            this.active = false;
            return { success: true };
        }
    }

    class DeepScan {
        constructor() {
            this.config = {
                maxDepth: 3,
                timeout: 10000,
                concurrent: 2
            };
        }

        async run(target, options = {}) {
            await new Promise(resolve => setTimeout(resolve, 100));
            return {
                success: true,
                scannedItems: Math.floor(Math.random() * 10) + 1,
                target: target
            };
        }
    }

    class Validator {
        static validateInput(input, schema = {}) {
            if (!input) return { valid: false, error: 'Input is required' };
            return { valid: true, data: input };
        }

        static sanitizeHTML(html) {
            if (typeof html !== 'string') return html;
            return html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        }
    }

    // ==================== SCAN LAYER CLASS ====================
    class ScanLayer {
        constructor() {
            this.context = {
                environment: {
                    IS_EXTENSION_CONTEXT: (() => {
                        try {
                            return !!(chrome?.runtime?.id && chrome.runtime.sendMessage);
                        } catch {
                            return false;
                        }
                    })(),
                    IS_CSP_RESTRICTED: false
                },
                security: { frozen: true, timestamp: Date.now() }
            };

            this.memoryManager = new SecureMemoryManager();
            this.eventBus = new SecureEventBus();
            this.resyncManager = new QuantumResyncManager();
            this.logger = new SecureLogger();
            this.dependencyGraph = new DependencyGraph();
            this.integrityGuard = IntegrityValidator.createIntegrityGuard();

            // Initialize inline modules
            this.liveScanManager = new LiveScanManager();
            this.deepScan = new DeepScan();
            this.validator = Validator;
            
            // اضافه کردن Scanner واقعی
            this.scanner = AISiteScanner;
            this.version = '4.2-GS-NoModule';

            // ========== DeepScan Engine و Coordinator ==========
            this.deepScanEngine = new DeepScanEngine();
            this.deepScanCoordinator = new DeepScanCoordinator(this.deepScanEngine);

            this.initializeDependencyGraph();
            this.setupEventHandlers();
        }

        // ========== FIXED: dispatchLiveScan با Contract صحیح ==========
        dispatchLiveScan(sessionId, scan) {
            try {
                // ✅ FIXED: Using correct SCANLAYER_STATUS contract
                const payload = {
                    type: "SCANLAYER_STATUS",
                    data: {
                        phase: 'live_scan_complete',
                        items: scan.messages?.length || 0,
                        ts: Date.now(),
                        sessionId: sessionId,
                        scanType: 'live',
                        success: scan.success || false,
                        source: 'scan_layer'
                    }
                };

                window.postMessage(
                    {
                        direction: "PAGEWORLD_TO_CS",
                        payload
                    },
                    "*"
                );

                console.log("📡 [ScanLayer] SCANLAYER_STATUS dispatched (live):", payload);
                return true;

            } catch (err) {
                console.error("❌ dispatchLiveScan failed:", err);
                return false;
            }
        }

        // ========== FIXED: dispatchDeepScanResults با Contract صحیح ==========
        dispatchDeepScanResults(sessionId, result) {
            try {
                // ✅ FIXED: Using correct SCANLAYER_STATUS contract
                const payload = {
                    type: "SCANLAYER_STATUS",
                    data: {
                        phase: 'deep_scan_complete',
                        items: result.shallowScan?.messages?.length || 0,
                        ts: Date.now(),
                        sessionId: sessionId,
                        scanType: 'deep',
                        success: result.success || false,
                        source: 'deepscan_engine'
                    }
                };

                window.postMessage(
                    { direction: "PAGEWORLD_TO_CS", payload },
                    "*"
                );

                console.log("📡 [ScanLayer] SCANLAYER_STATUS dispatched (deep):", payload);
                return true;

            } catch (err) {
                console.error("❌ dispatchDeepScanResults failed:", err);
                return false;
            }
        }

        initializeDependencyGraph() {
            this.dependencyGraph
                .registerModule('LiveScanManager', { group: 'core' })
                .registerModule('DeepScan', { group: 'core' })
                .registerModule('Validator', { group: 'core' })
                .registerModule('Logger', { group: 'core' })
                .registerModule('SecureMemoryManager', { group: 'infrastructure' })
                .registerModule('QuantumResyncManager', { group: 'infrastructure' })
                .registerModule('AISiteScanner', { group: 'scanner' })
                .registerModule('DeepScanEngine', { group: 'deepscan' })
                .registerModule('DeepScanCoordinator', { group: 'deepscan' })
                .addDependency('LiveScanManager', 'Validator')
                .addDependency('DeepScan', 'Validator')
                .addDependency('LiveScanManager', 'Logger')
                .addDependency('DeepScan', 'Logger')
                .addDependency('AISiteScanner', 'Validator')
                .addDependency('DeepScanCoordinator', 'DeepScanEngine');

            ['LiveScanManager', 'DeepScan', 'Validator', 'Logger', 
             'SecureMemoryManager', 'QuantumResyncManager', 'AISiteScanner',
             'DeepScanEngine', 'DeepScanCoordinator'].forEach(moduleName => {
                this.dependencyGraph.markAsLoaded(moduleName);
            });
        }

        setupEventHandlers() {
            this.eventBus.on('pipeline:stage:complete', this.handleStageComplete.bind(this));
            this.eventBus.on('resync:connection:restored', this.handleConnectionRestored.bind(this));
            this.eventBus.on('error', this.handleError.bind(this));
            
            this.eventBus.on('bridge:message', this.handleBridgeMessage.bind(this));
            this.eventBus.on('bridge:ready', this.handleBridgeReady.bind(this));
            
            this.eventBus.on('scan:request', this.handleScanRequest.bind(this));
        }

        async initialize() {
            try {
                await this.initializeCoreModules();
                await this.verifySystemIntegrity();
                await this.attachEventBus();
                await this.attachBridge();
                await this.attachDeepScan();
                await this.attachSession();
                
                return this;

            } catch (error) {
                throw error;
            }
        }

        async initializeCoreModules() {
            return true;
        }

        async verifySystemIntegrity() {
            // CS-Only Mode: Always pass integrity check
            console.warn("[ScanLayer-CS] Integrity check DISABLED (CS-Only Mode)");
            return true;
        }

        async attachEventBus() {
            this.eventBus.registerMiddleware(async (event, data) => {
                return true;
            });
        }

        async attachBridge() {
            this.bridgeActive = true;
            this.bridgeSessionId = `bridge_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        }

        async attachDeepScan() {
            return true;
        }

        async attachSession() {
            this.sessionId = `session_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
            this.sessionStartTime = Date.now();
        }

        finalizeExposure() {
            window.__SCAN_LAYER_LOADED__ = true;
            window.__SCAN_LAYER_INSTANCE__ = this;
            window.scanLayer = this; // fallback
            
            // ========== DeepScan API با dispatch ==========
            this.deepScan = {
                start: (options = {}) => {
                    return this.deepScanCoordinator.startDeepScan(options)
                        .then(res => {
                            this.dispatchDeepScanResults(options.sessionId || this.sessionId, res);
                            return res;
                        });
                },

                startDeepScan: (sessionId) => {
                    return this.deepScanCoordinator.startDeepScan({ sessionId })
                        .then(res => {
                            this.dispatchDeepScanResults(sessionId, res);
                            return res;
                        });
                },

                runFullDeepScan: (options = {}) => {
                    return this.deepScanCoordinator.runDeepScan(options)
                        .then(res => {
                            this.dispatchDeepScanResults(options.sessionId || this.sessionId, res);
                            return res;
                        });
                },

                getActiveScans: () => this.deepScanCoordinator.getActiveScans(),
                cleanup: () => this.deepScanCoordinator.cleanupOldScans()
            };
        }

        handleStageComplete(event) {
            this.memoryManager.set('metrics', `stage_${event.stage}`, event);
        }

        handleConnectionRestored(event) {
        }

        handleError(event) {
            this.memoryManager.set('metrics', 'error_events', event, 3600000);
        }

        handleBridgeMessage(data) {
        }

        handleBridgeReady(data) {
        }

        handleScanRequest(data) {
            console.log('📨 Scan request received via event bus:', data);
            
            if (data.immediate) {
                this.scanNow(data.options || {})
                    .then(result => {
                        this.eventBus.emit('scan:result', result);
                    })
                    .catch(error => {
                        this.eventBus.emit('scan:error', { error: error.message });
                    });
            }
        }

        async startLiveScan(options = {}) {
            console.log('🚀 Starting real AI site scan...');
            
            return await ResilientOperation.executeWithRetry(
                async () => {
                    try {
                        // اسکن واقعی سایت
                        const scanResult = AISiteScanner.scanCurrentSite();
                        
                        if (!scanResult.success) {
                            throw new Error(`Scan failed: ${scanResult.error}`);
                        }
                        
                        // ========== فراخوانی dispatchLiveScan ==========
                        this.dispatchLiveScan(options.reqId || this.sessionId, scanResult);
                        
                        // ارسال نتیجه از طریق Bridge با فرمت Router-compatible
                        if (this.bridgeActive) {
                            window.postMessage({
                                source: 'SCANLAYER_TO_CS',
                                type: 'SCAN_RESPONSE',
                                success: true,
                                reqId: options.reqId || `scan_${Date.now()}`,
                                payload: scanResult,
                                timestamp: Date.now()
                            }, '*');
                        }
                        
                        // ذخیره در memory
                        this.memoryManager.set('session', 'last_scan', {
                            result: scanResult,
                            timestamp: Date.now(),
                            url: window.location.href
                        });
                        
                        // log
                        this.logger.info('Live scan completed', {
                            messages: scanResult.messages?.length || 0,
                            site: scanResult.site
                        });
                        
                        return {
                            success: true,
                            scanResult,
                            sessionId: this.sessionId
                        };
                        
                    } catch (error) {
                        this.logger.error('Live scan error', { error: error.message });
                        throw error;
                    }
                },
                { 
                    maxRetries: 2, 
                    timeout: 15000,
                    shouldRetry: (error) => !error.message.includes('Unsupported site')
                }
            );
        }

        async scanNow(options = {}) {
            console.log('🔍 Manual scan requested');
            
            try {
                const result = await this.startLiveScan(options);
                
                // همچنین به Guardian هم اطلاع بده با فرمت Router-compatible
                window.postMessage({
                    source: 'SCANLAYER_TO_CS',
                    type: 'SCAN_RESPONSE',
                    success: true,
                    reqId: options.reqId || `scan_${Date.now()}`,
                    payload: result,
                    timestamp: Date.now()
                }, '*');
                
                return result;
                
            } catch (error) {
                this.logger.error('Manual scan failed', { error: error.message });
                
                // اطلاع خطا به Guardian با فرمت Router-compatible
                window.postMessage({
                    source: 'SCANLAYER_TO_CS',
                    type: 'SCAN_ERROR',
                    success: false,
                    reqId: options.reqId || `scan_${Date.now()}`,
                    payload: { error: error.message },
                    timestamp: Date.now()
                }, '*');
                
                throw error;
            }
        }

        // تابع جدید برای تست سریع
        async quickTestScan() {
            return AISiteScanner.quickScan();
        }

        getSystemStatus() {
            return {
                environment: this.context.environment,
                memory: this.memoryManager.getSegmentStats(),
                dependencies: this.dependencyGraph.visualize(),
                resync: this.resyncManager.getSyncStatus(),
                logs: {
                    total: this.logger.getLogs().length,
                    errors: this.logger.getLogs({ level: 'error' }).length,
                    warnings: this.logger.getLogs({ level: 'warn' }).length
                },
                timestamp: Date.now(),
                bridgeActive: this.bridgeActive,
                sessionId: this.sessionId,
                bootStatus: this.__BOOT_STATUS,
                version: this.version,
                modules: {
                    scanner: true,
                    liveScan: true,
                    deepScan: true,
                    validator: true,
                    deepScanEngine: true,
                    deepScanCoordinator: true
                }
            };
        }

        async cleanup() {
            if (this.resyncManager && typeof this.resyncManager.cleanup === 'function') {
                await this.resyncManager.cleanup();
            }
            if (this.deepScanCoordinator && typeof this.deepScanCoordinator.cleanupOldScans === 'function') {
                this.deepScanCoordinator.cleanupOldScans();
            }
        }
    }

    // ==================== MESSAGE LISTENER FOR SL_STATUS_REQUEST - FIXED ====================
    window.addEventListener('message', (event) => {
        if (!event.data || event.data.type !== 'SL_STATUS_REQUEST') return;

        // پیدا کردن instance ScanLayer
        let scanLayerInstance = window.ScanLayerInstance || window.scanLayer;

        // ✅ FIXED: Using correct SCANLAYER_STATUS contract
        const response = {
            source: 'SL_LAYER',
            type: 'SCANLAYER_STATUS',
            data: {
                phase: 'status_response',
                items: 1,
                ts: Date.now(),
                reqId: event.data.reqId,
                loaded: !!scanLayerInstance,
                version: scanLayerInstance?.version || 'unknown',
                modulesLoaded: !!scanLayerInstance?.scanner,
                scannerReady: typeof scanLayerInstance?.scanner?.scanCurrentSite === 'function',
                deepScanReady: !!(scanLayerInstance?.deepScan),
                source: 'status_listener'
            }
        };

        window.postMessage(response, '*');
        
        console.log('📡 SCANLAYER_STATUS sent for SL_STATUS_REQUEST:', response);
    });

    // ==================== GLOBAL EXPORTS ====================
    window.ScanLayer = {
        Main: ScanLayer,
        SecureMemoryManager,
        ResilientOperation,
        SecureEventBus,
        InterfaceValidator,
        IntegrityValidator,
        QuantumResyncManager,
        SecureLogger,
        DependencyGraph,
        AISiteScanner,
        DeepScanEngine,
        DeepScanCoordinator,
        LiveScanManager,
        DeepScan,
        Validator,
        
        createInstance: function(options = {}) {
            return new ScanLayer(options);
        },
        
        quickScan: function() {
            return AISiteScanner.quickScan();
        },
        
        scanCurrentSite: function() {
            return AISiteScanner.scanCurrentSite();
        },
        
        getVersion: function() {
            return '4.2-GS-NoModule';
        }
    };

    window.ScanLayerClass = ScanLayer;
    
    window.__SCAN_LAYER_LOADED__ = false;
    window.__SCAN_LAYER_LOADER__ = false;
    window.__SCANLAYER_STAGE_READY__ = false;
    window.ScanLayerInstance = null;

    console.log('✅ ScanLayer loaded as self-contained script');

    // ==================== STAGE‑3 EXPOSURE BOOTSTRAP FOR MAIN WORLD - FIXED ====================
    (function () {
        try {
            if (window.__SCANLAYER_STAGE_READY__ || window.__SCAN_LAYER_LOADED__) {
                console.warn("⚠️ ScanLayer already initialized, skipping bootstrap.");
                return;
            }

            console.log("🚀 [ScanLayer] Stage‑3 bootstrap starting…");

            const instance = new ScanLayer();
            window.ScanLayerInstance = instance;

            instance.initialize()
                .then(() => {
                    try {
                        instance.finalizeExposure();

                        window.__SCAN_LAYER_LOADER__ = true;
                        window.__SCAN_LAYER_SOURCE__ = "PAGE_WORLD";
                        window.__SCANLAYER_EXPOSE_SAFE__ = true;
                        window.__SCANLAYER_STAGE_READY__ = true;

                        window.postMessage({
                            source: "SCANLAYER_MAIN",
                            type: "SCANLAYER_READY",
                            ts: Date.now()
                        }, "*");

                        try {
                            // ✅ FIXED: Using correct SCANLAYER_STATUS contract
                            chrome.runtime.sendMessage({
                                type: "SCANLAYER_STATUS",
                                data: {
                                    phase: 'bootstrap_complete',
                                    items: 0,
                                    ts: Date.now(),
                                    ready: true,
                                    version: instance.version,
                                    deepScanReady: true,
                                    source: 'stage_3_bootstrap'
                                }
                            });
                        } catch (_) {
                            // اگر chrome.runtime در دسترس نباشد، سکوت کن
                        }

                        console.log("✅ [ScanLayer] Stage‑3 exposure completed");
                        console.log("🧠 [ScanLayer] DeepScan APIs exposed successfully");
                        console.log("📋 Available APIs:", {
                            scanNow: typeof instance.scanNow,
                            deepScan: typeof instance.deepScan,
                            deepScanStart: typeof instance.deepScan?.start,
                            deepScanFull: typeof instance.deepScan?.runFullDeepScan
                        });

                    } catch (error) {
                        console.error("🔥 Exposure finalize failed:", error);
                    }
                })
                .catch(err => {
                    console.error("🔥 ScanLayer initialize() failed:", err);
                });

        } catch (error) {
            console.error("🔥 Stage‑3 bootstrap crashed:", error);
        }
    })();

})(); // End of IIFE