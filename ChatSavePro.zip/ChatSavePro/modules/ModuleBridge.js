// ModuleBridge.js — QuantumStage v3.9 + GuardianIntegration - ENHANCED
// 14 Principles Compliant - Enterprise Grade
// ============================================================

// ✅ PRINCIPLE 14: STATIC ES6 IMPORTS
import { ModuleLoadTracker } from './ModuleLoadTracker.js';

// ✅ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Enhanced interface schemas
const MODULE_SCHEMAS = Object.freeze({
    HANDLER_REGISTRATION: Object.freeze({
        required: ['moduleName', 'handler'],
        moduleName: { 
            type: 'string', 
            maxLength: 50, 
            pattern: /^[a-zA-Z0-9_-]+$/,
            blacklist: ['__proto__', 'constructor', 'prototype', 'eval', 'function']
        },
        handler: { 
            type: 'object',
            allowedProperties: ['init', 'destroy', 'handle', 'process', 'execute'],
            maxPropertyCount: 20
        }
    }),
    METHOD_INVOCATION: Object.freeze({
        required: ['moduleName', 'methodName'],
        moduleName: { type: 'string', maxLength: 50 },
        methodName: { 
            type: 'string', 
            maxLength: 30, 
            pattern: /^[a-zA-Z0-9_]+$/,
            blacklist: ['__proto__', 'constructor', 'prototype', 'eval', 'function']
        },
        args: { 
            type: 'array', 
            maxLength: 10,
            maxDepth: 5,
            maxTotalSize: 1024 * 1024 // 1MB
        }
    }),
    EVENT_EMISSION: Object.freeze({
        required: ['eventName'],
        eventName: { 
            type: 'string', 
            maxLength: 80, 
            pattern: /^[a-zA-Z0-9_:.-]+$/,
            blacklist: ['__proto__', 'constructor', 'prototype']
        },
        payload: {
            maxSize: 1024 * 1024, // 1MB
            allowedTypes: ['string', 'number', 'boolean', 'object', 'array', 'null'],
            maxDepth: 10
        }
    })
});

// ✅ PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Enhanced retry configuration
const RETRY_CONFIG = Object.freeze({
    maxRetries: 3,
    baseDelay: 100,
    maxDelay: 3000,
    backoff: 'exponential',
    jitter: 0.1, // 10% jitter for better distribution
    timeout: 30000 // 30 second timeout
});

// ✅ PRINCIPLE 10: INTEGRITY BRIDGE - Signature verification
class BridgeIntegrityManager {
    #signatureRegistry = new Map();
    #verificationCache = new Map();
    #cacheMaxSize = 1000;
    
    constructor() {
        this.#initializeDefaultSignatures();
    }
    
    #initializeDefaultSignatures() {
        // Default system signatures for core modules
        const defaultSignatures = {
            'ModuleBridge': ['mb:v1:system', 'mb:v2:core'],
            'EventBus': ['eb:v1:system', 'eb:v2:core'],
            'GuardianIntegrity': ['gi:v1:system', 'gi:v2:security'],
            'SecureStatsManager': ['ssm:v1:system', 'ssm:v2:metrics']
        };
        
        for (const [module, signatures] of Object.entries(defaultSignatures)) {
            this.#signatureRegistry.set(module, Object.freeze([...signatures]));
        }
    }
    
    registerSignatures(moduleName, signatures) {
        this.#validateSignatures(moduleName, signatures);
        
        const existing = this.#signatureRegistry.get(moduleName) || [];
        const merged = [...new Set([...existing, ...signatures])];
        
        this.#signatureRegistry.set(moduleName, Object.freeze(merged));
        
        // Clear relevant cache entries
        this.#clearModuleCache(moduleName);
        
        return true;
    }
    
    verifySignature(moduleName, signature) {
        const cacheKey = `${moduleName}:${signature}`;
        
        // Check cache first for performance
        if (this.#verificationCache.has(cacheKey)) {
            return this.#verificationCache.get(cacheKey);
        }
        
        const validSignatures = this.#signatureRegistry.get(moduleName);
        const isValid = validSignatures ? validSignatures.includes(signature) : false;
        
        // Cache the result
        this.#verificationCache.set(cacheKey, isValid);
        
        // Manage cache size
        if (this.#verificationCache.size > this.#cacheMaxSize) {
            const firstKey = this.#verificationCache.keys().next().value;
            this.#verificationCache.delete(firstKey);
        }
        
        return isValid;
    }
    
    #validateSignatures(moduleName, signatures) {
        if (!moduleName || typeof moduleName !== 'string') {
            throw new Error('Module name must be a non-empty string');
        }
        
        if (moduleName.length > 50) {
            throw new Error('Module name exceeds 50 character limit');
        }
        
        if (!/^[a-zA-Z0-9_-]+$/.test(moduleName)) {
            throw new Error('Module name contains invalid characters');
        }
        
        if (!Array.isArray(signatures)) {
            throw new Error('Signatures must be an array');
        }
        
        if (signatures.length > 10) {
            throw new Error(`Too many signatures: ${signatures.length} > 10`);
        }
        
        for (const sig of signatures) {
            if (typeof sig !== 'string') {
                throw new Error('All signatures must be strings');
            }
            
            if (sig.length > 200) {
                throw new Error(`Signature too long: ${sig.length} > 200`);
            }
            
            if (!/^[a-zA-Z0-9:_\-\.=]+$/.test(sig)) {
                throw new Error('Signature contains invalid characters');
            }
        }
    }
    
    #clearModuleCache(moduleName) {
        for (const key of this.#verificationCache.keys()) {
            if (key.startsWith(moduleName)) {
                this.#verificationCache.delete(key);
            }
        }
    }
    
    getStats() {
        return {
            totalModules: this.#signatureRegistry.size,
            totalSignatures: Array.from(this.#signatureRegistry.values())
                .reduce((sum, sigs) => sum + sigs.length, 0),
            cacheSize: this.#verificationCache.size,
            cacheHitRate: this.#calculateCacheHitRate()
        };
    }
    
    #calculateCacheHitRate() {
        // Simplified cache hit rate calculation
        return this.#verificationCache.size > 0 ? 0.8 : 0; // Placeholder
    }
}

// ✅ PRINCIPLE 12: SECURE LOGGING - Enhanced audit trail
class BridgeAuditTrail {
    #events = [];
    #maxSize = 1000;
    #securityToken = null;
    
    constructor() {
        this.#securityToken = this.#generateSecurityToken();
    }
    
    #generateSecurityToken() {
        return `bridge_audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    log(eventType, data, level = 'info') {
        try {
            const auditEntry = {
                id: this.#generateEventId(),
                timestamp: Date.now(),
                event: eventType,
                data: this.#sanitizeAuditData(data),
                level: level,
                token: this.#securityToken
            };
            
            this.#events.push(auditEntry);
            
            // Maintain size limit
            if (this.#events.length > this.#maxSize) {
                this.#events.shift();
            }
            
            return auditEntry.id;
        } catch (error) {
            console.warn('⚠️ Bridge audit logging failed:', error.message);
            return null;
        }
    }
    
    #generateEventId() {
        return `bridge_evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    #sanitizeAuditData(data) {
        if (typeof data !== 'object' || data === null) {
            return typeof data === 'string' ? data.substring(0, 1000) : data;
        }
        
        const sanitized = {};
        const forbiddenKeys = ['__proto__', 'constructor', 'prototype', 'password', 'token', 'key', 'secret'];
        
        for (const [key, value] of Object.entries(data)) {
            if (forbiddenKeys.includes(key)) {
                sanitized[key] = '***REDACTED***';
                continue;
            }
            
            if (typeof value === 'string') {
                sanitized[key] = value.substring(0, 1000).replace(/[<>]/g, '');
            } else if (typeof value === 'object' && value !== null) {
                sanitized[key] = this.#sanitizeAuditData(value);
            } else {
                sanitized[key] = value;
            }
        }
        
        return sanitized;
    }
    
    getEvents(limit = 100, level = null) {
        let events = this.#events;
        if (level) {
            events = events.filter(entry => entry.level === level);
        }
        return events.slice(-limit).map(entry => Object.freeze({ ...entry }));
    }
    
    getStats() {
        return {
            totalEvents: this.#events.length,
            securityToken: this.#securityToken ? 'SET' : 'MISSING'
        };
    }
    
    clear() {
        this.#events = [];
    }
}

// ✅ PRINCIPLE 7: MEMORY SEGMENTATION - Enhanced memory management
class BridgeMemoryManager {
    #segments = new Map();
    #cleanupInterval = null;
    
    constructor() {
        this.#initializeSegments();
        this.#startCleanupCycle();
    }
    
    #initializeSegments() {
        this.#segments.set('handlers', new Map());      // Handler storage
        this.#segments.set('contexts', new Map());      // Context storage  
        this.#segments.set('cache', new Map());         // Cache segment
        this.#segments.set('metrics', new Map());       // Metrics segment
        this.#segments.set('operations', new Map());    // Operation tracking
        this.#segments.set('config', new Map());        // Configuration
    }
    
    #startCleanupCycle() {
        this.#cleanupInterval = setInterval(() => {
            this.#cleanupExpiredData();
        }, 60000); // Clean every minute
    }
    
    #cleanupExpiredData() {
        const now = Date.now();
        let cleanedCount = 0;
        
        // Clean old cache entries (older than 1 hour)
        const cache = this.#segments.get('cache');
        for (const [key, entry] of cache) {
            if (entry.expiresAt && now > entry.expiresAt) {
                cache.delete(key);
                cleanedCount++;
            }
        }
        
        // Clean old operation tracking (older than 5 minutes)
        const operations = this.#segments.get('operations');
        for (const [key, operation] of operations) {
            if (now - operation.startTime > 300000) { // 5 minutes
                operations.delete(key);
                cleanedCount++;
            }
        }
        
        if (cleanedCount > 0) {
            console.log(`🧹 [BridgeMemory] Cleaned ${cleanedCount} expired items`);
        }
    }
    
    set(segment, key, value, ttl = null) {
        if (!this.#segments.has(segment)) {
            throw new Error(`Invalid segment: ${segment}`);
        }
        
        const entry = {
            value,
            timestamp: Date.now(),
            expiresAt: ttl ? now + ttl : null,
            accessCount: 0
        };
        
        this.#segments.get(segment).set(key, entry);
        return true;
    }
    
    get(segment, key) {
        if (!this.#segments.has(segment)) return null;
        
        const entry = this.#segments.get(segment).get(key);
        if (!entry) return null;
        
        // Check expiration
        if (entry.expiresAt && Date.now() > entry.expiresAt) {
            this.#segments.get(segment).delete(key);
            return null;
        }
        
        entry.accessCount++;
        return entry.value;
    }
    
    delete(segment, key) {
        if (this.#segments.has(segment)) {
            return this.#segments.get(segment).delete(key);
        }
        return false;
    }
    
    getSegmentStats() {
        const stats = {};
        for (const [segmentName, segment] of this.#segments) {
            stats[segmentName] = {
                size: segment.size,
                sampleKeys: Array.from(segment.keys()).slice(0, 5)
            };
        }
        return stats;
    }
    
    destroy() {
        if (this.#cleanupInterval) {
            clearInterval(this.#cleanupInterval);
            this.#cleanupInterval = null;
        }
        
        this.#segments.clear();
        console.log('🧹 [BridgeMemory] Destroyed successfully');
    }
}

export class ModuleBridge {
    constructor() {
        if (ModuleBridge.#instance) return ModuleBridge.#instance;
        
        // ✅ PRINCIPLE 7: MEMORY SEGMENTATION - Enhanced memory management
        this.memoryManager = new BridgeMemoryManager();
        
        // ✅ PRINCIPLE 10: INTEGRITY BRIDGE - Signature verification
        this.integrityManager = new BridgeIntegrityManager();
        
        // ✅ PRINCIPLE 12: SECURE LOGGING - Enhanced audit trail
        this.auditTrail = new BridgeAuditTrail();
        
        this.eventBus = null;
        this.operationQueue = new Set();
        
        ModuleBridge.#instance = this;
        
        ModuleLoadTracker.registerModule('ModuleBridge', 'background', 'ModuleBridge.js');
        console.log('✅ Enhanced ModuleBridge v3.9 R9.9.0 loaded successfully');
    }

    static #instance = null;

    static getInstance() {
        if (!ModuleBridge.#instance) {
            ModuleBridge.#instance = new ModuleBridge();
        }
        return ModuleBridge.#instance;
    }

    // ✅ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Enhanced validation
    #validateHandlerRegistration(moduleName, handler) {
        const schema = MODULE_SCHEMAS.HANDLER_REGISTRATION;
        
        // Validate module name
        if (typeof moduleName !== 'string' || moduleName.length === 0) {
            throw new Error('Module name must be a non-empty string');
        }
        
        if (moduleName.length > schema.moduleName.maxLength) {
            throw new Error(`Module name too long: ${moduleName.length} > ${schema.moduleName.maxLength}`);
        }
        
        if (!schema.moduleName.pattern.test(moduleName)) {
            throw new Error(`Module name contains invalid characters: ${moduleName}`);
        }
        
        // Check blacklisted names
        if (schema.moduleName.blacklist.includes(moduleName.toLowerCase())) {
            throw new Error(`Module name not allowed: ${moduleName}`);
        }
        
        // Validate handler
        if (typeof handler !== 'object' || handler === null) {
            throw new Error('Handler must be a valid object');
        }
        
        // Prevent prototype pollution
        this.#sanitizeObject(handler);
        
        // Check handler property count
        const propertyCount = Object.keys(handler).length;
        if (propertyCount > schema.handler.maxPropertyCount) {
            throw new Error(`Too many handler properties: ${propertyCount} > ${schema.handler.maxPropertyCount}`);
        }
        
        return true;
    }

    // ✅ PRINCIPLE 2: STRICT INTERFACE CONTRACTS - Enhanced method invocation validation
    #validateMethodInvocation(moduleName, methodName, args) {
        const schema = MODULE_SCHEMAS.METHOD_INVOCATION;
        
        // Validate module name
        if (typeof moduleName !== 'string' || moduleName.length === 0) {
            throw new Error('Module name must be a non-empty string');
        }
        
        if (moduleName.length > schema.moduleName.maxLength) {
            throw new Error(`Module name too long: ${moduleName.length} > ${schema.moduleName.maxLength}`);
        }
        
        // Validate method name
        if (typeof methodName !== 'string' || methodName.length === 0) {
            throw new Error('Method name must be a non-empty string');
        }
        
        if (methodName.length > schema.methodName.maxLength) {
            throw new Error(`Method name too long: ${methodName.length} > ${schema.methodName.maxLength}`);
        }
        
        if (!schema.methodName.pattern.test(methodName)) {
            throw new Error(`Method name contains invalid characters: ${methodName}`);
        }
        
        // Check blacklisted method names
        if (schema.methodName.blacklist.includes(methodName.toLowerCase())) {
            throw new Error(`Method name not allowed: ${methodName}`);
        }
        
        // Validate arguments
        if (!Array.isArray(args)) {
            throw new Error('Arguments must be an array');
        }
        
        if (args.length > schema.args.maxLength) {
            throw new Error(`Too many arguments: ${args.length} > ${schema.args.maxLength}`);
        }
        
        // Validate argument size and depth
        const { totalSize, maxDepth } = this.#analyzeArguments(args);
        if (totalSize > schema.args.maxTotalSize) {
            throw new Error(`Arguments too large: ${totalSize} > ${schema.args.maxTotalSize}`);
        }
        
        if (maxDepth > schema.args.maxDepth) {
            throw new Error(`Arguments too deep: ${maxDepth} > ${schema.args.maxDepth}`);
        }
        
        // Sanitize arguments
        const sanitizedArgs = args.map(arg => this.#sanitizeData(arg));
        
        return sanitizedArgs;
    }

    #analyzeArguments(args, currentDepth = 0) {
        let totalSize = 0;
        let maxDepth = currentDepth;
        
        for (const arg of args) {
            if (arg === null || arg === undefined) {
                totalSize += 1;
                continue;
            }
            
            if (typeof arg === 'string') {
                totalSize += arg.length;
            } else if (typeof arg === 'number' || typeof arg === 'boolean') {
                totalSize += 8;
            } else if (Array.isArray(arg)) {
                const { size: childSize, depth: childDepth } = this.#analyzeArguments(arg, currentDepth + 1);
                totalSize += childSize;
                maxDepth = Math.max(maxDepth, childDepth);
            } else if (typeof arg === 'object') {
                const { size: childSize, depth: childDepth } = this.#analyzeArguments(Object.values(arg), currentDepth + 1);
                totalSize += childSize;
                maxDepth = Math.max(maxDepth, childDepth);
            }
        }
        
        return { totalSize, maxDepth };
    }

    // ✅ PRINCIPLE 9: FROZEN GLOBALS - Enhanced object sanitization
    #sanitizeObject(obj) {
        if (obj && typeof obj === 'object') {
            // Prevent prototype pollution on non-plain objects
            if (obj.constructor && obj.constructor.name !== 'Object' && obj.constructor.name !== 'Array') {
                throw new Error('Only plain objects and arrays allowed for handlers');
            }
            
            // Remove dangerous properties
            const dangerousProps = ['__proto__', 'constructor', 'prototype', 'eval', 'function'];
            dangerousProps.forEach(prop => {
                if (Object.prototype.hasOwnProperty.call(obj, prop)) {
                    delete obj[prop];
                }
            });
            
            // Recursively sanitize nested objects
            for (const key in obj) {
                if (obj.hasOwnProperty(key) && typeof obj[key] === 'object' && obj[key] !== null) {
                    this.#sanitizeObject(obj[key]);
                }
            }
        }
    }

    // ✅ PRINCIPLE 9: FROZEN GLOBALS - Enhanced data sanitization
    #sanitizeData(data, depth = 0) {
        if (depth > 10) { // Prevent infinite recursion
            return '[MAX_DEPTH_EXCEEDED]';
        }
        
        if (data === null || data === undefined) {
            return data;
        }
        
        if (typeof data === 'string') {
            // Limit string size and sanitize
            return data.substring(0, 10000).replace(/[<>]/g, '');
        }
        
        if (typeof data === 'number' || typeof data === 'boolean') {
            return data;
        }
        
        if (Array.isArray(data)) {
            return data.map(item => this.#sanitizeData(item, depth + 1));
        }
        
        if (typeof data === 'object') {
            const safeData = {};
            const forbiddenKeys = ['__proto__', 'constructor', 'prototype', 'password', 'token', 'key', 'secret'];
            
            for (const [key, value] of Object.entries(data)) {
                if (forbiddenKeys.includes(key)) {
                    safeData[key] = '***REDACTED***';
                    continue;
                }
                
                if (typeof value === 'object' && value !== null) {
                    safeData[key] = this.#sanitizeData(value, depth + 1);
                } else if (typeof value === 'string') {
                    safeData[key] = value.substring(0, 1000).replace(/[<>]/g, '');
                } else {
                    safeData[key] = value;
                }
            }
            
            return safeData;
        }
        
        return '[UNSUPPORTED_TYPE]';
    }

    // ✅ PRINCIPLE 5: RESILIENT ASYNC OPERATIONS - Enhanced retry mechanism
    async #executeWithRetry(operation, operationName, config = RETRY_CONFIG) {
        let lastError;
        const operationId = `${operationName}_${Date.now()}`;
        
        this.operationQueue.add(operationId);
        this.memoryManager.set('operations', operationId, {
            startTime: Date.now(),
            name: operationName,
            attempts: 0
        });
        
        try {
            for (let attempt = 1; attempt <= config.maxRetries; attempt++) {
                try {
                    this.memoryManager.set('operations', operationId, {
                        ...this.memoryManager.get('operations', operationId),
                        attempts: attempt
                    });
                    
                    const result = await this.#executeWithTimeout(operation, config.timeout, operationName);
                    
                    this.operationQueue.delete(operationId);
                    this.memoryManager.delete('operations', operationId);
                    
                    this.auditTrail.log('OPERATION_SUCCESS', { 
                        operation: operationName, 
                        attempt,
                        duration: Date.now() - this.memoryManager.get('operations', operationId)?.startTime
                    });
                    
                    return result;
                    
                } catch (error) {
                    lastError = error;
                    
                    this.auditTrail.log('OPERATION_RETRY', { 
                        operation: operationName, 
                        attempt, 
                        error: error.message 
                    });
                    
                    if (attempt < config.maxRetries) {
                        const delay = this.#calculateBackoff(attempt, config);
                        await new Promise(resolve => setTimeout(resolve, delay));
                    }
                }
            }
            
            throw lastError;
            
        } catch (finalError) {
            this.operationQueue.delete(operationId);
            this.memoryManager.delete('operations', operationId);
            
            this.auditTrail.log('OPERATION_FAILED', { 
                operation: operationName, 
                attempts: config.maxRetries, 
                error: finalError.message 
            });
            
            throw new Error(`Operation '${operationName}' failed after ${config.maxRetries} attempts: ${finalError.message}`);
        }
    }

    async #executeWithTimeout(operation, timeout, operationName) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Operation '${operationName}' timeout after ${timeout}ms`));
            }, timeout);
            
            Promise.resolve(operation())
                .then(resolve)
                .catch(reject)
                .finally(() => clearTimeout(timeoutId));
        });
    }

    #calculateBackoff(attempt, config) {
        let delay;
        
        switch (config.backoff) {
            case 'exponential':
                delay = Math.min(config.baseDelay * Math.pow(2, attempt - 1), config.maxDelay);
                break;
            case 'linear':
                delay = Math.min(config.baseDelay * attempt, config.maxDelay);
                break;
            default:
                delay = config.baseDelay;
        }
        
        // Add jitter for better distribution
        const jitter = delay * config.jitter * Math.random();
        return delay + jitter;
    }

    // ✅ PRINCIPLE 11: QUANTUM RESYNC - Background synchronization
    async syncWithBackground() {
        return this.#executeWithRetry(
            async () => {
                this.auditTrail.log('BACKGROUND_SYNC_STARTED', {});
                
                // Sync handlers and contexts with background
                const syncData = {
                    handlers: Array.from(this.memoryManager.getSegmentStats().handlers.sampleKeys),
                    contexts: Array.from(this.memoryManager.getSegmentStats().contexts.sampleKeys),
                    timestamp: Date.now(),
                    signature: this.integrityManager.generateSyncSignature()
                };
                
                // Emit sync event if event bus is available
                if (this.eventBus) {
                    await this.eventBus.emit('modulebridge:sync', syncData);
                }
                
                this.auditTrail.log('BACKGROUND_SYNC_COMPLETED', {
                    handlerCount: this.memoryManager.getSegmentStats().handlers.size,
                    contextCount: this.memoryManager.getSegmentStats().contexts.size
                });
                
                return { success: true, syncedAt: Date.now() };
            },
            'background_sync'
        );
    }

    registerContext(name, instance) {
        try {
            // Enhanced validation
            if (typeof name !== 'string' || name.length === 0 || name.length > 50) {
                throw new Error('Context name must be a string between 1-50 characters');
            }
            
            this.#sanitizeObject(instance);
            
            this.memoryManager.set('contexts', name, instance);
            
            this.auditTrail.log('CONTEXT_REGISTERED', { context: name });
            
            console.log('📌 Enhanced context registered:', name);
        } catch (error) {
            this.auditTrail.log('CONTEXT_REGISTRATION_FAILED', { 
                context: name, 
                error: error.message 
            }, 'error');
            throw error;
        }
    }

    registerHandler(moduleName, handler, signatures = []) {
        try {
            // Enhanced validation
            this.#validateHandlerRegistration(moduleName, handler);
            
            // Register signatures if provided
            if (signatures.length > 0) {
                this.integrityManager.registerSignatures(moduleName, signatures);
            }
            
            this.memoryManager.set('handlers', moduleName, handler);
            
            this.auditTrail.log('HANDLER_REGISTERED', { 
                module: moduleName,
                signatureCount: signatures.length
            });
            
            console.log('⚡ Enhanced handler registered for module:', moduleName);
        } catch (error) {
            this.auditTrail.log('HANDLER_REGISTRATION_FAILED', { 
                module: moduleName, 
                error: error.message 
            }, 'error');
            throw error;
        }
    }

    invokeHandler(moduleName, methodName, ...args) {
        return this.#executeWithRetry(
            () => this.#invokeHandlerInternal(moduleName, methodName, args),
            `invokeHandler_${moduleName}.${methodName}`
        );
    }

    async #invokeHandlerInternal(moduleName, methodName, args) {
        // Enhanced validation
        const sanitizedArgs = this.#validateMethodInvocation(moduleName, methodName, args);
        
        const handler = this.memoryManager.get('handlers', moduleName);
        if (!handler) {
            throw new Error(`Handler not found: ${moduleName}`);
        }
        
        if (typeof handler[methodName] !== 'function') {
            throw new Error(`Method not found: ${moduleName}.${methodName}`);
        }
        
        try {
            this.auditTrail.log('METHOD_INVOCATION_START', { 
                module: moduleName, 
                method: methodName,
                argsCount: sanitizedArgs.length
            });
            
            const startTime = Date.now();
            const result = await handler[methodName](...sanitizedArgs);
            const duration = Date.now() - startTime;
            
            this.auditTrail.log('METHOD_INVOCATION_SUCCESS', { 
                module: moduleName, 
                method: methodName,
                duration
            });
            
            return result;
            
        } catch (error) {
            this.auditTrail.log('METHOD_INVOCATION_FAILED', { 
                module: moduleName, 
                method: methodName,
                error: error.message,
                stack: error.stack?.substring(0, 500)
            }, 'error');
            
            throw error;
        }
    }

    // Enhanced EventBus integration
    setEventBus(eventBusInstance) {
        try {
            if (!eventBusInstance || typeof eventBusInstance.emit !== 'function') {
                throw new Error('Invalid EventBus instance - must have emit method');
            }
            
            this.eventBus = eventBusInstance;
            
            this.auditTrail.log('EVENTBUS_CONNECTED', {
                eventBusType: eventBusInstance.constructor?.name || 'unknown'
            });
            
        } catch (error) {
            this.auditTrail.log('EVENTBUS_CONNECTION_FAILED', { error: error.message }, 'error');
            throw error;
        }
    }

    emit(eventName, payload, signature = null) {
        if (!this.eventBus) {
            throw new Error('ModuleBridge missing EventBus connection');
        }
        
        try {
            // Validate event emission
            const schema = MODULE_SCHEMAS.EVENT_EMISSION;
            
            if (typeof eventName !== 'string' || eventName.length === 0) {
                throw new Error('Event name must be a non-empty string');
            }
            
            if (eventName.length > schema.eventName.maxLength) {
                throw new Error(`Event name too long: ${eventName.length} > ${schema.eventName.maxLength}`);
            }
            
            if (!schema.eventName.pattern.test(eventName)) {
                throw new Error(`Event name contains invalid characters: ${eventName}`);
            }
            
            if (schema.eventName.blacklist.includes(eventName.toLowerCase())) {
                throw new Error(`Event name not allowed: ${eventName}`);
            }
            
            // Verify signature if provided
            if (signature && !this.integrityManager.verifySignature('ModuleBridge', signature)) {
                throw new Error('Event signature verification failed');
            }
            
            const sanitizedPayload = this.#sanitizeData(payload);
            const payloadSize = JSON.stringify(sanitizedPayload).length;
            
            if (payloadSize > schema.payload.maxSize) {
                throw new Error(`Event payload too large: ${payloadSize} > ${schema.payload.maxSize}`);
            }
            
            this.auditTrail.log('EVENT_EMISSION', {
                event: eventName,
                payloadSize,
                signature: signature ? 'VERIFIED' : 'NONE'
            });
            
            return this.eventBus.emit(eventName, sanitizedPayload);
            
        } catch (error) {
            this.auditTrail.log('EVENT_EMISSION_FAILED', {
                event: eventName,
                error: error.message
            }, 'error');
            throw error;
        }
    }

    // ✅ PRINCIPLE 8: MODULAR CLEANUP - Enhanced cleanup
    async cleanup() {
        try {
            this.auditTrail.log('CLEANUP_STARTED', {});
            
            // Clear all memory segments
            this.memoryManager.destroy();
            
            // Clear operation queue
            this.operationQueue.clear();
            
            // Clear audit trail
            this.auditTrail.clear();
            
            // Reset event bus
            this.eventBus = null;
            
            this.auditTrail.log('CLEANUP_COMPLETED', {});
            console.log('🧹 Enhanced ModuleBridge cleanup completed');
        } catch (error) {
            this.auditTrail.log('CLEANUP_FAILED', { error: error.message }, 'error');
            throw error;
        }
    }

    // Enhanced monitoring and diagnostics
    getDiagnostics() {
        return {
            version: '3.9.0',
            segments: this.memoryManager.getSegmentStats(),
            integrity: this.integrityManager.getStats(),
            audit: this.auditTrail.getStats(),
            operations: {
                active: this.operationQueue.size,
                queue: Array.from(this.operationQueue).slice(0, 10)
            },
            eventBus: this.eventBus ? 'CONNECTED' : 'DISCONNECTED',
            timestamp: Date.now()
        };
    }

    getAuditTrail(limit = 100, level = null) {
        return this.auditTrail.getEvents(limit, level);
    }
}

// ✅ PRINCIPLE 9: FROZEN GLOBALS - Freeze all prototypes
Object.freeze(ModuleBridge.prototype);
Object.freeze(BridgeIntegrityManager.prototype);
Object.freeze(BridgeAuditTrail.prototype);
Object.freeze(BridgeMemoryManager.prototype);

// 🌐 Attach runtime globals (Popup-friendly for MV3)
if (typeof window !== 'undefined') {
    try {
        // Export CLASS
        window.ModuleBridge = ModuleBridge;

        // Export INSTANCE (useful for popup)
        try {
            window.moduleBridgeInstance = ModuleBridge.getInstance();
        } catch (e) {
            console.warn('ModuleBridge.getInstance() failed during global attach:', e);
        }

        // Export safeSendMessage helper
        window.safeSendMessage = async function (...args) {
            try {
                const instance = ModuleBridge.getInstance();
                return await instance.invokeHandler('PopupBridge', 'safeSendMessage', ...args);
            } catch (err) {
                console.warn('safeSendMessage failed:', err);
                throw err;
            }
        };

        console.log('🌐 ModuleBridge globals attached to window successfully');
    } catch (e) {
        console.warn('⚠️ Failed attaching ModuleBridge globals:', e);
    }
}


export default ModuleBridge;