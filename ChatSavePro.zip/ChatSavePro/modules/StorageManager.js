// modules/storage.js — Fixed for EventBus integration - ENHANCED WITH SCAN STATE PERSISTENCE
import EventBus from './EventBus.js';
import GuardianIntegrity from './GuardianIntegrity.js';

export class StorageManager {
    constructor() {
        this.MODULE_NAME = 'StorageManager';
        this.MODULE_VERSION = 'R9.9.0';
        this.eventBus = null;
        this.guardian = null;
        this.cache = new Map();
        this.health = { lastCheck: null, totalItems: 0, totalSize: 0, averageItemSize: 0, lastError: null, status: 'INITIALIZING' };
        this.logger = new StorageLogger();
        this.initialized = false;
        
        // 🆕 ENHANCEMENT: Scan state persistence for browser restart
        this.SCAN_STATE_KEY = 'quantumstage_scan_states';
        this.DEFAULT_SCAN_STATES = {
            liveScanActive: true,  // 🆕 Auto-start on browser restart
            deepScanActive: true,  // 🆕 Auto-start on browser restart  
            lastStateUpdate: Date.now(),
            version: this.MODULE_VERSION
        };
    }

    async init(eventBusInstance, guardianInstance) {
        try {
            if (this.initialized) return true;
            this.eventBus = eventBusInstance || new EventBus();
            if (!this.eventBus.dispatchSystemEvent) {
                this.eventBus.dispatchSystemEvent = (name, meta) => console.log('[EventBus][Fallback] Event:', name, meta);
            }
            this.guardian = guardianInstance || new GuardianIntegrity();
            await this._loadExisting();
            
            // 🆕 ENHANCEMENT: Load saved scan states on initialization
            await this._loadScanStates();
            
            this.health.status = 'READY';
            this.initialized = true;
            this.logger.log('INFO', 'StorageManager initialized', { version: this.MODULE_VERSION });
            this.eventBus?.dispatchSystemEvent('STORAGE_READY', { version: this.MODULE_VERSION });
            return true;
        } catch (err) {
            this.logger.log('ERROR', 'Initialization failed', { error: err.message });
            this.health.lastError = err.message;
            this.health.status = 'FAILURE';
            return false;
        }
    }

    // 🆕 ENHANCEMENT: Scan state management methods
    async saveScanStates(scanStates) {
        try {
            const statesToSave = {
                ...this.DEFAULT_SCAN_STATES,
                ...scanStates,
                lastStateUpdate: Date.now(),
                version: this.MODULE_VERSION
            };
            
            await this._saveToStorage(this.SCAN_STATE_KEY, statesToSave);
            this.logger.log('INFO', 'Scan states saved', { states: statesToSave });
            
            return { success: true, states: statesToSave };
        } catch (error) {
            this.logger.log('ERROR', 'Failed to save scan states', { error: error.message });
            return { success: false, error: error.message };
        }
    }

    async loadScanStates() {
        try {
            const savedStates = await this._loadFromStorage(this.SCAN_STATE_KEY);
            const states = {
                ...this.DEFAULT_SCAN_STATES,
                ...savedStates
            };
            
            this.logger.log('INFO', 'Scan states loaded', { states });
            return { success: true, states };
        } catch (error) {
            this.logger.log('ERROR', 'Failed to load scan states', { error: error.message });
            return { success: false, error: error.message, states: this.DEFAULT_SCAN_STATES };
        }
    }

    async clearScanStates() {
        try {
            await this._removeFromStorage(this.SCAN_STATE_KEY);
            this.logger.log('INFO', 'Scan states cleared');
            return { success: true };
        } catch (error) {
            this.logger.log('ERROR', 'Failed to clear scan states', { error: error.message });
            return { success: false, error: error.message };
        }
    }

    // 🆕 ENHANCEMENT: Popup state persistence (survives popup close/open)
    async savePopupState(popupState) {
        try {
            const POPUP_STATE_KEY = 'quantumstage_popup_state';
            const stateToSave = {
                ...popupState,
                lastUpdate: Date.now(),
                version: this.MODULE_VERSION
            };
            
            await this._saveToStorage(POPUP_STATE_KEY, stateToSave);
            return { success: true };
        } catch (error) {
            this.logger.log('ERROR', 'Failed to save popup state', { error: error.message });
            return { success: false, error: error.message };
        }
    }

    async loadPopupState() {
        try {
            const POPUP_STATE_KEY = 'quantumstage_popup_state';
            const savedState = await this._loadFromStorage(POPUP_STATE_KEY);
            return { success: true, state: savedState };
        } catch (error) {
            this.logger.log('ERROR', 'Failed to load popup state', { error: error.message });
            return { success: false, error: error.message, state: null };
        }
    }

    // Private storage methods
    async _loadScanStates() {
        try {
            const result = await this.loadScanStates();
            if (result.success) {
                this.logger.log('INFO', 'Scan states loaded during init', { 
                    liveScan: result.states.liveScanActive,
                    deepScan: result.states.deepScanActive 
                });
            }
        } catch (error) {
            this.logger.log('WARN', 'Scan states load failed during init', { error: error.message });
        }
    }

    async _saveToStorage(key, data) {
        return new Promise((resolve, reject) => {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ [key]: data }, () => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(true);
                    }
                });
            } else {
                // Fallback to localStorage for testing
                try {
                    localStorage.setItem(key, JSON.stringify(data));
                    resolve(true);
                } catch (error) {
                    reject(error);
                }
            }
        });
    }

    async _loadFromStorage(key) {
        return new Promise((resolve, reject) => {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.get([key], (result) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(result[key] || null);
                    }
                });
            } else {
                // Fallback to localStorage for testing
                try {
                    const item = localStorage.getItem(key);
                    resolve(item ? JSON.parse(item) : null);
                } catch (error) {
                    reject(error);
                }
            }
        });
    }

    async _removeFromStorage(key) {
        return new Promise((resolve, reject) => {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.remove([key], () => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(true);
                    }
                });
            } else {
                // Fallback to localStorage for testing
                try {
                    localStorage.removeItem(key);
                    resolve(true);
                } catch (error) {
                    reject(error);
                }
            }
        });
    }

    getStorageHealth(reportOptions = {}) {
        const healthReport = {
            timestamp: Date.now(),
            totalItems: this.health.totalItems,
            totalSize: this.health.totalSize,
            averageItemSize: this.health.averageItemSize,
            cacheSync: this.cache.size,
            status: this.health.status,
            lastError: this.health.lastError,
            // 🆕 ENHANCEMENT: Include scan state info in health report
            scanStates: {
                persistence: 'ENABLED',
                key: this.SCAN_STATE_KEY
            }
        };
        if (reportOptions.verbose) healthReport.cacheKeys = Array.from(this.cache.keys());
        try { this.eventBus?.dispatchSystemEvent('STORAGE_HEALTH_UPDATE', healthReport); } catch {}
        return healthReport;
    }

    async _loadExisting() { 
        // Optional Chrome storage load implementation
        this.logger.log('INFO', 'Loading existing storage data');
    }

    // 🆕 ENHANCEMENT: Cleanup method for extension unload
    async cleanup() {
        try {
            // Save current states before cleanup
            await this.saveScanStates({
                liveScanActive: true,  // Default to active on restart
                deepScanActive: true   // Default to active on restart
            });
            this.logger.log('INFO', 'StorageManager cleanup completed');
        } catch (error) {
            this.logger.log('ERROR', 'StorageManager cleanup failed', { error: error.message });
        }
    }
}

class StorageLogger {
    log(level, message, data = {}) { 
        console[level === 'ERROR' ? 'error' : 'log'](`[StorageManager][${level}] ${message}`, data); 
    }
}

export default StorageManager;