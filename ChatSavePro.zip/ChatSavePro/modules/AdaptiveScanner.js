// ============================================================
// AdaptiveScanner.js - Self-Healing AI Scanner v1.3 - FINAL
// ES6 Module Export - Fixed for Chrome Extension
// ============================================================

export default class AdaptiveScanner {
    constructor() {
        this.platform = null;
        this.selectorConfig = new Map();
        this.observer = null;
        this.healthCheckInterval = null;
        this.isMonitoring = false;
        
        // اضافه کردن circuit breaker و محدودیت‌ها
        this.selfHealingAttempts = 0;
        this.maxSelfHealingAttempts = 3;
        this.circuitBreakerOpen = false;
        this.lastHealthCheck = 0;
        this.healthCheckDebounce = 5000; // 5 ثانیه
        this.healthCheckTimeout = null;
        
        // استراتژی‌های fallback با error handling
        this.fallbackStrategies = [
            this.strategyChatGPT.bind(this),
            this.strategyDataAttributes.bind(this),
            this.strategyAriaLabels.bind(this),
            this.strategyTextContent.bind(this),
            this.strategyStructural.bind(this),
            this.strategyMachineLearning.bind(this)
        ];
        
        this.init();
    }

    async init() {
        try {
            await this.loadSelectorConfig();
            this.detectPlatform();
            this.startHealthMonitoring();
            this.startChangeDetection();
            
            console.log('🔄 AdaptiveScanner initialized for:', this.platform);
        } catch (error) {
            console.error('❌ Failed to initialize AdaptiveScanner:', error);
        }
    }

    // تشخیص خودکار پلتفرم
    detectPlatform() {
        try {
            const url = window.location.href;
            const hostname = window.location.hostname;

            if (hostname.includes('chat.openai.com') || hostname.includes('chatgpt.com')) {
                this.platform = 'chatgpt';
            } else if (hostname.includes('deepseek.com')) {
                this.platform = 'deepseek';
            } else if (hostname.includes('claude.ai')) {
                this.platform = 'claude';
            } else if (hostname.includes('web.telegram.org')) {
                this.platform = 'telegram';
            } else if (hostname.includes('web.whatsapp.com')) {
                this.platform = 'whatsapp';
            } else if (hostname.includes('gapgpt.app')) {
                this.platform = 'gapgpt';
            } else {
                this.platform = 'generic';
            }

            console.log('🌐 Platform detected:', this.platform);
            return this.platform;
        } catch (error) {
            console.error('❌ Platform detection failed:', error);
            this.platform = 'generic';
            return this.platform;
        }
    }

    // بارگذاری کانفیگ سلکتورها
    async loadSelectorConfig() {
        try {
            const result = await chrome.storage.local.get(['adaptiveSelectors']);
            const config = result.adaptiveSelectors || this.getDefaultConfig();
            
            this.selectorConfig = new Map(Object.entries(config));
            console.log('📁 Selector config loaded');
        } catch (error) {
            console.error('❌ Failed to load selector config:', error);
            this.selectorConfig = new Map(Object.entries(this.getDefaultConfig()));
        }
    }

    // کانفیگ پیش‌فرض
    getDefaultConfig() {
        return {
            chatgpt: {
                messages: [
                    '[data-testid^="conversation-turn"]',
                    '[data-message-author-role]',
                    'div[class*="group"] div[class*="items-start"]',
                    '[class*="message"]',
                    '[class*="chat-message"]'
                ],
                input: [
                    '#prompt-textarea',
                    'textarea[placeholder*="Message"]',
                    '[contenteditable="true"]',
                    '[data-id*="input"]'
                ]
            },
            // اصلاح سلکتورهای DeepSeek برای DOM جدید 2025
            deepseek: {
                messages: [
                    '.chat-message .message-text',
                    '[data-message-type="assistant"] .message-text',
                    '[data-message-type="user"] .message-text',
                    '.message-container .prose',
                    '.markdown-body',
                    '.chat-message',
                    '[data-message-type]',
                    // fallbackهای قدیمی برای سازگاری
                    'div[class*="message-text"]',
                    'div[class*="chat-message"]',
                    'div[data-chat-message="true"]',
                    '.ds-markdown',
                    '.markdown',
                    'div[class*="message-content"]',
                    'div[class*="bubble"]'
                ],
                input: [
                    'textarea[placeholder*="Message"]',
                    '[contenteditable="true"]',
                    '[role="textbox"]',
                    '.input-area',
                    'form textarea',
                    '[data-testid*="input"]',
                    '.chat-input',
                    'footer textarea',
                    '[aria-label*="message"]'
                ]
            },
            claude: {
                messages: [
                    '.chat-message',
                    '[class*="message-content"]',
                    '[data-testid*="message"]'
                ],
                input: [
                    '[contenteditable="true"]',
                    '.ProseMirror',
                    '[role="textbox"]'
                ]
            },
            gapgpt: {
                messages: [
                    '[class*="message"]',
                    '[class*="chat"]',
                    '[class*="bubble"]',
                    '[role*="listitem"]'
                ],
                input: [
                    'textarea[placeholder*="Message"]',
                    '[contenteditable="true"]',
                    '[role="textbox"]',
                    '.input-area'
                ]
            },
            telegram: {
                messages: [
                    '[class*="message"]',
                    '[class*="bubble"]',
                    '.message'
                ],
                input: [
                    '[contenteditable="true"]',
                    '.input-field'
                ]
            },
            whatsapp: {
                messages: [
                    '[class*="message"]',
                    '[class*="bubble"]',
                    '.message-in'
                ],
                input: [
                    '[contenteditable="true"]',
                    'div[contenteditable="true"]'
                ]
            },
            generic: {
                messages: [
                    '[class*="message"]',
                    '[class*="chat"]',
                    '[class*="bubble"]',
                    '[role="listitem"]',
                    // اضافه کردن سلکتورهای عمومی بیشتر
                    'article',
                    'section[class*="message"]',
                    'div[class*="content"]'
                ],
                input: [
                    'textarea',
                    '[contenteditable="true"]',
                    '[role="textbox"]',
                    'input[type="text"]',
                    // اضافه کردن سلکتورهای عمومی بیشتر
                    '.input-field',
                    '.chat-input',
                    'form [contenteditable]'
                ]
            }
        };
    }

    // شروع مانیتورینگ سلامت
    startHealthMonitoring() {
        // کاهش فرکانس چک‌ها برای بهبود performance
        this.healthCheckInterval = setInterval(() => {
            this.performHealthCheck();
        }, 45000); // هر 45 ثانیه

        console.log('❤️ Health monitoring started');
    }

    // چک سلامت سلکتورها
    async performHealthCheck() {
        // جلوگیری از چک‌های مکرر
        const now = Date.now();
        if (now - this.lastHealthCheck < this.healthCheckDebounce) {
            return;
        }
        this.lastHealthCheck = now;

        if (this.circuitBreakerOpen) {
            console.log('🔌 Circuit breaker open - skipping health check');
            return;
        }

        try {
            const platformConfig = this.selectorConfig.get(this.platform);
            if (!platformConfig) return;

            let needsHealing = false;
            const brokenSelectors = {};

            for (const [elementType, selectors] of Object.entries(platformConfig)) {
                const workingSelector = await this.findWorkingSelector(selectors);
                
                if (!workingSelector) {
                    needsHealing = true;
                    brokenSelectors[elementType] = selectors;
                    console.log(`🔧 Broken selectors detected for ${elementType}, attempting self-healing...`);
                } else if (workingSelector !== selectors[0]) {
                    // سلکتور اصلی کار نمی‌کند، اما fallback کار می‌کند
                    await this.optimizeSelectorPriority(elementType, workingSelector);
                }
            }

            // PATCH 3: Force Self-Healing When message count = 0 for DeepSeek
            const messagesResult = await this.performAdaptiveScan();
            console.log(`[AdaptiveScanner] Extracted messages: ${messagesResult.messages.count}`);
            
            if (this.platform === 'deepseek') {
                if (!messagesResult.messages || messagesResult.messages.count === 0) {
                    console.warn('[AdaptiveScanner] DeepSeek message count = 0 → forcing full self-healing');
                    needsHealing = true;
                    if (platformConfig.messages) {
                        brokenSelectors.messages = platformConfig.messages;
                    }
                }
            }
            
            if (messagesResult.messages.count > 0) {
                console.log('[AdaptiveScanner] Sample message:', messagesResult.messages.elements[0]?.textContent?.slice(0, 80) || 'No content');
            }

            if (needsHealing) {
                await this.triggerSelfHealing(brokenSelectors);
            }
            
        } catch (error) {
            console.error('❌ Health check failed:', error);
        }
    }

    // پیدا کردن سلکتور کارآمد
    async findWorkingSelector(selectors) {
        for (const selector of selectors) {
            try {
                // اعتبارسنجی selector قبل از اجرا
                if (!this.isValidSelector(selector)) {
                    continue;
                }
                
                const element = document.querySelector(selector);
                if (element && this.isValidElement(element)) {
                    return selector;
                }
            } catch (error) {
                console.log(`Selector failed: ${selector}`, error);
            }
        }
        return null;
    }

    // اعتبارسنجی selector
    isValidSelector(selector) {
        try {
            // تست ساده برای اعتبارسنجی selector
            document.createDocumentFragment().querySelector(selector);
            return true;
        } catch (error) {
            console.log(`Invalid selector: ${selector}`);
            return false;
        }
    }

    // اعتبارسنجی المنت
    isValidElement(element) {
        try {
            return element && 
                   element.isConnected && 
                   element.offsetParent !== null && 
                   element.getBoundingClientRect().width > 0;
        } catch (error) {
            return false;
        }
    }

    // شروع تشخیص تغییرات DOM
    startChangeDetection() {
        try {
            this.observer = new MutationObserver((mutations) => {
                this.handleDOMChanges(mutations);
            });

            this.observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['class', 'id', 'data-testid', 'role', 'placeholder', 'data-message-author-role']
            });

            this.isMonitoring = true;
            console.log('🔍 DOM change detection started');
        } catch (error) {
            console.error('❌ Failed to start DOM change detection:', error);
        }
    }

    // هندل کردن تغییرات DOM
    handleDOMChanges(mutations) {
        try {
            let significantChange = false;

            for (const mutation of mutations) {
                if (this.isSignificantChange(mutation)) {
                    significantChange = true;
                    break;
                }
            }

            if (significantChange) {
                console.log('🔄 Significant DOM change detected');
                this.scheduleHealthCheck();
            }
        } catch (error) {
            console.error('❌ DOM change handling failed:', error);
        }
    }

    // تشخیص تغییرات مهم
    isSignificantChange(mutation) {
        try {
            if (mutation.type === 'attributes') {
                const attrName = mutation.attributeName;
                // تغییرات class، id یا data-* مهم هستند
                return attrName === 'class' || attrName === 'id' || 
                       attrName?.startsWith('data-') || attrName === 'role';
            }

            if (mutation.type === 'childList') {
                // اگر تعداد زیادی المنت اضافه/حذف شده
                return mutation.addedNodes.length > 3 || mutation.removedNodes.length > 3;
            }

            return false;
        } catch (error) {
            return false;
        }
    }

    // زمان‌بندی چک سلامت
    scheduleHealthCheck() {
        try {
            clearTimeout(this.healthCheckTimeout);
            this.healthCheckTimeout = setTimeout(() => {
                this.performHealthCheck();
            }, 3000); // افزایش به 3 ثانیه برای کاهش load
        } catch (error) {
            console.error('❌ Health check scheduling failed:', error);
        }
    }

   // فعال‌سازی سیستم self-healing
async triggerSelfHealing(brokenSelectors) {
    if (this.circuitBreakerOpen) {
        console.log('🔌 Circuit breaker open - skipping self-healing');
        return;
    }

    this.selfHealingAttempts++;
    if (this.selfHealingAttempts >= this.maxSelfHealingAttempts) {
        this.circuitBreakerOpen = true;
        console.log('🚨 Circuit breaker triggered - too many self-healing failures');

        setTimeout(() => {
            this.circuitBreakerOpen = false;
            this.selfHealingAttempts = 0;
            console.log('🔃 Circuit breaker reset');
        }, 120000);

        return;
    }

    console.log('🛠️ Starting self-healing process...');

    try {
        const healedConfig = { ...this.selectorConfig.get(this.platform) };
        let healedCount = 0;

        // 1) این آرایه تمام تغییرات را نگه می‌دارد
        const updates = [];

        for (const [elementType, oldSelectors] of Object.entries(brokenSelectors)) {

            const oldSelector = oldSelectors[0];   // اولین سلکتور مشکل‌دار
            const newSelector = await this.findAlternativeSelector(elementType);

            if (newSelector && this.isValidSelector(newSelector)) {

                // جلوگیری از duplicate
                const filteredSelectors = oldSelectors.filter(s => s !== newSelector);

                healedConfig[elementType] = [newSelector, ...filteredSelectors];

                console.log(`✅ Healed ${elementType}: ${oldSelector} → ${newSelector}`);

                healedCount++;

                // 2) ثبت اطلاعات برای ارسال به BG
                updates.push({
                    elementType,
                    oldSelector,
                    newSelector
                });
            }
        }

        if (healedCount > 0) {

            // ذخیره config جدید
            this.selectorConfig.set(this.platform, healedConfig);
            await this.saveSelectorConfig();

            // 3) ارسال تمام آپدیت‌ها به Background
            for (const u of updates) {
                this.notifyBackgroundAboutUpdate(u.oldSelector, u.newSelector);
            }

            console.log(`🎉 Self-healing completed: ${healedCount} selectors healed`);
        } else {
            console.log('⚠️ Self-healing failed: no alternative selectors found');
        }

    } catch (error) {
        console.error('❌ Self-healing process failed:', error);
    }
}


    // پیدا کردن سلکتور جایگزین
    async findAlternativeSelector(elementType) {
        for (const strategy of this.fallbackStrategies) {
            try {
                const selector = await strategy(elementType);
                if (selector && this.isValidSelector(selector)) {
                    return selector;
                }
            } catch (error) {
                console.log(`⚠️ Strategy failed:`, error);
                // ادامه به استراتژی بعدی
            }
        }
        return null;
    }

    // استراتژی ۱: ChatGPT-specific (جدید)
    async strategyChatGPT(elementType) {
        if (this.platform !== 'chatgpt') return null;
        
        try {
            // سلکتورهای جدید ChatGPT
            const chatGPTSelectors = {
                messages: [
                    '[data-testid*="conversation-turn"]',
                    '[data-message-author-role]',
                    'div[class*="group"] div[class*="items-start"]',
                    'main div[class*="flex"][class*="flex-col"] > div',
                    '[role="presentation"] > div > div',
                    'div[data-testid]'
                ],
                input: [
                    '#prompt-textarea',
                    'textarea[placeholder*="Message"]',
                    'div[contenteditable="true"]',
                    '[role="textbox"]',
                    '[data-id*="input"]'
                ]
            };
            
            const selectors = chatGPTSelectors[elementType] || [];
            for (const selector of selectors) {
                try {
                    if (!this.isValidSelector(selector)) continue;
                    
                    const element = document.querySelector(selector);
                    if (element && this.isElementType(element, elementType)) {
                        console.log(`✅ Found ChatGPT ${elementType} selector: ${selector}`);
                        return selector;
                    }
                } catch (error) {
                    continue;
                }
            }
            return null;
        } catch (error) {
            console.error('❌ ChatGPT strategy failed:', error);
            return null;
        }
    }

    // استراتژی ۲: data attributes - کاملاً اصلاح شده!
    async strategyDataAttributes(elementType) {
        try {
            // روش بهبود یافته برای پیدا کردن data attributes دقیق‌تر
            const specificDataAttrs = [
                '[data-testid*="message"]',
                '[data-testid*="chat"]',
                '[data-testid*="conversation"]',
                '[data-id*="message"]',
                '[data-message]',
                '[data-chat]',
                '[data-role="message"]',
                // سپس موارد کلی‌تر
                '[data-testid]',
                '[data-id]'
            ];
            
            for (const selector of specificDataAttrs) {
                try {
                    if (!this.isValidSelector(selector)) continue;
                    
                    const elements = document.querySelectorAll(selector);
                    let validElements = 0;
                    
                    for (const el of elements) {
                        if (this.isElementType(el, elementType)) {
                            validElements++;
                            // اگر حداقل 1 المنت معتبر پیدا کردیم، این سلکتور خوبه
                            if (validElements >= 1) {
                                console.log(`✅ Found specific data attribute selector: ${selector}`);
                                return selector;
                            }
                        }
                    }
                } catch (error) {
                    continue;
                }
            }
            
            // روش fallback: پیدا کردن المنت‌های با data-testid خاص
            const allTestidElements = document.querySelectorAll('[data-testid]');
            const messageTestids = new Set();
            
            for (const el of allTestidElements) {
                if (this.isElementType(el, elementType)) {
                    const testid = el.getAttribute('data-testid');
                    if (testid && testid.length > 0) {
                        messageTestids.add(testid);
                    }
                }
            }
            
            // انتخاب بهترین data-testid
            if (messageTestids.size > 0) {
                const testidArray = Array.from(messageTestids);
                // اولویت با testidهای مرتبط با پیام
                const messageRelated = testidArray.filter(id => 
                    id.includes('message') || 
                    id.includes('chat') || 
                    id.includes('conversation')
                );
                
                const bestTestid = messageRelated.length > 0 ? messageRelated[0] : testidArray[0];
                const selector = `[data-testid="${bestTestid}"]`;
                
                if (this.isValidSelector(selector)) {
                    console.log(`✅ Generated precise data-testid selector: ${selector}`);
                    return selector;
                }
            }
            
            return null;
        } catch (error) {
            console.error('❌ Data attributes strategy failed:', error);
            return null;
        }
    }

    // استراتژی ۳: aria labels
    async strategyAriaLabels(elementType) {
        try {
            const ariaSelectors = [
                '[role="listitem"]',
                '[aria-label*="message"]',
                '[aria-labelledby*="message"]',
                '[role="textbox"]',
                '[aria-multiline="true"]',
                '[role="main"] [role="listitem"]'
            ];

            for (const selector of ariaSelectors) {
                try {
                    if (!this.isValidSelector(selector)) continue;
                    
                    const element = document.querySelector(selector);
                    if (element && this.isElementType(element, elementType)) {
                        return selector;
                    }
                } catch (error) {
                    continue;
                }
            }
            return null;
        } catch (error) {
            console.error('❌ Aria labels strategy failed:', error);
            return null;
        }
    }

    // استراتژی ۴: text content - PATCH 1 APPLIED
    async strategyTextContent(elementType) {
        try {
            // برای پیام‌ها: المنت‌های با متن طولانی
            if (elementType === 'messages') {
                const elements = document.querySelectorAll('*');
                
                for (const el of elements) {
                    try {
                        const text = el.textContent?.trim() || '';
                        const hasSubstantialText = text.length > 20;
                        const hasMessageIndicators = 
                            text.includes('?') || 
                            text.includes('!') || 
                            text.includes('.') ||
                            el.querySelector('img, video, audio') !== null;
                        
                        // PATCH 1: Removed !el.querySelector('*') && condition
                        if (hasSubstantialText && 
                            (hasMessageIndicators || text.split(' ').length > 3) && 
                            this.isVisible(el)) {
                            
                            const selector = this.generateStructuralSelector(el);
                            if (selector && this.isValidSelector(selector)) {
                                return selector;
                            }
                        }
                    } catch (error) {
                        continue;
                    }
                }
            }
            return null;
        } catch (error) {
            console.error('❌ Text content strategy failed:', error);
            return null;
        }
    }

    // استراتژی ۵: ساختاری
    async strategyStructural(elementType) {
        try {
            const commonStructures = {
                messages: [
                    'main > div > div > div',
                    '.container > .content > .messages',
                    '[role="main"] > div > div',
                    'div > div > div > div', // ساختارهای تودرتو عمومی
                    'section > div > div'
                ],
                input: [
                    'footer textarea',
                    '.input-area',
                    '.chat-input',
                    'form [contenteditable]',
                    'div[contenteditable="true"]'
                ]
            };

            const structures = commonStructures[elementType] || [];
            for (const selector of structures) {
                try {
                    if (!this.isValidSelector(selector)) continue;
                    
                    const element = document.querySelector(selector);
                    if (element && this.isElementType(element, elementType)) {
                        return selector;
                    }
                } catch (error) {
                    continue;
                }
            }
            return null;
        } catch (error) {
            console.error('❌ Structural strategy failed:', error);
            return null;
        }
    }

    // استراتژی ۶: ML-based (ساده)
    async strategyMachineLearning(elementType) {
        try {
            // نسخه ساده - آنالیز ساختار DOM
            const elements = document.querySelectorAll('*');
            const candidates = [];
            
            for (const el of elements) {
                try {
                    if (this.isElementType(el, elementType) && this.hasGoodSelectorPotential(el)) {
                        const selector = this.generateSmartSelector(el);
                        if (selector && this.isValidSelector(selector)) {
                            candidates.push(selector);
                        }
                    }
                } catch (error) {
                    continue;
                }
            }
            
            // انتخاب بهترین کاندید بر اساس امتیاز
            if (candidates.length > 0) {
                return candidates[0];
            }
            
            return null;
        } catch (error) {
            console.error('❌ ML strategy failed:', error);
            return null;
        }
    }

    // تولید سلکتور هوشمند
    generateSmartSelector(element) {
        try {
            const attributes = Array.from(element.attributes);
            const scores = [];
            
            // امتیازدهی به attributeهای مختلف
            for (const attr of attributes) {
                let score = 0;
                
                if (attr.name === 'data-testid') score = 10;
                else if (attr.name.startsWith('data-')) score = 8;
                else if (attr.name === 'role') score = 7;
                else if (attr.name === 'aria-label') score = 6;
                else if (attr.name === 'class') {
                    const classes = attr.value.split(' ');
                    const meaningfulClasses = classes.filter(c => 
                        c.length > 3 && 
                        !c.includes('--') && 
                        !/\d/.test(c)
                    );
                    if (meaningfulClasses.length > 0) score = 5;
                }
                
                if (score > 0) {
                    scores.push({
                        selector: `[${attr.name}="${attr.value}"]`,
                        score: score
                    });
                }
            }
            
            // انتخاب بهترین سلکتور
            if (scores.length > 0) {
                scores.sort((a, b) => b.score - a.score);
                return scores[0].selector;
            }
            
            return null;
        } catch (error) {
            console.error('❌ Smart selector generation failed:', error);
            return null;
        }
    }

    // تشخیص نوع المنت - بهبود یافته!
    isElementType(element, expectedType) {
        try {
            if (expectedType === 'messages') {
                const text = element.textContent?.trim() || '';
                const hasSubstantialText = text.length > 15;
                const hasMessageIndicators = 
                    text.includes('?') || 
                    text.includes('!') || 
                    text.includes('.') ||
                    element.querySelector('img, video, audio') !== null;
                
                return hasSubstantialText && 
                       (hasMessageIndicators || text.split(' ').length > 3) &&
                       this.isVisible(element);
            } else if (expectedType === 'input') {
                return (element.tagName === 'TEXTAREA' || 
                        element.getAttribute('contenteditable') === 'true' ||
                        element.getAttribute('role') === 'textbox') &&
                       this.isVisible(element);
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    // بررسی visibility
    isVisible(element) {
        try {
            const rect = element.getBoundingClientRect();
            const style = getComputedStyle(element);
            
            return !!(rect.width && rect.height && 
                     element.offsetParent !== null && 
                     style.visibility !== 'hidden' &&
                     style.display !== 'none' &&
                     style.opacity !== '0');
        } catch (error) {
            return false;
        }
    }

    // بررسی پتانسیل سلکتور
    hasGoodSelectorPotential(element) {
        try {
            const selector = this.generateStructuralSelector(element);
            if (!selector) return false;
            
            const similarElements = document.querySelectorAll(selector);
            return similarElements.length <= 5; // تعداد مشابه‌ها کم باشد
        } catch (error) {
            return false;
        }
    }

    // تولید سلکتور ساختاری
    generateStructuralSelector(element) {
        try {
            let path = [];
            let current = element;
            
            while (current && current !== document.body && path.length < 8) { // محدودیت عمق
                let selector = current.tagName.toLowerCase();
                
                if (current.id) {
                    selector += `#${current.id}`;
                    path.unshift(selector);
                    break;
                } else {
                    const siblings = Array.from(current.parentNode.children);
                    const index = siblings.indexOf(current) + 1;
                    selector += `:nth-child(${index})`;
                    path.unshift(selector);
                }
                
                current = current.parentNode;
            }
            
            return path.length > 0 ? path.join(' > ') : null;
        } catch (error) {
            console.error('❌ Structural selector generation failed:', error);
            return null;
        }
    }

    // بهینه‌سازی اولویت سلکتورها
    async optimizeSelectorPriority(elementType, workingSelector) {
        try {
            const config = this.selectorConfig.get(this.platform);
            if (config && config[elementType]) {
                const selectors = config[elementType];
                const newSelectors = [workingSelector, ...selectors.filter(s => s !== workingSelector)];
                config[elementType] = newSelectors;
                
                await this.saveSelectorConfig();
                console.log(`🎯 Optimized ${elementType} selector priority`);
            }
        } catch (error) {
            console.error('❌ Selector priority optimization failed:', error);
        }
    }

    // ذخیره کانفیگ
    async saveSelectorConfig() {
        try {
            const configObject = Object.fromEntries(this.selectorConfig);
            await chrome.storage.local.set({ 
                adaptiveSelectors: configObject 
            });
        } catch (error) {
            console.error('❌ Failed to save selector config:', error);
        }
    }

   notifyBackgroundAboutUpdate(oldSelector, newSelector) {
    chrome.runtime.sendMessage({
        action: "SELECTOR_CONFIG_UPDATED",
        platform: this.platform,
        oldSelector,
        newSelector,
        timestamp: Date.now()
    });

    console.log("📡 [CS] SELECTOR_CONFIG_UPDATED sent:", {
        oldSelector,
        newSelector
    });
}

    // اجرای rebuild selector برای DeepSeek
    async triggerSelectorRebuild(platform) {
        console.log(`🛠️ [AdaptiveScanner] Triggering selector rebuild for ${platform}`);
        
        try {
            const newSelector = await this.rebuildSelectorByAI(platform);
            if (newSelector) {
                await this.reportSelectorUpdate(platform, 'auto', newSelector);
                console.log(`✅ [AdaptiveScanner] Selector rebuilt for ${platform}: ${newSelector}`);
            } else {
                console.warn(`⚠️ [AdaptiveScanner] Could not rebuild selector for ${platform}`);
            }
        } catch (error) {
            console.error(`❌ [AdaptiveScanner] Selector rebuild failed for ${platform}:`, error);
        }
    }

    // بازسازی selector با الگوریتم AI
    async rebuildSelectorByAI(platform) {
        try {
            // الگوریتم هوشمند برای پیدا کردن selector جدید
            const allElements = document.querySelectorAll('*');
            const candidates = [];
            
            for (const el of allElements) {
                const text = el.textContent?.trim() || '';
                if (text.length > 30) { // فقط متن‌های معنی‌دار
                    // ساخت selector بر اساس کلاس‌ها
                    const classes = el.className;
                    if (classes && typeof classes === 'string') {
                        const classList = classes.split(' ').filter(c => c.length > 2);
                        for (const cls of classList) {
                            const selector = `.${cls}`;
                            if (this.isValidSelector(selector)) {
                                const elements = document.querySelectorAll(selector);
                                if (elements.length > 0 && elements.length < 10) {
                                    candidates.push(selector);
                                }
                            }
                        }
                    }
                    
                    // ساخت selector بر اساس data attributes
                    const attributes = el.attributes;
                    for (const attr of attributes) {
                        if (attr.name.startsWith('data-')) {
                            const selector = `[${attr.name}="${attr.value}"]`;
                            if (this.isValidSelector(selector)) {
                                candidates.push(selector);
                            }
                        }
                    }
                }
            }
            
            // انتخاب بهترین selector
            if (candidates.length > 0) {
                // حذف duplicate
                const uniqueCandidates = [...new Set(candidates)];
                // اولویت با selectorهای کوتاه‌تر
                uniqueCandidates.sort((a, b) => a.length - b.length);
                return uniqueCandidates[0];
            }
            
            return null;
        } catch (error) {
            console.error('❌ [AdaptiveScanner] AI selector rebuild failed:', error);
            return null;
        }
    }

    // گزارش به‌روزرسانی selector
    async reportSelectorUpdate(platform, source, selector) {
        try {
            // به‌روزرسانی config محلی
            const currentConfig = this.selectorConfig.get(platform) || {};
            if (selector && !currentConfig.messages?.includes(selector)) {
                currentConfig.messages = [selector, ...(currentConfig.messages || [])];
                this.selectorConfig.set(platform, currentConfig);
                await this.saveSelectorConfig();
                
                // ارسال notification
                chrome.runtime.sendMessage({
                    action: "SELECTOR_AUTO_UPDATED",
                    platform: platform,
                    selector: selector,
                    source: source,
                    timestamp: Date.now()
                });
                
                console.log(`✅ [AdaptiveScanner] Selector auto-updated for ${platform}: ${selector}`);
            }
        } catch (error) {
            console.error('❌ [AdaptiveScanner] Failed to report selector update:', error);
        }
    }

    // دریافت سلکتورهای فعلی
    getCurrentSelectors() {
        return this.selectorConfig.get(this.platform) || {};
    }

    // اجرای اسکن با سلکتورهای adaptive
    async performAdaptiveScan() {
        try {
            const selectors = this.getCurrentSelectors();
            const results = {};
            
            for (const [elementType, selectorList] of Object.entries(selectors)) {
                const workingSelector = await this.findWorkingSelector(selectorList);
                if (workingSelector) {
                    const elements = Array.from(document.querySelectorAll(workingSelector));
                    results[elementType] = {
                        selector: workingSelector,
                        elements: elements,
                        count: elements.length
                    };
                }
            }
            
            // PATCH 4: Fix Fallback Scan (Return only actual message blocks)
            if (this.platform === 'deepseek' && (!results.messages || results.messages.count === 0)) {
                console.log('[AdaptiveScanner] No messages found with selectors, trying fallback...');
                
                const fallbackElements = Array.from(
                    document.querySelectorAll('.chat-message, .message-container, [data-message-type]')
                )
                .flatMap(parent =>
                    Array.from(parent.querySelectorAll('.message-text, .prose, .markdown-body'))
                )
                .filter(el => {
                    const text = el.textContent?.trim() || '';
                    return text.length > 15 && this.isVisible(el);
                });
                
                if (fallbackElements.length > 0) {
                    console.warn('[AdaptiveScanner] Fallback messages detected:', fallbackElements.length);
                    results.messages = {
                        selector: 'deepseek-fallback-parent-child',
                        elements: fallbackElements,
                        count: fallbackElements.length
                    };
                }
            }
            
            return {
                success: true,
                messages: results.messages || { elements: [], count: 0 },
                platform: this.platform,
                timestamp: Date.now()
            };
        } catch (error) {
            console.error('❌ Adaptive scan failed:', error);
            return {
                success: false,
                messages: { elements: [], count: 0 },
                platform: this.platform,
                timestamp: Date.now(),
                error: error.message
            };
        }
    }

    // توقف سیستم
    destroy() {
        try {
            if (this.observer) {
                this.observer.disconnect();
            }
            
            if (this.healthCheckInterval) {
                clearInterval(this.healthCheckInterval);
            }
            
            if (this.healthCheckTimeout) {
                clearTimeout(this.healthCheckTimeout);
            }
            
            this.isMonitoring = false;
            console.log('🛑 AdaptiveScanner destroyed');
        } catch (error) {
            console.error('❌ Error destroying AdaptiveScanner:', error);
        }
    }
}

// اضافه کردن named export برای سازگاری بیشتر
export { AdaptiveScanner };