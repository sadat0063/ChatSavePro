class SecureFilterManager {
  constructor() {
    this.MODULE_NAME = 'SecureFilterManager';
    this.MODULE_VERSION = '2.0.0';
    
    // Core filters registry
    this.filters = new Map();
    this.filterMetadata = new Map();
    
    // Processing cache
    this.processedCache = new Map();
    this.cacheTtl = 300000; // 5 minutes
    
    // Statistics
    this.stats = {
      totalProcessed: 0,
      filterApplied: 0,
      cacheHits: 0,
      cacheMisses: 0,
      errors: 0,
      startTime: Date.now()
    };
    
    this.initialized = false;
    this.init();
  }
  
  init() {
    if (this.initialized) return;
    
    try {
      this.registerDefaultFilters();
      this.startCacheCleanup();
      this.initialized = true;
      
      console.log(`✅ ${this.MODULE_NAME} v${this.MODULE_VERSION} initialized successfully`);
    } catch (error) {
      console.error(`❌ ${this.MODULE_NAME} initialization failed:`, error);
      throw error;
    }
  }
  
  registerDefaultFilters() {
    // 1. PII Filter (Personally Identifiable Information)
    this.registerFilter('pii_filter', async (data) => {
      const sensitivePatterns = [
        // Email addresses
        /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
        // Phone numbers (various formats)
        /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,
        /\b\(\d{3}\)\s*\d{3}[-.]?\d{4}\b/g,
        // Credit cards
        /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g,
        // Social security numbers
        /\b\d{3}[-.]?\d{2}[-.]?\d{4}\b/g,
        // IP addresses
        /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g,
        // MAC addresses
        /\b([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\b/g
      ];
      
      return this.recursiveFilter(data, (value) => {
        if (typeof value !== 'string') return value;
        
        let filtered = value;
        sensitivePatterns.forEach(pattern => {
          filtered = filtered.replace(pattern, '[REDACTED]');
        });
        
        return filtered;
      });
    }, {
      description: 'Removes Personally Identifiable Information',
      category: 'security',
      priority: 100
    });
    
    // 2. Token/Key Filter
    this.registerFilter('token_filter', async (data) => {
      const tokenPatterns = [
        // API keys (various formats)
        /sk_[a-zA-Z0-9]{32,}/g,
        /sk-[a-zA-Z0-9]{32,}/g,
        /AKIA[0-9A-Z]{16}/g, // AWS keys
        // JWT tokens
        /eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/g,
        // OAuth tokens
        /[a-zA-Z0-9]{32,}/g
      ];
      
      return this.recursiveFilter(data, (value) => {
        if (typeof value !== 'string') return value;
        
        let filtered = value;
        tokenPatterns.forEach(pattern => {
          filtered = filtered.replace(pattern, '[TOKEN_REDACTED]');
        });
        
        return filtered;
      });
    }, {
      description: 'Removes API keys and authentication tokens',
      category: 'security',
      priority: 90
    });
    
    // 3. URL Sanitizer
    this.registerFilter('url_sanitizer', async (data) => {
      return this.recursiveFilter(data, (value) => {
        if (typeof value !== 'string') return value;
        
        try {
          const url = new URL(value);
          // Remove query parameters containing sensitive data
          const cleanUrl = new URL(url.origin + url.pathname);
          
          // Preserve some safe query parameters
          const safeParams = ['utm_source', 'utm_medium', 'utm_campaign', 'ref', 'page'];
          safeParams.forEach(param => {
            if (url.searchParams.has(param)) {
              cleanUrl.searchParams.set(param, url.searchParams.get(param));
            }
          });
          
          return cleanUrl.toString();
        } catch {
          // Not a valid URL, return as-is
          return value;
        }
      });
    }, {
      description: 'Sanitizes URLs by removing sensitive query parameters',
      category: 'privacy',
      priority: 80
    });
    
    // 4. Content Redactor (for sensitive conversation content)
    this.registerFilter('content_redactor', async (data) => {
      const sensitiveKeywords = [
        'password', 'secret', 'token', 'key', 'credential',
        'private', 'confidential', 'sensitive', 'classified'
      ];
      
      const sensitiveRegex = new RegExp(
        `\\b(${sensitiveKeywords.join('|')})\\b`,
        'gi'
      );
      
      return this.recursiveFilter(data, (value) => {
        if (typeof value !== 'string') return value;
        
        // Replace sensitive keywords with placeholders
        return value.replace(sensitiveRegex, '[REDACTED]');
      });
    }, {
      description: 'Redacts sensitive keywords from content',
      category: 'privacy',
      priority: 70
    });
    
    // 5. Metadata Cleaner
    this.registerFilter('metadata_cleaner', async (data) => {
      const metadataFieldsToRemove = [
        '_internal', '_debug', '_trace', '_temp',
        'debugInfo', 'traceId', 'sessionId', 'ipAddress'
      ];
      
      return this.recursiveFilter(data, (value, key, parent) => {
        // Remove metadata fields
        if (metadataFieldsToRemove.includes(key)) {
          if (parent && typeof parent === 'object') {
            delete parent[key];
          }
          return undefined;
        }
        
        return value;
      }, true);
    }, {
      description: 'Removes internal metadata fields',
      category: 'cleanup',
      priority: 60
    });
    
    // 6. Duplicate Remover
    this.registerFilter('duplicate_remover', async (data) => {
      if (!Array.isArray(data)) return data;
      
      const seen = new Set();
      const result = [];
      
      for (const item of data) {
        const key = this.generateItemKey(item);
        if (!seen.has(key)) {
          seen.add(key);
          result.push(item);
        }
      }
      
      return result;
    }, {
      description: 'Removes duplicate items from arrays',
      category: 'optimization',
      priority: 50
    });
    
    console.log(`✅ ${this.MODULE_NAME}: Registered ${this.filters.size} default filters`);
  }
  
  registerFilter(name, filterFn, metadata = {}) {
    if (this.filters.has(name)) {
      console.warn(`⚠️ Filter "${name}" already registered, overwriting`);
    }
    
    this.filters.set(name, filterFn);
    this.filterMetadata.set(name, {
      name,
      registeredAt: Date.now(),
      ...metadata
    });
    
    console.log(`📝 Registered filter: ${name} (${metadata.category || 'uncategorized'})`);
  }
  
  unregisterFilter(name) {
    const existed = this.filters.delete(name);
    this.filterMetadata.delete(name);
    
    if (existed) {
      console.log(`🗑️ Unregistered filter: ${name}`);
    }
    
    return existed;
  }
  
  async applyFilters(data, options = {}) {
    const startTime = Date.now();
    this.stats.totalProcessed++;
    
    try {
      // Check cache
      const cacheKey = this.generateCacheKey(data, options);
      if (this.processedCache.has(cacheKey)) {
        const cached = this.processedCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTtl) {
          this.stats.cacheHits++;
          console.log(`✅ ${this.MODULE_NAME}: Cache hit for ${cacheKey}`);
          return cached.result;
        } else {
          this.processedCache.delete(cacheKey);
        }
      }
      
      this.stats.cacheMisses++;
      
      // Get filters in priority order
      const filters = this.getFiltersByPriority(options.filters);
      
      // Apply filters sequentially
      let result = this.deepClone(data);
      
      for (const [name, filterFn] of filters) {
        const filterStart = Date.now();
        
        try {
          result = await filterFn(result);
          this.stats.filterApplied++;
          
          const duration = Date.now() - filterStart;
          console.log(`🔧 ${this.MODULE_NAME}: Applied filter "${name}" in ${duration}ms`);
        } catch (filterError) {
          console.error(`❌ ${this.MODULE_NAME}: Filter "${name}" failed:`, filterError);
          if (options.failFast !== false) {
            throw new Error(`Filter "${name}" failed: ${filterError.message}`);
          }
        }
      }
      
      // Cache the result
      this.processedCache.set(cacheKey, {
        result: result,
        timestamp: Date.now(),
        filtersApplied: filters.map(([name]) => name)
      });
      
      // Clean cache if too large
      this.cleanCacheIfNeeded();
      
      const totalDuration = Date.now() - startTime;
      console.log(`✅ ${this.MODULE_NAME}: Processed data in ${totalDuration}ms, applied ${filters.length} filters`);
      
      return result;
      
    } catch (error) {
      this.stats.errors++;
      console.error(`❌ ${this.MODULE_NAME}: Filter application failed:`, error);
      throw error;
    }
  }
  
  getFiltersByPriority(requestedFilters = null) {
    const entries = Array.from(this.filters.entries());
    
    // Sort by priority (highest first)
    entries.sort((a, b) => {
      const metaA = this.filterMetadata.get(a[0]) || { priority: 0 };
      const metaB = this.filterMetadata.get(b[0]) || { priority: 0 };
      return (metaB.priority || 0) - (metaA.priority || 0);
    });
    
    // Filter if specific filters requested
    if (requestedFilters && Array.isArray(requestedFilters)) {
      return entries.filter(([name]) => requestedFilters.includes(name));
    }
    
    return entries;
  }
  
  recursiveFilter(data, filterFn, modifyOriginal = false) {
    const processValue = (value, key = null, parent = null) => {
      // Apply the filter function
      const filtered = filterFn(value, key, parent);
      
      // If filter returns undefined and we're modifying original, delete the key
      if (filtered === undefined && modifyOriginal && parent && key && typeof parent === 'object') {
        delete parent[key];
        return undefined;
      }
      
      // Recursively process nested structures
      if (filtered !== null && typeof filtered === 'object') {
        if (Array.isArray(filtered)) {
          const resultArray = [];
          for (let i = 0; i < filtered.length; i++) {
            const processed = processValue(filtered[i], i, resultArray);
            if (processed !== undefined) {
              resultArray.push(processed);
            }
          }
          return resultArray;
        } else {
          const resultObj = {};
          for (const [k, v] of Object.entries(filtered)) {
            const processed = processValue(v, k, resultObj);
            if (processed !== undefined) {
              resultObj[k] = processed;
            }
          }
          return resultObj;
        }
      }
      
      return filtered;
    };
    
    return processValue(data);
  }
  
  generateCacheKey(data, options) {
    try {
      const dataString = JSON.stringify(data);
      const optionsString = JSON.stringify(options);
      return `cache_${this.hashString(dataString + optionsString)}`;
    } catch {
      // If serialization fails, use timestamp
      return `cache_fallback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
  }
  
  generateItemKey(item) {
    try {
      return JSON.stringify(item);
    } catch {
      return String(item);
    }
  }
  
  hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(36);
  }
  
  deepClone(obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj.getTime());
    if (Array.isArray(obj)) return obj.map(item => this.deepClone(item));
    
    const cloned = {};
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        cloned[key] = this.deepClone(obj[key]);
      }
    }
    return cloned;
  }
  
  startCacheCleanup() {
    setInterval(() => {
      this.cleanExpiredCache();
    }, 60000); // Run every minute
  }
  
  cleanExpiredCache() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, entry] of this.processedCache.entries()) {
      if (now - entry.timestamp > this.cacheTtl) {
        this.processedCache.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      console.log(`🧹 ${this.MODULE_NAME}: Cleaned ${cleaned} expired cache entries`);
    }
  }
  
  cleanCacheIfNeeded() {
    const maxSize = 1000; // Maximum cache entries
    if (this.processedCache.size > maxSize) {
      // Remove oldest entries
      const entries = Array.from(this.processedCache.entries());
      entries.sort((a, b) => a[1].timestamp - b[1].timestamp);
      
      const toRemove = entries.slice(0, this.processedCache.size - maxSize);
      toRemove.forEach(([key]) => this.processedCache.delete(key));
      
      console.log(`📉 ${this.MODULE_NAME}: Cache trimmed, removed ${toRemove.length} old entries`);
    }
  }
  
  getFilterInfo(name = null) {
    if (name) {
      const metadata = this.filterMetadata.get(name);
      const filterFn = this.filters.get(name);
      return {
        exists: !!filterFn,
        metadata: metadata || null,
        registered: !!filterFn
      };
    }
    
    return {
      totalFilters: this.filters.size,
      filters: Array.from(this.filterMetadata.values()),
      stats: { ...this.stats }
    };
  }
  
  getStats() {
    const uptime = Date.now() - this.stats.startTime;
    
    return {
      ...this.stats,
      uptime,
      cacheSize: this.processedCache.size,
      initialized: this.initialized,
      filtersCount: this.filters.size,
      performance: {
        avgProcessingTime: this.stats.totalProcessed > 0 
          ? uptime / this.stats.totalProcessed 
          : 0,
        cacheHitRate: (this.stats.cacheHits + this.stats.cacheMisses) > 0
          ? (this.stats.cacheHits / (this.stats.cacheHits + this.stats.cacheMisses)) * 100
          : 0
      }
    };
  }
  
  clearCache() {
    const size = this.processedCache.size;
    this.processedCache.clear();
    console.log(`🧹 ${this.MODULE_NAME}: Cleared cache (${size} entries removed)`);
    return size;
  }
  
  resetStats() {
    this.stats = {
      totalProcessed: 0,
      filterApplied: 0,
      cacheHits: 0,
      cacheMisses: 0,
      errors: 0,
      startTime: Date.now()
    };
    console.log(`📊 ${this.MODULE_NAME}: Statistics reset`);
  }
  
  healthCheck() {
    return {
      healthy: this.initialized,
      version: this.MODULE_VERSION,
      filters: this.filters.size,
      cache: this.processedCache.size,
      stats: this.getStats(),
      timestamp: Date.now()
    };
  }
}

// Expose for MV3 service worker (importScripts-compatible)
globalThis.SecureFilterManager = SecureFilterManager;