// ============================================================
// MultiFormatExporter.js – SecureMultiFormatExporter (ES6 Module Singleton)
// 14 Principles Compliant - Enhanced Version - PDF DELEGATION FIX
// ============================================================

import PDFExporter from './PDFExporter.js';

export class SecureMultiFormatExporter {
    static #instance = null;
    
    #supportedFormats = new Map();
    #performanceReport = new Map();
    #isInitialized = false;
    #isPDFProOnly = true; // ✅ PDF فقط برای کاربران Pro

    constructor() {
        this.#initializeFormats();
        this.#initializePerformance();
    }

    // ==================== STATIC METHODS ====================

    static async create() {
        if (!this.#instance) {
            this.#instance = new SecureMultiFormatExporter();
            await this.#instance.init();
        }
        return this.#instance;
    }

    static getInstance() {
        console.warn('⚠️ getInstance() is deprecated. Use create() instead.');
        return this.#instance;
    }

    isInitialized() {
        return this.#isInitialized;
    }

    forceInitialized() {
        this.#isInitialized = true;
        console.log('⚠️ MultiFormatExporter forced to initialized state (fallback mode)');
        return true;
    }

    // ==================== PRIVATE METHODS ====================

    #initializeFormats() {
        // ✅ تغییر: TXT اولین فرمت در لیست
        this.#supportedFormats.set('TXT', 'text/plain');
        this.#supportedFormats.set('JSON', 'application/json');
        this.#supportedFormats.set('CSV', 'text/csv');
        this.#supportedFormats.set('HTML', 'text/html');
        this.#supportedFormats.set('PDF', 'application/pdf');
    }

    #initializePerformance() {
        this.#performanceReport.set('summary', {
            exportsCompleted: 0,
            exportsFailed: 0,
            totalExports: 0
        });
        
        this.#performanceReport.set('logs', []);
        this.#performanceReport.set('metrics', {
            startTime: Date.now(),
            lastExport: null,
            avgExportSize: 0
        });
    }

    #logExport(format, success, error = null) {
        const logEntry = {
            format,
            timestamp: Date.now(),
            success,
            error: success ? null : error
        };

        const logs = this.#performanceReport.get('logs');
        logs.push(logEntry);
        
        if (logs.length > 100) {
            logs.shift();
        }

        const summary = this.#performanceReport.get('summary');
        if (success) {
            summary.exportsCompleted++;
        } else {
            summary.exportsFailed++;
        }
        summary.totalExports++;

        const metrics = this.#performanceReport.get('metrics');
        metrics.lastExport = Date.now();
    }

    #generateJSON(data, options = {}) {
        try {
            const content = JSON.stringify(data, null, 2);
            const filename = options.filename || `export_${Date.now()}.json`;
            
            return { 
                success: true, 
                content, 
                filename, 
                format: 'JSON',
                size: content.length,
                timestamp: Date.now()
            };
        } catch (error) {
            return { 
                success: false, 
                error: error.message,
                timestamp: Date.now()
            };
        }
    }

    #generateCSV(data, options = {}) {
        try {
            const rows = [];
            
            const flatten = (obj, prefix = '') => {
                const result = {};
                for (let k in obj) {
                    if (obj.hasOwnProperty(k)) {
                        const value = obj[k];
                        if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                            Object.assign(result, flatten(value, prefix + k + '.'));
                        } else {
                            result[prefix + k] = value;
                        }
                    }
                }
                return result;
            };

            const items = Array.isArray(data) ? data : [data];
            
            if (items.length === 0) {
                return { 
                    success: false, 
                    error: 'No data to export',
                    timestamp: Date.now()
                };
            }

            const header = Object.keys(flatten(items[0]));
            rows.push(header.join(','));
            
            items.forEach(item => {
                const flatItem = flatten(item);
                const row = header.map(h => {
                    const value = flatItem[h] ?? '';
                    const escaped = String(value).replace(/"/g, '""');
                    return `"${escaped}"`;
                }).join(',');
                rows.push(row);
            });
            
            const content = rows.join('\n');
            const filename = options.filename || `export_${Date.now()}.csv`;
            
            return { 
                success: true, 
                content, 
                filename, 
                format: 'CSV',
                size: content.length,
                timestamp: Date.now()
            };
        } catch (error) {
            return { 
                success: false, 
                error: error.message,
                timestamp: Date.now()
            };
        }
    }

    #generateTXT(data, options = {}) {
        try {
            console.log('📝 [TXT] Starting TXT export with data length:', 
                Array.isArray(data) ? data.length : 1);
            
            let content = '';
            
            if (Array.isArray(data)) {
                // ✅ منطق اختصاصی برای TXT
                data.forEach((item, index) => {
                    content += `=== Entry ${index + 1} ===\n`;
                    content += `Timestamp: ${new Date(item.timestamp || Date.now()).toISOString()}\n`;
                    
                    if (item.platform) {
                        content += `Platform: ${item.platform}\n`;
                    }
                    
                    if (item.content) {
                        content += `Content:\n${item.content}\n`;
                    }
                    
                    if (item.metadata) {
                        content += `Metadata: ${JSON.stringify(item.metadata, null, 2)}\n`;
                    }
                    
                    content += '\n'.repeat(2);
                });
                
                if (content === '') {
                    content = 'No data available for export.\n';
                }
            } else if (typeof data === 'object' && data !== null) {
                // ✅ برای آبجکت تک
                content = `=== Single Export ===\n`;
                for (const [key, value] of Object.entries(data)) {
                    content += `${key}: ${JSON.stringify(value, null, 2)}\n`;
                }
            } else if (typeof data === 'string') {
                content = data;
            } else {
                content = String(data);
            }
            
            const filename = options.filename || `export_${Date.now()}.txt`;
            
            console.log('✅ [TXT] Export completed, size:', content.length, 'bytes');
            
            return { 
                success: true, 
                content, 
                filename, 
                format: 'TXT',
                size: content.length,
                timestamp: Date.now()
            };
        } catch (error) {
            console.error('❌ [TXT] Export failed:', error);
            return { 
                success: false, 
                error: error.message,
                timestamp: Date.now()
            };
        }
    }

    #generateHTML(data, options = {}) {
        try {
            const content = `
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatSavePro – خروجی گفتگو</title>
    <style>
        /* ==================== HARD CSS RESET ==================== */
        html, body {
            width: 100%;
            margin: 0;
            padding: 0;
        }
        
        body {
            all: unset;
            direction: rtl;
            background: #ffffff;
            color: #333333;
            font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif;
            width: 100%;
            min-height: 100vh;
        }
        
        .page {
            min-width: 100%;
            padding: 24px 32px;
            box-sizing: border-box;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* ==================== REST OF STYLES ==================== */
        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        .header { 
            background: linear-gradient(135deg, #4a6fa5 0%, #2c4a7a 100%);
            color: white; 
            padding: 30px; 
            border-radius: 12px;
            margin-bottom: 30px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .edition {
            font-size: 13px;
            opacity: 0.8;
            margin-top: 6px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .warning-box {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin: 30px 0;
            color: #856404;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            width: 100%;
        }
        
        .conversation { 
            width: 100%;
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
            border: 1px solid #e9ecef;
        }
        
        .conversation-header {
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        
        .conversation-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .conversation-info {
            font-size: 13px;
            color: #6c757d;
        }
        
        .conversation-platform {
            display: inline-block;
            background: #e9ecef;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: #495057;
            margin-top: 5px;
        }
        
        .message {
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 10px;
            background: #f8f9fa;
            border-left: 4px solid #4a6fa5;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 8px;
            border-bottom: 1px solid #dee2e6;
        }
        
        .message-sender {
            font-weight: 600;
            color: #2c3e50;
            font-size: 14px;
        }
        
        .message-time {
            font-size: 12px;
            color: #6c757d;
        }
        
        .message-content {
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 14px;
            line-height: 1.7;
            color: #495057;
        }
        
        .metadata-section {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }
        
        .metadata-title {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 14px;
        }
        
        .metadata-content {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            font-size: 13px;
            color: #6c757d;
            white-space: pre-wrap;
            font-family: monospace;
        }
        
        .footer {
            text-align: center;
            padding: 25px;
            margin-top: 40px;
            border-top: 1px solid #dee2e6;
            color: #6c757d;
            font-size: 13px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            width: 100%;
        }
        
        .export-info {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .export-item {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .export-label {
            font-size: 11px;
            color: #adb5bd;
            margin-bottom: 3px;
        }
        
        .export-value {
            font-weight: 600;
            color: #4a6fa5;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-muted {
            color: #6c757d;
        }
        
        .mb-10 {
            margin-bottom: 10px;
        }
        
        .mb-20 {
            margin-bottom: 20px;
        }
        
        h2 {
            font-size: 24px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            width: 100%;
        }
        
        #conversations-container {
            width: 100%;
        }
        
        @media (max-width: 768px) {
            .page {
                padding: 12px 16px;
            }
            
            .header {
                padding: 20px;
                margin-bottom: 20px;
            }
            
            .header h1 {
                font-size: 22px;
            }
            
            .conversation {
                padding: 15px;
                margin-bottom: 20px;
            }
            
            .message {
                padding: 12px;
            }
            
            .warning-box {
                padding: 15px;
                margin: 20px 0;
            }
            
            .export-info {
                gap: 15px;
            }
            
            h2 {
                font-size: 20px;
                margin-bottom: 15px;
            }
        }
        
        @media print {
            body {
                background: white !important;
                padding: 0 !important;
            }
            
            .page {
                padding: 0;
                max-width: 100%;
            }
            
            .header {
                box-shadow: none !important;
                border: 1px solid #dee2e6;
            }
            
            .conversation {
                box-shadow: none !important;
                border: 1px solid #dee2e6;
                page-break-inside: avoid;
            }
            
            .warning-box {
                display: none;
            }
            
            .footer {
                box-shadow: none !important;
                border: 1px solid #dee2e6;
            }
        }
    </style>
</head>

<body>
    <div class="page">
        <div class="header">
            <h1>ChatSavePro – خروجی گفتگو</h1>
            <p class="edition">Free Edition – Local HTML Export</p>
        </div>
        
        <div class="warning-box">
            ⚠️ این فایل فقط برای استفاده محلی و شخصی تولید شده است.<br>
            پردازش کاملاً روی دستگاه شما انجام می‌شود و هیچ داده‌ای ارسال نمی‌گردد.
        </div>
        
        <h2 class="text-center mb-20">مکالمه‌های ذخیره شده</h2>
        
        <div id="conversations-container">
            ${Array.isArray(data) ? 
                data.map((item, index) => {
                    const timestamp = item.timestamp || Date.now();
                    const platform = item.platform || 'نامشخص';
                    const content = item.content || '';
                    const metadata = item.metadata || {};
                    
                    let messagesHtml = '';
                    if (content) {
                        messagesHtml = `
                                <div class="message">
                                    <div class="message-header">
                                        <span class="message-sender">متن مکالمه</span>
                                        <span class="message-time">${new Date(timestamp).toLocaleString('fa-IR')}</span>
                                    </div>
                                    <div class="message-content">${content.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>')}</div>
                                </div>
                            `;
                    }
                    
                    let metadataHtml = '';
                    if (Object.keys(metadata).length > 0) {
                        metadataHtml = `
                                <div class="metadata-section">
                                    <div class="metadata-title">اطلاعات اضافی:</div>
                                    <pre class="metadata-content">${JSON.stringify(metadata, null, 2).replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
                                </div>
                            `;
                    }
                    
                    return `
                            <div class="conversation">
                                <div class="conversation-header">
                                    <div class="conversation-title">مکالمه ${(index + 1).toLocaleString('fa-IR')}</div>
                                    <div class="conversation-info">
                                        تاریخ: ${new Date(timestamp).toLocaleString('fa-IR')}
                                    </div>
                                    <div class="conversation-platform">${platform}</div>
                                </div>
                                ${messagesHtml}
                                ${metadataHtml}
                            </div>
                        `;
                }).join('') : 
                `
                <div class="conversation">
                    <div class="conversation-header">
                        <div class="conversation-title">مکالمه ۱</div>
                        <div class="conversation-info">
                            تاریخ: ${new Date().toLocaleString('fa-IR')}
                        </div>
                    </div>
                    <div class="message">
                        <div class="message-header">
                            <span class="message-sender">اطلاعات</span>
                            <span class="message-time">${new Date().toLocaleString('fa-IR')}</span>
                        </div>
                        <div class="message-content">
                            <pre>${JSON.stringify(data, null, 2).replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
                        </div>
                    </div>
                </div>
                `
            }
        </div>
        
        <div class="footer">
            <div class="export-info">
                <div class="export-item">
                    <span class="export-label">تاریخ تولید</span>
                    <span class="export-value">${new Date().toLocaleString('fa-IR')}</span>
                </div>
                <div class="export-item">
                    <span class="export-label">تعداد مکالمه</span>
                    <span class="export-value">${Array.isArray(data) ? data.length.toLocaleString('fa-IR') : '۱'}</span>
                </div>
                <div class="export-item">
                    <span class="export-label">فرمت</span>
                    <span class="export-value">HTML</span>
                </div>
                <div class="export-item">
                    <span class="export-label">نسخه</span>
                    <span class="export-value">رایگان</span>
                </div>
            </div>
            <p class="text-muted mb-10">ChatSavePro – نسخه رایگان | خروجی محلی و ایمن</p>
            <p class="text-muted" style="font-size: 11px;">تولید شده توسط ChatSavePro • تمام حقوق محفوظ است</p>
        </div>
    </div>
</body>
</html>`;
            const filename = options.filename || `chatsave_export_${Date.now()}.html`;
            
            console.log('✅ [HTML] Export completed');
            
            return { 
                success: true, 
                content, 
                filename, 
                format: 'HTML',
                size: content.length,
                timestamp: Date.now()
            };
        } catch (error) {
            console.error('❌ [HTML] Export failed:', error);
            return { 
                success: false, 
                error: error.message,
                timestamp: Date.now()
            };
        }
    }

    #validateFormat(format) {
        const upperFormat = format.toUpperCase();
        
        if (!this.#supportedFormats.has(upperFormat)) {
            throw new Error(`Unsupported format: ${format}. Supported formats: ${Array.from(this.#supportedFormats.keys()).join(', ')}`);
        }
        
        // ✅ بررسی PDF Pro-only
        if (upperFormat === 'PDF' && this.#isPDFProOnly) {
            throw new Error('PDF export is only available in the Pro version. Please upgrade to access PDF export features.');
        }
        
        return true;
    }

    #validateData(data) {
        if (!data || (Array.isArray(data) && data.length === 0)) {
            throw new Error('No data provided for export');
        }
        return true;
    }

    #sanitizeData(data) {
        try {
            if (typeof data === 'string') {
                return data.substring(0, 1000000);
            }
            
            if (Array.isArray(data)) {
                return data.slice(0, 10000);
            }
            
            if (typeof data === 'object' && data !== null) {
                const sanitized = {};
                for (const [key, value] of Object.entries(data)) {
                    if (typeof key === 'string' && key.length <= 100) {
                        sanitized[key] = this.#sanitizeData(value);
                    }
                }
                return sanitized;
            }
            
            return data;
        } catch (error) {
            console.warn('⚠️ Data sanitization failed, using fallback:', error.message);
            return { error: 'Data sanitization failed', originalData: 'REDACTED' };
        }
    }

    // ==================== PUBLIC METHODS ====================

    async init() {
        if (this.#isInitialized) return true;

        try {
            if (typeof chrome === 'undefined') {
                throw new Error('Chrome extension environment not detected');
            }

            this.#isInitialized = true;
            console.log('✅ SecureMultiFormatExporter initialized');
            console.log('📁 Supported formats:', Array.from(this.#supportedFormats.keys()));
            console.log('🔒 PDF Pro-only:', this.#isPDFProOnly);
            
            return true;
        } catch (error) {
            console.error('❌ SecureMultiFormatExporter initialization failed:', error);
            throw error;
        }
    }

    getSupportedFormats() {
        const formats = Object.fromEntries(this.#supportedFormats);
        // ✅ اضافه کردن flag برای PDF
        formats.PDF_IS_PRO_ONLY = this.#isPDFProOnly;
        return formats;
    }

    getPerformanceReport() {
        const summary = this.#performanceReport.get('summary');
        const metrics = this.#performanceReport.get('metrics');
        const logs = this.#performanceReport.get('logs');
        
        return {
            summary: { ...summary },
            metrics: { ...metrics },
            recentLogs: logs.slice(-10),
            efficiency: summary.totalExports > 0 ? 
                (summary.exportsCompleted / summary.totalExports) * 100 : 100,
            avgSizeMB: metrics.avgExportSize,
            timestamp: Date.now()
        };
    }

    async export(data, format = 'TXT', scope = 'current') {
        try {
            console.log('📤 [MultiFormatExporter] Starting export:', { format, scope });

            if (!this.#isInitialized) {
                await this.init();
            }

            this.#validateFormat(format);
            
            let exportData = data;
            if (!exportData) {
                exportData = await this.#getDataFromStorage(scope);
            }

            this.#validateData(exportData);

            const sanitizedData = this.#sanitizeData(exportData);

            // PDF CASE - DELEGATE TO PDFExporter (only if user is Pro)
            if (format.toUpperCase() === 'PDF') {
                // ✅ جلوگیری از اجرای PDF برای کاربران Free
                throw new Error('PDF export is only available in the Pro version. Please upgrade to access PDF export features.');
            }

            // OTHER FORMATS (TXT/JSON/CSV/HTML)
            let result;
            const upperFormat = format.toUpperCase();
            
            switch (upperFormat) {
                case 'TXT':
                    result = this.#generateTXT(sanitizedData, { scope });
                    break;
                case 'JSON':
                    result = this.#generateJSON(sanitizedData, { scope });
                    break;
                case 'CSV':
                    result = this.#generateCSV(sanitizedData, { scope });
                    break;
                case 'HTML':
                    result = this.#generateHTML(sanitizedData, { scope });
                    break;
                default:
                    throw new Error(`Format handler not implemented: ${format}`);
            }

            this.#logExport(format, result.success, result.error);

            if (result.success) {
                const downloadResult = await this.#downloadFile(
                    result.content, 
                    result.filename, 
                    this.#supportedFormats.get(upperFormat)
                );

                return {
                    success: true,
                    format: result.format,
                    filename: result.filename,
                    size: result.size,
                    downloadId: downloadResult.downloadId,
                    timestamp: result.timestamp,
                    scope: scope
                };
            } else {
                return {
                    success: false,
                    error: result.error,
                    format: format,
                    timestamp: result.timestamp,
                    scope: scope
                };
            }

        } catch (error) {
            console.error('❌ Export failed:', error);
            
            this.#logExport(format, false, error.message);
            
            return {
                success: false,
                error: error.message,
                format: format,
                timestamp: Date.now(),
                scope: scope
            };
        }
    }

    async exportSelected(format, data, options = {}) {
        try {
            this.#validateFormat(format);
            this.#validateData(data);

            if (format.toUpperCase() === 'PDF') {
                throw new Error('PDF export is only available in the Pro version. Please upgrade to access PDF export features.');
            }

            let result;
            const upperFormat = format.toUpperCase();

            switch (upperFormat) {
                case 'TXT':
                    result = this.#generateTXT(data, options);
                    break;
                case 'JSON':
                    result = this.#generateJSON(data, options);
                    break;
                case 'CSV':
                    result = this.#generateCSV(data, options);
                    break;
                case 'HTML':
                    result = this.#generateHTML(data, options);
                    break;
                default:
                    throw new Error(`Format handler not implemented: ${format}`);
            }

            this.#logExport(format, result.success, result.error);

            if (result.success) {
                await this.#downloadFile(result.content, result.filename, this.#supportedFormats.get(upperFormat));
            }

            return result;

        } catch (error) {
            this.#logExport(format, false, error.message);
            return { 
                success: false, 
                error: error.message,
                timestamp: Date.now()
            };
        }
    }

    async exportAsTXT(data, options = {}) {
        return await this.exportSelected('TXT', data, options);
    }

    async exportAsJSON(data, options = {}) {
        return await this.exportSelected('JSON', data, options);
    }

    async exportAsCSV(data, options = {}) {
        return await this.exportSelected('CSV', data, options);
    }

    async handleExport(format, data = null, options = {}) {
        if (!data) {
            data = await this.#getDataFromStorage(options.scope || 'current');
        }
        
        return await this.export(data, format, options.scope);
    }

    // ==================== UTILITY METHODS ====================

    async #downloadFile(content, filename, mimeType) {
        return new Promise((resolve, reject) => {
            try {
                const blob = new Blob([content], { type: mimeType });
                const url = URL.createObjectURL(blob);
                
                chrome.downloads.download({
                    url: url,
                    filename: filename,
                    saveAs: true
                }, (downloadId) => {
                    URL.revokeObjectURL(url);
                    
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve({ 
                            success: true, 
                            downloadId,
                            filename,
                            size: content.length,
                            timestamp: Date.now()
                        });
                    }
                });
                
            } catch (error) {
                reject(error);
            }
        });
    }

    async #getDataFromStorage(scope = 'current') {
        return new Promise((resolve) => {
            const keys = ['scanResults', 'exportData', 'sessionData'];
            
            chrome.storage.local.get(keys, (result) => {
                let data = [];
                
                if (scope === 'current' && result.scanResults) {
                    data = result.scanResults;
                } else if (scope === 'all' && result.exportData) {
                    data = result.exportData;
                } else if (result.sessionData) {
                    data = result.sessionData;
                }
                
                resolve(data || []);
            });
        });
    }

    async healthCheck() {
        return {
            status: this.#isInitialized ? 'healthy' : 'not_initialized',
            supportedFormats: Array.from(this.#supportedFormats.keys()),
            pdfProOnly: this.#isPDFProOnly,
            performance: this.getPerformanceReport(),
            timestamp: Date.now(),
            version: '3.9'
        };
    }

    async cleanup() {
        this.#performanceReport.clear();
        this.#isInitialized = false;
        console.log('✅ SecureMultiFormatExporter cleanup completed');
        
        return {
            success: true,
            message: 'Cleanup completed',
            timestamp: Date.now()
        };
    }
}

// ============================================================
// EXPORT FOR GUARDIAN SERVICE WORKER (MV3 Compatible)
// ============================================================

let MultiFormatExporterInstance = null;

(async () => {
    try {
        MultiFormatExporterInstance = await SecureMultiFormatExporter.create();
        
        if (typeof self !== 'undefined') {
            self.MultiFormatExporter = MultiFormatExporterInstance;
            console.log('✅ SecureMultiFormatExporter registered under self.MultiFormatExporter');
        }
    } catch (error) {
        console.error('❌ Failed to initialize MultiFormatExporter:', error);
        
        MultiFormatExporterInstance = new SecureMultiFormatExporter();
        
        try {
            MultiFormatExporterInstance.forceInitialized();
        } catch (fallbackError) {
            console.error('❌ Fallback initialization failed:', fallbackError);
        }
        
        if (typeof self !== 'undefined') {
            self.MultiFormatExporter = MultiFormatExporterInstance;
            console.log('⚠️ MultiFormatExporter running in fallback mode');
        }
    }
})();

export default SecureMultiFormatExporter;
export { MultiFormatExporterInstance };