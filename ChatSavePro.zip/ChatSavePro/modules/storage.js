// ============================================================
// modules/storage.js — QuantumStage v3.9 (Performance Analytics Integration)
// ============================================================
// ⚙️ Version: R9.9.0
// Storage Core integrated with EventBus + GuardianIntegrity
// ============================================================

import { EventBus } from './EventBus.js';
import GuardianIntegrity from './GuardianIntegrity.js';

export class StorageManager {
    constructor() {
        this.MODULE_NAME = 'StorageManager';
        this.MODULE_VERSION = 'R9.9.0';

        this.eventBus = null;
        this.guardian = null;
        this.cache = new Map();
        this.health = {
            lastCheck: null,
            totalItems: 0,
            totalSize: 0,
            averageItemSize: 0,
            lastError: null,
            status: 'INITIALIZING'
        };

        this.logger = new StorageLogger();
        this.initialized = false;
    }

    async init(eventBusInstance, guardianInstance) {
        try {
            if (this.initialized) return true;

            this.eventBus = eventBusInstance || new EventBus();
            this.guardian = guardianInstance || GuardianIntegrity.getInstance();

            await this._loadExisting();
            this.health.status = 'READY';
            this.initialized = true;

            this.logger.log('INFO', 'StorageManager initialized', {
                version: this.MODULE_VERSION
            });

            if (this.eventBus) {
                this.eventBus.dispatchSystemEvent('STORAGE_READY', { version: this.MODULE_VERSION });
            }

            return true;
        } catch (err) {
            this.logger.log('ERROR', 'Initialization failed', { error: err.message });
            this.health.lastError = err.message;
            this.health.status = 'FAILURE';
            return false;
        }
    }

    // ==================== BASIC STORAGE OPERATIONS ====================
    async setItem(key, value) {
        try {
            const payload = {
                key,
                value,
                signature: `sig_storage_${Date.now()}`
            };

            // Validate signature if Guardian is active
            if (this.guardian) {
                this.guardian.verifyMessageSignature(this.MODULE_NAME, payload);
            }

            const stringified = JSON.stringify(value);
            const size = new Blob([stringified]).size;

            await chrome.storage.local.set({ [key]: value });
            this.cache.set(key, { value, size, timestamp: Date.now() });

            this.health.totalItems = this.cache.size;
            this.health.totalSize += size;
            this.health.averageItemSize = this.health.totalSize / this.health.totalItems;

            if (this.eventBus) {
                this.eventBus.dispatchSystemEvent('STORAGE_ITEM_SET', { key });
            }

            return { success: true, key, size };
        } catch (error) {
            this.logger.log('ERROR', 'setItem failed', { key, error: error.message });
            if (this.guardian) this.guardian.recordFailure(this.MODULE_NAME, error);
            return { success: false, error: error.message };
        }
    }

    async getItem(key) {
        try {
            const fromCache = this.cache.get(key);
            if (fromCache) return fromCache.value;

            const result = await new Promise((resolve) => {
                chrome.storage.local.get([key], (data) => resolve(data[key]));
            });

            if (!result) return null;

            const size = new Blob([JSON.stringify(result)]).size;
            this.cache.set(key, { value: result, size, timestamp: Date.now() });

            return result;
        } catch (error) {
            this.logger.log('ERROR', 'getItem failed', { key, error: error.message });
            if (this.guardian) this.guardian.recordFailure(this.MODULE_NAME, error);
            return null;
        }
    }

    async removeItem(key) {
        try {
            await chrome.storage.local.remove([key]);
            this.cache.delete(key);
            this.health.totalItems = this.cache.size;

            if (this.eventBus) {
                this.eventBus.dispatchSystemEvent('STORAGE_ITEM_REMOVED', { key });
            }

            return true;
        } catch (error) {
            this.logger.log('ERROR', 'removeItem failed', { key, error: error.message });
            if (this.guardian) this.guardian.recordFailure(this.MODULE_NAME, error);
            return false;
        }
    }

    async clear() {
        try {
            await chrome.storage.local.clear();
            this.cache.clear();
            this.health.totalItems = 0;
            this.health.totalSize = 0;
            this.health.averageItemSize = 0;

            if (this.eventBus) {
                this.eventBus.dispatchSystemEvent('STORAGE_CLEARED', { source: this.MODULE_NAME });
            }
            return true;
        } catch (error) {
            this.logger.log('ERROR', 'clear failed', { error: error.message });
            if (this.guardian) this.guardian.recordFailure(this.MODULE_NAME, error);
            return false;
        }
    }

    async _loadExisting() {
        return new Promise((resolve) => {
            chrome.storage.local.get(null, (items) => {
                for (const [key, value] of Object.entries(items)) {
                    const size = new Blob([JSON.stringify(value)]).size;
                    this.cache.set(key, { value, size, timestamp: Date.now() });
                }
                this.health.totalItems = this.cache.size;
                this.health.totalSize = Array.from(this.cache.values()).reduce((sum, i) => sum + i.size, 0);
                this.health.averageItemSize = this.health.totalItems > 0
                    ? this.health.totalSize / this.health.totalItems
                    : 0;
                resolve();
            });
        });
    }

    // ==================== HEALTH & SELF‑RECOVERY ====================
    getStorageHealth(reportOptions = {}) {
        const healthReport = {
            timestamp: Date.now(),
            totalItems: this.health.totalItems,
            totalSize: this.health.totalSize,
            averageItemSize: this.health.averageItemSize,
            cacheSync: this.cache.size,
            status: this.health.status,
            lastError: this.health.lastError,
            chromeStorageAvailable: !!chrome.storage?.local
        };

        if (reportOptions.verbose) {
            healthReport.cacheKeys = Array.from(this.cache.keys());
        }

        if (this.eventBus) {
            this.eventBus.dispatchSystemEvent('STORAGE_HEALTH_UPDATE', healthReport);
        }

        return healthReport;
    }

    async selfRecover() {
        try {
            this.logger.log('WARN', 'Self-recovery triggered');
            await this._loadExisting();
            this.health.status = 'HEALTHY';
            if (this.eventBus) this.eventBus.dispatchSystemEvent('STORAGE_RECOVERED', {});
        } catch (err) {
            this.logger.log('ERROR', 'Self-recovery failed', { error: err.message });
            this.health.status = 'DEGRADED';
            this.health.lastError = err.message;
        }
    }

    cleanup() {
        this.cache.clear();
        this.health.status = 'CLEAN';
        this.logger.log('INFO', 'StorageManager cleaned up');
    }
}

// =======================================
// 🔸 Helper Class: Logger
// =======================================
class StorageLogger {
    constructor() {
        this.logs = [];
        this.limit = 50;
    }

    log(level, message, data = {}) {
        const entry = { level, message, data, timestamp: Date.now() };
        this.logs.push(entry);
        if (this.logs.length > this.limit) this.logs.shift();

        console[level === 'ERROR' ? 'error' : 'log'](`[StorageManager][${level}] ${message}`, data);
    }

    getLogs(limit = 10) {
        return this.logs.slice(-limit);
    }
}

export default StorageManager;

// ============================================================
// ✅ Ready Log for QuantumStage v3.9
// ============================================================
console.log('✅ StorageManager v3.9 (R9EventBus + GuardianIntegration) loaded');
