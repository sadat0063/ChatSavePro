// File: modules/animation-manager.js
// ============================================================
// ES6 Module Version - Guardian Principles 10 & 11 Compliant
// ============================================================

export class AnimationManager {
    constructor() {
        this.animations = new Map();
        this.defaultDuration = 300;
        
        // 🛡️ اصل ۱۰: Audit & Traceability - Enhanced monitoring
        this.monitoring = {
            totalAnimations: 0,
            activeAnimations: 0,
            completedAnimations: 0,
            cancelledAnimations: 0,
            errorCount: 0,
            averageDuration: 0,
            performanceIssues: 0,
            lastAnimationTime: null,
            startupTime: Date.now()
        };
        
        // 🛡️ اصل ۱۱: Inter-Module Integrity - Immutable configurations
        this.animationPresets = Object.freeze({
            fadeIn: Object.freeze({ type: 'fade', direction: 'in', duration: 300 }),
            fadeOut: Object.freeze({ type: 'fade', direction: 'out', duration: 300 }),
            slideDown: Object.freeze({ type: 'slide', direction: 'down', duration: 400 }),
            slideUp: Object.freeze({ type: 'slide', direction: 'up', duration: 400 }),
            bounce: Object.freeze({ type: 'bounce', duration: 600 }),
            shake: Object.freeze({ type: 'shake', duration: 500 }),
            pulse: Object.freeze({ type: 'pulse', duration: 1000 }),
            zoomIn: Object.freeze({ type: 'zoom', direction: 'in', duration: 300 }),
            zoomOut: Object.freeze({ type: 'zoom', direction: 'out', duration: 300 })
        });

        this.animationHistory = [];
        this.maxAnimationHistory = 50;
        this.animationTimeouts = new Map();
        
        // Queue management
        this.animationQueue = Object.freeze({
            tasks: [],
            isProcessing: false,
            maxQueueSize: 20,
            throttleDelay: 16
        });

        // Performance metrics
        this.performance = Object.freeze({
            rafSupported: !!window.requestAnimationFrame,
            cssTransitionsSupported: this.checkCSSTransitionsSupport(),
            cssAnimationsSupported: this.checkCSSAnimationsSupport(),
            prefersReducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches
        });

        this.cleanupInterval = null;
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity - Controlled initialization
    static async init(config = {}) {
        const instance = new AnimationManager();
        await instance._initialize(config);
        
        // فریز کردن برای اصل ۱۱
        Object.freeze(instance.animationPresets);
        Object.freeze(instance.performance);
        
        console.log('✅ AnimationManager ES6 Module loaded successfully');
        return instance;
    }

    async _initialize(config = {}) {
        try {
            await this.waitForDOM();
            this.setupCleanupInterval();
            this.setupReducedMotionListener();
            
            // اعمال تنظیمات
            if (config.defaultDuration) {
                this.defaultDuration = config.defaultDuration;
            }

            console.log('[AnimationManager][INFO] AnimationManager initialized successfully', {
                defaultDuration: this.defaultDuration,
                supportedFeatures: this.performance,
                reducedMotion: this.performance.prefersReducedMotion,
                config: config
            });
            
            return this;
        } catch (error) {
            console.error('[AnimationManager][ERROR] Initialization failed', error);
            this.monitoring.errorCount++;
            throw error;
        }
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Comprehensive metrics
    getMetrics() {
        const totalDuration = this.monitoring.averageDuration * this.monitoring.completedAnimations;
        const successRate = this.monitoring.totalAnimations > 0 ? 
            (this.monitoring.completedAnimations / this.monitoring.totalAnimations) : 1;
        const cancellationRate = this.monitoring.totalAnimations > 0 ? 
            (this.monitoring.cancelledAnimations / this.monitoring.totalAnimations) : 0;

        return Object.freeze({
            system: Object.freeze({
                version: '2.0.0-guardian',
                uptime: Date.now() - this.monitoring.startupTime,
                isInitialized: true,
                healthScore: this._calculateHealthScore()
            }),
            performance: Object.freeze({
                totalAnimations: this.monitoring.totalAnimations,
                activeAnimations: this.monitoring.activeAnimations,
                completedAnimations: this.monitoring.completedAnimations,
                cancelledAnimations: this.monitoring.cancelledAnimations,
                errorCount: this.monitoring.errorCount,
                averageDuration: Math.round(this.monitoring.averageDuration),
                successRate: Math.round(successRate * 100) + '%',
                cancellationRate: Math.round(cancellationRate * 100) + '%',
                totalOperationTime: Math.round(totalDuration),
                lastAnimationTime: this.monitoring.lastAnimationTime
            }),
            resources: Object.freeze({
                queueSize: this.animationQueue.tasks.length,
                maxQueueSize: this.animationQueue.maxQueueSize,
                activeAnimationElements: this.animations.size,
                pendingTimeouts: this.animationTimeouts.size,
                historySize: this.animationHistory.length,
                maxHistorySize: this.maxAnimationHistory
            }),
            capabilities: Object.freeze({
                rafSupported: this.performance.rafSupported,
                cssTransitionsSupported: this.performance.cssTransitionsSupported,
                cssAnimationsSupported: this.performance.cssAnimationsSupported,
                prefersReducedMotion: this.performance.prefersReducedMotion,
                availablePresets: Object.keys(this.animationPresets).length
            }),
            history: Object.freeze({
                recentAnimations: this.animationHistory.slice(-5).map(anim => 
                    Object.freeze({
                        type: anim.type,
                        duration: anim.duration,
                        element: anim.element,
                        timestamp: anim.endTime
                    })
                )
            })
        });
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Health monitoring
    _calculateHealthScore() {
        let score = 100;
        
        // کسر برای خطاها
        if (this.monitoring.errorCount > 0) {
            score -= Math.min(30, this.monitoring.errorCount * 5);
        }
        
        // کسر برای مشکلات صف
        if (this.animationQueue.tasks.length > this.animationQueue.maxQueueSize * 0.8) {
            score -= 20;
        }
        
        // کسر برای مشکلات عملکرد
        if (this.monitoring.averageDuration > 1000) {
            score -= 15;
        }
        
        // کسر برای انیمیشن‌های فعال زیاد
        if (this.animations.size > 10) {
            score -= 10;
        }
        
        return Math.max(0, Math.round(score));
    }

    // 🛡️ اصل ۱۰: Audit & Traceability - Self-test
    async runIntegrityCheck() {
        const testResults = {
            timestamp: Date.now(),
            passed: true,
            checks: {}
        };
        
        try {
            // بررسی اولیه
            testResults.checks.initialization = this.monitoring.startupTime > 0;
            testResults.checks.metricsAvailable = typeof this.getMetrics === 'function';
            testResults.checks.performanceMetrics = this.performance.rafSupported !== undefined;
            
            // بررسی ساختار داده‌ها
            testResults.checks.animationsMap = this.animations instanceof Map;
            testResults.checks.presetsFrozen = Object.isFrozen(this.animationPresets);
            testResults.checks.performanceFrozen = Object.isFrozen(this.performance);
            
            // بررسی عملکرد
            const metrics = this.getMetrics();
            testResults.checks.metricsStructure = 
                metrics.system && metrics.performance && metrics.resources;
            testResults.checks.healthScore = metrics.system.healthScore >= 0;
            
            testResults.passed = Object.values(testResults.checks).every(check => check === true);
            
            console.log('[AnimationManager][INFO] Integrity check completed', testResults);
            return Object.freeze(testResults);
            
        } catch (error) {
            console.error('[AnimationManager][ERROR] Integrity check failed', error);
            testResults.passed = false;
            testResults.error = error.message;
            return Object.freeze(testResults);
        }
    }

    // 🛡️ اصل ۱۱: Inter-Module Integrity - Safe destruction
    async destroy() {
        // متوقف کردن intervalهای فعال
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
        }
        
        // لغو تمام انیمیشن‌های در حال اجرا
        this.animations.forEach((_, element) => {
            this.cancelAnimations(element);
        });
        this.animations.clear();
        
        // پاک‌سازی timeoutها
        this.animationTimeouts.forEach((timeout) => {
            clearTimeout(timeout);
        });
        this.animationTimeouts.clear();
        
        // پاک‌سازی صف
        this.animationQueue.tasks.length = 0;
        this.animationQueue.isProcessing = false;
        
        // حذف event listenerها
        if (this.motionPreferenceHandler) {
            const motionMediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
            motionMediaQuery.removeEventListener('change', this.motionPreferenceHandler);
            this.motionPreferenceHandler = null;
        }
        
        const finalMetrics = this.getMetrics();
        
        console.log('[AnimationManager][INFO] AnimationManager destroyed', {
            finalMetrics: finalMetrics.performance,
            totalUptime: finalMetrics.system.uptime,
            finalHealthScore: finalMetrics.system.healthScore
        });

        return Object.freeze({
            destroyed: true,
            timestamp: Date.now(),
            finalMetrics: finalMetrics
        });
    }

    // سایر متدهای موجود (fadeIn, fadeOut, slideDown, etc.) بدون تغییر باقی می‌مانند
    // اما باید از Object.freeze در خروجی‌ها استفاده شود

    fadeIn(element, duration = this.defaultDuration) {
        return this.queueAnimation(async () => {
            const startTime = performance.now();
            this.monitoring.totalAnimations++;
            this.monitoring.activeAnimations++;
            
            try {
                // اجرای انیمیشن...
                // پس از اتمام:
                this._completeAnimation(element, animationId, startTime);
                
            } catch (error) {
                this.monitoring.errorCount++;
                console.error('[AnimationManager][ERROR] FadeIn animation failed', error);
                throw error;
            }
        });
    }

    // سایر متدهای انیمیشن...
}

// 🛡️ اصل ۱۱: Inter-Module Integrity - Freeze prototype
Object.freeze(AnimationManager.prototype);
Object.freeze(AnimationManager);

export default AnimationManager;