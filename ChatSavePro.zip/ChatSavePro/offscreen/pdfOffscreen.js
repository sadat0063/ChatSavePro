console.log("🔥 [OFFSCREEN] pdfOffscreen.js parsed - FINAL COMPLETE VERSION");

// ============================================
// ✅ FIX CRITICAL: فقط یک listener اصلی - حل تداخل
// ============================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("📨 [OFFSCREEN] Message received:", message?.type);
    
    // مدیریت PING
    if (message?.type === "PING") {
        console.log("🏓 [OFFSCREEN] PING received");
        sendResponse({ 
            success: true, 
            ready: document.readyState === 'complete',
            loading: document.readyState !== 'complete',
            timestamp: Date.now() 
        });
        return true;
    }
    
    // مدیریت GENERATE_PDF
    if (message?.type === "GENERATE_PDF") {
        console.log("[OFFSCREEN] 📥 GENERATE_PDF received", {
            htmlLength: message.html?.length,
            payloadHtmlLength: message.payload?.html?.length,
            hasHtmlContent: !!message.htmlContent,
            hasContent: !!message.content
        });
        
        (async () => {
            try {
                // ✅ FIX: جستجوی HTML در همه مکان‌ها
                let htmlContent = null;
                
                // جستجو در تمام مکان‌های احتمالی
                const searchLocations = [
                    message.html,
                    message.payload?.html,
                    message.htmlContent,
                    message.content,
                    message.payload?.content,
                    message.payload?.htmlContent,
                    message.payload?.data,
                    message.data
                ];
                
                for (const html of searchLocations) {
                    if (html && typeof html === 'string' && html.length > 0) {
                        htmlContent = html;
                        break;
                    }
                }
                
                if (!htmlContent) {
                    throw new Error(`Empty HTML input. Available keys: ${Object.keys(message).join(', ')}`);
                }
                
                console.log(`📊 [OFFSCREEN] HTML validated: ${htmlContent.length} chars`);
                
                // ✅ FIX CRITICAL: استفاده از innerHTML امن
                const root = ensureRootElement();
                root.innerHTML = '';
                
                // استفاده از DOMParser برای sanitization
                const parser = new DOMParser();
                const doc = parser.parseFromString(htmlContent, 'text/html');
                
                // حذف scriptها برای امنیت
                doc.querySelectorAll('script').forEach(script => script.remove());
                
                // Import nodeها به صورت امن
                const fragment = document.createDocumentFragment();
                Array.from(doc.body.children).forEach(child => {
                    try {
                        fragment.appendChild(document.importNode(child, true));
                    } catch (e) {
                        console.warn("⚠️ [OFFSCREEN] Failed to import node:", e.message);
                    }
                });
                
                root.appendChild(fragment);
                
                // ✅ منتظر ماندن برای منابع خارجی
                await waitForExternalResources();
                await waitForRender();
                
                console.log(`✅ [OFFSCREEN] HTML rendered successfully`);
                
                // ✅ تولید PDF با timeout 30 ثانیه
                console.log("[OFFSCREEN] 📄 Calling chrome.printToPDF with 30s timeout...");
                const pdfResult = await generatePDFWithTimeout();
                
                if (!pdfResult?.data) {
                    throw new Error("chrome.printToPDF returned no data");
                }
                
                console.log(`✅ [OFFSCREEN] PDF generated: ${pdfResult.data.byteLength} bytes`);
                
                sendResponse({
                    success: true,
                    data: pdfResult.data,
                    fileName: message.fileName || `export_${Date.now()}.pdf`,
                    fileSize: pdfResult.data.byteLength,
                    format: "pdf",
                    timestamp: Date.now()
                });
                
            } catch (err) {
                console.error("❌ [OFFSCREEN] PDF generation failed:", err);
                sendResponse({ 
                    success: false, 
                    error: err.message,
                    timestamp: Date.now()
                });
            }
        })();
        
        return true; // برای async response
    }
    
    if (message?.type === "OFFSCREEN_READY") {
        console.log("ℹ️ [OFFSCREEN] READY acknowledged");
        return;
    }
    
    sendResponse({ 
        success: false, 
        error: "Unknown message type",
        timestamp: Date.now() 
    });
    return true;
});

// ============================================
// تابع تولید PDF با timeout 30 ثانیه
// ============================================
async function generatePDFWithTimeout() {
    return new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
            reject(new Error('PDF generation timeout after 30 seconds'));
        }, 30000);
        
        chrome.printToPDF({
            landscape: false,
            displayHeaderFooter: false,
            printBackground: true,
            scale: 1,
            paperWidth: 8.27,    // A4 width in inches
            paperHeight: 11.69,  // A4 height in inches
            marginTop: 0.4,
            marginBottom: 0.4,
            marginLeft: 0.4,
            marginRight: 0.4,
            pageRanges: ''
        }, (result) => {
            clearTimeout(timeoutId);
            if (chrome.runtime.lastError) {
                reject(new Error(`PDF generation error: ${chrome.runtime.lastError.message}`));
            } else {
                resolve(result);
            }
        });
    });
}

// ============================================
// تابع کمکی برای ایجاد root element
// ============================================
function ensureRootElement() {
    let root = document.getElementById("root");
    if (!root) {
        root = document.createElement("div");
        root.id = "root";
        document.body.appendChild(root);
        console.log("✅ [OFFSCREEN] Root container created");
    }
    return root;
}

// ============================================
// تابع منتظر ماندن برای منابع خارجی
// ============================================
async function waitForExternalResources() {
    const images = document.querySelectorAll('img[src]');
    const total = images.length;
    
    if (total === 0) {
        return;
    }
    
    console.log(`🖼️ [OFFSCREEN] Waiting for ${total} images to load...`);
    
    return new Promise((resolve) => {
        let loadedCount = 0;
        let hasTimeout = false;
        
        const checkComplete = () => {
            if (loadedCount >= total && !hasTimeout) {
                console.log(`✅ [OFFSCREEN] All images loaded (${loadedCount}/${total})`);
                resolve();
            }
        };
        
        images.forEach(img => {
            if (img.complete) {
                loadedCount++;
                checkComplete();
            } else {
                img.onload = () => {
                    if (!hasTimeout) {
                        loadedCount++;
                        checkComplete();
                    }
                };
                img.onerror = () => {
                    if (!hasTimeout) {
                        loadedCount++;
                        checkComplete();
                    }
                };
            }
        });
        
        // Timeout بعد از 10 ثانیه
        setTimeout(() => {
            hasTimeout = true;
            console.warn(`⚠️ [OFFSCREEN] Images loading timeout (${loadedCount}/${total} loaded)`);
            resolve();
        }, 10000);
    });
}

// ============================================
// تابع کمکی برای انتظار render
// ============================================
function waitForRender() {
    return new Promise(resolve => {
        requestAnimationFrame(() => setTimeout(resolve, 100));
    });
}

// ============================================
// DOMContentLoaded Handler برای setup اولیه
// ============================================
document.addEventListener("DOMContentLoaded", () => {
    console.log("✅ [OFFSCREEN] DOMContentLoaded - Offscreen fully ready");
    
    // ✅ Safe CSS injection
    const style = document.createElement("style");
    style.textContent = `
        body {
            margin: 0;
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            background: white;
        }
        #root {
            width: 100%;
            min-height: 100vh;
            box-sizing: border-box;
        }
        @media print {
            body { 
                padding: 0; 
                margin: 0;
            }
            #root {
                min-height: auto;
            }
        }
    `;
    document.head.appendChild(style);
    
    // ایجاد root element اگر هنوز وجود ندارد
    ensureRootElement();
    
    console.log("✅ [OFFSCREEN] Setup completed, ready for PDF generation");
    
    // اطلاع به runtime که offscreen آماده است
    chrome.runtime.sendMessage({
        type: 'OFFSCREEN_READY',
        payload: { timestamp: Date.now() }
    }, (response) => {
        if (chrome.runtime.lastError) {
            console.log("ℹ️ [OFFSCREEN] Runtime not ready yet:", chrome.runtime.lastError.message);
        } else {
            console.log("✅ [OFFSCREEN] Runtime acknowledged");
        }
    });
});

// ============================================
// Global error handler برای catch کردن خطاهای غیرمنتظره
// ============================================
window.addEventListener('error', (event) => {
    console.error("💥 [OFFSCREEN] Global error:", event.error);
    
    try {
        chrome.runtime.sendMessage({
            type: 'OFFSCREEN_ERROR',
            payload: {
                error: event.error?.message || 'Unknown error',
                timestamp: Date.now()
            }
        });
    } catch (sendError) {
        console.error("Failed to send error to runtime:", sendError);
    }
});

// ============================================
// Log برای اطلاع از load شدن فایل
// ============================================
console.log("🚀 [OFFSCREEN] pdfOffscreen.js loaded successfully - READY FOR PDF GENERATION");