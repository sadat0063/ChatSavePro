// PDF Generator v1 – Free / Simple (Robust Version)
// Scope: text-only, large content safe, MV3 Offscreen compatible

(async () => {
  // ---- jsPDF loader (safe) ----
  async function ensureJsPDF() {
    if (window.jspdf && window.jspdf.jsPDF) return true;

    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("libs/jspdf.umd.min.js");
      script.onload = () => {
        if (window.jspdf && window.jspdf.jsPDF) {
          console.log("[PDF v1 Offscreen] jsPDF loaded successfully");
          resolve(true);
        } else {
          reject(new Error("jsPDF namespace not found"));
        }
      };
      script.onerror = () => reject(new Error("Failed to load jsPDF script"));
      document.head.appendChild(script);
    });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.type !== "GENERATE_PDF_V1") return;

    (async () => {
      try {
        await ensureJsPDF();

        const payload = message.payload || {};
        const rawContent = payload.content;

        if (typeof rawContent !== "string" || !rawContent.trim()) {
          sendResponse({
            success: false,
            error: "INVALID_CONTENT"
          });
          return;
        }

        const title = payload.title || "ChatSavePro Export";

        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
          unit: "mm",
          format: "a4"
        });

        pdf.setFont("Times", "Normal");
        pdf.setFontSize(12);

        // ---- HTML → Text sanitize ----
        const cleanText = rawContent
          .replace(/<br\s*\/?>/gi, "\n")
          .replace(/<\/p>/gi, "\n\n")
          .replace(/<li>/gi, "• ")
          .replace(/<\/li>/gi, "\n")
          .replace(/<[^>]+>/g, "")
          .replace(/\n{3,}/g, "\n\n");

        const pageWidth = 180;
        const startY = 20;
        const lineHeight = 7;
        const pageHeight = 277;

        const lines = pdf.splitTextToSize(cleanText, pageWidth);

        let y = startY;

        for (let i = 0; i < lines.length; i++) {
          if (y > pageHeight) {
            pdf.addPage();
            y = startY;
          }
          pdf.text(lines[i], 15, y);
          y += lineHeight;
        }

        const buffer = pdf.output("arraybuffer");

        sendResponse({
          success: true,
          buffer
        });

        console.log("[PDF v1 Offscreen] PDF generated successfully", {
          pages: pdf.getNumberOfPages(),
          size: buffer.byteLength
        });

      } catch (error) {
        console.error("[PDF v1 Offscreen] Fatal error:", error);

        sendResponse({
          success: false,
          error: error.message || "PDF_V1_GENERATION_FAILED"
        });
      }
    })();

    return true; // async
  });
})();
