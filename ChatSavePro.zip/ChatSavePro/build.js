const esbuild = require("esbuild");
const fs = require("fs");
const path = require("path");

const rootDir = __dirname;
const distDir = path.join(rootDir, "dist");
const modulesSrc = path.join(rootDir, "modules");
const modulesDist = path.join(distDir, "modules");
const sharedSrc = path.join(rootDir, "shared");
const sharedDist = path.join(distDir, "shared");
/* ✅ مسیر جدید برای PDF assets */
const pdfSrc = path.join(rootDir, "pdf");
const pdfDist = path.join(distDir, "pdf");

/* ✅ مسیر درست offscreen (در ریشه افزونه) */
const offscreenSrc = path.join(rootDir, "offscreen");
const offscreenDist = path.join(distDir, "offscreen");

/* -------------------------------------------------------------
   Utility: Recursive copy (✔ fixes EPERM)
--------------------------------------------------------------*/
function copyDirRecursive(src, dst) {
    fs.mkdirSync(dst, { recursive: true });

    for (const entry of fs.readdirSync(src)) {
        const s = path.join(src, entry);
        const d = path.join(dst, entry);

        if (fs.lstatSync(s).isDirectory()) {
            copyDirRecursive(s, d);
        } else {
            fs.copyFileSync(s, d);
        }
    }
}

/* -------------------------------------------------------------
   1) پاکسازی dist
--------------------------------------------------------------*/
if (fs.existsSync(distDir)) {
    fs.rmSync(distDir, { recursive: true, force: true });
}
fs.mkdirSync(distDir, { recursive: true });

/* -------------------------------------------------------------
   2) کپی فایل‌های استاتیک (✔ recursive واقعی)
--------------------------------------------------------------*/
const staticItems = [
    "icons",
    "icontheme",
    "lib",
    "content-style.css",
    "manifest.json"
];

for (const item of staticItems) {
    const src = path.join(rootDir, item);
    const dest = path.join(distDir, item);

    if (!fs.existsSync(src)) continue;

    if (fs.lstatSync(src).isDirectory()) {
        copyDirRecursive(src, dest);
    } else {
        fs.copyFileSync(src, dest);
    }
}

/* -------------------------------------------------------------
   Utility: Bundle helper
--------------------------------------------------------------*/
function bundle(entry, out, config = {}) {
    esbuild.buildSync({
        entryPoints: [entry],
        outfile: out,
        bundle: true,
        format: config.format || "iife",
        globalName: config.globalName,
        platform: "browser",
        target: ["chrome120"],
        minify: !!config.minify,
        sourcemap: false
    });
}

/* -------------------------------------------------------------
   3) background.js
--------------------------------------------------------------*/
bundle(
    path.join(rootDir, "background.js"),
    path.join(distDir, "background.js"),
    { format: "cjs", minify: false }
);

/* -------------------------------------------------------------
   4) contentScript.js (RAW)
--------------------------------------------------------------*/
fs.copyFileSync(
    path.join(rootDir, "contentScript.js"),
    path.join(distDir, "contentScript.js")
);

/* -------------------------------------------------------------
   5) guardian (RAW)
--------------------------------------------------------------*/
const guardianSrc = path.join(rootDir, "contentScript.guardian.js");
const guardianDist = path.join(distDir, "contentScript.guardian.js");

if (fs.existsSync(guardianSrc)) {
    fs.copyFileSync(guardianSrc, guardianDist);
}

/* -------------------------------------------------------------
   6) Popup
--------------------------------------------------------------*/
const popupSrc = path.join(rootDir, "popup");
const popupDist = path.join(distDir, "popup");

fs.mkdirSync(popupDist, { recursive: true });
fs.copyFileSync(path.join(popupSrc, "popup.html"), path.join(popupDist, "popup.html"));
fs.copyFileSync(path.join(popupSrc, "popup.css"), path.join(popupDist, "popup.css"));

bundle(
    path.join(popupSrc, "popup.js"),
    path.join(popupDist, "popup.js"),
    { globalName: "PopupBundle", minify: true }
);

/* -------------------------------------------------------------
   7) shared/ (RAW)
--------------------------------------------------------------*/
if (fs.existsSync(sharedSrc)) {
    copyDirRecursive(sharedSrc, sharedDist);
}

/* -------------------------------------------------------------
   8) RAW modules
--------------------------------------------------------------*/
fs.mkdirSync(modulesDist, { recursive: true });

function copyModulesRec(src, dst) {
    for (const entry of fs.readdirSync(src)) {
        const s = path.join(src, entry);
        const d = path.join(dst, entry);

        if (fs.lstatSync(s).isDirectory()) {
            fs.mkdirSync(d, { recursive: true });
            copyModulesRec(s, d);
        } else if (entry.endsWith(".js")) {
            fs.copyFileSync(s, d);
        }
    }
}

copyModulesRec(modulesSrc, modulesDist);

/* -------------------------------------------------------------
   ✅ 9) Offscreen (ریشه صحیح) - FIXED VERSION
--------------------------------------------------------------*/
if (fs.existsSync(offscreenSrc)) {
    // استفاده از تابع copyDirRecursive برای کپی کامل پوشه
    copyDirRecursive(offscreenSrc, offscreenDist);
    console.log("✅ offscreen/ folder copied recursively");
} else {
    console.warn("⚠️ offscreen not found — PDF will fail");
}

/* -------------------------------------------------------------
   ✅ 10) PDF Assets (افزوده شد)
--------------------------------------------------------------*/
if (fs.existsSync(pdfSrc)) {
    copyDirRecursive(pdfSrc, pdfDist);
    console.log("✅ pdf/ assets copied");
}

/* -------------------------------------------------------------
   11) ModuleBridge.bundle.js
--------------------------------------------------------------*/
const moduleBridgeSrc = path.join(modulesSrc, "ModuleBridge.js");
const moduleBridgeOut = path.join(modulesDist, "ModuleBridge.bundle.js");

if (fs.existsSync(moduleBridgeSrc)) {
    bundle(moduleBridgeSrc, moduleBridgeOut, {
        globalName: "ModuleBridge",
        format: "iife",
        minify: true
    });
}

console.log(`
📂 DIST READY
✅ OFFSCREEN ROOT PATH FIXED (RECURSIVE COPY)
✅ PDF ASSETS COPIED
🎉 BUILD DONE — REAL PDF ENABLED
`);